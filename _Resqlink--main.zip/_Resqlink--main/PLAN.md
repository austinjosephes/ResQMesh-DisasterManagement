# ResQMesh Trust — Architectural Implementation Plan

## 1. Current Repository Condition
- **Workspace:** `D:\ResQLink` (clean slate initialization)
- **Node.js:** v24.21.0
- **Package Manager:** pnpm workspaces
- **Target Architecture:** Monorepo (`apps/web`, `packages/verifier`, `packages/shared`, `prisma`)

## 2. Core Security & Product Philosophy
**"Calm authority under pressure."**
ResQMesh Trust provides offline-verifiable, digitally signed, device-bound responder credentials for disaster response personnel.

### The Four Decoupled Decisions:
1. **Authenticity:** Is the credential structurally valid and cryptographically signed (ES256) by a trusted issuer in the active trust bundle?
2. **Device Possession:** Can the responder prove possession of the private key bound to the credential (`cnf` thumbprint) via challenge-response?
3. **Authorization:** Does the responder's role, permissions, incident scope, and lifecycle state permit the requested action?
4. **Freshness:** Is the cached revocation status snapshot sufficiently fresh for the requested action's risk tier according to offline policy?

## 3. Architecture & Trust Boundaries
```
+-------------------------------------------------------------+
|                     Trust Boundaries                        |
|                                                             |
|  [ Issuer / Admin ]        [ Responder Device ]             |
|   - Server-side ES256 keys  - Client-side WebCrypto P-256   |
|   - Argon2id Sessions       - Non-extractable CryptoKey     |
|   - Audit Log Hash Chain    - IndexedDB storage             |
|            |                         |                      |
|            +-----------> [ QR / NFC / File ] <------+       |
|                                                     |       |
|                                            [ Offline Verifier ]
|                                             - Shared Engine
|                                             - Injected Clock
|                                             - Cached Trust Bundle
|                                             - Monotonic Revocation
|                                             - Local Event Storage
+-------------------------------------------------------------+
```

## 4. Subsystem Breakdown & Preservation Assessment
- **Monorepo & Package Structure:** Initializing clean pnpm workspace (`apps/web`, `packages/verifier`, `packages/shared`).
- **Cryptographic Engine:** Shared TypeScript package (`packages/verifier`) implementing RFC 7515 compact JWS, RFC 7638 JWK thumbprints, Web Crypto P-256 device binding, replay-protected challenge-response, monotonic trust bundles, and configurable risk tiers.
- **Backend & Database:** Next.js App Router API handlers with PostgreSQL + Prisma ORM (and SQLite fallback for local zero-dependency run), structured Zod validation, HttpOnly sessions, RBAC, tamper-evident SHA-256 hash-chained audit logging, and transactional synchronization.
- **Frontend & Workspaces:**
  - **Shared App Shell:** Global connectivity banner (Online / Offline Detected / Offline Simulated), synchronization health, command palette (`cmdk`), accessible navigation.
  - **Verifier Workspace (`/verifier`):** 3-panel layout (Input, Subject/Action, Diagnostics) with genuine offline verification, camera QR scanning, JSON vector testing.
  - **Responder Workspace (`/responder`):** Credential card, non-extractable device key enrollment, challenge signing, offline action log, sync queue.
  - **Admin Command Dashboard (`/admin`):** Responder management, credential issuance/suspension/revocation, role-permission matrix, audit chain verification, synchronization conflict resolution queue.
  - **Security Lab (`/security-lab`):** 20+ interactive attack scenarios running the actual verifier against tampering, replay, clock skew, stale status, forged roots, and expired challenges.
  - **Cinematic 3D Landing Page (`/`):** React Three Fiber + Drei procedural globe, scroll-driven storytelling (The Severed Network, The Credential, Offline Verification, Authority, Final CTA), strict performance tiering, full reduced-motion accessibility.

## 5. Phased Implementation Roadmap
- **Phase 0:** Repository audit & documentation (PLAN, PROGRESS, Architecture, Threat Model, etc.)
- **Phase 1:** Monorepo setup, dependencies, design tokens, shared types (`packages/shared`)
- **Phase 2:** Cryptographic core & shared verifier (`packages/verifier`) with unit test vectors
- **Phase 3:** Backend routes, database schema, session auth, audit chain, synchronization handlers
- **Phase 4:** Verifier workspace (genuine offline engine, diagnostics, vector import)
- **Phase 5:** Responder workspace (Web Crypto enrollment, challenge signing, offline event recording)
- **Phase 6:** Admin Command workspace (issuance, lifecycle transitions, audit verification, sync review)
- **Phase 7:** Interactive Security Lab (20+ live test scenarios)
- **Phase 8:** Cinematic 3D landing page with Three.js / R3F / Lucide / Tailwind
- **Phase 9:** Verification, automated tests, truthfulness audit, demo script, and launch
