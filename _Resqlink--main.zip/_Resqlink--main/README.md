# ResQLink Kerala — Predict, Reach, Rescue
### AI-Assisted Disaster Early Warning, Resident Risk Intelligence & Rescue Coordination Platform

> **Live Production Deployments**:
> - 🌐 **Citizen Safety Portal**: [https://resqlink-citizen-portal.vercel.app](https://resqlink-citizen-portal.vercel.app)
> - 🛡️ **SEOC Admin Command Operations**: [https://resqlink-admin-command.vercel.app](https://resqlink-admin-command.vercel.app)
> - 📦 **GitHub Repository**: [https://github.com/jenitjenson45-debug/_Resqlink-](https://github.com/jenitjenson45-debug/_Resqlink-)

> **Kerala State Disaster Management Authority (KSDMA) Aligned Platform**  
> An integrated, full-stack disaster management and rescue coordination system connecting official IMD/KSDMA hazard warning polygons, localized resident risk twins, Indian Telecom DLT-compliant alert dissemination, transparent multi-factor rescue priority scoring, and network-loss survival operation.

---

## 1. System Overview & The 4 Core Capabilities

ResQLink Kerala operates along a synchronized disaster-response pipeline:
`Official Hazard Warning → Validate Warning → Ray-Casting Exposure Match → DLT SMS Notification → Resident SOS Intake → Transparent Priority Scoring → Rescue Team Dispatch → Status Tracking`.

```
           +---------------------------------------------+
           |       Official Warnings (IMD / KSDMA)       |
           |      GeoJSON Hazard Polygons (Red/Orange)   |
           +----------------------+----------------------+
                                  |
                                  v
+-----------------------------------------------------------------+
|               Resident Risk Digital Twin Engine                 |
|   • Ray-Casting Point-in-Polygon Exposure Matching              |
|   • Vulnerability Profiling (Elderly, Infants, Oxygen, Mobility)|
+------------------+------------------------------+---------------+
                   |                              |
                   v                              v
+-------------------------------------+   +-------------------------------+
| Adaptive Alert Delivery (DLT SMS)   |   | Network-Loss Survival Mode    |
| • English & Malayalam (മലയാളം)      |   | • Offline ServiceWorker Cache |
| • Telecom DLT Format Compliance     |   | • IndexedDB SOS Outbox        |
| • Retry with Bounded Backoff        |   | • Virtual Peer Mesh Relay     |
| • Truth-in-UX Delivery Tracking     |   | • Truth-in-UX Status Badges   |
+-------------------------------------+   +---------------+---------------+
                                                          |
                                                          v
                                  +-------------------------------+
                                  |     Rescue Priority Engine    |
                                  |  • Threat (0-35)              |
                                  |  • Trapped/Injured (0-25)     |
                                  |  • Wait Time (0-20)           |
                                  |  • Location Confidence (0-10) |
                                  |  • Vulnerability Index (0-10) |
                                  |  • Human Coordinator Override |
                                  +---------------+---------------+
                                                  |
                                                  v
                                  +-------------------------------+
                                  | Rescue Operator Coordination  |
                                  |  • NDRF Alpha, Fire & Rescue  |
                                  |  • Kerala Coastal Volunteers  |
                                  |  • Relief Shelter Allocation  |
                                  +-------------------------------+
```

### 1. Resident Risk Digital Twin
- **Geospatial Ray-Casting Point-in-Polygon Engine** (`apps/web/lib/geospatial.ts`): Automatically matches registered households across all 14 Kerala districts against active IMD/KSDMA hazard warning polygons.
- **Special Vulnerability Profiling**: Tracks elderly residents, infants, wheelchair-bound persons, and continuous medical/oxygen dependencies.
- **Calculated Exposure Metrics**: Immediate counts of exposed households, individuals, and high-risk medical dependencies per district.

### 2. Adaptive Alert Delivery Intelligence
- **DLT Telecom Template Formatting** (`apps/web/lib/sms-adapter.ts`): Bilingual SMS messages in **English** and **Malayalam (മലയാളം)** complying with Indian Telecom DLT entity guidelines (`KSDMA-GOVKER`).
- **Strict Truth-in-UX Status Progression**: Clearly distinguishes states: `QUEUED` -> `SUBMITTED` -> `DELIVERED` (only with carrier ACK) -> `FAILED` -> `ACKNOWLEDGED` (by resident).
- **Bounded Exponential Backoff Retry**: Automatic delivery retry calculation avoiding carrier congestion.

### 3. Rescue Priority Engine
- **Transparent Multi-Factor Urgent Scoring Formula** (`apps/web/lib/priority-engine.ts`):
  $$\text{Priority Score} = \text{Threat (0-35)} + \text{Trapped/Injured (0-25)} + \text{Wait Time (0-20)} + \text{Location Confidence (0-10)} + \text{Vulnerability (0-10)}$$
- **Urgency Buckets**: `CRITICAL` (80-100), `HIGH` (60-79), `MODERATE` (35-59), `LOW` (0-34), and `NEEDS_VERIFICATION` (when GPS accuracy > 500m or unconfirmed address).
- **Auditable Coordinator Overrides**: Human dispatchers can override scores with mandatory recorded justification stored in the immutable audit trail.

### 4. Network-Loss Survival Mode
- **Zero-Network SOS Queuing**: When cellular signals drop, SOS requests persist in IndexedDB (`sos_offline_<uuid>`) with cryptographic UUID idempotency keys.
- **Service Worker Cache**: Offline access to Kerala emergency safety guides for Flash Floods, Landslides, Coastal Storm Surges, and First Aid.
- **Truthful Labeling**: Explicit "SIMULATED PEER RELAY (PROTOTYPE)" badge — never claiming live satellite or hardware connectivity when disconnected.

---

## 2. Seed Accounts & Roles

The system is pre-seeded with 6 functional personas. Use password **`ResQLink@2026!`** for all accounts:

| Persona | Role | Email | Password | Primary Route |
|---|---|---|---|---|
| **Dr. Radhika Menon** | System Admin | `admin@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/admin/dashboard` |
| **Suresh Kumar** | State Disaster Officer | `officer@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/admin/live-map` |
| **Ananya Varma** | District Coordinator | `coordinator@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/admin/residents` |
| **Sub-Inspector Arun Pillai** | Rescue Team Operator | `responder@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/rescue/dashboard` |
| **Adv. Joseph Matthew** | Citizen Resident | `citizen@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/resident/dashboard` |
| **Pradeep Nambiar** | Compliance Auditor | `auditor@resqlink.kerala.gov.in` | `ResQLink@2026!` | `/admin/audit-logs` |

---

## 3. Complete Route Architecture

### Public Routes
- `/` — Landing page with Kerala hazard map preview, problem statement, architecture, and live stats.
- `/how-it-works` — Deep dive into the 4 core pillars and operational workflow.
- `/safety` — Multilingual Kerala disaster safety guides (Floods, Landslides, Storms, First Aid).
- `/login` — Unified role-based login with quick demo persona selection.
- `/register` — Resident registration with district, local body, ward, coordinates, and medical assistance flags.
- `/privacy` — Responsible data handling, consent management, and location privacy explanation.

### Resident Portal (`/resident`)
- `/resident/dashboard` — Live district risk status, active hazard polygons, emergency SOS shortcut.
- `/resident/alerts` — Real-time warning history, DLT SMS status, and acknowledgment buttons.
- `/resident/locations` — Registered household coordinates, safe zones, and nearest relief shelters.
- `/resident/request-help` — Interactive SOS dispatch form with real-time transparent priority score calculator and offline survival queuing.
- `/resident/requests` — SOS ticket lifecycle tracker (`QUEUED_LOCAL` -> `VERIFIED` -> `ASSIGNED` -> `ON_SCENE` -> `RESOLVED`).
- `/resident/profile` — Household members, vulnerability flags (elderly, infants, oxygen, wheelchair).
- `/resident/settings` — Bilingual toggle (English / മലയാളം), high contrast mode, and cache purge.

### Incident Command Administration (`/admin`)
- `/admin/dashboard` — High-level situation room metrics (Active warnings, exposed residents, unassigned SOS).
- `/admin/live-map` — Tactical Kerala map with 14 districts, hazard warning polygons, household pins, SOS beacons, rescue units, and shelters.
- `/admin/residents` — Resident Risk Digital Twin registry with polygon containment filters.
- `/admin/alerts` — Hazard warning ingestion, polygon geometry inspector, and DLT SMS broadcast trigger.
- `/admin/notifications` — SMS transmission status tracker (`QUEUED`, `SUBMITTED`, `DELIVERED`, `ACKNOWLEDGED`).
- `/admin/incidents` — SOS Incident triage table with priority engine breakdown scores and team assignment dialog.
- `/admin/rescue-teams` — Field team roster (NDRF 04 Bn Alpha, Kerala Fire & Rescue, Coastal Fishermen Volunteers).
- `/admin/shelters` — Relief camp directory with live occupancy and capacity indicators.
- `/admin/analytics` — Geospatial and operational response metrics.
- `/admin/audit-logs` — Immutable SHA-256 tamper-evident log chain of all administrative decisions.
- `/admin/settings` — Disaster threshold configuration and DLT provider settings.

### Rescue Operator Workspace (`/rescue`)
- `/rescue/dashboard` — Unit dispatch cockpit, active assignments, and navigation shortcuts.
- `/rescue/assignments` — Triage queue with live status transitions (`ASSIGNED` -> `ACKNOWLEDGED` -> `ON_SCENE` -> `RESOLVED`).
- `/rescue/incidents/[id]` — Operational incident detail, household vulnerability details, and field notes logger.

---

## 4. Local Setup & Execution

### Prerequisites
- Node.js v20+ or v24+
- pnpm v9+

### Commands

```bash
# 1. Install dependencies
pnpm install

# 2. Push Prisma database schema
pnpm exec prisma db push

# 3. Seed Kerala demonstration data
node --experimental-strip-types apps/web/seed.ts

# 4. Run automated test suites (32 unit & integration tests)
pnpm test

# 5. Typecheck the codebase
pnpm typecheck

# 6. Launch the development server
pnpm dev
# Server runs on: http://localhost:3000
```

---

## 5. Automated Test Coverage

The project includes 32 passing tests verifying all critical algorithms and security invariants:

```
 ✓ packages/verifier/tests/auth-security.test.ts (2 tests)
 ✓ packages/verifier/tests/sos.test.ts (5 tests)
 ✓ packages/verifier/tests/geospatial.test.ts (4 tests)
   • isPointInPolygon inside polygon
   • isPointInPolygon outside polygon
   • haversineDistanceKm calculation
   • checkHazardExposure polygon matching
 ✓ packages/verifier/tests/priority-engine.test.ts (3 tests)
   • Transparent scoring calculation & threshold
   • Vulnerability & wait time weighting
   • Low-confidence verification flagging
 ✓ packages/verifier/tests/sms-adapter.test.ts (4 tests)
   • English DLT message formatting
   • Malayalam (മലയാളം) DLT message formatting
   • Delivery state progression
   • Bounded exponential retry backoff
 ✓ packages/verifier/tests/verifier.test.ts (11 tests)
 ✓ packages/verifier/tests/mesh.test.ts (3 tests)

Test Files: 7 passed (7)
Tests:      32 passed (32)
```

---

## 6. Truthfulness in UX Standard

1. **SMS Dissemination**: Never displays fake "Delivered" badges without carrier delivery receipts; defaults to `SUBMITTED` until simulation ACK arrives.
2. **Offline Operations**: Clearly marks un-synced events with `OFFLINE_LOCAL` and displays unambiguous "SIMULATED PEER RELAY" notices for experimental transport layers.
3. **Emergency Priority**: Shows exact formula score breakdowns to coordinators to prevent unexplainable "black box" algorithmic bias.
4. **Warnings vs. Dispatches**: Official hazard alerts remain distinct from confirmed rescue incidents to prevent panic-driven premature dispatches.
