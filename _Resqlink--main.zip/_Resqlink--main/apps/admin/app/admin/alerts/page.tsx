'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Bell,
  ShieldAlert,
  Plus,
  RefreshCw,
  Clock,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Send,
  MapPin,
  ShieldCheck,
  X,
  Radio,
  Sliders,
  Check,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function AdminAlertsPage() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [showIngestModal, setShowIngestModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Form state for manual alert ingestion
  const [district, setDistrict] = useState('Wayanad');
  const [hazardType, setHazardType] = useState('LANDSLIDE');
  const [severity, setSeverity] = useState('EMERGENCY');
  const [source, setSource] = useState('KSDMA_IMD_RADAR');
  const [headline, setHeadline] = useState('RED ALERT: Critical Slope Instability & Flash Floods');
  const [description, setDescription] = useState('Rainfall exceeding 250mm recorded in 24 hours. River stages rising rapidly.');
  const [instruction, setInstruction] = useState('Immediate evacuation to designated higher ground shelters.');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ingestMsg, setIngestMsg] = useState('');

  const fetchAlerts = () => {
    setIsLoading(true);
    fetch('/api/alerts')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.alerts) setAlerts(data.alerts);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const handleIngest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setIngestMsg('');

    const distInfo = KERALA_DISTRICTS.find((d) => d.name === district) || KERALA_DISTRICTS[2];
    const center = distInfo.center;
    const defaultPolygon = JSON.stringify({
      type: 'Polygon',
      coordinates: [
        [
          [Number((center.lng - 0.04).toFixed(4)), Number((center.lat - 0.04).toFixed(4))],
          [Number((center.lng + 0.04).toFixed(4)), Number((center.lat - 0.04).toFixed(4))],
          [Number((center.lng + 0.04).toFixed(4)), Number((center.lat + 0.04).toFixed(4))],
          [Number((center.lng - 0.04).toFixed(4)), Number((center.lat + 0.04).toFixed(4))],
          [Number((center.lng - 0.04).toFixed(4)), Number((center.lat - 0.04).toFixed(4))],
        ],
      ],
    });

    try {
      const res = await fetch('/api/integrations/alerts/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source,
          hazardType,
          severity,
          headline,
          description,
          instruction,
          affectedDistrict: district,
          polygonGeoJson: defaultPolygon,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setIngestMsg(`Alert ingested! Matched ${data.exposureAnalysis?.matchedExposedHouseholds || 0} exposed households & dispatched SMS.`);
        setShowIngestModal(false);
        fetchAlerts();
      }
    } catch (e) {
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
              <Bell className="w-3.5 h-3.5 text-[#FF6B35]" />
              <span>ALERT MANAGEMENT SYSTEM &bull; SEOC KERALA</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA]">
              Official Warning Ingestion &amp; Versions
            </h1>
            <p className="text-xs text-[#929CAB] font-mono">
              Ingests CAP v1.2 hazard polygons and triggers batch DLT SMS broadcasts to matched households.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={fetchAlerts}
              disabled={isLoading}
              className="p-2.5 rounded-xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#FF6B35]' : ''}`} />
            </button>

            <button
              onClick={() => setShowIngestModal(true)}
              className="px-4 py-2.5 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold text-xs uppercase font-mono tracking-wider transition shadow-md shadow-[#FF6B35]/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Ingest New Warning</span>
            </button>
          </div>
        </div>

        {ingestMsg && (
          <div className="p-4 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/30 flex items-center gap-2 text-xs text-[#22C55E] font-mono">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{ingestMsg}</span>
          </div>
        )}

        {/* Alerts Stream */}
        <div className="space-y-4">
          {alerts.map((alert) => {
            const isRed = alert.severity === 'EMERGENCY' || alert.severity === 'CRITICAL';
            const isOrange = alert.severity === 'WARNING';

            return (
              <div
                key={alert.id}
                className="p-6 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-4 shadow-xl relative overflow-hidden"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[rgba(255,255,255,0.06)] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full ${
                        isRed
                          ? 'bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]'
                          : isOrange
                          ? 'bg-[#FF6B35]/15 border border-[#FF6B35]/30 text-[#FF6B35]'
                          : 'bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623]'
                      }`}
                    >
                      {alert.severity} • {alert.hazardType}
                    </span>

                    <span className="text-xs font-mono text-[#929CAB] flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#FF6B35]" />
                      <span>{alert.affectedDistrict || 'Kerala'} Sector</span>
                    </span>

                    <span className="text-xs font-mono text-[#6F7C93]">
                      &bull; Source: {alert.source}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs font-mono text-[#6F7C93]">
                    <span className="px-2 py-0.5 rounded bg-[#151E29] text-[#22C55E] flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Signed JOSE ES256</span>
                    </span>
                    <span>Version: v{alert.version}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="text-base font-bold text-[#F5F7FA]">{alert.headline}</h3>
                  <p className="text-xs text-[#929CAB] leading-relaxed">{alert.description}</p>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] text-xs space-y-1">
                  <span className="text-[10px] font-mono text-[#F5A623] font-bold uppercase tracking-wider">
                    OFFICIAL ACTION DIRECTIVE:
                  </span>
                  <p className="text-[#F5F7FA]">{alert.instruction}</p>
                </div>

                {/* Ingestion & Notification Jobs Telemetry */}
                {alert.notificationJobs && alert.notificationJobs.length > 0 && (
                  <div className="p-3 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] text-[11px] font-mono flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[#929CAB]">
                      <Send className="w-3.5 h-3.5 text-[#38BDF8]" />
                      <span>
                        Notification Pipeline: {alert.notificationJobs[0].totalMatched} Households Matched
                      </span>
                    </div>
                    <span className="text-[#22C55E] font-bold">
                      {alert.notificationJobs[0].successfulCount} Delivered via Carrier DLT
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Ingest Warning Modal */}
        {showIngestModal && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-[#101720] border border-[rgba(255,255,255,0.12)] rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-[#FF6B35]" />
                  <h3 className="text-base font-bold text-[#F5F7FA]">Ingest Disaster Hazard Warning</h3>
                </div>
                <button onClick={() => setShowIngestModal(false)} className="text-[#6F7C93] hover:text-[#F5F7FA]">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleIngest} className="space-y-4 text-xs font-mono">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Target District:</label>
                    <select
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                    >
                      {KERALA_DISTRICTS.map((d) => (
                        <option key={d.id} value={d.name}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Hazard Type:</label>
                    <select
                      value={hazardType}
                      onChange={(e) => setHazardType(e.target.value)}
                      className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                    >
                      <option value="LANDSLIDE">LANDSLIDE</option>
                      <option value="FLOOD">FLOOD</option>
                      <option value="HEAVY_RAIN">HEAVY_RAIN</option>
                      <option value="COASTAL_EROSION">COASTAL_EROSION</option>
                      <option value="DAM_DISCHARGE">DAM_DISCHARGE</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Severity:</label>
                    <select
                      value={severity}
                      onChange={(e) => setSeverity(e.target.value)}
                      className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                    >
                      <option value="EMERGENCY">EMERGENCY (Critical Red)</option>
                      <option value="WARNING">WARNING (High Orange)</option>
                      <option value="WATCH">WATCH (Amber)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Authority Source:</label>
                    <input
                      type="text"
                      value={source}
                      onChange={(e) => setSource(e.target.value)}
                      className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[#929CAB]">Headline:</label>
                  <input
                    type="text"
                    required
                    value={headline}
                    onChange={(e) => setHeadline(e.target.value)}
                    className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#929CAB]">Situation Description:</label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#929CAB]">Public Safety Instructions:</label>
                  <textarea
                    rows={2}
                    value={instruction}
                    onChange={(e) => setInstruction(e.target.value)}
                    className="w-full bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl p-2.5 text-[#F5F7FA]"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowIngestModal(false)}
                    className="px-4 py-2 rounded-xl bg-[#0B1017] text-[#929CAB] hover:text-[#F5F7FA]"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>Ingest &amp; Broadcast</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
