'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Activity,
  Bell,
  Radio,
  LifeBuoy,
  RefreshCw,
  BarChart3,
  PieChart,
  ShieldAlert,
} from 'lucide-react';

export default function AdminAnalyticsPage() {
  const [analytics, setAnalytics] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAnalytics = () => {
    setIsLoading(true);
    fetch('/api/admin/analytics')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) setAnalytics(data);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const alertsByCategory = analytics?.alertsByCategory || [];
  const incidentsByDistrict = analytics?.incidentsByDistrict || [];
  const deliveryFunnel = analytics?.deliveryFunnel || [];
  const statusBreakdown = analytics?.statusBreakdown || [];

  const maxDistrictCount = Math.max(1, ...incidentsByDistrict.map((d: any) => d.count));

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-primary" />
            <span>Operational Intelligence</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Disaster Operations &amp; Delivery Analytics
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            Telemetry metrics across meteorological alerts, SMS delivery funnels, and district response loads.
          </p>
        </div>

        <button
          onClick={fetchAnalytics}
          disabled={isLoading}
          className="px-3 py-2 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-secondary hover:text-text-primary flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-primary' : ''}`} />
          <span>Refresh Metrics</span>
        </button>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Chart 1: Alerts by Hazard Category */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-surface-3 pb-3">
            <h3 className="text-xs font-mono font-bold text-text-primary uppercase flex items-center gap-2">
              <Bell className="w-4 h-4 text-primary" />
              <span>Active Warnings by Hazard Type</span>
            </h3>
            <span className="text-[10px] font-mono text-text-muted">KSDMA / IMD</span>
          </div>

          <div className="space-y-3 pt-2">
            {alertsByCategory.map((item: any) => (
              <div key={item.category} className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-text-secondary">{item.category}</span>
                  <span className="font-bold text-text-primary">{item.count} Active</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${Math.min(100, item.count * 30)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Notification Delivery Funnel */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-surface-3 pb-3">
            <h3 className="text-xs font-mono font-bold text-text-primary uppercase flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-400" />
              <span>SMS Delivery Verification Funnel</span>
            </h3>
            <span className="text-[10px] font-mono text-text-muted">TRAI DLT</span>
          </div>

          <div className="space-y-3 pt-2">
            {deliveryFunnel.map((item: any) => (
              <div key={item.status} className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-text-secondary">{item.status}</span>
                  <span className="font-bold text-text-primary">{item.count} SMS</span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      item.status.includes('Blackouts') ? 'bg-red-500' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, (item.count / 30) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 3: Incidents by Kerala District */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4 shadow-lg md:col-span-2">
          <div className="flex items-center justify-between border-b border-surface-3 pb-3">
            <h3 className="text-xs font-mono font-bold text-text-primary uppercase flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-red-400" />
              <span>SOS Emergency Incident Density Across All 14 Districts</span>
            </h3>
            <span className="text-[10px] font-mono text-text-muted">Live Queue</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-7 gap-3 pt-2">
            {incidentsByDistrict.map((d: any) => {
              const heightPct = Math.round((d.count / maxDistrictCount) * 100);

              return (
                <div
                  key={d.district}
                  className="p-3 rounded-lg bg-surface-2 border border-surface-3 flex flex-col justify-between space-y-2 text-center"
                >
                  <p className="text-[10px] font-mono text-text-muted truncate">{d.district}</p>
                  <div className="h-16 flex items-end justify-center">
                    <div
                      className={`w-5 rounded-t transition-all ${
                        d.count > 0 ? 'bg-red-500' : 'bg-surface-3'
                      }`}
                      style={{ height: `${Math.max(12, heightPct)}%` }}
                    />
                  </div>
                  <p className="text-xs font-mono font-bold text-text-primary">{d.count}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
