'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  FileCheck2,
  ShieldCheck,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Lock,
  GitCommit,
} from 'lucide-react';

export default function AdminAuditLogsPage() {
  const [logs, setAuditLogs] = useState<any[]>([]);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchLogs = () => {
    setIsLoading(true);
    fetch('/api/audit/logs')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.logs) setAuditLogs(data.logs);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleVerifyChain = async () => {
    setIsVerifying(true);
    try {
      const res = await fetch('/api/audit/verify-chain', { method: 'POST' });
      const data = await res.json();
      setVerificationResult(data);
    } catch (e) {
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-emerald-400 font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Cryptographic Non-Repudiation</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Tamper-Evident SHA-256 Audit Log Chain
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            Every dispatch action, priority override, and warning publication is sequentially cryptographically chained.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleVerifyChain}
            disabled={isVerifying}
            className="px-4 py-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 transition text-xs font-mono font-bold flex items-center gap-1.5"
          >
            <GitCommit className="w-3.5 h-3.5" />
            <span>{isVerifying ? 'Evaluating Hashes...' : 'Verify Entire Chain'}</span>
          </button>
        </div>
      </div>

      {/* Verification Result Banner */}
      {verificationResult && (
        <div
          className={`p-4 rounded-xl border flex items-center gap-3 text-xs font-mono ${
            verificationResult.valid
              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
              : 'bg-red-500/10 border-red-500/40 text-red-300'
          }`}
        >
          {verificationResult.valid ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
          )}
          <div className="space-y-0.5">
            <p className="font-bold">
              {verificationResult.valid
                ? 'AUDIT CHAIN INTEGRITY VERIFIED (0 TAMPER DETECTED)'
                : 'INTEGRITY BREACH DETECTED IN CHAIN'}
            </p>
            <p className="text-[11px] text-text-muted">
              Evaluated {verificationResult.recordsChecked || logs.length} sequential blocks from genesis hash.
            </p>
          </div>
        </div>
      )}

      {/* Audit Log Table */}
      <div className="rounded-xl bg-surface-1 border border-surface-3 overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface-2 border-b border-surface-3 font-mono text-[11px] text-text-muted">
              <tr>
                <th className="p-3.5">Seq #</th>
                <th className="p-3.5">Actor</th>
                <th className="p-3.5">Action Event</th>
                <th className="p-3.5">Resource ID</th>
                <th className="p-3.5">Outcome</th>
                <th className="p-3.5">SHA-256 Current Block Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-3/50 font-mono text-text-secondary text-[11px]">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-surface-2/60 transition">
                  <td className="p-3.5 font-bold text-text-primary">#{log.sequence}</td>
                  <td className="p-3.5 text-text-primary truncate max-w-[160px] font-sans">
                    {log.actor}
                  </td>
                  <td className="p-3.5 text-primary font-bold">{log.action}</td>
                  <td className="p-3.5 text-text-muted truncate max-w-[140px]">{log.resource}</td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.outcome === 'SUCCESS'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/10 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {log.outcome}
                    </span>
                  </td>
                  <td className="p-3.5 text-text-muted text-[10px] truncate max-w-[200px]" title={log.currentHash}>
                    {log.currentHash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
