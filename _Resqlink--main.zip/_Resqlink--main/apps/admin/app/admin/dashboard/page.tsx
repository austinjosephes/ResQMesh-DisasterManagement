'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldAlert,
  Users,
  User,
  Radio,
  LifeBuoy,
  Bell,
  HeartPulse,
  Activity,
  Layers,
  Compass,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Phone,
  RefreshCw,
  ExternalLink,
  MapPin,
  Send,
  Clock,
  Check,
  CheckCheck,
  X,
  Smartphone,
  Navigation,
  Building2,
  Lock,
  CloudRain,
  ShieldCheck,
  Sliders,
  Zap,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { KeralaTacticalMap } from '@/components/map/KeralaTacticalMap';
import { EmergencyNetworkGraph } from '@/components/network/EmergencyNetworkGraph';
import { findNearestGramaPanchayat } from '@/lib/kerala-administrative';

export default function AdminDashboardPage() {
  const [data, setData] = useState<any>(null);
  const [mapData, setMapData] = useState<any>({
    hazards: [],
    households: [],
    incidents: [],
    rescueTeams: [],
    shelters: [],
  });
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState<string>('');

  // Operational Development Action Modal State
  const [activeRequestModal, setActiveRequestModal] = useState<any | null>(null);
  const [actionStatus, setActionStatus] = useState<string>('ASSIGNED');
  const [actionTeam, setActionTeam] = useState<string>('NDRF 04 Battalion Alpha Team');
  const [actionShelter, setActionShelter] = useState<string>('Govt Higher Secondary School Meppadi / Chooralmala St. Joseph Hall');
  const [actionEta, setActionEta] = useState<number>(12);
  const [actionMessage, setActionMessage] = useState<string>(
    'NDRF Rescue Team Alpha has been dispatched to your GPS location. ETA ~12 minutes. Move to roof or highest ground with flashlight.'
  );
  const [isSubmittingAction, setIsSubmittingAction] = useState(false);
  const [actionFeedback, setActionFeedback] = useState('');
  const [actionError, setActionError] = useState('');

  // Admin Officer Identity & Clearance State
  const [adminName, setAdminName] = useState<string>('Commander K. Radhakrishnan');
  const [adminEmail, setAdminEmail] = useState<string>('commander.seoc@kerala.gov.in');
  const [adminPhone, setAdminPhone] = useState<string>('+91 94471 99000');
  const [showAdminClearanceModal, setShowAdminClearanceModal] = useState<boolean>(false);
  const [isSavingClearance, setIsSavingClearance] = useState<boolean>(false);
  const [clearanceError, setClearanceError] = useState<string>('');

  // Multi-Channel Alert & Directive Dispatch Modal State (SMS, Phone, Gmail)
  const [dispatchModalOpen, setDispatchModalOpen] = useState(false);
  const [dispatchPhone, setDispatchPhone] = useState('+919072105574');
  const [dispatchEmail, setDispatchEmail] = useState('resident.emergency@gmail.com');
  const [dispatchName, setDispatchName] = useState('Resident Citizen');
  const [dispatchCategory, setDispatchCategory] = useState('DIRECTIVE');
  const [dispatchBody, setDispatchBody] = useState(
    'SEOC DISASTER DIRECTIVE: Move immediately to designated high ground or evacuation camp. Rescue unit dispatched.'
  );
  const [dispatchTracking, setDispatchTracking] = useState<string | null>(null);
  const [dispatchChannels, setDispatchChannels] = useState<{ SMS: boolean; PHONE: boolean; EMAIL: boolean }>({
    SMS: true,
    PHONE: true,
    EMAIL: true,
  });
  const [isSendingDispatch, setIsSendingDispatch] = useState(false);
  const [dispatchFeedback, setDispatchFeedback] = useState('');
  const [dispatchReceipts, setDispatchReceipts] = useState<any[]>([]);
  const [dispatchError, setDispatchError] = useState('');

  // Clock Update & Admin Profile Verification on Mount
  useEffect(() => {
    // Check saved Admin profile in localStorage
    const savedAdminProfile = localStorage.getItem('resqlink_admin_profile');
    if (savedAdminProfile) {
      try {
        const parsed = JSON.parse(savedAdminProfile);
        if (parsed.name) setAdminName(parsed.name);
        if (parsed.email) setAdminEmail(parsed.email);
        if (parsed.phone) setAdminPhone(parsed.phone);
      } catch (e) {}
    } else {
      // First time admin entry -> automatically prompt for clearance credentials!
      setShowAdminClearanceModal(true);
    }

    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-IN', {
          timeZone: 'Asia/Kolkata',
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' IST'
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSaveAdminClearance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminName.trim()) {
      setClearanceError('Please enter your Officer Full Name');
      return;
    }
    if (!adminEmail.trim() || !adminEmail.includes('@')) {
      setClearanceError('Please enter a valid official Gmail / Email address');
      return;
    }
    if (!adminPhone.trim() || adminPhone.trim().length < 8) {
      setClearanceError('Please enter your emergency operations phone number');
      return;
    }

    setIsSavingClearance(true);
    setClearanceError('');

    localStorage.setItem(
      'resqlink_admin_profile',
      JSON.stringify({
        name: adminName.trim(),
        email: adminEmail.trim(),
        phone: adminPhone.trim(),
        clearance: 'LEVEL_4_STATE_COMMANDER',
        timestamp: new Date().toISOString(),
      })
    );

    setTimeout(() => {
      setIsSavingClearance(false);
      setShowAdminClearanceModal(false);
    }, 400);
  };

  const openDispatchModal = (targetPhone?: string, targetEmail?: string, targetName?: string, trackingNumber?: string) => {
    if (targetPhone) setDispatchPhone(targetPhone);
    if (targetEmail) setDispatchEmail(targetEmail);
    if (targetName) setDispatchName(targetName);
    if (trackingNumber) setDispatchTracking(trackingNumber);
    else setDispatchTracking(null);
    setDispatchFeedback('');
    setDispatchReceipts([]);
    setDispatchError('');
    setDispatchModalOpen(true);
  };

  const handleSendMultiChannelDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSendingDispatch(true);
    setDispatchFeedback('');
    setDispatchReceipts([]);
    setDispatchError('');

    const activeChannels = Object.entries(dispatchChannels)
      .filter(([_, active]) => active)
      .map(([channel]) => channel);

    if (activeChannels.length === 0) {
      setDispatchError('Please select at least one delivery channel (SMS, Phone, or Gmail)');
      setIsSendingDispatch(false);
      return;
    }

    try {
      const res = await fetch('/api/admin/direct-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipientPhone: dispatchPhone,
          recipientEmail: dispatchEmail,
          recipientName: dispatchName,
          messageBody: dispatchBody,
          category: dispatchCategory,
          trackingNumber: dispatchTracking,
          channels: activeChannels,
          adminName: adminName,
        }),
      });

      const resData = await res.json();
      if (res.ok && resData.success) {
        setDispatchFeedback(`✓ Multi-channel directives dispatched automatically by ${adminName}`);
        setDispatchReceipts(resData.channels || []);
        loadData();
        setTimeout(() => {
          setDispatchModalOpen(false);
        }, 2200);
      } else {
        setDispatchError(resData.error || 'Failed to dispatch alert.');
      }
    } catch (err: any) {
      setDispatchError(err.message || 'Network error dispatching multi-channel alert.');
    } finally {
      setIsSendingDispatch(false);
    }
  };

  const loadData = () => {
    setIsLoading(true);
    Promise.all([
      fetch('/api/admin/overview').then((r) => (r.ok ? r.json() : null)),
      fetch('/api/admin/map-data').then((r) => (r.ok ? r.json() : null)),
    ])
      .then(([overview, mapRes]) => {
        if (overview) setData(overview);
        if (mapRes) setMapData(mapRes);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 8000);
    return () => clearInterval(interval);
  }, []);

  const openActionModal = (req: any) => {
    setActiveRequestModal(req);
    setActionStatus(req.status === 'SUBMITTED' ? 'ASSIGNED' : req.status);
    setActionTeam(req.assignedTeamName || 'NDRF 04 Battalion Alpha Team');

    let resolvedCamp = req.assignedReliefCamp;
    if (!resolvedCamp && req.latitude && req.longitude) {
      try {
        const nearest = findNearestGramaPanchayat(req.latitude, req.longitude);
        resolvedCamp = nearest.designatedReliefCamp;
      } catch (e) {}
    }
    setActionShelter(resolvedCamp || 'Designated Regional Taluk Community Relief Camp');
    setActionEta(req.etaMinutes || 12);
    setActionMessage(
      req.adminMessage ||
        `SEOC RESCUE DISPATCH: Rescue unit dispatched to your location in ${
          req.gramaPanchayat || req.district || 'your sector'
        }. ETA ~12 mins. Remain in a safe covered position.`
    );
    setActionFeedback('');
    setActionError('');
  };

  const handleExecuteOperationalAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRequestModal) return;

    setIsSubmittingAction(true);
    setActionFeedback('');
    setActionError('');

    try {
      const res = await fetch('/api/admin/incidents/developments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId: activeRequestModal.id,
          trackingNumber: activeRequestModal.trackingNumber,
          status: actionStatus,
          assignedTeamName: actionTeam,
          assignedReliefCamp: actionShelter,
          etaMinutes: Number(actionEta),
          adminMessage: actionMessage,
          responderNotes: `Admin command updated status to ${actionStatus}. Assigned team ${actionTeam}. Directive sent.`,
        }),
      });

      const resData = await res.json();
      if (res.ok && resData.success) {
        setActionFeedback('✓ Operational development recorded and emergency directive forwarded to resident handset.');
        loadData();
        setTimeout(() => {
          setActiveRequestModal(null);
        }, 1500);
      } else {
        setActionError(resData.error || 'Failed to update incident.');
      }
    } catch (err: any) {
      setActionError(err.message || 'Network error.');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const metrics = data?.metrics || {
    activeWarnings: 3,
    exposedHouseholds: 450,
    exposedResidents: 1820,
    vulnerableAssistanceNeeded: 48,
    openSos: 3,
    criticalIncidents: 1,
    unassignedSos: 1,
    availableRescueTeams: 3,
    totalRescueTeams: 4,
    notificationDeliveryRate: 94,
    notificationFailures: 12,
    shelterCapacity: 2250,
    shelterOccupancy: 631,
    pendingRequestsCount: 2,
    awaitingAckCount: 1,
  };

  const liveRequests = data?.liveResidentRequests || [];

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] pb-16 selection:bg-[#FF6B35]/20 selection:text-white font-classic">
      {/* 0. SEOC DUTY COMMANDER CLEARANCE & IDENTIFICATION MODAL */}
      {showAdminClearanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-2xl animate-in fade-in">
          <div className="ios-glass-card-elevated w-full max-w-lg p-7 sm:p-8 space-y-6 relative border border-white/[0.2] shadow-2xl text-left">
            {adminName && (
              <button
                onClick={() => setShowAdminClearanceModal(false)}
                className="absolute top-5 right-5 p-1.5 rounded-full bg-white/[0.08] hover:bg-white/[0.15] text-[#929CAB] hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <div className="space-y-2">
              <div className="ios-capsule text-[#EF4444] font-extrabold text-[10px] uppercase tracking-widest">
                <ShieldCheck className="w-3.5 h-3.5 text-[#EF4444]" />
                <span>STATE EMERGENCY COMMAND CLEARANCE</span>
              </div>
              <h3 className="text-2xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
                Duty Commander Identification
              </h3>
              <p className="text-xs text-[#929CAB] leading-relaxed">
                Enter your administrative credentials. All directives and multi-channel broadcasts sent to citizens will be digitally attributed to your command clearance.
              </p>
            </div>

            <form onSubmit={handleSaveAdminClearance} className="space-y-4">
              {clearanceError && (
                <div className="p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 text-xs text-[#EF4444] font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{clearanceError}</span>
                </div>
              )}

              {/* Commander Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Commander Full Name <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    placeholder="e.g. Commander K. Radhakrishnan / S. Balakrishnan"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#EF4444] focus:ring-1 focus:ring-[#EF4444] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition"
                  />
                </div>
              </div>

              {/* Official Gmail / SEOC Email */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Official Gmail / SEOC Email <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="e.g. commander.seoc@kerala.gov.in / name@gmail.com"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#38BDF8] focus:ring-1 focus:ring-[#38BDF8] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition font-mono"
                  />
                </div>
              </div>

              {/* Duty Mobile Phone */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Emergency Operations Mobile Phone <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    placeholder="e.g. +91 94471 99000"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#22C55E] focus:ring-1 focus:ring-[#22C55E] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition font-mono"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs font-mono flex items-center justify-between text-[#929CAB]">
                <span>Clearance Level:</span>
                <span className="text-[#22C55E] font-bold">LEVEL-4 INCIDENT DIRECTOR</span>
              </div>

              <button
                type="submit"
                disabled={isSavingClearance}
                className="ios-button-primary w-full py-4 text-sm font-bold shadow-xl cursor-pointer disabled:opacity-50"
              >
                {isSavingClearance ? 'Authenticating Clearance...' : '✓ Authorize Command Clearance'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 1. PERSISTENT TOP COMMAND BAR */}
      <div className="bg-[#0B1017]/90 border-b border-white/[0.1] sticky top-0 z-40 backdrop-blur-2xl px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          {/* Left: Platform Status & Commander Identity */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] font-bold">
              <span className="w-2 h-2 rounded-full bg-[#EF4444] animate-ping" />
              <span>SEOC KERALA LIVE</span>
            </div>

            {/* Officer Identity Pill */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.06] border border-white/[0.12]">
              <User className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span className="text-[#929CAB]">Duty Commander:</span>
              <span className="text-[#F5F7FA] font-bold">{adminName}</span>
              <button
                onClick={() => setShowAdminClearanceModal(true)}
                className="text-[#FF6B35] hover:underline font-bold ml-1 cursor-pointer"
                title="Change Commander Credentials"
              >
                [Edit]
              </button>
            </div>

            <div className="hidden lg:flex items-center gap-3 text-[#929CAB]">
              <span>Active Incidents: <strong className="text-[#F5F7FA]">{metrics.openSos}</strong></span>
              <span>•</span>
              <span>Exposed Pop: <strong className="text-[#F5A623]">~{metrics.exposedResidents}</strong></span>
            </div>
          </div>

          {/* Right: Clock & Quick Emergency Multi-Channel Broadcast */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.05] border border-white/[0.08] text-[#38BDF8]">
              <Clock className="w-3.5 h-3.5" />
              <span>{currentTime || '12:00:00 IST'}</span>
            </div>

            <button
              onClick={() => openDispatchModal()}
              className="ios-button-primary px-4 py-1.5 text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Dispatch Directive (SMS/Call/Gmail)</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* 2. DASHBOARD HEADER & QUICK CONTROLS */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-[rgba(255,255,255,0.08)] pb-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
              <ShieldAlert className="w-4 h-4 text-[#FF6B35]" />
              <span>STATE EMERGENCY OPERATIONS CENTRE (SEOC) &bull; KSDMA</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] tracking-tight font-sans">
              State Disaster Command &amp; Intelligence Center
            </h1>
            <p className="text-xs sm:text-sm text-[#929CAB] max-w-2xl leading-relaxed">
              Real-time geospatial twin matching across 941 Gramas &amp; 152 Blocks, live citizen distress queue, telecom notification pipeline, and verified rescue dispatch.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Link
              href="/admin/jurisdictions"
              className="px-3.5 py-2 rounded-xl bg-[#101720] hover:bg-[#151E29] border border-[rgba(255,255,255,0.08)] text-xs font-mono text-[#F5F7FA] transition flex items-center gap-2"
            >
              <MapPin className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>941 Gramas / 152 Blocks</span>
            </Link>

            <button
              onClick={loadData}
              disabled={isLoading}
              className="px-3.5 py-2 rounded-xl bg-[#101720] hover:bg-[#151E29] border border-[rgba(255,255,255,0.08)] text-xs font-mono text-[#929CAB] hover:text-[#F5F7FA] transition flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#FF6B35]' : ''}`} />
              <span>Sync Telemetry</span>
            </button>

            <Link
              href="/admin/live-map"
              className="px-4 py-2 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-mono font-bold text-xs uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-[#FF6B35]/20"
            >
              <Compass className="w-4 h-4" />
              <span>Full Tactical Radar</span>
            </Link>
          </div>
        </div>

        {/* 3. SIX ANALYTICAL METRIC CARDS WITH TRENDS */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {/* Metric 1: Total Incidents */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>TOTAL INCIDENTS</span>
              <ShieldAlert className="w-3.5 h-3.5 text-[#EF4444]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F5F7FA]">
              {metrics.openSos}
            </div>
            <div className="text-[10px] font-mono text-[#EF4444] flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>+2 past 3 hrs</span>
            </div>
          </div>

          {/* Metric 2: Critical Distress Calls */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>CRITICAL SOS</span>
              <LifeBuoy className="w-3.5 h-3.5 text-[#EF4444] animate-pulse" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#EF4444]">
              {metrics.criticalIncidents}
            </div>
            <div className="text-[10px] font-mono text-[#929CAB]">
              P1 High Priority
            </div>
          </div>

          {/* Metric 3: Active Rescue Teams */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>RESCUE TEAMS</span>
              <Layers className="w-3.5 h-3.5 text-[#F5A623]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F5A623]">
              {metrics.availableRescueTeams} / {metrics.totalRescueTeams}
            </div>
            <div className="text-[10px] font-mono text-[#22C55E] flex items-center gap-1">
              <span>NDRF &bull; KFRS Deployed</span>
            </div>
          </div>

          {/* Metric 4: Shelters Operating */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>SHELTERS ACTIVE</span>
              <HeartPulse className="w-3.5 h-3.5 text-[#38BDF8]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#38BDF8]">
              14 Camps
            </div>
            <div className="text-[10px] font-mono text-[#929CAB]">
              Cap: {metrics.shelterCapacity} Beds
            </div>
          </div>

          {/* Metric 5: Evacuated Citizens */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>EVACUATED</span>
              <Users className="w-3.5 h-3.5 text-[#22C55E]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#22C55E]">
              {metrics.shelterOccupancy}
            </div>
            <div className="text-[10px] font-mono text-[#22C55E] flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>Safe in shelters</span>
            </div>
          </div>

          {/* Metric 6: Emergency Broadcast Reach */}
          <div className="p-4 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-2 relative overflow-hidden">
            <div className="text-[10px] font-mono uppercase text-[#6F7C93] flex items-center justify-between">
              <span>TELECOM REACH</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-[#22C55E]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F5F7FA]">
              {metrics.notificationDeliveryRate}%
            </div>
            <div className="text-[10px] font-mono text-[#929CAB]">
              {metrics.awaitingAckCount || 0} Awaiting ACK
            </div>
          </div>
        </div>

        {/* 4. CENTREPIECE GEOSPATIAL MONITORING AREA */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-[#FF6B35] font-bold flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-[#FF6B35] animate-pulse" />
                <span>CENTREPIECE GEOSPATIAL MONITORING AREA</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#F5F7FA] mt-0.5">
                Kerala Tactical Hazard &amp; Response Radar
              </h2>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="px-2.5 py-1 rounded bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] font-bold">
                Red Zones: 1
              </span>
              <span className="px-2.5 py-1 rounded bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623] font-bold">
                Amber Zones: 1
              </span>
              <span className="px-2.5 py-1 rounded bg-[#38BDF8]/15 border border-[#38BDF8]/30 text-[#38BDF8] font-bold">
                Cyan Watch: 1
              </span>
            </div>
          </div>

          <div className="rounded-2xl border border-[rgba(255,255,255,0.08)] bg-[#101720] overflow-hidden shadow-2xl">
            <KeralaTacticalMap
              height="500px"
              hazards={mapData.hazards}
              incidents={mapData.incidents}
              rescueTeams={mapData.rescueTeams}
              shelters={mapData.shelters}
              households={mapData.households}
            />
          </div>
        </div>

        {/* 5. EMERGENCY RESPONSE NETWORK VISUALIZATION */}
        <EmergencyNetworkGraph />

        {/* 6. REAL-TIME CITIZEN DISTRESS QUEUE */}
        <div className="rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] overflow-hidden shadow-2xl space-y-4 p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[rgba(255,255,255,0.08)] pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444] animate-ping" />
                <span className="text-[10px] font-mono uppercase text-[#EF4444] font-bold tracking-wider">
                  LIVE CITIZEN DISTRESS QUEUE
                </span>
              </div>
              <h3 className="text-lg font-bold text-[#F5F7FA] mt-0.5">
                Active SOS &amp; Rescue Requests ({liveRequests.length})
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => openDispatchModal()}
                className="px-3.5 py-1.5 rounded-xl bg-[#151E29] hover:bg-[#1C2736] border border-[rgba(255,255,255,0.12)] text-xs font-mono text-[#F5F7FA] transition flex items-center gap-2"
              >
                <Send className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Multi-Channel Directive Broadcast</span>
              </button>
            </div>
          </div>

          {liveRequests.length === 0 ? (
            <div className="p-8 text-center text-xs font-mono text-[#929CAB]">
              No pending citizen distress signals at this time.
            </div>
          ) : (
            <div className="space-y-3">
              {liveRequests.map((req: any) => {
                const isCritical = req.immediateDanger || req.category === 'TRAPPED' || req.priority === 'CRITICAL';
                return (
                  <div
                    key={req.id}
                    className={`p-4 rounded-xl border transition flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                      isCritical
                        ? 'bg-[#EF4444]/10 border-[#EF4444]/40 hover:border-[#EF4444]'
                        : 'bg-[#0B1017] border-[rgba(255,255,255,0.08)] hover:border-[rgba(255,255,255,0.14)]'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            isCritical
                              ? 'bg-[#EF4444] text-white'
                              : 'bg-[#F5A623]/20 text-[#F5A623] border border-[#F5A623]/30'
                          }`}
                        >
                          {req.priority || (isCritical ? 'P1 CRITICAL' : 'P2 HIGH')}
                        </span>

                        <span className="text-xs font-mono font-bold text-[#F5F7FA]">
                          #{req.trackingNumber || req.id.slice(-6)}
                        </span>

                        <span className="text-[11px] font-mono text-[#929CAB]">
                          &bull; {req.phone}
                        </span>

                        <span className="text-[11px] font-mono text-[#38BDF8]">
                          &bull; {req.gramaPanchayat || req.district || 'Sector'}
                        </span>
                      </div>

                      <p className="text-xs text-[#F5F7FA] font-medium leading-relaxed">
                        {req.description}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono text-[#6F7C93]">
                        <span>People: <strong className="text-[#F5F7FA]">{req.peopleCount || 1}</strong></span>
                        {req.hasInjuries && <span className="text-[#EF4444] font-bold">⚠️ Injuries</span>}
                        {req.assignedTeamName && (
                          <span className="text-[#22C55E]">Unit: {req.assignedTeamName}</span>
                        )}
                        {req.userMessageAckAt && (
                          <span className="text-[#22C55E] flex items-center gap-1">
                            <CheckCheck className="w-3 h-3" /> Handshake ACK
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => openActionModal(req)}
                        className="px-4 py-2 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-md"
                      >
                        Dispatch / Action
                      </button>

                      <button
                        onClick={() => openDispatchModal(req.phone, req.email, req.name, req.trackingNumber)}
                        className="p-2 rounded-xl bg-[#151E29] hover:bg-[#1C2736] text-[#38BDF8] border border-[rgba(255,255,255,0.08)] transition cursor-pointer"
                        title="Dispatch Multi-Channel Directive (SMS / Phone Call / Gmail)"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* 7. OPERATIONAL DEVELOPMENT ACTION MODAL */}
      {activeRequestModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#101720] border border-[rgba(255,255,255,0.12)] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-[#FF6B35]" />
                <h3 className="text-base font-bold text-[#F5F7FA]">
                  Dispatch Directive &bull; #{activeRequestModal.trackingNumber || activeRequestModal.id.slice(-6)}
                </h3>
              </div>
              <button onClick={() => setActiveRequestModal(null)} className="text-[#6F7C93] hover:text-[#F5F7FA]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteOperationalAction} className="space-y-4 text-xs font-mono">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#929CAB]">Mission Status:</label>
                  <select
                    value={actionStatus}
                    onChange={(e) => setActionStatus(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                  >
                    <option value="ASSIGNED">ASSIGNED (Dispatching)</option>
                    <option value="EN_ROUTE">EN_ROUTE (Traveling)</option>
                    <option value="ON_SCENE">ON_SCENE (At GPS)</option>
                    <option value="RESOLVED">RESOLVED (Extracted)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[#929CAB]">ETA (Minutes):</label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={actionEta}
                    onChange={(e) => setActionEta(parseInt(e.target.value) || 12)}
                    className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[#929CAB]">Assigned Rescue Unit:</label>
                <select
                  value={actionTeam}
                  onChange={(e) => setActionTeam(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                >
                  <option value="NDRF 04 Battalion Alpha Team">NDRF 04 Battalion Alpha Team (Chooralmala)</option>
                  <option value="Kerala Fire & Rescue Quick Response Team">Kerala Fire &amp; Rescue QRT (Kalpetta)</option>
                  <option value="Indian Coast Guard Gemini Boat Unit">Indian Coast Guard Gemini Boat Unit (Kochi)</option>
                  <option value="Civil Defense Volunteer Rapid Unit">Civil Defense Volunteer Rapid Unit</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[#929CAB]">Relief Shelter Allocation:</label>
                <input
                  type="text"
                  value={actionShelter}
                  onChange={(e) => setActionShelter(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#929CAB]">Handset Directive (Transmitted to Resident):</label>
                <textarea
                  rows={3}
                  value={actionMessage}
                  onChange={(e) => setActionMessage(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA] text-xs focus:border-[#FF6B35] focus:outline-none"
                />
              </div>

              {actionFeedback && (
                <div className="p-3 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/30 text-[#22C55E]">
                  {actionFeedback}
                </div>
              )}

              {actionError && (
                <div className="p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]">
                  {actionError}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveRequestModal(null)}
                  className="px-4 py-2.5 rounded-xl bg-[#0B1017] text-[#929CAB] hover:text-[#F5F7FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAction}
                  className="px-5 py-2.5 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmittingAction ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  <span>Execute Directive</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. MULTI-CHANNEL ALERT & DIRECTIVE DISPATCH MODAL (SMS, PHONE, GMAIL) */}
      {dispatchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-xl ios-glass-card-elevated border border-white/[0.2] p-7 space-y-5 shadow-2xl text-left font-classic">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#38BDF8]/20 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
                  <Send className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-[#F5F7FA] font-headline tracking-tight">
                    Multi-Channel Emergency Alert Dispatch
                  </h3>
                  <p className="text-[11px] text-[#929CAB] font-mono">
                    Dispatched under clearance of: <strong className="text-white">{adminName}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDispatchModalOpen(false)}
                className="p-1.5 rounded-full bg-white/[0.08] hover:bg-white/[0.15] text-[#6F7C93] hover:text-[#F5F7FA] transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendMultiChannelDispatch} className="space-y-4 text-xs font-mono">
              {/* Channel Selectors */}
              <div className="space-y-2">
                <label className="text-[#929CAB] uppercase tracking-wider font-bold text-[10px] block">
                  Select Transmission Channels (Simultaneous Multi-Push):
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {/* SMS Channel */}
                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition ${
                      dispatchChannels.SMS
                        ? 'bg-[#38BDF8]/15 border-[#38BDF8]/60 text-[#38BDF8]'
                        : 'bg-white/[0.04] border-white/[0.08] text-[#929CAB]'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={dispatchChannels.SMS}
                      onChange={(e) =>
                        setDispatchChannels((prev) => ({ ...prev, SMS: e.target.checked }))
                      }
                      className="accent-[#38BDF8]"
                    />
                    <div className="font-bold text-xs">Carrier DLT SMS</div>
                  </label>

                  {/* Phone Voice Channel */}
                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition ${
                      dispatchChannels.PHONE
                        ? 'bg-[#22C55E]/15 border-[#22C55E]/60 text-[#22C55E]'
                        : 'bg-white/[0.04] border-white/[0.08] text-[#929CAB]'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={dispatchChannels.PHONE}
                      onChange={(e) =>
                        setDispatchChannels((prev) => ({ ...prev, PHONE: e.target.checked }))
                      }
                      className="accent-[#22C55E]"
                    />
                    <div className="font-bold text-xs">Phone Voice Call</div>
                  </label>

                  {/* Gmail / Email Channel */}
                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition ${
                      dispatchChannels.EMAIL
                        ? 'bg-[#FF6B35]/15 border-[#FF6B35]/60 text-[#FF6B35]'
                        : 'bg-white/[0.04] border-white/[0.08] text-[#929CAB]'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={dispatchChannels.EMAIL}
                      onChange={(e) =>
                        setDispatchChannels((prev) => ({ ...prev, EMAIL: e.target.checked }))
                      }
                      className="accent-[#FF6B35]"
                    />
                    <div className="font-bold text-xs">Gmail / Email</div>
                  </label>
                </div>
              </div>

              {/* Recipient Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#929CAB] font-bold">Recipient Mobile Phone:</label>
                  <input
                    type="tel"
                    required={dispatchChannels.SMS || dispatchChannels.PHONE}
                    value={dispatchPhone}
                    onChange={(e) => setDispatchPhone(e.target.value)}
                    placeholder="+91..."
                    className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-white/[0.1] text-[#F5F7FA] outline-none focus:border-[#38BDF8]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#929CAB] font-bold">Recipient Gmail / Email:</label>
                  <input
                    type="email"
                    required={dispatchChannels.EMAIL}
                    value={dispatchEmail}
                    onChange={(e) => setDispatchEmail(e.target.value)}
                    placeholder="resident@gmail.com"
                    className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-white/[0.1] text-[#F5F7FA] outline-none focus:border-[#FF6B35]"
                  />
                </div>
              </div>

              {/* Directive Content */}
              <div className="space-y-1">
                <label className="text-[#929CAB] font-bold">Emergency Directive &amp; Instructions:</label>
                <textarea
                  required
                  rows={3}
                  value={dispatchBody}
                  onChange={(e) => setDispatchBody(e.target.value)}
                  className="w-full p-3 rounded-xl bg-[#0B1017] border border-white/[0.1] text-[#F5F7FA] text-xs focus:border-[#FF6B35] focus:outline-none leading-relaxed font-sans"
                />
              </div>

              {/* Real-time Delivery Receipts Feedback */}
              {dispatchFeedback && (
                <div className="p-3.5 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#22C55E] space-y-1 animate-in fade-in">
                  <div className="font-bold">{dispatchFeedback}</div>
                  {dispatchReceipts.map((rcpt: any, idx: number) => (
                    <div key={idx} className="text-[10px] text-[#929CAB]">
                      • [{rcpt.channel}] → {rcpt.recipient} ({rcpt.provider}): <strong className="text-[#22C55E]">{rcpt.status}</strong>
                    </div>
                  ))}
                </div>
              )}

              {dispatchError && (
                <div className="p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444]">
                  {dispatchError}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setDispatchModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-[#929CAB] hover:text-[#F5F7FA] transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingDispatch}
                  className="ios-button-primary px-6 py-2.5 text-xs font-bold transition flex items-center gap-2 disabled:opacity-50 cursor-pointer shadow-lg"
                >
                  {isSendingDispatch ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>Execute Automated Multi-Channel Dispatch</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
