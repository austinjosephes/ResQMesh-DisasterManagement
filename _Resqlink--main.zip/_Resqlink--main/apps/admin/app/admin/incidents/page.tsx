'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  LifeBuoy,
  ShieldAlert,
  Radio,
  Clock,
  Compass,
  CheckCircle2,
  AlertTriangle,
  Users,
  Send,
  Edit3,
} from 'lucide-react';

export default function AdminIncidentsQueuePage() {
  const [incidents, setIncidents] = useState<any[]>([]);
  const [rescueTeams, setRescueTeams] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Assignment Modal
  const [selectedSos, setSelectedSos] = useState<any | null>(null);
  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [dispatchNotes, setDispatchNotes] = useState('');
  const [isDispatching, setIsDispatching] = useState(false);

  // Override Modal
  const [overrideSos, setOverrideSos] = useState<any | null>(null);
  const [newPriority, setNewPriority] = useState('CRITICAL');
  const [overrideReason, setOverrideReason] = useState('');
  const [isOverriding, setIsOverriding] = useState(false);

  const [actionMsg, setActionMsg] = useState('');

  const loadData = () => {
    setIsLoading(true);
    Promise.all([
      fetch('/api/resident/requests').then((r) => (r.ok ? r.json() : null)),
      fetch('/api/admin/rescue-teams').then((r) => (r.ok ? r.json() : null)),
    ])
      .then(([reqData, teamsData]) => {
        if (reqData && reqData.requests) setIncidents(reqData.requests);
        if (teamsData && teamsData.teams) setRescueTeams(teamsData.teams);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAssignTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSos || !selectedTeamId) return;

    setIsDispatching(true);
    setActionMsg('');
    try {
      const res = await fetch(`/api/incidents/${selectedSos.id}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teamId: selectedTeamId,
          notes: dispatchNotes,
        }),
      });

      if (res.ok) {
        setActionMsg(`Rescue unit assigned successfully to SOS ${selectedSos.trackingNumber}`);
        setSelectedSos(null);
        loadData();
      }
    } catch (e) {
    } finally {
      setIsDispatching(false);
    }
  };

  const handleOverride = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideSos || !overrideReason) return;

    setIsOverriding(true);
    setActionMsg('');
    try {
      const res = await fetch(`/api/incidents/${overrideSos.id}/override`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priorityCategory: newPriority,
          overrideReason,
        }),
      });

      if (res.ok) {
        setActionMsg(`Priority overridden to ${newPriority} and committed to audit chain.`);
        setOverrideSos(null);
        setOverrideReason('');
        loadData();
      }
    } catch (e) {
    } finally {
      setIsOverriding(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-red-400 font-semibold flex items-center gap-1.5">
          <LifeBuoy className="w-4 h-4 text-red-400" />
          <span>Innovation 03</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Rescue Priority Engine &amp; Incident Dispatch Queue
        </h1>
        <p className="text-xs text-text-secondary mt-1">
          Transparent multi-factor triage scoring, location confidence verification, and auditable coordinator overrides.
        </p>
      </div>

      {actionMsg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400 font-mono">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{actionMsg}</span>
        </div>
      )}

      {/* Incidents Table */}
      <div className="rounded-xl bg-surface-1 border border-surface-3 overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface-2 border-b border-surface-3 font-mono text-[11px] text-text-muted">
              <tr>
                <th className="p-3.5">Ticket / District</th>
                <th className="p-3.5">Category &amp; Hazard</th>
                <th className="p-3.5">Urgency Score &amp; Factors</th>
                <th className="p-3.5">Victims / Needs</th>
                <th className="p-3.5">Location &amp; Confidence</th>
                <th className="p-3.5">Assigned Unit</th>
                <th className="p-3.5">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-3/50 text-text-secondary">
              {incidents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-text-muted">
                    No open SOS requests in queue.
                  </td>
                </tr>
              ) : (
                incidents.map((sos) => {
                  let breakdownReasons: string[] = [];
                  try {
                    if (sos.scoreBreakdown) {
                      const parsed = JSON.parse(sos.scoreBreakdown);
                      if (parsed.reasons) breakdownReasons = parsed.reasons;
                    }
                  } catch (e) {}

                  return (
                    <tr key={sos.id} className="hover:bg-surface-2/60 transition">
                      <td className="p-3.5">
                        <p className="font-mono font-bold text-text-primary">{sos.trackingNumber}</p>
                        <p className="text-[10px] text-text-muted font-mono">{sos.district || 'Wayanad'}</p>
                      </td>

                      <td className="p-3.5">
                        <span className="font-semibold text-text-primary">{sos.category}</span>
                        <p className="text-[11px] text-text-muted truncate max-w-[180px]">
                          {sos.description}
                        </p>
                      </td>

                      <td className="p-3.5">
                        <div className="space-y-1">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              sos.priorityCategory === 'CRITICAL'
                                ? 'bg-red-500 text-canvas'
                                : sos.priorityCategory === 'HIGH'
                                ? 'bg-amber-500/20 text-amber-400'
                                : sos.priorityCategory === 'NEEDS_VERIFICATION'
                                ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40'
                                : 'bg-primary/20 text-primary'
                            }`}
                          >
                            {sos.priorityCategory} ({sos.priorityScore}/100)
                          </span>
                          {breakdownReasons.length > 0 && (
                            <p className="text-[10px] text-text-muted truncate max-w-[200px]">
                              {breakdownReasons[0]}
                            </p>
                          )}
                          {sos.overrideReason && (
                            <p className="text-[9px] text-amber-400 font-mono italic">
                              Override: {sos.overrideReason}
                            </p>
                          )}
                        </div>
                      </td>

                      <td className="p-3.5">
                        <p className="font-bold text-text-primary">{sos.peopleCount} Persons</p>
                        <p className="text-[10px] text-amber-400 truncate max-w-[150px]">
                          {sos.accessibilityNeeds || (sos.hasInjuries ? 'Trauma Reported' : 'Standard')}
                        </p>
                      </td>

                      <td className="p-3.5 font-mono text-[11px]">
                        {sos.latitude ? `${sos.latitude.toFixed(4)}, ${sos.longitude?.toFixed(4)}` : 'Coarse'}
                        <p className="text-[10px] text-text-muted">
                          Confidence: {Math.round(sos.locationConfidence * 100)}%
                        </p>
                      </td>

                      <td className="p-3.5 font-mono text-[11px]">
                        {sos.assignedTeamName ? (
                          <span className="text-primary font-bold">{sos.assignedTeamName}</span>
                        ) : (
                          <span className="text-red-400 font-semibold">Unassigned</span>
                        )}
                        <p className="text-[10px] text-text-muted">{sos.status}</p>
                      </td>

                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setSelectedSos(sos)}
                            className="px-2.5 py-1 rounded bg-surface-2 hover:bg-surface-3 border border-surface-3 text-primary text-[10px] font-mono font-bold"
                          >
                            Assign Unit
                          </button>
                          <button
                            onClick={() => {
                              setOverrideSos(sos);
                              setNewPriority(sos.priorityCategory);
                            }}
                            className="p-1 rounded bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-muted hover:text-text-primary"
                            title="Coordinator Priority Override"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Team Modal */}
      {selectedSos && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-surface-1 border border-surface-3 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-text-primary">Dispatch Rescue Team</h3>
            <p className="text-xs text-text-secondary">
              Assign an authorized disaster response unit to SOS{' '}
              <strong className="text-primary font-mono">{selectedSos.trackingNumber}</strong>.
            </p>

            <form onSubmit={handleAssignTeam} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-text-muted">Available Rescue Units:</label>
                <select
                  required
                  value={selectedTeamId}
                  onChange={(e) => setSelectedTeamId(e.target.value)}
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                >
                  <option value="">Select Response Unit</option>
                  {rescueTeams.map((team) => (
                    <option key={team.id} value={team.id}>
                      {team.name} ({team.agency} • {team.status})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-text-muted">Operational Dispatch Notes:</label>
                <textarea
                  rows={2}
                  value={dispatchNotes}
                  onChange={(e) => setDispatchNotes(e.target.value)}
                  placeholder="e.g. Deploy inflatable motorized craft. Carry portable battery pack for oxygen concentrator."
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2.5 text-text-primary font-sans"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  disabled={isDispatching}
                  className="flex-1 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase"
                >
                  {isDispatching ? 'Dispatching...' : 'Confirm Dispatch'}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedSos(null)}
                  className="px-4 py-2.5 rounded-lg bg-surface-2 text-text-secondary text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Override Priority Modal */}
      {overrideSos && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-surface-1 border border-surface-3 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-text-primary">Coordinator Priority Override</h3>
            <p className="text-xs text-text-secondary">
              Human control requirement: All priority overrides must record a documented operational justification
              committed to the tamper-evident SHA-256 audit chain.
            </p>

            <form onSubmit={handleOverride} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-text-muted">New Priority Category:</label>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value)}
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                >
                  <option value="CRITICAL">CRITICAL</option>
                  <option value="HIGH">HIGH</option>
                  <option value="MODERATE">MODERATE</option>
                  <option value="LOW">LOW</option>
                  <option value="NEEDS_VERIFICATION">NEEDS_VERIFICATION</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-text-muted">Mandatory Documented Reason *:</label>
                <textarea
                  rows={3}
                  required
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="e.g. Field ranger confirmed dam shutter opening will submerge house within 20 minutes."
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2.5 text-text-primary font-sans"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  disabled={isOverriding}
                  className="flex-1 py-2.5 rounded-lg bg-amber-500 text-canvas font-bold text-xs uppercase"
                >
                  {isOverriding ? 'Recording...' : 'Commit Override to Audit Chain'}
                </button>
                <button
                  type="button"
                  onClick={() => setOverrideSos(null)}
                  className="px-4 py-2.5 rounded-lg bg-surface-2 text-text-secondary text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
