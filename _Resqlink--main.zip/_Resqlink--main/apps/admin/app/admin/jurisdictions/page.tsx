'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  MapPin,
  Building2,
  Users,
  ShieldAlert,
  Search,
  Filter,
  Radio,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  HeartPulse,
  Compass,
  ArrowRight,
  CheckCircle2,
  Navigation,
  Send,
  CloudRain,
  Mountain,
  Waves,
  Sparkles,
  Info,
  Layers,
} from 'lucide-react';
import {
  KERALA_STATISTICS_2026,
  KERALA_ADMINISTRATIVE_HIERARCHY,
  DistrictHierarchy,
  BlockPanchayat,
  GramaPanchayat,
  searchAdministrativeAreas,
  SearchAdministrativeResult,
} from '@/lib/kerala-administrative';

export default function AdminJurisdictionsDirectoryPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');
  const [selectedVulnerability, setSelectedVulnerability] = useState<string>('ALL');
  const [expandedBlocks, setExpandedBlocks] = useState<Record<string, boolean>>({
    'Kalpetta Block': true,
    'Devikulam Block': true,
    'Aluva Block': true,
  });
  const [activeModalGrama, setActiveModalGrama] = useState<GramaPanchayat | null>(null);

  // Toggle block accordion
  const toggleBlock = (blockName: string) => {
    setExpandedBlocks((prev) => ({
      ...prev,
      [blockName]: !prev[blockName],
    }));
  };

  // Perform search when query has at least 2 characters
  const searchResults = useMemo(() => {
    if (searchQuery.trim().length >= 2) {
      return searchAdministrativeAreas(searchQuery.trim(), 40);
    }
    return [];
  }, [searchQuery]);

  // Filter districts and their blocks & gramas based on selection
  const filteredDistricts = useMemo(() => {
    let districts = KERALA_ADMINISTRATIVE_HIERARCHY;
    if (selectedDistrict !== 'ALL') {
      districts = districts.filter((d) => d.name.toLowerCase() === selectedDistrict.toLowerCase());
    }

    if (selectedVulnerability === 'ALL') {
      return districts;
    }

    return districts
      .map((dist) => {
        const matchingBlocks = dist.blocks
          .map((b) => {
            const matchingGramas = b.gramaPanchayats.filter(
              (g) => g.primaryVulnerability === selectedVulnerability
            );
            return {
              ...b,
              gramaPanchayats: matchingGramas,
            };
          })
          .filter((b) => b.gramaPanchayats.length > 0);

        return {
          ...dist,
          blocks: matchingBlocks,
        };
      })
      .filter((dist) => dist.blocks.length > 0);
  }, [selectedDistrict, selectedVulnerability]);

  const getVulnerabilityBadge = (vuln: string) => {
    switch (vuln) {
      case 'LANDSLIDE':
        return {
          label: 'Landslide Risk Zone',
          color: 'bg-red-500/10 text-red-400 border-red-500/30',
          icon: Mountain,
        };
      case 'FLOOD':
        return {
          label: 'Flood Inundation Basin',
          color: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
          icon: Waves,
        };
      case 'DAM_DISCHARGE':
        return {
          label: 'Dam Discharge Spillway',
          color: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
          icon: Waves,
        };
      case 'COASTAL_EROSION':
        return {
          label: 'Coastal Surge & Erosion',
          color: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
          icon: Waves,
        };
      case 'CYCLONE':
        return {
          label: 'High Wind / Cyclone Alert',
          color: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          icon: AlertTriangle,
        };
      default:
        return {
          label: 'Heavy Rain / Cloudburst',
          color: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
          icon: CloudRain,
        };
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-surface-3 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase text-primary font-bold flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-primary" />
              <span>State Disaster Management Authority • SEOC Administrative Directory</span>
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-text-primary mt-1 tracking-tight">
            Kerala State Administrative Jurisdictions
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            Complete demographic distribution covering exactly 14 Districts, 152 Block Panchayats, 941 Grama Panchayats, and all constituent local areas &amp; designated emergency relief camps.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/weather-ingest"
            className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-mono font-bold hover:bg-primary-hover transition flex items-center gap-2 shadow-glow-accent"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Ingest Weather Alert</span>
          </Link>
          <Link
            href="/admin/live-map"
            className="px-4 py-2 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary hover:border-primary/50 transition flex items-center gap-2"
          >
            <Compass className="w-3.5 h-3.5 text-primary" />
            <span>Tactical Map</span>
          </Link>
        </div>
      </div>

      {/* 2026 State Baseline Demographics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3">
          <div className="text-[10px] font-mono uppercase text-text-muted">Total Population (2026)</div>
          <div className="text-xl md:text-2xl font-mono font-bold text-primary mt-1">
            {(KERALA_STATISTICS_2026.TOTAL_POPULATION_ESTIMATE / 10000000).toFixed(2)} Cr
          </div>
          <div className="text-[11px] font-mono text-text-secondary mt-0.5">37,300,000 Verified</div>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3">
          <div className="text-[10px] font-mono uppercase text-text-muted">Revenue Districts</div>
          <div className="text-xl md:text-2xl font-mono font-bold text-text-primary mt-1">
            {KERALA_STATISTICS_2026.TOTAL_DISTRICTS}
          </div>
          <div className="text-[11px] font-mono text-text-secondary mt-0.5">14 District HQs Active</div>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3">
          <div className="text-[10px] font-mono uppercase text-text-muted">Block Panchayats</div>
          <div className="text-xl md:text-2xl font-mono font-bold text-amber-400 mt-1">
            {KERALA_STATISTICS_2026.TOTAL_BLOCK_PANCHAYATS}
          </div>
          <div className="text-[11px] font-mono text-text-secondary mt-0.5">152 Intermediate Tiers</div>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3">
          <div className="text-[10px] font-mono uppercase text-text-muted">Grama Panchayats</div>
          <div className="text-xl md:text-2xl font-mono font-bold text-emerald-400 mt-1">
            {KERALA_STATISTICS_2026.TOTAL_GRAMA_PANCHAYATS}
          </div>
          <div className="text-[11px] font-mono text-text-secondary mt-0.5">941 Local Governments</div>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 col-span-2 md:col-span-1">
          <div className="text-[10px] font-mono uppercase text-text-muted">Local Areas &amp; Shelters</div>
          <div className="text-xl md:text-2xl font-mono font-bold text-sky-400 mt-1">
            15,960+
          </div>
          <div className="text-[11px] font-mono text-text-secondary mt-0.5">100% Shelter Mapped</div>
        </div>
      </div>

      {/* Instant Search & Multi-tier Filter Panel */}
      <div className="p-5 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-text-muted absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Grama Panchayat, Block, District, or local area / town / ward (e.g. Meppadi, Chooralmala, Mundakkai, Ranni, Kuttanad, Aluva, Munambam)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-surface-2 border border-surface-3 text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary/60 font-mono transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-text-muted hover:text-text-primary px-1.5 py-0.5 rounded bg-surface-3"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            <Filter className="w-3.5 h-3.5 text-text-muted shrink-0 ml-1" />
            <select
              value={selectedVulnerability}
              onChange={(e) => setSelectedVulnerability(e.target.value)}
              aria-label="Filter by disaster vulnerability classification"
              className="px-3 py-2 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary focus:outline-none focus:border-primary/50"
            >
              <option value="ALL">All Hazard Profiles</option>
              <option value="LANDSLIDE">Landslide Risk Zones</option>
              <option value="FLOOD">Flood Inundation Basins</option>
              <option value="DAM_DISCHARGE">Dam Spillway Zones</option>
              <option value="COASTAL_EROSION">Coastal Surge & Erosion</option>
              <option value="CYCLONE">High Wind / Cyclone</option>
              <option value="HEAVY_RAIN">Heavy Rain & Cloudburst</option>
            </select>
          </div>
        </div>

        {/* Quick District Selector Pills */}
        <div className="space-y-1.5 pt-2 border-t border-surface-3">
          <div className="text-[10px] font-mono uppercase text-text-muted">Select District ({KERALA_ADMINISTRATIVE_HIERARCHY.length} Available):</div>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setSelectedDistrict('ALL')}
              className={`px-3 py-1 rounded-lg text-xs font-mono transition ${
                selectedDistrict === 'ALL'
                  ? 'bg-primary text-primary-foreground font-bold shadow-sm'
                  : 'bg-surface-2 text-text-secondary hover:text-text-primary hover:bg-surface-3'
              }`}
            >
              All Districts (14)
            </button>
            {KERALA_ADMINISTRATIVE_HIERARCHY.map((d) => {
              const isSelected = selectedDistrict.toLowerCase() === d.name.toLowerCase();
              return (
                <button
                  key={d.name}
                  onClick={() => setSelectedDistrict(d.name)}
                  className={`px-3 py-1 rounded-lg text-xs font-mono transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-primary text-primary-foreground font-bold shadow-sm'
                      : 'bg-surface-2 text-text-secondary hover:text-text-primary hover:bg-surface-3'
                  }`}
                >
                  <span>{d.name}</span>
                  <span className={`text-[10px] px-1 py-0.2 rounded ${isSelected ? 'bg-black/20 text-white' : 'bg-surface-3 text-text-muted'}`}>
                    {d.totalGramaCount} GP
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* SEARCH RESULTS VIEW (when typing query) */}
      {searchQuery.trim().length >= 2 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs font-mono text-text-secondary">
              Search results for <strong className="text-primary font-bold">"{searchQuery}"</strong> ({searchResults.length} matches found)
            </div>
            <span className="text-[11px] font-mono text-text-muted">Instant local area &amp; ward resolution</span>
          </div>

          {searchResults.length === 0 ? (
            <div className="p-8 rounded-2xl bg-surface-1 border border-surface-3 text-center space-y-2">
              <Search className="w-8 h-8 text-text-muted mx-auto" />
              <div className="text-sm font-mono font-medium text-text-primary">No jurisdictions or local areas matched</div>
              <p className="text-xs text-text-muted max-w-md mx-auto">
                Try searching for Grama Panchayat names (e.g. Meppadi, Kumarakom), Block names (Kalpetta, Aluva), or prominent local areas (Chooralmala, Mundakkai, Munambam).
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {searchResults.map((res, idx) => {
                const targetGrama = res.type === 'GRAMA' || res.type === 'LOCAL_AREA' ? res.grama : undefined;
                const targetBlock = res.block;
                const targetDistrict = res.district;
                const scope = res.type === 'DISTRICT' ? 'DISTRICT' : res.type === 'BLOCK' ? 'BLOCK_PANCHAYAT' : 'GRAMA_PANCHAYAT';

                return (
                  <div
                    key={`${res.type}-${res.name}-${idx}`}
                    className="p-4 rounded-xl bg-surface-1 border border-surface-3 hover:border-primary/40 transition space-y-3 flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider mb-1 bg-surface-2 text-text-secondary border border-surface-3">
                            {res.type === 'LOCAL_AREA' && <MapPin className="w-3 h-3 text-primary" />}
                            {res.type === 'GRAMA' && <Building2 className="w-3 h-3 text-emerald-400" />}
                            {res.type === 'BLOCK' && <Layers className="w-3 h-3 text-amber-400" />}
                            {res.type === 'DISTRICT' && <Compass className="w-3 h-3 text-sky-400" />}
                            <span>{res.type.replace('_', ' ')}</span>
                          </div>
                          <h3 className="text-base font-semibold text-text-primary">
                            {res.name}
                          </h3>
                        </div>

                        {res.primaryVulnerability && (
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${getVulnerabilityBadge(res.primaryVulnerability).color}`}>
                            {res.primaryVulnerability}
                          </span>
                        )}
                      </div>

                      <div className="text-xs font-mono text-text-muted space-y-0.5">
                        {res.grama && res.type === 'LOCAL_AREA' && (
                          <div>Panchayat: <strong className="text-text-secondary">{res.grama}</strong></div>
                        )}
                        {res.block && (
                          <div>Block: <strong className="text-text-secondary">{res.block}</strong></div>
                        )}
                        <div>District: <strong className="text-text-secondary">{res.district}</strong></div>
                        <div>2026 Population: <strong className="text-primary">{res.populationEst.toLocaleString()} residents</strong></div>
                      </div>

                      {res.reliefCamp && (
                        <div className="text-[11px] font-mono p-2 rounded bg-surface-2 border border-surface-3 text-text-secondary flex items-start gap-1.5">
                          <HeartPulse className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                          <span className="line-clamp-2">Shelter: {res.reliefCamp}</span>
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-surface-3 flex items-center justify-between gap-2">
                      <Link
                        href={`/admin/weather-ingest?district=${encodeURIComponent(targetDistrict)}${
                          targetBlock ? `&block=${encodeURIComponent(targetBlock)}` : ''
                        }${targetGrama ? `&grama=${encodeURIComponent(targetGrama)}` : ''}&scope=${scope}`}
                        className="w-full py-2 px-3 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/30 text-xs font-mono text-primary font-bold transition flex items-center justify-center gap-1.5"
                      >
                        <Send className="w-3 h-3" />
                        <span>Dispatch Ingest SMS</span>
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* FULL DISTRICT & BLOCK HIERARCHY ACCORDION */}
      {searchQuery.trim().length < 2 && (
        <div className="space-y-6">
          {filteredDistricts.map((dist) => (
            <div
              key={dist.id}
              className="rounded-2xl bg-surface-1 border border-surface-3 overflow-hidden shadow-sm"
            >
              {/* District Header Banner */}
              <div className="p-5 bg-surface-2/80 border-b border-surface-3 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-primary/10 text-primary border border-primary/30 uppercase">
                      Revenue District
                    </span>
                    <span className="text-xs font-mono text-text-muted">
                      HQ: <strong className="text-text-secondary">{dist.headquarters}</strong> • Lat: {dist.center.lat}, Lng: {dist.center.lng}
                    </span>
                  </div>
                  <h2 className="text-xl md:text-2xl font-display font-bold text-text-primary">
                    {dist.name} District
                  </h2>
                  <div className="text-xs font-mono text-text-secondary flex flex-wrap items-center gap-3">
                    <span>Population: <strong className="text-primary">{dist.population2026Est.toLocaleString()}</strong></span>
                    <span>•</span>
                    <span>Blocks: <strong className="text-amber-400">{dist.totalBlockCount}</strong></span>
                    <span>•</span>
                    <span>Grama Panchayats: <strong className="text-emerald-400">{dist.totalGramaCount}</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Link
                    href={`/admin/weather-ingest?district=${encodeURIComponent(dist.name)}&scope=DISTRICT`}
                    className="px-3 py-2 rounded-lg bg-surface-1 hover:bg-surface-3 border border-surface-3 text-xs font-mono text-text-primary hover:border-primary/50 transition flex items-center gap-1.5"
                  >
                    <Send className="w-3 h-3 text-primary" />
                    <span>Alert Entire District ({dist.totalGramaCount} GPs)</span>
                  </Link>
                </div>
              </div>

              {/* District Blocks & Constituents */}
              <div className="p-5 space-y-6">
                {dist.blocks.map((block) => {
                  const isExpanded = expandedBlocks[block.name] !== false;
                  return (
                    <div
                      key={block.id}
                      className="rounded-xl border border-surface-3/80 bg-surface-0/60 overflow-hidden"
                    >
                      {/* Block Title & Expander */}
                      <div
                        onClick={() => toggleBlock(block.name)}
                        className="p-4 bg-surface-2/40 hover:bg-surface-2/70 transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-surface-3/60"
                      >
                        <div className="flex items-center gap-3">
                          <button className="text-text-muted hover:text-text-primary">
                            {isExpanded ? (
                              <ChevronDown className="w-4 h-4 text-primary" />
                            ) : (
                              <ChevronRight className="w-4 h-4 text-text-muted" />
                            )}
                          </button>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="text-base font-semibold text-text-primary">
                                {block.name}
                              </h3>
                              <span className="px-2 py-0.2 rounded text-[10px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
                                {block.gramaPanchayats.length} Grama Panchayats
                              </span>
                            </div>
                            <div className="text-xs font-mono text-text-muted mt-0.5">
                              Est. Population: <strong className="text-text-secondary">{block.population2026Est.toLocaleString()}</strong> • Centroid: [{block.center.lat}, {block.center.lng}]
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                          <Link
                            href={`/admin/weather-ingest?district=${encodeURIComponent(dist.name)}&block=${encodeURIComponent(
                              block.name
                            )}&scope=BLOCK_PANCHAYAT`}
                            className="px-2.5 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 border border-surface-3 text-xs font-mono text-text-secondary hover:text-text-primary transition flex items-center gap-1.5"
                          >
                            <Send className="w-3 h-3 text-amber-400" />
                            <span>Alert Block ({block.gramaPanchayats.length} GPs)</span>
                          </Link>
                        </div>
                      </div>

                      {/* Grama Panchayats Grid within Block */}
                      {isExpanded && (
                        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                          {block.gramaPanchayats.map((gp) => {
                            const badge = getVulnerabilityBadge(gp.primaryVulnerability);
                            const BadgeIcon = badge.icon;

                            return (
                              <div
                                key={gp.id}
                                className="p-3.5 rounded-xl bg-surface-1 border border-surface-3 hover:border-primary/40 transition space-y-2.5 flex flex-col justify-between"
                              >
                                <div className="space-y-2">
                                  {/* GP Header */}
                                  <div className="flex items-start justify-between gap-1.5">
                                    <div>
                                      <div className="text-[10px] font-mono text-text-muted">{gp.id}</div>
                                      <h4 className="text-sm font-semibold text-text-primary">
                                        {gp.name}
                                      </h4>
                                    </div>
                                    <span
                                      className={`px-2 py-0.5 rounded text-[10px] font-mono border flex items-center gap-1 shrink-0 ${badge.color}`}
                                      title={badge.label}
                                    >
                                      <BadgeIcon className="w-3 h-3" />
                                      <span>{gp.primaryVulnerability}</span>
                                    </span>
                                  </div>

                                  {/* Metrics */}
                                  <div className="text-xs font-mono text-text-muted flex items-center justify-between">
                                    <span>2026 Pop: <strong className="text-primary">{gp.population2026Est.toLocaleString()}</strong></span>
                                    <span>[{gp.center.lat.toFixed(3)}, {gp.center.lng.toFixed(3)}]</span>
                                  </div>

                                  {/* Designated Shelter */}
                                  <div className="p-2 rounded bg-surface-2 border border-surface-3 text-[11px] font-mono text-text-secondary flex items-start gap-1.5">
                                    <HeartPulse className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                                    <span className="line-clamp-1" title={gp.designatedReliefCamp}>
                                      Shelter: {gp.designatedReliefCamp}
                                    </span>
                                  </div>

                                  {/* Local Areas / Towns / Wards */}
                                  {gp.localAreas && gp.localAreas.length > 0 && (
                                    <div className="space-y-1">
                                      <div className="text-[10px] font-mono uppercase text-text-muted flex items-center justify-between">
                                        <span>Local Areas / Wards ({gp.localAreas.length})</span>
                                        <button
                                          onClick={() => setActiveModalGrama(gp)}
                                          className="text-primary hover:underline"
                                        >
                                          View All
                                        </button>
                                      </div>
                                      <div className="flex flex-wrap gap-1">
                                        {gp.localAreas.slice(0, 4).map((area) => (
                                          <span
                                            key={area}
                                            className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-surface-2 text-text-secondary border border-surface-3"
                                          >
                                            {area}
                                          </span>
                                        ))}
                                        {gp.localAreas.length > 4 && (
                                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-surface-3 text-text-muted">
                                            +{gp.localAreas.length - 4} more
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </div>

                                {/* Action Buttons */}
                                <div className="pt-2 border-t border-surface-3 flex items-center gap-2">
                                  <Link
                                    href={`/admin/weather-ingest?district=${encodeURIComponent(
                                      dist.name
                                    )}&block=${encodeURIComponent(block.name)}&grama=${encodeURIComponent(
                                      gp.name
                                    )}&scope=GRAMA_PANCHAYAT`}
                                    className="flex-1 py-1.5 px-2.5 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/30 text-xs font-mono text-primary font-semibold transition flex items-center justify-center gap-1.5"
                                  >
                                    <Send className="w-3 h-3" />
                                    <span>Target Ingest SMS</span>
                                  </Link>
                                  <button
                                    onClick={() => setActiveModalGrama(gp)}
                                    className="p-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-secondary hover:text-text-primary transition"
                                    title="View full local areas and shelter details"
                                  >
                                    <Info className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* DETAIL MODAL FOR SELECTED GRAMA PANCHAYAT */}
      {activeModalGrama && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-surface-1 border border-surface-3 rounded-2xl p-6 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 border-b border-surface-3 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 uppercase">
                    Grama Panchayat Detail
                  </span>
                  <span className="text-xs font-mono text-text-muted">{activeModalGrama.id}</span>
                </div>
                <h3 className="text-xl font-display font-bold text-text-primary mt-1">
                  {activeModalGrama.name}
                </h3>
                <div className="text-xs font-mono text-text-secondary mt-0.5">
                  Block: {activeModalGrama.blockName} • District: {activeModalGrama.districtName}
                </div>
              </div>

              <button
                onClick={() => setActiveModalGrama(null)}
                className="p-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-muted hover:text-text-primary transition text-sm font-mono"
              >
                ✕
              </button>
            </div>

            {/* Demographics & Coordinates */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3">
                <div className="text-[10px] font-mono uppercase text-text-muted">2026 Population</div>
                <div className="text-lg font-mono font-bold text-primary mt-0.5">
                  {activeModalGrama.population2026Est.toLocaleString()}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3">
                <div className="text-[10px] font-mono uppercase text-text-muted">Primary Hazard</div>
                <div className="text-xs font-mono font-bold text-red-400 mt-1">
                  {activeModalGrama.primaryVulnerability}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 col-span-2 sm:col-span-1">
                <div className="text-[10px] font-mono uppercase text-text-muted">GPS Centroid</div>
                <div className="text-xs font-mono text-text-primary mt-1">
                  {activeModalGrama.center.lat.toFixed(4)}°N, {activeModalGrama.center.lng.toFixed(4)}°E
                </div>
              </div>
            </div>

            {/* Relief Shelter */}
            <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
              <div className="text-xs font-mono uppercase text-text-muted flex items-center gap-1.5">
                <HeartPulse className="w-4 h-4 text-rose-400" />
                <span>Designated Emergency Relief Shelter Camp</span>
              </div>
              <div className="text-sm font-semibold text-text-primary">
                {activeModalGrama.designatedReliefCamp}
              </div>
              <div className="text-xs text-text-secondary font-mono">
                Official evacuation center with backup satellite mesh communications, solar microgrid, and disaster provisions.
              </div>
            </div>

            {/* Local Areas & Wards List */}
            <div className="space-y-2">
              <div className="text-xs font-mono uppercase text-text-muted flex items-center justify-between">
                <span>Constituent Local Areas, Towns &amp; Wards ({activeModalGrama.localAreas.length})</span>
                <span className="text-[11px] text-primary">All registered SIMs receive SMS</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {activeModalGrama.localAreas.map((area, i) => (
                  <div
                    key={area}
                    className="p-2 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary flex items-center gap-2"
                  >
                    <span className="text-[10px] text-text-muted font-bold">W{i + 1}</span>
                    <span>{area}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-surface-3 flex items-center justify-end gap-3">
              <button
                onClick={() => setActiveModalGrama(null)}
                className="px-4 py-2 rounded-lg bg-surface-2 hover:bg-surface-3 text-xs font-mono text-text-secondary hover:text-text-primary transition"
              >
                Close
              </button>
              <Link
                href={`/admin/weather-ingest?district=${encodeURIComponent(
                  activeModalGrama.districtName
                )}&block=${encodeURIComponent(activeModalGrama.blockName)}&grama=${encodeURIComponent(
                  activeModalGrama.name
                )}&scope=GRAMA_PANCHAYAT`}
                className="px-4 py-2 rounded-lg bg-primary hover:bg-primary-hover text-primary-foreground text-xs font-mono font-bold transition flex items-center gap-1.5 shadow-glow-accent"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Dispatch Calamity Alert to {activeModalGrama.name}</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
