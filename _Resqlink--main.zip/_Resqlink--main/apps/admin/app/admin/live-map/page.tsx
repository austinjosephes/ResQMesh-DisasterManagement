'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Compass,
  ShieldAlert,
  Users,
  Radio,
  LifeBuoy,
  HeartPulse,
  RefreshCw,
  ArrowLeft,
  Filter,
  Layers,
  Globe,
  MapPin,
  Clock,
  Maximize2,
  Navigation,
  Eye,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { KeralaTacticalMap } from '@/components/map/KeralaTacticalMap';
import { CinematicEarth3D } from '@/components/landing/CinematicEarth3D';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function AdminLiveMapPage() {
  const [mapData, setMapData] = useState<any>({
    hazards: [],
    households: [],
    incidents: [],
    rescueTeams: [],
    shelters: [],
  });
  const [selectedDistrict, setSelectedDistrict] = useState('ALL');
  const [viewMode, setViewMode] = useState<'2D_TACTICAL' | '3D_ORBITAL'>('2D_TACTICAL');
  const [radarScanning, setRadarScanning] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedEntity, setSelectedEntity] = useState<any | null>(null);

  const fetchMapData = () => {
    setIsLoading(true);
    fetch(`/api/admin/map-data?district=${selectedDistrict}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) setMapData(data);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchMapData();
  }, [selectedDistrict]);

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] bg-[#07090D] text-[#F5F7FA] overflow-hidden">
      {/* 1. TACTICAL TOP BAR */}
      <div className="h-14 bg-[#0B1017] border-b border-[rgba(255,255,255,0.08)] px-4 flex items-center justify-between gap-4 z-40 shrink-0">
        <div className="flex items-center gap-3">
          <Link
            href="/admin/dashboard"
            className="p-2 rounded-xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
            title="Return to Dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>

          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-[#FF6B35] animate-ping" />
            <h1 className="text-xs sm:text-sm font-extrabold font-mono text-[#F5F7FA] uppercase tracking-wider">
              SATELLITE INTELLIGENCE &bull; KERALA GEOSPATIAL COMMAND
            </h1>
          </div>
        </div>

        {/* 2D / 3D Mode Toggle & District Filter */}
        <div className="flex items-center gap-2.5 text-xs font-mono">
          {/* 2D / 3D Mode Switcher */}
          <div className="flex items-center bg-[#101720] p-1 rounded-xl border border-[rgba(255,255,255,0.08)]">
            <button
              onClick={() => setViewMode('2D_TACTICAL')}
              className={`px-3 py-1 rounded-lg transition flex items-center gap-1.5 cursor-pointer font-bold ${
                viewMode === '2D_TACTICAL'
                  ? 'bg-[#FF6B35] text-[#07090D]'
                  : 'text-[#929CAB] hover:text-[#F5F7FA]'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>2D Tactical</span>
            </button>
            <button
              onClick={() => setViewMode('3D_ORBITAL')}
              className={`px-3 py-1 rounded-lg transition flex items-center gap-1.5 cursor-pointer font-bold ${
                viewMode === '3D_ORBITAL'
                  ? 'bg-[#FF6B35] text-[#07090D]'
                  : 'text-[#929CAB] hover:text-[#F5F7FA]'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>3D Orbital</span>
            </button>
          </div>

          {/* District Selector */}
          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            className="bg-[#101720] text-[#F5F7FA] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-1.5 focus:border-[#FF6B35] focus:outline-none"
          >
            <option value="ALL">All 14 Districts</option>
            {KERALA_DISTRICTS.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name} ({d.nameMl})
              </option>
            ))}
          </select>

          <button
            onClick={fetchMapData}
            disabled={isLoading}
            className="p-2 rounded-xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
            title="Refresh Map Layers"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#FF6B35]' : ''}`} />
          </button>
        </div>
      </div>

      {/* 2. MAIN MAP VIEWPORT */}
      <div className="flex-1 w-full h-full relative overflow-hidden">
        {viewMode === '2D_TACTICAL' ? (
          <div className="w-full h-full relative">
            <KeralaTacticalMap
              hazards={mapData.hazards}
              incidents={mapData.incidents}
              households={mapData.households}
              rescueTeams={mapData.rescueTeams}
              shelters={mapData.shelters}
              selectedDistrict={selectedDistrict}
              onDistrictChange={setSelectedDistrict}
              height="100%"
              interactive={true}
            />

            {/* Subtle Circular Radar Sweep Effect Overlay */}
            {radarScanning && (
              <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-25">
                <div
                  className="w-[180vw] h-[180vw] max-w-[1200px] max-h-[1200px] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#38BDF8]/40 animate-spin"
                  style={{
                    animationDuration: '12s',
                    background: 'conic-gradient(from 0deg at 50% 50%, rgba(56, 189, 248, 0.25) 0deg, transparent 60deg, transparent 360deg)',
                  }}
                />
              </div>
            )}
          </div>
        ) : (
          /* 3D Cinematic Orbital Earth Mode */
          <div className="w-full h-full relative bg-[#07090D]">
            <CinematicEarth3D mode="command" showControls={true} className="w-full h-full" />
          </div>
        )}

        {/* 3. BOTTOM FLOATING TELEMETRY BAR */}
        <div className="absolute bottom-4 left-4 right-4 z-20 pointer-events-none">
          <div className="max-w-4xl mx-auto p-3.5 rounded-2xl bg-[#101720]/90 backdrop-blur-md border border-[rgba(255,255,255,0.08)] shadow-2xl flex flex-wrap items-center justify-between gap-4 pointer-events-auto text-xs font-mono">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5 text-[#EF4444]">
                <ShieldAlert className="w-4 h-4" />
                <span className="font-bold">{mapData.hazards?.length || 0}</span>
                <span className="text-[#929CAB]">Active Hazards</span>
              </div>

              <span className="text-[#6F7C93]">•</span>

              <div className="flex items-center gap-1.5 text-[#38BDF8]">
                <LifeBuoy className="w-4 h-4" />
                <span className="font-bold">{mapData.incidents?.length || 0}</span>
                <span className="text-[#929CAB]">Distress Beacons</span>
              </div>

              <span className="text-[#6F7C93]">•</span>

              <div className="flex items-center gap-1.5 text-[#F5A623]">
                <Layers className="w-4 h-4" />
                <span className="font-bold">{mapData.rescueTeams?.length || 0}</span>
                <span className="text-[#929CAB]">Rescue Teams</span>
              </div>

              <span className="text-[#6F7C93]">•</span>

              <div className="flex items-center gap-1.5 text-[#22C55E]">
                <HeartPulse className="w-4 h-4" />
                <span className="font-bold">{mapData.shelters?.length || 0}</span>
                <span className="text-[#929CAB]">Shelters Ready</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-[#6F7C93]">
              <span>POINT-IN-POLYGON ENGINE: <strong className="text-[#22C55E]">ACTIVE</strong></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
