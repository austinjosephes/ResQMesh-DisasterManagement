'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Radio,
  Bell,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Send,
  WifiOff,
  Phone,
} from 'lucide-react';

export default function AdminNotificationsPage() {
  const [jobs, setJobs] = useState<any[]>([]);
  const [attempts, setAttempts] = useState<any[]>([]);
  const [telemetry, setTelemetry] = useState<any>({
    total: 0,
    delivered: 0,
    submitted: 0,
    failed: 0,
    acknowledged: 0,
  });
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [retryMsg, setRetryMsg] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchTelemetry = () => {
    setIsLoading(true);
    fetch('/api/admin/notifications')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          if (data.jobs) setJobs(data.jobs);
          if (data.attempts) setAttempts(data.attempts);
          if (data.telemetry) setTelemetry(data.telemetry);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchTelemetry();
  }, []);

  const handleRetry = async (attemptId: string) => {
    setRetryingId(attemptId);
    setRetryMsg('');
    try {
      const res = await fetch('/api/admin/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ attemptId }),
      });
      const data = await res.json();
      if (res.ok) {
        setRetryMsg(`Retry executed! Backoff: ${Math.round(data.backoffMs / 1000)}s`);
        fetchTelemetry();
      }
    } catch (e) {
    } finally {
      setRetryingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-amber-400 font-semibold flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-amber-400" />
            <span>Innovation 02</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Adaptive Alert Delivery Intelligence &amp; Telecom Queue
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            Real-time delivery verification, Indian Telecom DLT compliance monitoring, and tower blackout detection.
          </p>
        </div>

        <button
          onClick={fetchTelemetry}
          disabled={isLoading}
          className="px-3 py-2 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-secondary hover:text-text-primary flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-primary' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {retryMsg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400 font-mono">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{retryMsg}</span>
        </div>
      )}

      {/* Telemetry Funnel Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">TOTAL SMS DISPATCHED</span>
          <p className="text-2xl font-bold font-mono text-text-primary">{telemetry.total}</p>
          <p className="text-[10px] text-text-secondary">High-priority carrier queue</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">CONFIRMED DELIVERED</span>
          <p className="text-2xl font-bold font-mono text-emerald-400">{telemetry.delivered}</p>
          <p className="text-[10px] text-text-secondary">Handset delivery receipt verified</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">PENDING / CARRIER QUEUED</span>
          <p className="text-2xl font-bold font-mono text-amber-400">{telemetry.submitted}</p>
          <p className="text-[10px] text-text-secondary">Submitted to radio network</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">DELIVERY BLACKOUTS (FAILED)</span>
          <p className="text-2xl font-bold font-mono text-red-400">{telemetry.failed}</p>
          <p className="text-[10px] text-red-400">Tower collapse or signal absence</p>
        </div>
      </div>

      {/* Delivery Telemetry Log Table */}
      <div className="rounded-xl bg-surface-1 border border-surface-3 overflow-hidden shadow-lg space-y-4">
        <div className="p-4 bg-surface-2/60 border-b border-surface-3 flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            SMS Carrier Telemetry &amp; Delivery Outcomes
          </h3>
          <span className="text-[10px] font-mono text-text-muted">
            Strict Honesty: SUBMITTED ≠ DELIVERED
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface-2 border-b border-surface-3 font-mono text-[11px] text-text-muted">
              <tr>
                <th className="p-3.5">Recipient</th>
                <th className="p-3.5">Phone</th>
                <th className="p-3.5">Gateway / Provider</th>
                <th className="p-3.5">Delivery Status</th>
                <th className="p-3.5">Retries</th>
                <th className="p-3.5">Carrier Diagnostic</th>
                <th className="p-3.5">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-3/50 text-text-secondary">
              {attempts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-text-muted">
                    No notification attempts recorded.
                  </td>
                </tr>
              ) : (
                attempts.map((att) => (
                  <tr key={att.id} className="hover:bg-surface-2/60 transition font-mono">
                    <td className="p-3.5 font-sans font-bold text-text-primary">
                      {att.recipientName || 'Resident'}
                    </td>
                    <td className="p-3.5 text-text-muted">{att.recipientPhone}</td>
                    <td className="p-3.5 text-[11px] text-text-secondary">{att.providerName}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          att.status === 'DELIVERED'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : att.status === 'SUBMITTED'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {att.status}
                      </span>
                    </td>
                    <td className="p-3.5">{att.retryCount}</td>
                    <td className="p-3.5 text-[11px] text-text-muted truncate max-w-[200px]">
                      {att.lastError || att.providerMsgId || 'OK'}
                    </td>
                    <td className="p-3.5">
                      {att.status === 'FAILED' && (
                        <button
                          onClick={() => handleRetry(att.id)}
                          disabled={retryingId === att.id}
                          className="px-2.5 py-1 rounded bg-surface-3 text-primary hover:bg-surface-2 border border-surface-3 text-[10px] font-bold"
                        >
                          {retryingId === att.id ? 'Retrying...' : 'Retry Backoff'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
