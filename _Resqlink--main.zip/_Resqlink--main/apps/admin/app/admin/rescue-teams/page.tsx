'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Layers,
  Radio,
  Plus,
  RefreshCw,
  Phone,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Anchor,
  Compass,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function AdminRescueTeamsPage() {
  const [teams, setTeams] = useState<any[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // New team form state
  const [name, setName] = useState('');
  const [agency, setAgency] = useState('KERALA_FIRE_RESCUE');
  const [district, setDistrict] = useState('Wayanad');
  const [captainName, setCaptainName] = useState('');
  const [phone, setPhone] = useState('+91');
  const [memberCount, setMemberCount] = useState(8);
  const [boatCapacity, setBoatCapacity] = useState(2);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchTeams = () => {
    setIsLoading(true);
    fetch('/api/admin/rescue-teams')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.teams) setTeams(data.teams);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchTeams();
  }, []);

  const handleAddTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/admin/rescue-teams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          agency,
          baseDistrict: district,
          captainName,
          contactPhone: phone,
          memberCount,
          boatCapacity,
        }),
      });
      if (res.ok) {
        setShowAddModal(false);
        fetchTeams();
      }
    } catch (e) {
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-blue-400 font-semibold flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-blue-400" />
            <span>Disaster Response Fleet</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Authorized Rescue Teams &amp; Rosters
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            NDRF, Kerala Fire &amp; Rescue, Fishermen Volunteers (&quot;Kerala&apos;s Own Army&quot;), and Civil Defence units.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Deploy New Team</span>
        </button>
      </div>

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {teams.map((team) => (
          <div
            key={team.id}
            className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4 shadow-lg hover:border-surface-3/80 transition"
          >
            <div className="flex items-start justify-between gap-2 border-b border-surface-3 pb-3">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                  {team.agency}
                </span>
                <h3 className="text-base font-bold text-text-primary mt-1.5">{team.name}</h3>
                <span className="text-xs font-mono text-text-muted">Code: {team.teamCode}</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  team.status === 'AVAILABLE'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : team.status === 'DISPATCHED'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    : 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                }`}
              >
                {team.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-2.5 rounded bg-surface-2 border border-surface-3 space-y-0.5">
                <span className="text-[10px] text-text-muted">BASE DISTRICT</span>
                <p className="font-bold text-text-primary">{team.baseDistrict}</p>
              </div>
              <div className="p-2.5 rounded bg-surface-2 border border-surface-3 space-y-0.5">
                <span className="text-[10px] text-text-muted">RESCUE BOATS</span>
                <p className="font-bold text-primary">{team.boatCapacity} Crafts</p>
              </div>
              <div className="p-2.5 rounded bg-surface-2 border border-surface-3 space-y-0.5">
                <span className="text-[10px] text-text-muted">PERSONNEL</span>
                <p className="font-bold text-text-primary">{team.memberCount} Responders</p>
              </div>
              <div className="p-2.5 rounded bg-surface-2 border border-surface-3 space-y-0.5">
                <span className="text-[10px] text-text-muted">MEDICAL EQUIPMENT</span>
                <p className="font-bold text-emerald-400">
                  {team.hasMedicalKit ? 'TRAUMA KIT READY' : 'NONE'}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-text-secondary pt-1 border-t border-surface-3">
              <span>Leader: {team.captainName}</span>
              <span className="font-mono text-primary flex items-center gap-1">
                <Phone className="w-3 h-3" />
                {team.contactPhone}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Team Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-surface-1 border border-surface-3 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-text-primary">Deploy New Rescue Unit</h3>
            <form onSubmit={handleAddTeam} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-text-muted">Team Name:</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. SDRF Special Mountain Rescue Flotilla"
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-text-muted">Agency:</label>
                  <select
                    value={agency}
                    onChange={(e) => setAgency(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  >
                    <option value="NDRF">NDRF</option>
                    <option value="KERALA_FIRE_RESCUE">KERALA FIRE &amp; RESCUE</option>
                    <option value="FISHERMEN_VOLUNTEERS">FISHERMEN VOLUNTEERS</option>
                    <option value="COAST_GUARD">COAST GUARD</option>
                    <option value="CIVIL_DEFENCE">CIVIL DEFENCE</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-text-muted">Base District:</label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                  >
                    {KERALA_DISTRICTS.map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-text-muted">Captain / Leader:</label>
                  <input
                    type="text"
                    required
                    value={captainName}
                    onChange={(e) => setCaptainName(e.target.value)}
                    placeholder="Officer Name"
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-text-muted">Contact Phone:</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-text-muted">Member Count:</label>
                  <input
                    type="number"
                    min={1}
                    value={memberCount}
                    onChange={(e) => setMemberCount(parseInt(e.target.value) || 1)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-text-muted">Rescue Boats:</label>
                  <input
                    type="number"
                    min={0}
                    value={boatCapacity}
                    onChange={(e) => setBoatCapacity(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase"
                >
                  {isSubmitting ? 'Registering...' : 'Register Team'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-lg bg-surface-2 text-text-secondary text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
