'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Users,
  ShieldAlert,
  MapPin,
  HeartPulse,
  Filter,
  Search,
  CheckCircle2,
  AlertTriangle,
  Download,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function AdminResidentsTwinPage() {
  const [households, setHouseholds] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({
    totalHouseholds: 0,
    exposedCount: 0,
    exposedResidentsCount: 0,
    vulnerableCount: 0,
    exposurePercentage: 0,
  });
  const [selectedDistrict, setSelectedDistrict] = useState('ALL');
  const [exposureFilter, setExposureFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchResidents = () => {
    setIsLoading(true);
    fetch(`/api/admin/residents?district=${selectedDistrict}&exposure=${exposureFilter}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          setHouseholds(data.households || []);
          if (data.summary) setSummary(data.summary);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchResidents();
  }, [selectedDistrict, exposureFilter]);

  const filteredList = households.filter((h) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      h.name.toLowerCase().includes(q) ||
      h.address.toLowerCase().includes(q) ||
      h.district.toLowerCase().includes(q) ||
      (h.localBody && h.localBody.toLowerCase().includes(q))
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
          <Users className="w-4 h-4 text-primary" />
          <span>Innovation 01</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Resident Risk Digital Twin &amp; Exposure Engine
        </h1>
        <p className="text-xs text-text-secondary mt-1">
          Real-time point-in-polygon matching of registered households against active IMD &amp; KSDMA hazard warning polygons.
        </p>
      </div>

      {/* Aggregate Exposure KPI Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">TOTAL REGISTERED HOMES</span>
          <p className="text-2xl font-bold font-mono text-text-primary">{summary.totalHouseholds}</p>
          <p className="text-[10px] text-text-secondary">Across Kerala districts</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">EXPOSED IN WARNING ZONES</span>
          <p className="text-2xl font-bold font-mono text-red-400">
            {summary.exposedCount} ({summary.exposurePercentage}%)
          </p>
          <p className="text-[10px] text-text-secondary">Intersecting hazard polygons</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">ESTIMATED CITIZENS AT RISK</span>
          <p className="text-2xl font-bold font-mono text-amber-400">
            {summary.exposedResidentsCount} Persons
          </p>
          <p className="text-[10px] text-text-secondary">From registered household sizes</p>
        </div>

        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 space-y-1">
          <span className="text-[11px] font-mono text-text-muted">CRITICAL EVACUATION SUPPORT</span>
          <p className="text-2xl font-bold font-mono text-primary">{summary.vulnerableCount}</p>
          <p className="text-[10px] text-text-secondary">Elderly, infants, wheelchair, oxygen</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-surface-1 p-3.5 rounded-xl border border-surface-3 text-xs">
        <div className="flex items-center gap-2.5 flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-text-muted" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search resident, landmark, local body, ward..."
            className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-1.5 text-text-primary focus:border-primary focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            className="bg-surface-2 border border-surface-3 rounded-lg px-2.5 py-1.5 text-text-primary font-sans"
          >
            <option value="ALL">All Kerala Districts</option>
            {KERALA_DISTRICTS.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={exposureFilter}
            onChange={(e) => setExposureFilter(e.target.value)}
            className="bg-surface-2 border border-surface-3 rounded-lg px-2.5 py-1.5 text-text-primary font-mono"
          >
            <option value="all">All Exposure States</option>
            <option value="exposed">Exposed Only (In Polygon)</option>
            <option value="safe">Safe (Outside Polygon)</option>
          </select>
        </div>
      </div>

      {/* Residents Registry Table */}
      <div className="rounded-xl bg-surface-1 border border-surface-3 overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-surface-2 border-b border-surface-3 font-mono text-[11px] text-text-muted">
              <tr>
                <th className="p-3.5">Resident / Household</th>
                <th className="p-3.5">District / Ward</th>
                <th className="p-3.5">GPS Coordinates</th>
                <th className="p-3.5">Digital Twin Status</th>
                <th className="p-3.5">Evacuation Constraints</th>
                <th className="p-3.5">Contact Method</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-3/50 text-text-secondary">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-text-muted">
                    No matching household records found.
                  </td>
                </tr>
              ) : (
                filteredList.map((hh) => (
                  <tr key={hh.id} className="hover:bg-surface-2/60 transition">
                    <td className="p-3.5">
                      <p className="font-bold text-text-primary">{hh.name}</p>
                      <p className="text-[11px] text-text-muted truncate max-w-[200px]">
                        {hh.address}
                      </p>
                    </td>

                    <td className="p-3.5 font-mono">
                      <p className="text-text-primary font-semibold">{hh.district}</p>
                      <p className="text-[10px] text-text-muted">
                        {hh.localBody ? `${hh.localBody}, ` : ''}
                        {hh.ward || ''}
                      </p>
                    </td>

                    <td className="p-3.5 font-mono text-[11px]">
                      {hh.latitude.toFixed(4)}, {hh.longitude.toFixed(4)}
                    </td>

                    <td className="p-3.5">
                      {hh.isExposed ? (
                        <div className="space-y-1">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-500/20 text-red-400 border border-red-500/40">
                            <AlertTriangle className="w-3 h-3" />
                            EXPOSED ({hh.matchingSeverity})
                          </span>
                          <p className="text-[10px] text-text-muted truncate max-w-[220px]">
                            {hh.matchingAlertHeadline}
                          </p>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" />
                          SAFE CONTOUR
                        </span>
                      )}
                    </td>

                    <td className="p-3.5">
                      {hh.requiresEvacuationAssist || hh.hasElderly || hh.hasDisabilities ? (
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-mono text-amber-400 font-bold">
                            ASSIST REQUIRED ({hh.householdSize} ppl)
                          </span>
                          <p className="text-[10px] text-text-muted truncate max-w-[180px]">
                            {hh.medicalNeedsSummary || 'Elderly / mobility support flagged'}
                          </p>
                        </div>
                      ) : (
                        <span className="text-[11px] text-text-muted">Standard ({hh.householdSize} ppl)</span>
                      )}
                    </td>

                    <td className="p-3.5 font-mono text-[11px] text-text-primary">
                      {hh.phone}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
