'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Sliders, Radio, ShieldAlert, CheckCircle2, Lock, Server } from 'lucide-react';

export default function AdminSettingsPage() {
  const [capFeedUrl, setCapFeedUrl] = useState('https://sdma.kerala.gov.in/feed/cap-v1.2.xml');
  const [telecomGateway, setTelecomGateway] = useState('AIRTEL_KERALA_DLT_EMERGENCY');
  const [maxRetryCount, setMaxRetryCount] = useState(3);
  const [msg, setMsg] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('System parameters and integration adapter settings saved.');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
          <Sliders className="w-4 h-4 text-primary" />
          <span>System Administration</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Disaster Platform Configuration
        </h1>
      </div>

      {msg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{msg}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-primary" />
            <span>Official Hazard Warning Ingestion Feed (CAP v1.2)</span>
          </h3>
          <div className="space-y-1 text-xs">
            <label className="font-mono text-text-muted">KSDMA / IMD OASIS CAP XML Endpoint</label>
            <input
              type="url"
              value={capFeedUrl}
              onChange={(e) => setCapFeedUrl(e.target.value)}
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary font-mono focus:border-primary"
            />
          </div>
        </div>

        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
            <Radio className="w-4 h-4 text-amber-400" />
            <span>Telecom DLT Emergency SMS Gateway</span>
          </h3>
          <div className="grid grid-cols-2 gap-4 text-xs font-mono">
            <div className="space-y-1">
              <label className="text-text-muted">Carrier Gateway Adapter:</label>
              <select
                value={telecomGateway}
                onChange={(e) => setTelecomGateway(e.target.value)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary"
              >
                <option value="AIRTEL_KERALA_DLT_EMERGENCY">Airtel Kerala Circle (DLT Direct)</option>
                <option value="BSNL_KERALA_CIRCLE">BSNL Kerala High-Priority Gov Pool</option>
                <option value="JIO_EMERGENCY_ROUTER">Jio Disaster Broadcast Router</option>
                <option value="SIMULATED_DEV_ADAPTER">Simulated Development Adapter</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-text-muted">Max Exponential Retries:</label>
              <input
                type="number"
                min={1}
                max={5}
                value={maxRetryCount}
                onChange={(e) => setMaxRetryCount(parseInt(e.target.value) || 3)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="px-6 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan"
        >
          Save Configuration
        </button>
      </form>
    </div>
  );
}
