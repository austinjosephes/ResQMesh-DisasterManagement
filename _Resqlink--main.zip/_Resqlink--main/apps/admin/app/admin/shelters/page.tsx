'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  HeartPulse,
  Plus,
  RefreshCw,
  Phone,
  CheckCircle2,
  Users,
  Compass,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function AdminSheltersPage() {
  const [shelters, setShelters] = useState<any[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [district, setDistrict] = useState('Wayanad');
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [capacity, setCapacity] = useState(400);
  const [inCharge, setInCharge] = useState('');
  const [phone, setPhone] = useState('+91');
  const [isLoading, setIsLoading] = useState(true);

  const fetchShelters = () => {
    setIsLoading(true);
    fetch('/api/admin/shelters')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.shelters) setShelters(data.shelters);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchShelters();
  }, []);

  const handleAddShelter = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const distInfo = KERALA_DISTRICTS.find((d) => d.name === district);
      const res = await fetch('/api/admin/shelters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          district,
          address,
          totalCapacity: capacity,
          inChargeName: inCharge,
          inChargePhone: phone,
          latitude: distInfo?.center.lat || 11.558,
          longitude: distInfo?.center.lng || 76.131,
        }),
      });
      if (res.ok) {
        setShowAddModal(false);
        fetchShelters();
      }
    } catch (e) {}
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-emerald-400 font-semibold flex items-center gap-1.5">
            <HeartPulse className="w-4 h-4 text-emerald-400" />
            <span>Evacuation Infrastructure</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Relief Camps &amp; Emergency Shelters
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            Live capacity tracking, food stock duration, and medical post readiness across Kerala districts.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Shelter Camp</span>
        </button>
      </div>

      {/* Shelters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {shelters.map((s) => {
          const occupancyPct = Math.round((s.currentOccupacy / s.totalCapacity) * 100);

          return (
            <div
              key={s.id}
              className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4 shadow-lg hover:border-surface-3/80 transition"
            >
              <div className="flex items-start justify-between gap-2 border-b border-surface-3 pb-3">
                <div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                    {s.district} DISTRICT
                  </span>
                  <h3 className="text-base font-bold text-text-primary mt-1.5">{s.name}</h3>
                  <p className="text-xs text-text-muted">{s.address}</p>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400">
                  {s.status}
                </span>
              </div>

              {/* Occupancy Progress */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-text-muted">CAMP OCCUPANCY</span>
                  <span className="text-text-primary font-bold">
                    {s.currentOccupacy} / {s.totalCapacity} ({occupancyPct}%)
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      occupancyPct > 80 ? 'bg-red-500' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, occupancyPct)}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                <div className="p-2 rounded bg-surface-2 border border-surface-3">
                  <span className="text-[9px] text-text-muted">POWER BACKUP</span>
                  <p className="font-bold text-emerald-400">{s.hasPowerBackup ? 'YES' : 'NO'}</p>
                </div>
                <div className="p-2 rounded bg-surface-2 border border-surface-3">
                  <span className="text-[9px] text-text-muted">MEDICAL POST</span>
                  <p className="font-bold text-primary">{s.hasMedicalPost ? 'ACTIVE' : 'NONE'}</p>
                </div>
                <div className="p-2 rounded bg-surface-2 border border-surface-3">
                  <span className="text-[9px] text-text-muted">FOOD STOCKS</span>
                  <p className="font-bold text-text-primary">{s.foodStockDays} Days</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-text-secondary pt-1 border-t border-surface-3">
                <span>In-Charge: {s.inChargeName}</span>
                <span className="font-mono text-primary flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  {s.inChargePhone}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Shelter Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-surface-1 border border-surface-3 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-text-primary">Add New Relief Shelter Camp</h3>
            <form onSubmit={handleAddShelter} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-text-muted">Shelter Name:</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Government Higher Secondary School Camp"
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-text-muted">District:</label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                  >
                    {KERALA_DISTRICTS.map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-text-muted">Max Capacity:</label>
                  <input
                    type="number"
                    min={50}
                    value={capacity}
                    onChange={(e) => setCapacity(parseInt(e.target.value) || 100)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-text-muted">Address &amp; Landmark:</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-text-muted">Camp Officer:</label>
                  <input
                    type="text"
                    required
                    value={inCharge}
                    onChange={(e) => setInCharge(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary font-sans"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-text-muted">Contact Phone:</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-surface-2 border border-surface-3 rounded p-2 text-text-primary"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase"
                >
                  Save Shelter
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-lg bg-surface-2 text-text-secondary text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
