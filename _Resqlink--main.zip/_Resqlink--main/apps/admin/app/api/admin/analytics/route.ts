import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export async function GET() {
  try {
    const [alerts, sosList, attempts, teams, shelters] = await Promise.all([
      prisma.hazardAlert.findMany(),
      prisma.sOSRequest.findMany(),
      prisma.notificationAttempt.findMany(),
      prisma.rescueTeam.findMany(),
      prisma.shelter.findMany(),
    ]);

    // 1. Alerts by Hazard Category
    const hazardCounts: Record<string, number> = {};
    for (const a of alerts) {
      hazardCounts[a.hazardType] = (hazardCounts[a.hazardType] || 0) + 1;
    }
    const alertsByCategory = Object.entries(hazardCounts).map(([category, count]) => ({
      category,
      count,
    }));

    // 2. Incident counts by District
    const districtCounts: Record<string, number> = {};
    for (const s of sosList) {
      const dist = s.district || 'Wayanad';
      districtCounts[dist] = (districtCounts[dist] || 0) + 1;
    }
    const incidentsByDistrict = KERALA_DISTRICTS.map((d) => ({
      district: d.name,
      districtMl: d.nameMl,
      count: districtCounts[d.name] || 0,
    })).sort((a, b) => b.count - a.count);

    // 3. Notification Delivery Outcomes Funnel
    const outcomeCounts = {
      SUBMITTED: 0,
      DELIVERED: 0,
      FAILED: 0,
      ACKNOWLEDGED: 0,
    };
    for (const att of attempts) {
      if (att.status in outcomeCounts) {
        outcomeCounts[att.status as keyof typeof outcomeCounts]++;
      }
    }
    const deliveryFunnel = [
      { status: 'Submitted to Carrier', count: outcomeCounts.SUBMITTED + outcomeCounts.DELIVERED },
      { status: 'Confirmed Delivered', count: outcomeCounts.DELIVERED },
      { status: 'Acknowledged / Read', count: outcomeCounts.ACKNOWLEDGED || 1 },
      { status: 'Carrier Failures (Blackouts)', count: outcomeCounts.FAILED },
    ];

    // 4. Incident Status Breakdown
    const statusCounts: Record<string, number> = {};
    for (const s of sosList) {
      statusCounts[s.status] = (statusCounts[s.status] || 0) + 1;
    }
    const statusBreakdown = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
    }));

    return NextResponse.json({
      alertsByCategory,
      incidentsByDistrict,
      deliveryFunnel,
      statusBreakdown,
      totals: {
        totalAlerts: alerts.length,
        totalSos: sosList.length,
        totalNotifications: attempts.length,
        totalRescueTeams: teams.length,
        totalShelters: shelters.length,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
