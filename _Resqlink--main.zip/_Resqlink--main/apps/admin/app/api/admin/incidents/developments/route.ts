import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      requestId,
      trackingNumber,
      status,
      assignedTeamName,
      assignedReliefCamp,
      etaMinutes,
      adminMessage,
      responderNotes,
    } = body;

    if (!requestId && !trackingNumber) {
      return NextResponse.json({ error: 'Request ID or tracking number is required' }, { status: 400 });
    }

    // Find the SOS request
    const existing = await prisma.sOSRequest.findFirst({
      where: requestId ? { id: requestId } : { trackingNumber },
      include: { user: true },
    });

    if (!existing) {
      return NextResponse.json({ error: 'Incident / SOS request not found' }, { status: 404 });
    }

    const updatedData: any = {};
    if (status) updatedData.status = status;
    if (assignedTeamName) updatedData.assignedTeamName = assignedTeamName;
    if (assignedReliefCamp) updatedData.assignedReliefCamp = assignedReliefCamp;
    if (typeof etaMinutes === 'number') updatedData.etaMinutes = etaMinutes;
    if (responderNotes) updatedData.responderNotes = responderNotes;

    // Direct message from Admin to Resident
    if (adminMessage && adminMessage.trim().length > 0) {
      updatedData.adminMessage = adminMessage.trim();
      updatedData.adminMessageSentAt = new Date();
      updatedData.userMessageAckAt = null; // Reset user ACK until resident confirms receipt
    }

    const updated = await prisma.sOSRequest.update({
      where: { id: existing.id },
      data: updatedData,
    });

    // If an admin message was sent, dispatch an emergency carrier SMS notification record to respective phone
    const rawPhone = existing.phone || existing.user?.phone || '+919447100004';
    const cleanPhone = rawPhone.trim().replace(/\s+/g, '');
    const recipientPhone = cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}`;

    if (adminMessage && adminMessage.trim().length > 0) {
      let job = await prisma.notificationJob.findFirst({
        where: { targetDistrict: existing.district || 'Wayanad' },
      });

      if (!job) {
        let dummyAlert = await prisma.hazardAlert.findFirst();
        if (!dummyAlert) {
          dummyAlert = await prisma.hazardAlert.create({
            data: {
              source: 'SEOC_DIRECT_DISPATCH',
              hazardType: 'RESCUE_DIRECTIVE',
              severity: 'EMERGENCY',
              headline: 'SEOC Emergency Directive Broadcast',
              description: 'Official rescue directives issued to resident handset',
              instruction: 'Follow tactical directives from emergency personnel',
              affectedDistrict: existing.district || 'Wayanad',
              polygonGeoJson: '{"type":"Polygon","coordinates":[[[76.0,11.5],[76.2,11.5],[76.2,11.7],[76.0,11.7],[76.0,11.5]]]}',
              effectiveAt: new Date(),
              expiresAt: new Date(Date.now() + 86400000),
            },
          });
        }
        job = await prisma.notificationJob.create({
          data: {
            alertId: dummyAlert.id,
            targetDistrict: existing.district || 'Wayanad',
            channel: 'SMS',
            totalMatched: 1,
            successfulCount: 1,
          },
        });
      }

      await prisma.notificationAttempt.create({
        data: {
          jobId: job.id,
          recipientPhone,
          recipientName: existing.user?.name || `Resident (${recipientPhone.slice(-4)})`,
          messageBody: `[VK-KSDMA] OFFICIAL DIRECTIVE: ${adminMessage.trim()}${
            etaMinutes ? ` (ETA: ~${etaMinutes} mins)` : ''
          }${assignedTeamName ? ` | Team: ${assignedTeamName}` : ''} | Ref #${existing.trackingNumber}`,
          dltTemplateId: 'DLT_KL_RESCUE_DIRECTIVE_1002',
          providerName: 'BSNL_AIRTEL_TELECOM_GATEWAY',
          providerMsgId: `TEL-DIR-${Date.now().toString().slice(-6)}`,
          status: 'DELIVERED',
          deliveredAt: new Date(),
        },
      });
    }

    // Append audit log
    await appendAuditLog({
      actor: 'SEOC_DUTY_COMMAND',
      action: 'incident.operational_development',
      resource: `sos:${existing.id}`,
      outcome: 'SUCCESS',
      reason: `Admin updated status to ${status || existing.status}. Assigned team: ${
        assignedTeamName || 'N/A'
      }. Message sent: ${adminMessage ? 'YES' : 'NO'}`,
    });

    return NextResponse.json({
      success: true,
      message: 'Operational development saved and forwarded to resident handset',
      incident: updated,
    });
  } catch (error: any) {
    console.error('Incident development error:', error);
    return NextResponse.json({ error: error.message || 'Failed to update incident' }, { status: 500 });
  }
}
