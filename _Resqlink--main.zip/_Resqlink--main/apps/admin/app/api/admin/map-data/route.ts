import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkHazardExposure } from '@/lib/geospatial';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const districtFilter = searchParams.get('district');

    const [alerts, households, sosList, teams, shelters] = await Promise.all([
      prisma.hazardAlert.findMany({
        where: {
          status: 'ACTIVE',
          affectedDistrict: districtFilter && districtFilter !== 'ALL' ? districtFilter : undefined,
        },
      }),
      prisma.residentProfile.findMany({
        where:
          districtFilter && districtFilter !== 'ALL'
            ? { registeredDistrict: districtFilter }
            : undefined,
      }),
      prisma.sOSRequest.findMany({
        where: {
          status: { notIn: ['CLOSED'] },
          district: districtFilter && districtFilter !== 'ALL' ? districtFilter : undefined,
        },
      }),
      prisma.rescueTeam.findMany({
        where:
          districtFilter && districtFilter !== 'ALL'
            ? { baseDistrict: districtFilter }
            : undefined,
      }),
      prisma.shelter.findMany({
        where:
          districtFilter && districtFilter !== 'ALL'
            ? { district: districtFilter }
            : undefined,
      }),
    ]);

    // Parse hazard polygons
    const hazardLayers = alerts.map((a) => {
      let polygon: [number, number][] = [];
      try {
        const geo = JSON.parse(a.polygonGeoJson);
        if (geo.type === 'Polygon' && geo.coordinates && geo.coordinates[0]) {
          polygon = geo.coordinates[0];
        }
      } catch (e) {}

      return {
        id: a.id,
        district: a.affectedDistrict,
        hazardType: a.hazardType,
        severity: a.severity,
        headline: a.headline,
        source: a.source,
        polygon,
      };
    });

    // Evaluate household exposure (Digital Twin)
    const householdLayers = households.map((hh) => {
      let isExposed = false;
      for (const alert of alerts) {
        if (checkHazardExposure({ lat: hh.latitude, lng: hh.longitude }, alert.polygonGeoJson)) {
          isExposed = true;
          break;
        }
      }
      return {
        id: hh.id,
        district: hh.registeredDistrict,
        latitude: hh.latitude,
        longitude: hh.longitude,
        householdSize: hh.householdSize,
        requiresEvacuationAssist: hh.requiresEvacuationAssist || hh.hasElderly || hh.hasDisabilities,
        isExposed,
        address: hh.registeredAddress,
      };
    });

    // Format SOS incident pins
    const incidentLayers = sosList
      .filter((s) => s.latitude && s.longitude)
      .map((s) => ({
        id: s.id,
        trackingNumber: s.trackingNumber,
        category: s.category,
        priorityCategory: s.priorityCategory,
        priorityScore: s.priorityScore,
        peopleCount: s.peopleCount,
        district: s.district || 'Wayanad',
        latitude: s.latitude!,
        longitude: s.longitude!,
        address: s.address || '',
        description: s.description,
        status: s.status,
        hasInjuries: s.hasInjuries,
        assignedTeamName: s.assignedTeamName,
      }));

    // Format rescue teams
    const teamLayers = teams
      .filter((t) => t.currentLatitude && t.currentLongitude)
      .map((t) => ({
        id: t.id,
        name: t.name,
        agency: t.agency,
        baseDistrict: t.baseDistrict,
        captainName: t.captainName,
        status: t.status,
        latitude: t.currentLatitude!,
        longitude: t.currentLongitude!,
        boatCapacity: t.boatCapacity,
        contactPhone: t.contactPhone,
      }));

    // Format shelters
    const shelterLayers = shelters.map((s) => ({
      id: s.id,
      name: s.name,
      district: s.district,
      totalCapacity: s.totalCapacity,
      currentOccupacy: s.currentOccupacy,
      latitude: s.latitude,
      longitude: s.longitude,
      inChargeName: s.inChargeName,
      inChargePhone: s.inChargePhone,
      status: s.status,
      foodStockDays: s.foodStockDays,
    }));

    return NextResponse.json({
      hazards: hazardLayers,
      households: householdLayers,
      incidents: incidentLayers,
      rescueTeams: teamLayers,
      shelters: shelterLayers,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
