import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { defaultSmsProvider, getRetryBackoffMs } from '@/lib/sms-adapter';
import { appendAuditLog } from '@/lib/audit';

export async function GET() {
  try {
    const [jobs, attempts] = await Promise.all([
      prisma.notificationJob.findMany({
        orderBy: { createdAt: 'desc' },
        include: { alert: true },
      }),
      prisma.notificationAttempt.findMany({
        orderBy: { submittedAt: 'desc' },
        take: 50,
      }),
    ]);

    const delivered = attempts.filter((a) => a.status === 'DELIVERED').length;
    const submitted = attempts.filter((a) => a.status === 'SUBMITTED').length;
    const failed = attempts.filter((a) => a.status === 'FAILED').length;
    const acknowledged = attempts.filter((a) => a.status === 'ACKNOWLEDGED').length;

    return NextResponse.json({
      jobs,
      attempts,
      telemetry: {
        total: attempts.length,
        delivered,
        submitted,
        failed,
        acknowledged,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}

// POST endpoint to trigger retry for failed notification attempts
export async function POST(req: Request) {
  try {
    const { attemptId } = await req.json();

    const attempt = await prisma.notificationAttempt.findUnique({
      where: { id: attemptId },
    });

    if (!attempt) {
      return NextResponse.json({ error: 'Attempt not found' }, { status: 404 });
    }

    // Calculate backoff
    const nextRetry = attempt.retryCount + 1;
    const backoffMs = getRetryBackoffMs(attempt.retryCount);

    const result = await defaultSmsProvider.send(attempt.recipientPhone, attempt.messageBody, {
      dltTemplateId: attempt.dltTemplateId || undefined,
    });

    const updated = await prisma.notificationAttempt.update({
      where: { id: attempt.id },
      data: {
        status: result.status,
        retryCount: nextRetry,
        providerMsgId: result.providerMsgId,
        lastError: result.error || null,
        deliveredAt: result.status === 'DELIVERED' ? new Date() : null,
      },
    });

    await appendAuditLog({
      actor: 'ADMIN_NOTIFICATIONS_QUEUE',
      action: 'notification.retry.dispatched',
      resource: `attempt:${attempt.id}`,
      outcome: result.success ? 'SUCCESS' : 'FAILURE',
      reason: `Retried SMS delivery to ${attempt.recipientPhone} (Attempt #${nextRetry})`,
    });

    return NextResponse.json({
      success: result.success,
      attempt: updated,
      backoffMs,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Retry failed' }, { status: 500 });
  }
}
