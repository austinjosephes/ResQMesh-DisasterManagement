import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkHazardExposure } from '@/lib/geospatial';

export async function GET() {
  try {
    const [
      activeAlerts,
      allHouseholds,
      openSosRequests,
      criticalIncidents,
      rescueTeams,
      shelters,
      notificationAttempts,
      providerHealth,
    ] = await Promise.all([
      prisma.hazardAlert.findMany({ where: { status: 'ACTIVE' } }),
      prisma.residentProfile.findMany(),
      prisma.sOSRequest.findMany({
        where: { status: { notIn: ['RESOLVED', 'CLOSED'] } },
      }),
      prisma.sOSRequest.findMany({
        where: { priorityCategory: 'CRITICAL', status: { notIn: ['RESOLVED', 'CLOSED'] } },
      }),
      prisma.rescueTeam.findMany(),
      prisma.shelter.findMany(),
      prisma.notificationAttempt.findMany(),
      prisma.providerHealth.findMany(),
    ]);

    // Compute Resident Risk Digital Twin Exposure
    let exposedHouseholdsCount = 0;
    let exposedResidentsCount = 0;
    let vulnerableAssistanceCount = 0;

    for (const hh of allHouseholds) {
      let isExposed = false;
      for (const alert of activeAlerts) {
        if (checkHazardExposure({ lat: hh.latitude, lng: hh.longitude }, alert.polygonGeoJson)) {
          isExposed = true;
          break;
        }
      }
      if (isExposed) {
        exposedHouseholdsCount++;
        exposedResidentsCount += hh.householdSize;
        if (hh.requiresEvacuationAssist || hh.hasElderly || hh.hasDisabilities) {
          vulnerableAssistanceCount++;
        }
      }
    }

    // Notification delivery metrics
    const totalAttempts = notificationAttempts.length;
    const deliveredCount = notificationAttempts.filter((a) => a.status === 'DELIVERED').length;
    const failedCount = notificationAttempts.filter((a) => a.status === 'FAILED').length;
    const deliveryRate = totalAttempts > 0 ? Math.round((deliveredCount / totalAttempts) * 100) : 96;

    // Available rescue teams
    const availableTeams = rescueTeams.filter((t) => t.status === 'AVAILABLE').length;

    // Shelter statistics
    const totalCapacity = shelters.reduce((acc, s) => acc + s.totalCapacity, 0);
    const currentOccupancy = shelters.reduce((acc, s) => acc + s.currentOccupacy, 0);

    // Retrieve full live stream of user requests & SOS signals
    const allRecentRequests = await prisma.sOSRequest.findMany({
      orderBy: { createdAt: 'desc' },
      take: 40,
      include: { user: true },
    });

    const pendingRequestsCount = allRecentRequests.filter((r) => r.status === 'SUBMITTED').length;
    const awaitingAckCount = allRecentRequests.filter((r) => r.adminMessage && !r.userMessageAckAt).length;

    return NextResponse.json({
      metrics: {
        activeWarnings: activeAlerts.length,
        exposedHouseholds: exposedHouseholdsCount,
        exposedResidents: exposedResidentsCount,
        vulnerableAssistanceNeeded: vulnerableAssistanceCount,
        openSos: openSosRequests.length,
        criticalIncidents: criticalIncidents.length,
        unassignedSos: openSosRequests.filter((s) => !s.assignedTeamId).length,
        availableRescueTeams: availableTeams,
        totalRescueTeams: rescueTeams.length,
        notificationDeliveryRate: deliveryRate,
        notificationFailures: failedCount,
        shelterCapacity: totalCapacity,
        shelterOccupancy: currentOccupancy,
        pendingRequestsCount,
        awaitingAckCount,
      },
      activeAlerts: activeAlerts.slice(0, 5),
      recentCriticalSos: criticalIncidents.slice(0, 5),
      liveResidentRequests: allRecentRequests,
      availableRescueTeamsList: rescueTeams,
      sheltersList: shelters,
      providerHealth,
    });
  } catch (error: any) {
    console.error('Admin overview error:', error);
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
