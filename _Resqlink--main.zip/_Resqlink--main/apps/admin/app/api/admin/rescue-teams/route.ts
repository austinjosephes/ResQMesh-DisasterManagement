import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET() {
  try {
    const teams = await prisma.rescueTeam.findMany({
      orderBy: { agency: 'asc' },
      include: {
        assignments: {
          include: { incident: true },
        },
        members: {
          include: { user: true },
        },
      },
    });

    return NextResponse.json({ teams });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const body = await req.json();
    const {
      name,
      agency = 'KERALA_FIRE_RESCUE',
      baseDistrict = 'Wayanad',
      contactPhone,
      captainName,
      memberCount = 6,
      boatCapacity = 0,
      hasMedicalKit = true,
      currentLatitude,
      currentLongitude,
    } = body;

    const teamCode = `${agency}-${baseDistrict.substring(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const team = await prisma.rescueTeam.create({
      data: {
        teamCode,
        name,
        agency,
        baseDistrict,
        contactPhone: contactPhone || '+919447000000',
        captainName: captainName || 'Team Leader',
        memberCount: Number(memberCount) || 6,
        boatCapacity: Number(boatCapacity) || 0,
        hasMedicalKit: Boolean(hasMedicalKit),
        currentLatitude: typeof currentLatitude === 'number' ? currentLatitude : 11.5545,
        currentLongitude: typeof currentLongitude === 'number' ? currentLongitude : 76.1285,
        status: 'AVAILABLE',
      },
    });

    return NextResponse.json({ success: true, team }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create team' }, { status: 500 });
  }
}
