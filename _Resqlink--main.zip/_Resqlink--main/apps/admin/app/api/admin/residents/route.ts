import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkHazardExposure } from '@/lib/geospatial';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const districtFilter = searchParams.get('district');
    const exposureFilter = searchParams.get('exposure'); // 'all', 'exposed', 'safe'

    const [alerts, households] = await Promise.all([
      prisma.hazardAlert.findMany({ where: { status: 'ACTIVE' } }),
      prisma.residentProfile.findMany({
        where:
          districtFilter && districtFilter !== 'ALL'
            ? { registeredDistrict: districtFilter }
            : undefined,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
              preferredLanguage: true,
            },
          },
        },
      }),
    ]);

    // Map exposure for each household
    const mappedHouseholds = households.map((hh) => {
      let isExposed = false;
      let matchingAlertHeadline = null;
      let matchingSeverity = null;

      for (const alert of alerts) {
        if (checkHazardExposure({ lat: hh.latitude, lng: hh.longitude }, alert.polygonGeoJson)) {
          isExposed = true;
          matchingAlertHeadline = alert.headline;
          matchingSeverity = alert.severity;
          break;
        }
      }

      return {
        id: hh.id,
        userId: hh.userId,
        name: hh.user?.name || 'Resident',
        phone: hh.user?.phone || 'N/A',
        district: hh.registeredDistrict,
        localBody: hh.registeredLocalBody,
        ward: hh.registeredWard,
        address: hh.registeredAddress,
        latitude: hh.latitude,
        longitude: hh.longitude,
        householdSize: hh.householdSize,
        hasElderly: hh.hasElderly,
        hasInfants: hh.hasInfants,
        hasDisabilities: hh.hasDisabilities,
        requiresEvacuationAssist: hh.requiresEvacuationAssist,
        medicalNeedsSummary: hh.medicalNeedsSummary,
        isExposed,
        matchingAlertHeadline,
        matchingSeverity,
      };
    });

    const filtered = mappedHouseholds.filter((hh) => {
      if (exposureFilter === 'exposed') return hh.isExposed;
      if (exposureFilter === 'safe') return !hh.isExposed;
      return true;
    });

    const totalHouseholds = mappedHouseholds.length;
    const exposedCount = mappedHouseholds.filter((h) => h.isExposed).length;
    const exposedResidentsCount = mappedHouseholds
      .filter((h) => h.isExposed)
      .reduce((sum, h) => sum + h.householdSize, 0);
    const vulnerableCount = mappedHouseholds.filter(
      (h) => h.isExposed && (h.requiresEvacuationAssist || h.hasElderly || h.hasDisabilities)
    ).length;

    return NextResponse.json({
      households: filtered,
      summary: {
        totalHouseholds,
        exposedCount,
        exposedResidentsCount,
        vulnerableCount,
        exposurePercentage: totalHouseholds > 0 ? Math.round((exposedCount / totalHouseholds) * 100) : 0,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
