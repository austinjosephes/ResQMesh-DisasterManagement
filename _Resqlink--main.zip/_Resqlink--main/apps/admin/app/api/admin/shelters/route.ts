import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET() {
  try {
    const shelters = await prisma.shelter.findMany({
      orderBy: { district: 'asc' },
    });

    return NextResponse.json({ shelters });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const body = await req.json();
    const {
      name,
      district,
      localBody,
      address,
      latitude,
      longitude,
      totalCapacity = 300,
      inChargeName,
      inChargePhone,
    } = body;

    const code = `SHELTER-${(district || 'KER').substring(0, 4).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;

    const shelter = await prisma.shelter.create({
      data: {
        code,
        name,
        district: district || 'Wayanad',
        localBody: localBody || null,
        address: address || `${district}, Kerala`,
        latitude: typeof latitude === 'number' ? latitude : 11.558,
        longitude: typeof longitude === 'number' ? longitude : 76.131,
        totalCapacity: Number(totalCapacity) || 300,
        currentOccupacy: 0,
        inChargeName: inChargeName || 'Camp Officer',
        inChargePhone: inChargePhone || '+919447000000',
        status: 'OPEN',
      },
    });

    return NextResponse.json({ success: true, shelter }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create shelter' }, { status: 500 });
  }
}
