import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const alerts = await prisma.hazardAlert.findMany({
      orderBy: { effectiveAt: 'desc' },
      include: {
        versions: true,
        notificationJobs: {
          include: {
            attempts: {
              take: 5,
            },
          },
        },
      },
    });

    return NextResponse.json({ alerts });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch alerts' }, { status: 500 });
  }
}
