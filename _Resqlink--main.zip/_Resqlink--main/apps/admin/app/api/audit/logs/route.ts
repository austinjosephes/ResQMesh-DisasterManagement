import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const search = searchParams.get('search');

    const where: any = {};
    if (search) {
      where.OR = [
        { actor: { contains: search } },
        { action: { contains: search } },
        { resource: { contains: search } },
        { correlationId: { contains: search } },
      ];
    }

    const logs = await prisma.auditLog.findMany({
      where,
      orderBy: { sequence: 'desc' },
      take: limit,
    });

    const totalCount = await prisma.auditLog.count();

    return NextResponse.json({
      logs,
      totalCount,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
