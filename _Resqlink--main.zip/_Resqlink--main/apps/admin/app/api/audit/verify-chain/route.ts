import { NextResponse } from 'next/server';
import { verifyAuditChain } from '@/lib/audit';

export async function POST() {
  try {
    const report = await verifyAuditChain();
    return NextResponse.json({ report });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
