import { NextResponse } from 'next/server';
import { destroySession, getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST() {
  const user = await getSessionUser();
  if (user) {
    await appendAuditLog({
      actor: user.email,
      action: 'auth.logout',
      resource: `user:${user.id}`,
      outcome: 'SUCCESS',
      reason: 'User logged out',
    });
  }

  await destroySession();
  return NextResponse.json({ success: true });
}
