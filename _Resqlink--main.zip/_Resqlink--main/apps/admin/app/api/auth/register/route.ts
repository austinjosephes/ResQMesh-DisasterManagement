import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { hashPassword, createSession } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';
import { findNearestKeralaDistrict } from '@/lib/geospatial';
import { getBlocksForDistrict } from '@/lib/kerala-administrative';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      name,
      email,
      phone,
      password,
      preferredLanguage = 'en',
      district,
      localBody = '',
      ward = '',
      address = '',
      latitude,
      longitude,
      accuracy,
      householdSize = 1,
      hasElderly = false,
      hasInfants = false,
      hasDisabilities = false,
      requiresEvacuationAssist = false,
      medicalNeedsSummary = '',
      emergencyContactName,
      emergencyContactPhone,
      emergencyContactRelation = 'Family',
      consentLocation = true,
      consentSms = true,
      autoRegister = false,
    } = body;

    const lat = typeof latitude === 'number' ? latitude : 11.5545;
    const lng = typeof longitude === 'number' ? longitude : 76.1285;

    // Detect closest district from GPS coordinates
    let finalDistrict = district;
    let finalLocalBody = localBody;
    if (typeof latitude === 'number' && typeof longitude === 'number') {
      const nearest = findNearestKeralaDistrict(latitude, longitude);
      if (!district || body.autoDetectDistrict || autoRegister) {
        finalDistrict = nearest.name;
        if (!finalLocalBody && nearest.localBodies && nearest.localBodies.length > 0) {
          finalLocalBody = nearest.localBodies[0];
        }
      }
    }
    if (!finalDistrict) {
      finalDistrict = 'Wayanad';
    }

    const isAuto = Boolean(autoRegister) || (!email && !password);
    const uniqueSuffix = `${Date.now().toString().slice(-6)}-${Math.random().toString(36).substring(2, 6)}`;
    const resolvedName = name?.trim() || `Citizen (${finalDistrict} Sector)`;
    const resolvedEmail = email
      ? email.toLowerCase().trim()
      : `citizen-${finalDistrict.toLowerCase().replace(/\s+/g, '')}-${uniqueSuffix}@resqlink.kerala.gov.in`;
    const resolvedPassword = password || 'ResQLink@2026!';
    const resolvedPhone = phone ? phone.trim() : `+919447${Math.floor(100000 + Math.random() * 900000)}`;
    const resolvedAddress =
      address || `Auto-Registered GPS Pin (${lat.toFixed(4)}°N, ${lng.toFixed(4)}°E), ${finalDistrict}, Kerala`;

    if (!isAuto && (!name || !email || !password)) {
      return NextResponse.json(
        { error: 'Full name, email, and password are required' },
        { status: 400 }
      );
    }

    if (!isAuto && password.length < 8) {
      return NextResponse.json(
        { error: 'Password must be at least 8 characters long' },
        { status: 400 }
      );
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: resolvedEmail },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'An account with this email address already exists' },
        { status: 409 }
      );
    }

    const user = await prisma.user.create({
      data: {
        name: resolvedName,
        email: resolvedEmail,
        phone: resolvedPhone,
        phoneVerified: isAuto ? true : false,
        passwordHash: hashPassword(resolvedPassword),
        role: 'CITIZEN',
        preferredLanguage,
        district: finalDistrict,
        localBody: finalLocalBody || null,
        ward: ward || 'Ward 01',
      },
    });

    const blocks = getBlocksForDistrict(finalDistrict);
    const resolvedBlock = blocks.length > 0 ? blocks[0].name : 'Central Block';
    const gramas = blocks.length > 0 ? blocks[0].gramaPanchayats : [];
    const resolvedGrama = gramas.length > 0 ? gramas[0].name : finalLocalBody || 'Main Grama Panchayat';

    // Create Resident Profile
    await prisma.residentProfile.create({
      data: {
        userId: user.id,
        householdSize: Number(householdSize) || 1,
        hasElderly: Boolean(hasElderly),
        hasInfants: Boolean(hasInfants),
        hasDisabilities: Boolean(hasDisabilities),
        requiresEvacuationAssist: Boolean(requiresEvacuationAssist),
        medicalNeedsSummary: medicalNeedsSummary || null,
        registeredDistrict: finalDistrict,
        blockPanchayat: resolvedBlock,
        gramaPanchayat: resolvedGrama,
        registeredLocalBody: finalLocalBody || resolvedGrama,
        registeredWard: ward || 'Ward 01',
        registeredAddress: resolvedAddress,
        latitude: lat,
        longitude: lng,
      },
    });

    // Create Resident Registered Home Location
    await prisma.residentLocation.create({
      data: {
        userId: user.id,
        label: 'Home (Registered Primary)',
        address: resolvedAddress,
        district: finalDistrict,
        localBody: finalLocalBody || null,
        ward: ward || 'Ward 01',
        latitude: lat,
        longitude: lng,
        accuracyMeters: typeof accuracy === 'number' ? accuracy : 4.5,
        locationSource: typeof latitude === 'number' ? 'GPS' : 'AUTO_CENTROID',
        isVerified: true,
        isPrimary: true,
      },
    });

    // Create Emergency Contact if provided
    if (emergencyContactName && emergencyContactPhone) {
      await prisma.emergencyContact.create({
        data: {
          userId: user.id,
          name: emergencyContactName.trim(),
          phone: emergencyContactPhone.trim(),
          relationship: emergencyContactRelation || 'Family',
          priority: 1,
        },
      });
    }

    // Record Consents
    if (consentLocation) {
      await prisma.consent.create({
        data: {
          userId: user.id,
          consentType: 'LOCATION_PROCESSING',
          granted: true,
        },
      });
    }

    if (consentSms) {
      await prisma.consent.create({
        data: {
          userId: user.id,
          consentType: 'EMERGENCY_SMS',
          granted: true,
        },
      });
    }

    // Auto-create session
    await createSession(user.id);

    await appendAuditLog({
      actor: user.email,
      action: 'resident.register',
      resource: `user:${user.id}`,
      outcome: 'SUCCESS',
      reason: `Registered resident in ${district} with household size ${householdSize}`,
    });

    return NextResponse.json(
      {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          district: user.district,
        },
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Registration error:', error);
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
