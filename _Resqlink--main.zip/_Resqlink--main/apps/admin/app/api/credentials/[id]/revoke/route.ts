import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';
import { signStatusSnapshot } from '@/lib/issuer';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    const actorEmail = user?.email || 'admin@resqmesh.trust';

    const body = await req.json().catch(() => ({}));
    const reason = body.reason || 'Reported compromised or lost responder device';

    const credential = await prisma.credential.findUnique({ where: { id } });
    if (!credential) {
      return NextResponse.json({ error: 'Credential not found' }, { status: 404 });
    }

    const now = Math.floor(Date.now() / 1000);

    // 1. Update credential state
    const updated = await prisma.credential.update({
      where: { id },
      data: { status: 'REVOKED' },
    });

    // 2. Record revocation entry
    await prisma.revocation.upsert({
      where: { credentialJti: credential.jti },
      create: {
        credentialJti: credential.jti,
        revokedAt: now,
        reason,
        issuerKid: credential.kid,
      },
      update: {
        revokedAt: now,
        reason,
      },
    });

    // 3. Create newly signed monotonic status snapshot
    const allRevocations = await prisma.revocation.findMany({
      orderBy: { revokedAt: 'desc' },
    });

    const latestSnapshot = await prisma.signedStatusSnapshot.findFirst({
      orderBy: { version: 'desc' },
    });
    const nextVersion = (latestSnapshot?.version || 0) + 1;

    const snapshotPayload = {
      snapshot_version: nextVersion,
      issued_at: now,
      issuer_kid: credential.kid,
      revoked_credentials: allRevocations.map((r) => ({
        credential_jti: r.credentialJti,
        revoked_at: r.revokedAt,
        reason: r.reason,
      })),
    };

    const signedSnapshot = await signStatusSnapshot(snapshotPayload);

    await prisma.signedStatusSnapshot.create({
      data: {
        version: nextVersion,
        issuedAt: now,
        issuerKid: credential.kid,
        snapshotJson: JSON.stringify(signedSnapshot),
        signature: signedSnapshot.signature,
      },
    });

    // 4. Lifecycle history
    await prisma.credentialLifecycleHistory.create({
      data: {
        credentialId: id,
        state: 'REVOKED',
        changedBy: actorEmail,
        reason,
      },
    });

    // 5. Audit log
    await appendAuditLog({
      actor: actorEmail,
      action: 'credential.revoke',
      resource: credential.jti,
      outcome: 'SUCCESS',
      reason: `Revoked and bumped status snapshot to v${nextVersion}: ${reason}`,
    });

    return NextResponse.json({
      success: true,
      credential: updated,
      snapshotVersion: nextVersion,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
