import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    const actorEmail = user?.email || 'admin@resqmesh.trust';

    const body = await req.json().catch(() => ({}));
    const reason = body.reason || 'Administrative suspension pending investigation';

    const credential = await prisma.credential.findUnique({ where: { id } });
    if (!credential) {
      return NextResponse.json({ error: 'Credential not found' }, { status: 404 });
    }

    if (credential.status === 'REVOKED') {
      return NextResponse.json({ error: 'Cannot suspend a permanently revoked credential' }, { status: 400 });
    }

    const updated = await prisma.credential.update({
      where: { id },
      data: { status: 'SUSPENDED' },
    });

    await prisma.credentialLifecycleHistory.create({
      data: {
        credentialId: id,
        state: 'SUSPENDED',
        changedBy: actorEmail,
        reason,
      },
    });

    await appendAuditLog({
      actor: actorEmail,
      action: 'credential.suspend',
      resource: credential.jti,
      outcome: 'SUCCESS',
      reason,
    });

    return NextResponse.json({ success: true, credential: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
