import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { signCredentialJwt } from '@/lib/issuer';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    const actorEmail = user?.email || 'admin@resqmesh.trust';

    const body = await req.json();
    const {
      sub,
      role,
      permissions,
      incidentScope,
      validDays = 3,
      deviceThumbprint,
      devicePublicKeyJwk,
      reason = 'Field responder deployment',
    } = body;

    if (!sub || !role || !permissions || !incidentScope || !deviceThumbprint || !devicePublicKeyJwk) {
      return NextResponse.json({ error: 'Missing required credential issuance fields' }, { status: 400 });
    }

    const jti = crypto.randomUUID();
    const now = Math.floor(Date.now() / 1000);
    const exp = now + 86400 * Number(validDays);

    const claims = {
      jti,
      iss: 'did:resqmesh:issuer:federal-fema-ca',
      sub,
      iat: now,
      nbf: now,
      exp,
      role,
      permissions,
      incident_scope: incidentScope,
      credential_version: '1.0',
      policy_version: '2026.1',
      status: {
        status_list_id: 'sl-2026-10',
        status_list_index: Math.floor(Math.random() * 1000),
      },
      cnf: {
        jwk_thumbprint: deviceThumbprint,
        jwk: devicePublicKeyJwk,
      },
    };

    const tokenJws = await signCredentialJwt(claims);

    const credential = await prisma.credential.create({
      data: {
        jti,
        sub,
        iss: claims.iss,
        kid: 'issuer-fema-alpha-2026',
        role,
        permissionsJson: JSON.stringify(permissions),
        incidentScope,
        iat: now,
        nbf: now,
        exp,
        status: 'ACTIVE',
        cnfThumbprint: deviceThumbprint,
        tokenJws,
      },
    });

    await prisma.credentialLifecycleHistory.create({
      data: {
        credentialId: credential.id,
        state: 'ACTIVE',
        changedBy: actorEmail,
        reason,
      },
    });

    await appendAuditLog({
      actor: actorEmail,
      action: 'credential.issue',
      resource: jti,
      outcome: 'SUCCESS',
      reason: `Issued ${role} credential to ${sub}: ${reason}`,
    });

    return NextResponse.json({
      success: true,
      credential: {
        ...credential,
        permissions,
        tokenJws,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
