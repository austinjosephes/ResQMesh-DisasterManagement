import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const where: any = {};
    if (status && status !== 'ALL') {
      where.status = status;
    }
    if (search) {
      where.OR = [
        { sub: { contains: search } },
        { jti: { contains: search } },
        { role: { contains: search } },
      ];
    }

    const credentials = await prisma.credential.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        history: {
          orderBy: { timestamp: 'desc' },
        },
      },
    });

    return NextResponse.json({
      credentials: credentials.map((c) => ({
        ...c,
        permissions: JSON.parse(c.permissionsJson),
      })),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
