import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    const body = await req.json();
    const { responderSub, deviceThumbprint, publicKeyJwk } = body;

    if (!responderSub || !deviceThumbprint || !publicKeyJwk) {
      return NextResponse.json({ error: 'Missing required device enrollment fields' }, { status: 400 });
    }

    const device = await prisma.device.upsert({
      where: { deviceThumbprint },
      create: {
        userId: user?.id,
        responderSub,
        deviceThumbprint,
        publicKeyJwk: typeof publicKeyJwk === 'string' ? publicKeyJwk : JSON.stringify(publicKeyJwk),
        status: 'ENROLLED',
      },
      update: {
        userId: user?.id,
        responderSub,
        lastSeenAt: new Date(),
        status: 'ENROLLED',
      },
    });

    await appendAuditLog({
      actor: user?.email || responderSub,
      action: 'device.enroll',
      resource: deviceThumbprint,
      outcome: 'SUCCESS',
      reason: `Enrolled browser device key for ${responderSub}`,
    });

    return NextResponse.json({ success: true, device });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
