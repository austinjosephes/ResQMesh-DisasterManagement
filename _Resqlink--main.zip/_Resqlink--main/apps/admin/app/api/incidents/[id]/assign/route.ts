import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized to dispatch rescue teams' }, { status: 403 });
    }

    const { teamId, notes } = await req.json();
    if (!teamId) {
      return NextResponse.json({ error: 'Rescue team ID is required' }, { status: 400 });
    }

    const team = await prisma.rescueTeam.findUnique({ where: { id: teamId } });
    if (!team) {
      return NextResponse.json({ error: 'Rescue team not found' }, { status: 404 });
    }

    // Check if id is an SOSRequest or Incident
    const sos = await prisma.sOSRequest.findFirst({
      where: { OR: [{ id }, { trackingNumber: id }] },
    });

    if (sos) {
      const updatedSos = await prisma.sOSRequest.update({
        where: { id: sos.id },
        data: {
          assignedTeamId: team.id,
          assignedTeamName: team.name,
          status: 'ASSIGNED',
          verificationStatus: 'VERIFIED',
        },
      });

      // Update team status to DISPATCHED
      await prisma.rescueTeam.update({
        where: { id: team.id },
        data: { status: 'DISPATCHED' },
      });

      await appendAuditLog({
        actor: user.email,
        action: 'incident.team.assigned',
        resource: `sos:${sos.id}`,
        outcome: 'SUCCESS',
        reason: `Assigned rescue team ${team.name} to SOS ${sos.trackingNumber}. Notes: ${notes || 'Immediate dispatch'}`,
      });

      return NextResponse.json({
        success: true,
        message: `Assigned team ${team.name} successfully`,
        sos: updatedSos,
      });
    }

    // Otherwise check Incident
    const incident = await prisma.incident.findFirst({
      where: { OR: [{ id }, { incidentCode: id }] },
    });

    if (incident) {
      const assignment = await prisma.incidentAssignment.create({
        data: {
          incidentId: incident.id,
          teamId: team.id,
          assignedBy: user.name || user.email,
          status: 'DISPATCHED',
          fieldNotes: notes || null,
        },
      });

      await prisma.rescueTeam.update({
        where: { id: team.id },
        data: { status: 'DISPATCHED' },
      });

      await appendAuditLog({
        actor: user.email,
        action: 'incident.team.assigned',
        resource: `incident:${incident.id}`,
        outcome: 'SUCCESS',
        reason: `Assigned ${team.name} to Incident ${incident.incidentCode}`,
      });

      return NextResponse.json({ success: true, assignment });
    }

    return NextResponse.json({ error: 'Incident or SOS ticket not found' }, { status: 404 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Dispatch failed' }, { status: 500 });
  }
}
