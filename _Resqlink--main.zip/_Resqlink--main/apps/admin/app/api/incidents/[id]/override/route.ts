import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized to override priority' }, { status: 403 });
    }

    const { priorityCategory, overrideReason } = await req.json();

    if (!overrideReason || overrideReason.trim().length < 5) {
      return NextResponse.json(
        { error: 'A mandatory documented justification is required for algorithmic priority override.' },
        { status: 400 }
      );
    }

    const sos = await prisma.sOSRequest.findFirst({
      where: { OR: [{ id }, { trackingNumber: id }] },
    });

    if (!sos) {
      return NextResponse.json({ error: 'SOS request not found' }, { status: 404 });
    }

    const updated = await prisma.sOSRequest.update({
      where: { id: sos.id },
      data: {
        priorityCategory,
        overrideReason: overrideReason.trim(),
        overrideBy: user.name || user.email,
      },
    });

    await appendAuditLog({
      actor: user.email,
      action: 'priority.coordinator.override',
      resource: `sos:${sos.id}`,
      outcome: 'SUCCESS',
      reason: `Overrode priority from ${sos.priorityCategory} to ${priorityCategory}. Justification: ${overrideReason}`,
    });

    return NextResponse.json({
      success: true,
      message: 'Priority successfully overridden and recorded in tamper-evident audit chain.',
      sos: updated,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Override failed' }, { status: 500 });
  }
}
