import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const incident = await prisma.incident.findFirst({
      where: {
        OR: [{ id }, { incidentCode: id }],
      },
      include: {
        assignments: true,
      },
    });

    if (!incident) {
      return NextResponse.json({ error: 'Incident not found' }, { status: 404 });
    }

    return NextResponse.json({ incident });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch incident' }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const { status, severity, description } = await req.json();

    const incident = await prisma.incident.update({
      where: { id },
      data: {
        ...(status && { status }),
        ...(severity && { severity }),
        ...(description && { description }),
      },
    });

    return NextResponse.json({ incident });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update incident' }, { status: 500 });
  }
}
