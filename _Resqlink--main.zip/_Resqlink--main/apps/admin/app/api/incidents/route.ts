import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET() {
  try {
    const incidents = await prisma.incident.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        assignments: true,
      },
    });

    return NextResponse.json({ incidents });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch incidents' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    if (!user || (user.role !== 'ADMIN' && user.role !== 'COMMANDER' && user.role !== 'RESPONDER')) {
      return NextResponse.json({ error: 'Unauthorized to declare incident' }, { status: 403 });
    }

    const body = await req.json();
    const { title, description, category, severity, sector, latitude, longitude, radiusMeters } = body;

    const incidentCode = `INC-2026-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    const incident = await prisma.incident.create({
      data: {
        incidentCode,
        title,
        description,
        category: category || 'GENERAL',
        severity: severity || 'MODERATE',
        district: body.district || 'Wayanad',
        sector: sector || 'General Sector',
        latitude: parseFloat(latitude) || 37.7749,
        longitude: parseFloat(longitude) || -122.4194,
        radiusMeters: parseInt(radiusMeters) || 500,
        reportedBy: user.name,
      },
    });

    return NextResponse.json({ incident }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create incident' }, { status: 500 });
  }
}
