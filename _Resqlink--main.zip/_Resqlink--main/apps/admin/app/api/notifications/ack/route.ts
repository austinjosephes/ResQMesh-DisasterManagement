import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { attemptId, alertId, recipientPhone, ackMethod = 'SMS_REPLY_SAFE' } = body;

    let targetAttempt = null;

    if (attemptId) {
      targetAttempt = await prisma.notificationAttempt.findUnique({
        where: { id: attemptId },
        include: { job: true },
      });
    } else if (recipientPhone) {
      const cleanRaw = recipientPhone.trim().replace(/\s+/g, '');
      const cleanDigits = cleanRaw.replace(/\D/g, '').slice(-10);
      const phoneVariants = [
        cleanRaw,
        cleanDigits,
        `+91${cleanDigits}`,
        cleanRaw.startsWith('+') ? cleanRaw : `+91${cleanRaw}`,
        cleanRaw.replace(/^\+91/, ''),
      ];

      targetAttempt = await prisma.notificationAttempt.findFirst({
        where: { recipientPhone: { in: phoneVariants } },
        orderBy: { submittedAt: 'desc' },
        include: { job: true },
      });
    } else if (alertId) {
      targetAttempt = await prisma.notificationAttempt.findFirst({
        where: { job: { alertId } },
        orderBy: { submittedAt: 'desc' },
        include: { job: true },
      });
    }

    if (targetAttempt) {
      // Update attempt to ACKNOWLEDGED
      await prisma.notificationAttempt.update({
        where: { id: targetAttempt.id },
        data: {
          status: 'ACKNOWLEDGED',
          acknowledgedAt: new Date(),
        },
      });

      // Create acknowledgement record
      await prisma.notificationAcknowledgement.create({
        data: {
          jobId: targetAttempt.jobId,
          recipientPhone: targetAttempt.recipientPhone,
          ackMethod,
          acknowledgedAt: new Date(),
        },
      });

      await appendAuditLog({
        actor: targetAttempt.recipientPhone,
        action: 'notification.acknowledged',
        resource: `attempt:${targetAttempt.id}`,
        outcome: 'SUCCESS',
        reason: `Resident confirmed receipt of emergency SMS via ${ackMethod}`,
      });

      return NextResponse.json({
        success: true,
        acknowledged: true,
        attemptId: targetAttempt.id,
        recipientPhone: targetAttempt.recipientPhone,
        status: 'ACKNOWLEDGED',
        acknowledgedAt: new Date().toISOString(),
      });
    }

    return NextResponse.json({
      success: true,
      acknowledged: true,
      status: 'ACKNOWLEDGED',
      acknowledgedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
