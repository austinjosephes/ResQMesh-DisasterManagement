import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET() {
  try {
    const user = await getSessionUser();

    // Fetch assignments for responder or all active missions for testing
    const assignments = await prisma.incidentAssignment.findMany({
      orderBy: { assignedAt: 'desc' },
      include: {
        incident: true,
        team: true,
      },
    });

    const activeSos = await prisma.sOSRequest.findMany({
      where: {
        status: { in: ['ASSIGNED', 'EN_ROUTE', 'ON_SCENE', 'IN_PROGRESS'] },
      },
      orderBy: { priorityScore: 'desc' },
    });

    return NextResponse.json({
      assignments,
      assignedSos: activeSos,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
