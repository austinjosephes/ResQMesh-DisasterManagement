import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();
    if (!user || user.role === 'CITIZEN') {
      return NextResponse.json({ error: 'Unauthorized field operation' }, { status: 403 });
    }

    const body = await req.json();
    const { status, fieldNotes, victimsAided = 0 } = body;

    // Check if updating SOS request
    const sos = await prisma.sOSRequest.findFirst({
      where: { OR: [{ id }, { trackingNumber: id }] },
    });

    if (sos) {
      const updatedSos = await prisma.sOSRequest.update({
        where: { id: sos.id },
        data: {
          status: status || sos.status,
          responderNotes: fieldNotes ? `${sos.responderNotes ? sos.responderNotes + ' | ' : ''}${fieldNotes}` : sos.responderNotes,
        },
      });

      await appendAuditLog({
        actor: user.email,
        action: 'rescue.field.status_update',
        resource: `sos:${sos.id}`,
        outcome: 'SUCCESS',
        reason: `Field responder updated SOS ${sos.trackingNumber} status to ${status}. Aided: ${victimsAided}. Notes: ${fieldNotes || 'Status advance'}`,
      });

      return NextResponse.json({ success: true, sos: updatedSos });
    }

    // Check IncidentAssignment
    const assignment = await prisma.incidentAssignment.findFirst({
      where: { OR: [{ id }, { incidentId: id }] },
    });

    if (assignment) {
      const updated = await prisma.incidentAssignment.update({
        where: { id: assignment.id },
        data: {
          status: status || assignment.status,
          fieldNotes: fieldNotes || assignment.fieldNotes,
          victimsAided: Number(victimsAided) || assignment.victimsAided,
          arrivedAt: status === 'ON_SCENE' ? new Date() : assignment.arrivedAt,
          completedAt: status === 'RESOLVED' ? new Date() : assignment.completedAt,
        },
      });

      await appendAuditLog({
        actor: user.email,
        action: 'rescue.field.status_update',
        resource: `assignment:${assignment.id}`,
        outcome: 'SUCCESS',
        reason: `Responder advanced assignment to ${status}`,
      });

      return NextResponse.json({ success: true, assignment: updated });
    }

    return NextResponse.json({ error: 'Record not found' }, { status: 404 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Triage update failed' }, { status: 500 });
  }
}
