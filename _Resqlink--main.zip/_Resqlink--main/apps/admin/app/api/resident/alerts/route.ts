import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { checkHazardExposure } from '@/lib/geospatial';

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const queryPhone = url.searchParams.get('phone');
    let user = await getSessionUser();

    if (!user && queryPhone) {
      const clean = queryPhone.trim().replace(/\s+/g, '');
      user = await prisma.user.findFirst({
        where: {
          OR: [
            { phone: clean },
            { phone: clean.startsWith('+') ? clean : `+91${clean}` },
          ],
        },
      });
    }

    const residentProfile = user
      ? await prisma.residentProfile.findUnique({
          where: { userId: user.id },
        })
      : null;

    const alerts = await prisma.hazardAlert.findMany({
      where: {
        status: { in: ['ACTIVE', 'UPDATED'] },
      },
      orderBy: { effectiveAt: 'desc' },
      include: {
        versions: true,
      },
    });

    // Check if resident is exposed to any of the hazard polygons or administrative scopes
    const evaluatedAlerts = alerts.map((alert) => {
      let isExposed = false;
      if (residentProfile) {
        const distName = residentProfile.registeredDistrict || '';
        const alertDist = alert.affectedDistrict || '';
        const districtMatch = distName && alertDist ? distName.toLowerCase() === alertDist.toLowerCase() : false;

        let subJurisdictionMatch = true;
        if (alert.targetScope === 'GRAMA_PANCHAYAT' && alert.targetGramaPanchayat) {
          const gpName = (residentProfile.gramaPanchayat || '').toLowerCase();
          const targetGp = alert.targetGramaPanchayat.toLowerCase();
          const localBody = (residentProfile.registeredLocalBody || '').toLowerCase();
          const addr = (residentProfile.registeredAddress || '').toLowerCase();

          subJurisdictionMatch = Boolean(
            (gpName && gpName === targetGp) ||
            (localBody && localBody.includes(targetGp)) ||
            (addr && addr.includes(targetGp))
          );
        } else if (alert.targetScope === 'BLOCK_PANCHAYAT' && alert.targetBlockPanchayat) {
          const blkName = (residentProfile.blockPanchayat || '').toLowerCase();
          const targetBlk = alert.targetBlockPanchayat.toLowerCase();
          const localBody = (residentProfile.registeredLocalBody || '').toLowerCase();
          const addr = (residentProfile.registeredAddress || '').toLowerCase();

          subJurisdictionMatch = Boolean(
            (blkName && blkName === targetBlk) ||
            (localBody && localBody.includes(targetBlk)) ||
            (addr && addr.includes(targetBlk))
          );
        }

        const geoExposed = checkHazardExposure(
          { lat: residentProfile.latitude, lng: residentProfile.longitude },
          alert.polygonGeoJson
        );

        isExposed = (districtMatch && subJurisdictionMatch) || geoExposed;
      }

      let parsedPolygon: [number, number][] = [];
      try {
        const geo = JSON.parse(alert.polygonGeoJson);
        if (geo.type === 'Polygon' && geo.coordinates && geo.coordinates[0]) {
          parsedPolygon = geo.coordinates[0];
        }
      } catch (e) {}

      return {
        id: alert.id,
        externalSourceId: alert.externalSourceId,
        source: alert.source,
        hazardType: alert.hazardType,
        severity: alert.severity,
        headline: alert.headline,
        description: alert.description,
        instruction: alert.instruction,
        headlineMl: alert.headlineMl,
        descriptionMl: alert.descriptionMl,
        instructionMl: alert.instructionMl,
        affectedDistrict: alert.affectedDistrict,
        targetScope: alert.targetScope,
        targetBlockPanchayat: alert.targetBlockPanchayat,
        targetGramaPanchayat: alert.targetGramaPanchayat,
        targetPopulationEst: alert.targetPopulationEst,
        polygon: parsedPolygon,
        effectiveAt: alert.effectiveAt,
        expiresAt: alert.expiresAt,
        isStale: alert.isStale,
        status: alert.status,
        version: alert.version,
        isResidentExposed: isExposed,
      };
    });

    const isAnyExposure = evaluatedAlerts.some((a) => a.isResidentExposed);

    // Normalize and generate all variants for target phone number
    const rawTarget = (queryPhone || user?.phone || '+919447100004').trim().replace(/\s+/g, '');
    const cleanDigits = rawTarget.replace(/\D/g, '');
    const last10 = cleanDigits.slice(-10);
    const phoneVariants = Array.from(
      new Set(
        [
          rawTarget,
          cleanDigits,
          last10,
          `+91${last10}`,
          `91${last10}`,
          rawTarget.startsWith('+') ? rawTarget : `+91${rawTarget}`,
          rawTarget.replace(/^\+91/, ''),
          rawTarget.replace(/^\+/, ''),
        ].filter((p) => p && p.length >= 8)
      )
    );

    const searchConditions: any[] = [{ recipientPhone: { in: phoneVariants } }];
    if (user?.name) {
      searchConditions.push({ recipientName: user.name });
    }

    const attempts = await prisma.notificationAttempt.findMany({
      where: {
        OR: searchConditions,
      },
      orderBy: { submittedAt: 'desc' },
      take: 15,
    });

    const activeTopAlert = evaluatedAlerts[0];
    const latestAttempt = attempts.length > 0 ? attempts[0] : null;

    const incomingSms = latestAttempt
      ? {
          id: latestAttempt.id,
          recipientPhone: latestAttempt.recipientPhone,
          messageBody: latestAttempt.messageBody,
          dltTemplateId: latestAttempt.dltTemplateId,
          status: latestAttempt.status,
          deliveredAt: latestAttempt.deliveredAt || latestAttempt.submittedAt,
          acknowledgedAt: latestAttempt.acknowledgedAt,
        }
      : activeTopAlert
      ? {
          id: `SIM_SMS_${activeTopAlert.id.slice(0, 8)}`,
          recipientPhone: phoneVariants[0] || '+919447100004',
          messageBody: `[VK-KSDMA] RESQLINK KERALA: Urgent ${activeTopAlert.hazardType} warning for ${activeTopAlert.affectedDistrict}, Kerala. Extreme rainfall or flood hazard forecasted. Follow official safety instructions. Source: ${activeTopAlert.source}. Issued: ${new Date(activeTopAlert.effectiveAt).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })}.`,
          dltTemplateId: 'DLT_KL_DISASTER_EMG_EN_1001',
          status: 'DELIVERED',
          deliveredAt: new Date(),
          acknowledgedAt: null,
        }
      : null;

    const allSmsMessages = attempts.map((att) => ({
      id: att.id,
      recipientPhone: att.recipientPhone,
      messageBody: att.messageBody,
      dltTemplateId: att.dltTemplateId,
      status: att.status,
      deliveredAt: att.deliveredAt || att.submittedAt,
      acknowledgedAt: att.acknowledgedAt,
      senderHeader: 'VK-KSDMA',
    }));

    const hasUnacknowledgedSms = attempts.some(
      (a) => a.status === 'DELIVERED' && !a.acknowledgedAt
    );

    return NextResponse.json({
      alerts: evaluatedAlerts,
      residentExposed: isAnyExposure,
      registeredLocation: residentProfile
        ? {
            lat: residentProfile.latitude,
            lng: residentProfile.longitude,
            district: residentProfile.registeredDistrict,
            blockPanchayat: residentProfile.blockPanchayat || 'Kalpetta Block',
            gramaPanchayat: residentProfile.gramaPanchayat || residentProfile.registeredLocalBody || 'Meppadi Grama Panchayat',
            address: residentProfile.registeredAddress,
            phone: user?.phone || rawTarget,
          }
        : null,
      incomingSms,
      allSmsMessages,
      hasUnacknowledgedSms,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}
