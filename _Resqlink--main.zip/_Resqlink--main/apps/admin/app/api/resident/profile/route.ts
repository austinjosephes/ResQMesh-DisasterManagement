import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const fullProfile = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        residentProfile: true,
        residentLocations: true,
        emergencyContacts: true,
        consents: true,
      },
    });

    if (!fullProfile) {
      return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
    }

    return NextResponse.json({
      user: {
        id: fullProfile.id,
        email: fullProfile.email,
        name: fullProfile.name,
        phone: fullProfile.phone,
        phoneVerified: fullProfile.phoneVerified,
        role: fullProfile.role,
        district: fullProfile.district,
        localBody: fullProfile.localBody,
        ward: fullProfile.ward,
        preferredLanguage: fullProfile.preferredLanguage,
      },
      profile: fullProfile.residentProfile,
      locations: fullProfile.residentLocations,
      contacts: fullProfile.emergencyContacts,
      consents: fullProfile.consents,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      name,
      phone,
      preferredLanguage,
      district,
      localBody,
      ward,
      householdSize,
      hasElderly,
      hasInfants,
      hasDisabilities,
      requiresEvacuationAssist,
      medicalNeedsSummary,
      latitude,
      longitude,
      address,
    } = body;

    // Update User
    const updatedUser = await prisma.user.update({
      where: { id: user.id },
      data: {
        name: name !== undefined ? name : undefined,
        phone: phone !== undefined ? phone : undefined,
        preferredLanguage: preferredLanguage !== undefined ? preferredLanguage : undefined,
        district: district !== undefined ? district : undefined,
        localBody: localBody !== undefined ? localBody : undefined,
        ward: ward !== undefined ? ward : undefined,
      },
    });

    // Update or create ResidentProfile
    await prisma.residentProfile.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        householdSize: Number(householdSize) || 1,
        hasElderly: Boolean(hasElderly),
        hasInfants: Boolean(hasInfants),
        hasDisabilities: Boolean(hasDisabilities),
        requiresEvacuationAssist: Boolean(requiresEvacuationAssist),
        medicalNeedsSummary: medicalNeedsSummary || null,
        registeredDistrict: district || 'Wayanad',
        registeredLocalBody: localBody || null,
        registeredWard: ward || null,
        registeredAddress: address || `${district || 'Kerala'}`,
        latitude: typeof latitude === 'number' ? latitude : 11.5545,
        longitude: typeof longitude === 'number' ? longitude : 76.1285,
      },
      update: {
        householdSize: householdSize !== undefined ? Number(householdSize) : undefined,
        hasElderly: hasElderly !== undefined ? Boolean(hasElderly) : undefined,
        hasInfants: hasInfants !== undefined ? Boolean(hasInfants) : undefined,
        hasDisabilities: hasDisabilities !== undefined ? Boolean(hasDisabilities) : undefined,
        requiresEvacuationAssist:
          requiresEvacuationAssist !== undefined ? Boolean(requiresEvacuationAssist) : undefined,
        medicalNeedsSummary: medicalNeedsSummary !== undefined ? medicalNeedsSummary : undefined,
        registeredDistrict: district !== undefined ? district : undefined,
        registeredLocalBody: localBody !== undefined ? localBody : undefined,
        registeredWard: ward !== undefined ? ward : undefined,
        registeredAddress: address !== undefined ? address : undefined,
        latitude: typeof latitude === 'number' ? latitude : undefined,
        longitude: typeof longitude === 'number' ? longitude : undefined,
      },
    });

    await appendAuditLog({
      actor: user.email,
      action: 'resident.profile.update',
      resource: `user:${user.id}`,
      outcome: 'SUCCESS',
      reason: 'Resident updated evacuation assistance and household profile',
    });

    return NextResponse.json({ success: true, message: 'Profile updated successfully' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Update failed' }, { status: 500 });
  }
}
