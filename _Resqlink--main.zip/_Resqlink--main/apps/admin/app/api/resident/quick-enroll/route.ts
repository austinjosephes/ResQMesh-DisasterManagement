import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { createSession } from '@/lib/auth';
import { findNearestGramaPanchayat } from '@/lib/kerala-administrative';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    let { phone, latitude, longitude, accuracy, name, email } = body;

    if (!phone || typeof phone !== 'string' || phone.trim().length < 8) {
      return NextResponse.json({ error: 'Valid mobile phone number is required' }, { status: 400 });
    }

    // Normalize phone number
    let cleanPhone = phone.trim().replace(/\s+/g, '');
    if (!cleanPhone.startsWith('+')) {
      if (cleanPhone.length === 10) {
        cleanPhone = `+91${cleanPhone}`;
      } else if (cleanPhone.startsWith('91') && cleanPhone.length === 12) {
        cleanPhone = `+${cleanPhone}`;
      } else {
        cleanPhone = `+91${cleanPhone}`;
      }
    }

    const citizenName = name?.trim() || `Citizen (${cleanPhone.slice(-4)})`;
    const userEmail = email?.trim() || `resident-${cleanPhone.replace('+', '')}@resqlink.kerala.gov.in`;

    const lat = typeof latitude === 'number' && !isNaN(latitude) ? latitude : 11.5545;
    const lng = typeof longitude === 'number' && !isNaN(longitude) ? longitude : 76.1285;
    const acc = typeof accuracy === 'number' && !isNaN(accuracy) ? accuracy : 5.0;

    // Automatically resolve Grama Panchayat, Block, District, and Shelter from coordinates
    const detectedJurisdiction = findNearestGramaPanchayat(lat, lng);
    const district = body.district || detectedJurisdiction.districtName;
    const block = body.blockPanchayat || body.block || detectedJurisdiction.blockName;
    const grama = body.gramaPanchayat || body.grama || detectedJurisdiction.name;
    const reliefCamp = body.designatedReliefCamp || body.reliefCamp || detectedJurisdiction.designatedReliefCamp;
    const localArea = body.ward || body.localArea || detectedJurisdiction.localAreas?.[0] || 'Ward 01';

    // Check if user already exists with this phone
    let user = await prisma.user.findFirst({
      where: { phone: cleanPhone },
      include: { residentProfile: true, residentLocations: true },
    });

    if (user) {
      // Update user details if provided
      const updateUserData: any = {};
      if (name?.trim()) updateUserData.name = name.trim();
      if (email?.trim()) updateUserData.email = email.trim();
      if (Object.keys(updateUserData).length > 0) {
        user = await prisma.user.update({
          where: { id: user.id },
          data: updateUserData,
          include: { residentProfile: true, residentLocations: true },
        });
      }

      // Update location and resident profile
      if (user.residentProfile) {
        await prisma.residentProfile.update({
          where: { userId: user.id },
          data: {
            latitude: lat,
            longitude: lng,
            registeredDistrict: district,
            blockPanchayat: block,
            gramaPanchayat: grama,
            registeredLocalBody: grama,
            registeredAddress: `${localArea}, ${grama}, ${block}, ${district}, Kerala`,
          },
        });
      }

      const primaryLoc = user.residentLocations?.find((l) => l.isPrimary);
      if (primaryLoc) {
        await prisma.residentLocation.update({
          where: { id: primaryLoc.id },
          data: {
            latitude: lat,
            longitude: lng,
            accuracyMeters: acc,
            district,
            localBody: grama,
          },
        });
      }
    } else {
      // Create new user and profile with provided name and email
      user = await prisma.user.create({
        data: {
          name: citizenName,
          email: userEmail,
          phone: cleanPhone,
          phoneVerified: true,
          passwordHash: 'PHONE_ENROLLED_PASSWORDLESS',
          role: 'CITIZEN',
          preferredLanguage: 'en',
          district,
          localBody: grama,
          ward: localArea,
          residentProfile: {
            create: {
              householdSize: 1,
              hasElderly: false,
              hasInfants: false,
              hasDisabilities: false,
              requiresEvacuationAssist: false,
              registeredDistrict: district,
              blockPanchayat: block,
              gramaPanchayat: grama,
              registeredLocalBody: grama,
              registeredWard: localArea,
              registeredAddress: `${localArea}, ${grama}, ${block}, ${district}, Kerala`,
              latitude: lat,
              longitude: lng,
            },
          },
          residentLocations: {
            create: {
              label: 'Auto-Detected Device Location',
              address: `${localArea}, ${grama}, ${block}, ${district}, Kerala`,
              district,
              localBody: grama,
              ward: localArea,
              latitude: lat,
              longitude: lng,
              accuracyMeters: acc,
              locationSource: 'GPS',
              isVerified: true,
              isPrimary: true,
            },
          },
        },
        include: { residentProfile: true, residentLocations: true },
      });
    }

    // Create authenticated session cookie
    const token = await createSession(user.id);
    const response = NextResponse.json({
      success: true,
      message: `Enrolled successfully via mobile phone ${cleanPhone}`,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        district,
        blockPanchayat: block,
        gramaPanchayat: grama,
        localArea,
        reliefCamp,
        latitude: lat,
        longitude: lng,
        accuracy: acc,
      },
    });

    response.cookies.set('resqlink_session', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 30, // 30 days
    });

    return response;
  } catch (error: any) {
    console.error('Quick enrollment error:', error);
    return NextResponse.json({ error: error.message || 'Enrollment failed' }, { status: 500 });
  }
}
