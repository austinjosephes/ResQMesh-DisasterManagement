import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { appendAuditLog } from '@/lib/audit';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { requestId, trackingNumber, phone } = body;

    if (!requestId && !trackingNumber && !phone) {
      return NextResponse.json({ error: 'Request identifier or phone required' }, { status: 400 });
    }

    const whereClause: any = {};
    if (requestId) whereClause.id = requestId;
    else if (trackingNumber) whereClause.trackingNumber = trackingNumber;
    else if (phone) {
      const clean = phone.trim().replace(/\s+/g, '');
      whereClause.OR = [
        { phone: clean },
        { phone: clean.startsWith('+') ? clean : `+91${clean}` },
      ];
    }

    const existing = await prisma.sOSRequest.findFirst({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
    });

    if (!existing) {
      return NextResponse.json({ error: 'Request not found' }, { status: 404 });
    }

    const ackTimestamp = new Date();

    const updated = await prisma.sOSRequest.update({
      where: { id: existing.id },
      data: {
        userMessageAckAt: ackTimestamp,
      },
    });

    // Also update notification attempts for this phone number
    const targetPhone = existing.phone || phone;
    if (targetPhone) {
      const cleanRaw = targetPhone.trim().replace(/\s+/g, '');
      const cleanDigits = cleanRaw.replace(/\D/g, '').slice(-10);
      const phoneVariants = [
        cleanRaw,
        cleanDigits,
        `+91${cleanDigits}`,
        cleanRaw.startsWith('+') ? cleanRaw : `+91${cleanRaw}`,
        cleanRaw.replace(/^\+91/, ''),
      ];

      await prisma.notificationAttempt.updateMany({
        where: {
          recipientPhone: { in: phoneVariants },
          status: 'DELIVERED',
        },
        data: {
          status: 'ACKNOWLEDGED',
          acknowledgedAt: ackTimestamp,
        },
      });
    }

    // Append tamper-evident audit log
    await appendAuditLog({
      actor: targetPhone || 'RESIDENT_HANDSET',
      action: 'resident.message_acknowledged',
      resource: `sos:${existing.id}`,
      outcome: 'SUCCESS',
      reason: `Resident verified delivery receipt of admin instructions for tracking #${existing.trackingNumber}`,
    });

    return NextResponse.json({
      success: true,
      verified: true,
      message: 'Message receipt acknowledged by resident handset',
      acknowledgedAt: ackTimestamp,
      trackingNumber: existing.trackingNumber,
    });
  } catch (error: any) {
    console.error('Request ACK error:', error);
    return NextResponse.json({ error: error.message || 'Failed to acknowledge message' }, { status: 500 });
  }
}
