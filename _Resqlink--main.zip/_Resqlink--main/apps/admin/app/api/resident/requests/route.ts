import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { calculateRescuePriority } from '@/lib/priority-engine';
import { findNearestGramaPanchayat } from '@/lib/kerala-administrative';

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const queryPhone = url.searchParams.get('phone');
    let user = await getSessionUser();

    if (!user && queryPhone) {
      const clean = queryPhone.trim().replace(/\s+/g, '');
      user = await prisma.user.findFirst({
        where: {
          OR: [
            { phone: clean },
            { phone: clean.startsWith('+') ? clean : `+91${clean}` },
          ],
        },
      });
    }

    const cleanPhone = queryPhone?.trim().replace(/\s+/g, '');
    const normalizedPhone = cleanPhone ? (cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}`) : user?.phone;

    const whereConditions: any[] = [];
    if (user?.id) whereConditions.push({ userId: user.id });
    if (normalizedPhone) {
      whereConditions.push({ phone: normalizedPhone });
      whereConditions.push({ phone: normalizedPhone.replace('+91', '') });
    }

    // Fetch user's requests if identified; otherwise recent community requests
    const requests = await prisma.sOSRequest.findMany({
      where: whereConditions.length > 0 ? { OR: whereConditions } : undefined,
      orderBy: { createdAt: 'desc' },
      take: 30,
    });

    return NextResponse.json({ requests });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    let user = await getSessionUser();
    const body = await req.json();

    const {
      phone,
      category = 'RESCUE_NEEDED',
      description,
      peopleCount = 1,
      hasInjuries = false,
      immediateDanger = false,
      latitude,
      longitude,
      address,
      district,
    } = body;

    if (!description || description.trim().length === 0) {
      return NextResponse.json({ error: 'Issue description is required' }, { status: 400 });
    }

    let lat = typeof latitude === 'number' && !isNaN(latitude) ? latitude : 11.5545;
    let lng = typeof longitude === 'number' && !isNaN(longitude) ? longitude : 76.1285;

    // Detect closest administrative jurisdiction
    const nearest = findNearestGramaPanchayat(lat, lng);
    const finalDistrict = district || body.district || nearest.districtName;
    const resolvedGrama = body.gramaPanchayat || body.grama || nearest.name;
    const resolvedBlock = body.blockPanchayat || body.block || nearest.blockName;
    const resolvedAddress = address || `${body.ward || nearest.localAreas?.[0] || 'Ward 01'}, ${resolvedGrama}, ${resolvedBlock}, ${finalDistrict}, Kerala`;

    // Associate or create user with phone
    if (!user && phone && typeof phone === 'string' && phone.trim().length > 7) {
      const cleanPhone = phone.trim().replace(/\s+/g, '');
      const normalizedPhone = cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}`;

      user = await prisma.user.findFirst({
        where: { phone: normalizedPhone },
      });

      if (!user) {
        user = await prisma.user.create({
          data: {
            name: `Citizen (${normalizedPhone.slice(-4)})`,
            email: `resident-${normalizedPhone.replace('+', '')}@resqlink.kerala.gov.in`,
            phone: normalizedPhone,
            phoneVerified: true,
            passwordHash: 'PHONE_ENROLLED_PASSWORDLESS',
            role: 'CITIZEN',
            district: finalDistrict,
            localBody: nearest.name,
            ward: nearest.localAreas?.[0] || 'Ward 01',
          },
        });
      }
    }

    // Compute priority engine score
    const priorityResult = calculateRescuePriority({
      category: category === 'RESCUE_NEEDED' ? 'TRAPPED' : category,
      peopleCount: Number(peopleCount) || 1,
      hasInjuries: Boolean(hasInjuries),
      immediateDanger: Boolean(immediateDanger),
      locationConfidence: 0.95,
      reportedAt: new Date(),
    });

    const trackingNumber = `ISSUE-KL-2026-${Math.floor(10000 + Math.random() * 90000)}`;

    const resolvedPhone = (phone ? (phone.startsWith('+') ? phone : `+91${phone}`) : user?.phone) || '+919447100004';

    const newRequest = await prisma.sOSRequest.create({
      data: {
        trackingNumber,
        userId: user ? user.id : null,
        phone: resolvedPhone,
        gramaPanchayat: resolvedGrama,
        blockPanchayat: resolvedBlock,
        category,
        description: description.trim(),
        peopleCount: Number(peopleCount) || 1,
        hasInjuries: Boolean(hasInjuries),
        immediateDanger: Boolean(immediateDanger),
        latitude: lat,
        longitude: lng,
        address: resolvedAddress,
        district: finalDistrict,
        locationSource: 'DEVICE_GPS',
        locationConfidence: 0.95,
        priorityScore: priorityResult.totalScore,
        priorityCategory: priorityResult.priorityCategory,
        status: 'SUBMITTED',
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Issue registered successfully in SEOC Rescue Command Queue',
      ticket: newRequest,
      trackingNumber,
      priorityCategory: priorityResult.priorityCategory,
    });
  } catch (error: any) {
    console.error('Register issue error:', error);
    return NextResponse.json({ error: error.message || 'Failed to register issue' }, { status: 500 });
  }
}
