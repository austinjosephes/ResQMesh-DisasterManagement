import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { calculateRescuePriority } from '@/lib/priority-engine';
import { appendAuditLog } from '@/lib/audit';
import { findNearestGramaPanchayat } from '@/lib/kerala-administrative';

export async function POST(req: Request) {
  try {
    let user = await getSessionUser();
    const body = await req.json();

    const {
      phone,
      category = 'FLOOD',
      description,
      peopleCount = 1,
      hasInjuries = false,
      immediateDanger = false,
      latitude,
      longitude,
      address,
      district,
      accessibilityNeeds,
      contactPreference = 'SMS',
      locationSource = 'DEVICE_GPS',
      locationConfidence = 0.90,
      idempotencyKey,
    } = body;

    // Link by phone if session user not already set
    if (!user && phone && typeof phone === 'string' && phone.trim().length > 7) {
      const cleanPhone = phone.trim().replace(/\s+/g, '');
      user = await prisma.user.findFirst({
        where: { phone: cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}` },
      });

      if (!user) {
        user = await prisma.user.create({
          data: {
            name: `Citizen (${cleanPhone.slice(-4)})`,
            email: `resident-${cleanPhone.replace('+', '')}@resqlink.kerala.gov.in`,
            phone: cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}`,
            phoneVerified: true,
            passwordHash: 'PHONE_ENROLLED_PASSWORDLESS',
            role: 'CITIZEN',
            district: district || 'Wayanad',
          },
        });
      }
    }

    if (!description || description.trim().length === 0) {
      return NextResponse.json({ error: 'Situation description is required' }, { status: 400 });
    }

    // Check offline idempotency key to prevent duplicate SOS creation upon network reconnection
    if (idempotencyKey) {
      const existingSync = await prisma.offlineSyncRecord.findUnique({
        where: { idempotencyKey },
      });
      if (existingSync && existingSync.resolvedId) {
        const existingSos = await prisma.sOSRequest.findUnique({
          where: { id: existingSync.resolvedId },
        });
        if (existingSos) {
          return NextResponse.json({
            sos: existingSos,
            duplicateHandled: true,
            message: 'SOS request previously synced successfully.',
          });
        }
      }
    }

    // Compute Rescue Priority Engine score
    const priorityResult = calculateRescuePriority({
      category,
      peopleCount: Number(peopleCount) || 1,
      hasInjuries: Boolean(hasInjuries),
      immediateDanger: Boolean(immediateDanger),
      locationConfidence: Number(locationConfidence) || 0.85,
      accessibilityNeeds: accessibilityNeeds || null,
      reportedAt: new Date(),
    });

    // Generate unique tracking number: SOS-KL-2026-XXXXX
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const trackingNumber = `SOS-KL-2026-${randomSuffix}`;

    const lat = typeof latitude === 'number' ? latitude : 11.5545;
    const lng = typeof longitude === 'number' ? longitude : 76.1285;
    const nearest = findNearestGramaPanchayat(lat, lng);
    const resolvedPhone = phone || user?.phone || '+919447100004';
    const resolvedDistrict = district || body.district || user?.district || nearest.districtName;
    const resolvedGrama = body.gramaPanchayat || body.grama || nearest.name;
    const resolvedBlock = body.blockPanchayat || body.block || nearest.blockName;
    const resolvedAddress = address || `${body.ward || nearest.localAreas?.[0] || 'Ward 01'}, ${resolvedGrama}, ${resolvedBlock}, ${resolvedDistrict}, Kerala`;

    const sos = await prisma.sOSRequest.create({
      data: {
        trackingNumber,
        userId: user ? user.id : null,
        phone: resolvedPhone,
        gramaPanchayat: resolvedGrama,
        blockPanchayat: resolvedBlock,
        category,
        description: description.trim(),
        peopleCount: Number(peopleCount) || 1,
        hasInjuries: Boolean(hasInjuries),
        immediateDanger: Boolean(immediateDanger),
        latitude: lat,
        longitude: lng,
        address: resolvedAddress,
        district: resolvedDistrict,
        accessibilityNeeds: accessibilityNeeds || null,
        contactPreference,
        locationSource,
        locationConfidence: Number(locationConfidence) || 0.85,
        priorityScore: priorityResult.totalScore,
        priorityCategory: priorityResult.priorityCategory,
        scoreBreakdown: JSON.stringify(priorityResult.breakdown),
        verificationStatus: priorityResult.requiresVerification
          ? 'AWAITING_VERIFICATION'
          : 'VERIFIED',
        status: 'SUBMITTED',
      },
    });

    // Record idempotency receipt if client provided key
    if (idempotencyKey) {
      await prisma.offlineSyncRecord.create({
        data: {
          idempotencyKey,
          payloadType: 'SOS_DRAFT',
          payloadJson: JSON.stringify(body),
          clientTimestamp: new Date(),
          status: 'SYNCED',
          resolvedId: sos.id,
        },
      });
    }

    // Append tamper-evident audit log
    await appendAuditLog({
      actor: user ? user.email : 'ANONYMOUS_RESIDENT',
      action: 'sos.submitted',
      resource: `sos:${sos.id}`,
      outcome: 'SUCCESS',
      reason: `SOS broadcasted with priority ${sos.priorityCategory} (Score ${sos.priorityScore})`,
    });

    return NextResponse.json({
      success: true,
      sos,
      trackingNumber: sos.trackingNumber,
      priorityCategory: sos.priorityCategory,
      priorityScore: sos.priorityScore,
      scoreBreakdown: priorityResult.breakdown,
    });
  } catch (error: any) {
    console.error('SOS submit error:', error);
    return NextResponse.json({ error: error.message || 'Failed to submit SOS' }, { status: 500 });
  }
}
