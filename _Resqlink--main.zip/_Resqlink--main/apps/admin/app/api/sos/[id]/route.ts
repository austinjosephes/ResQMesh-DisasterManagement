import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();

    const request = await prisma.sOSRequest.findFirst({
      where: {
        OR: [{ id }, { trackingNumber: id }],
      },
      include: {
        user: { select: { name: true, email: true } },
      },
    });

    if (!request) {
      return NextResponse.json({ error: 'SOS request not found' }, { status: 404 });
    }

    // Citizen can only access their own request, unless responder/admin
    if (
      user &&
      user.role === 'CITIZEN' &&
      request.userId &&
      request.userId !== user.id
    ) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    return NextResponse.json({ request });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch request' }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getSessionUser();

    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { status, responderNotes, assignedResponderId, priority } = await req.json();

    const existing = await prisma.sOSRequest.findFirst({
      where: {
        OR: [{ id }, { trackingNumber: id }],
      },
    });

    if (!existing) {
      return NextResponse.json({ error: 'SOS request not found' }, { status: 404 });
    }

    // Role check: citizens can only mark their own as RESOLVED or add update note; responders/admins can assign or change status
    const updateData: any = {};
    if (status) updateData.status = status;
    if (responderNotes) updateData.responderNotes = responderNotes;
    if (assignedResponderId && (user.role === 'ADMIN' || user.role === 'COMMANDER' || user.role === 'RESPONDER')) {
      updateData.assignedResponderId = assignedResponderId;
    }
    if (priority && (user.role === 'ADMIN' || user.role === 'COMMANDER')) {
      updateData.priority = priority;
    }

    const updated = await prisma.sOSRequest.update({
      where: { id: existing.id },
      data: updateData,
    });

    await appendAuditLog({
      actor: user.email,
      action: 'sos.update',
      resource: existing.trackingNumber,
      outcome: 'SUCCESS',
      reason: `Updated status to ${status || existing.status}`,
    });

    return NextResponse.json({ request: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update request' }, { status: 500 });
  }
}
