import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function GET(req: Request) {
  try {
    const user = await getSessionUser();
    
    // If authenticated, get user's SOS requests (or all if responder/admin)
    let requests: any[] = [];
    if (user && (user.role === 'ADMIN' || user.role === 'COMMANDER' || user.role === 'RESPONDER')) {
      requests = await prisma.sOSRequest.findMany({
        orderBy: { createdAt: 'desc' },
        include: { user: { select: { name: true, email: true } } },
      });
    } else if (user) {
      requests = await prisma.sOSRequest.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
      });
    } else {
      // Unauthenticated or offline sync query
      const url = new URL(req.url);
      const trackingNumber = url.searchParams.get('trackingNumber');
      if (trackingNumber) {
        requests = await prisma.sOSRequest.findMany({
          where: { trackingNumber },
        });
      } else {
        requests = [];
      }
    }

    return NextResponse.json({ requests });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch SOS requests' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    const body = await req.json();

    const {
      category,
      description,
      peopleCount,
      hasInjuries,
      immediateDanger,
      latitude,
      longitude,
      address,
      accessibilityNeeds,
      contactPreference,
      trackingNumber: clientTrackingNumber,
    } = body;

    if (!category || !description) {
      return NextResponse.json({ error: 'Category and description are required' }, { status: 400 });
    }

    const trackingNumber =
      clientTrackingNumber ||
      `SOS-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    // Check if trackingNumber already exists (idempotency from offline sync)
    const existing = await prisma.sOSRequest.findUnique({
      where: { trackingNumber },
    });

    if (existing) {
      return NextResponse.json({ request: existing, duplicate: true }, { status: 200 });
    }

    // Determine initial priority based on danger and injuries
    let priority = 'MEDIUM';
    if (immediateDanger) {
      priority = 'CRITICAL';
    } else if (hasInjuries) {
      priority = 'HIGH';
    } else if (peopleCount && peopleCount > 5) {
      priority = 'HIGH';
    }

    const newRequest = await prisma.sOSRequest.create({
      data: {
        trackingNumber,
        userId: user ? user.id : null,
        category,
        description,
        peopleCount: Number(peopleCount) || 1,
        hasInjuries: Boolean(hasInjuries),
        immediateDanger: Boolean(immediateDanger),
        latitude: latitude ? parseFloat(latitude) : null,
        longitude: longitude ? parseFloat(longitude) : null,
        address: address || null,
        accessibilityNeeds: accessibilityNeeds || null,
        contactPreference: contactPreference || 'MESH',
        status: 'RECEIVED',
        priority,
      },
    });

    if (user) {
      await appendAuditLog({
        actor: user.email,
        action: 'sos.create',
        resource: trackingNumber,
        outcome: 'SUCCESS',
        reason: `Emergency SOS submitted for category ${category}`,
      });
    }

    return NextResponse.json({ request: newRequest }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to submit SOS request' }, { status: 500 });
  }
}
