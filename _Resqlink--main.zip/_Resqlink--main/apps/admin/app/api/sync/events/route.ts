import { NextResponse } from 'next/server';
import crypto from 'crypto';
import * as jose from 'jose';
import { prisma } from '@/lib/prisma';
import { appendAuditLog } from '@/lib/audit';
import { OfflineEventRecord, SyncResultItem } from '@resqmesh/shared';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const events: OfflineEventRecord[] = body.events || [];

    if (!Array.isArray(events) || events.length === 0) {
      return NextResponse.json({ processed: 0, results: [] });
    }

    const results: SyncResultItem[] = [];
    const serverReceiptTime = Math.floor(Date.now() / 1000);

    for (const event of events) {
      // 1. Check for existing event ID
      const existing = await prisma.offlineEvent.findUnique({
        where: { eventId: event.event_id },
      });

      if (existing) {
        if (existing.payloadHash === event.payload_hash) {
          // Idempotent retry: return previously recorded status
          results.push({
            event_id: event.event_id,
            status: existing.syncStatus as any,
            reason: 'Idempotent duplicate: event previously ingested with identical payload hash',
            server_receipt_time: serverReceiptTime,
          });
          continue;
        } else {
          // Collision attack: same UUID, different payload!
          await appendAuditLog({
            actor: event.device_id,
            action: 'sync.collision_detected',
            resource: event.event_id,
            outcome: 'BLOCKED',
            reason: 'Event ID collision with differing payload hash detected.',
          });

          results.push({
            event_id: event.event_id,
            status: 'REJECTED',
            reason: 'SECURITY CONFLICT: Event ID already exists with a different payload hash.',
            server_receipt_time: serverReceiptTime,
          });
          continue;
        }
      }

      // 2. Validate payload hash
      const computedHash = crypto.createHash('sha256').update(event.payload_json).digest('hex');
      if (computedHash !== event.payload_hash) {
        results.push({
          event_id: event.event_id,
          status: 'REJECTED',
          reason: 'Payload hash integrity check failed: payload was modified.',
          server_receipt_time: serverReceiptTime,
        });
        continue;
      }

      // 3. Check device enrollment and signature
      const device = await prisma.device.findFirst({
        where: {
          OR: [{ id: event.device_id }, { deviceThumbprint: event.device_id }],
        },
      });

      let signatureValid = false;
      if (device) {
        try {
          const pubJwk = JSON.parse(device.publicKeyJwk);
          const cryptoKey = await crypto.subtle.importKey(
            'jwk',
            pubJwk,
            { name: 'ECDSA', namedCurve: 'P-256' },
            true,
            ['verify']
          );
          const sigBytes = jose.base64url.decode(event.device_signature);
          const dataBytes = new TextEncoder().encode(event.payload_hash);
          signatureValid = await crypto.subtle.verify(
            { name: 'ECDSA', hash: { name: 'SHA-256' } },
            cryptoKey,
            sigBytes,
            dataBytes
          );
        } catch (e) {
          signatureValid = false;
        }
      }

      // 4. Check sequence and previous event linkage
      const lastDeviceEvent = await prisma.offlineEvent.findFirst({
        where: { deviceId: event.device_id },
        orderBy: { sequenceNumber: 'desc' },
      });

      let syncStatus: 'ACCEPTED' | 'REJECTED' | 'NEEDS_REVIEW' = 'ACCEPTED';
      let reviewReason = undefined;

      if (lastDeviceEvent) {
        const expectedSeq = lastDeviceEvent.sequenceNumber + 1;
        if (event.sequence_number !== expectedSeq) {
          syncStatus = 'NEEDS_REVIEW';
          reviewReason = `Sequence gap: expected #${expectedSeq}, received #${event.sequence_number}`;
        } else if (event.previous_event_hash !== lastDeviceEvent.payloadHash) {
          syncStatus = 'NEEDS_REVIEW';
          reviewReason = `Hash chain mismatch: claimed previous hash does not match stored sequence #${lastDeviceEvent.sequenceNumber}`;
        }
      }

      // Check if credential is currently revoked
      const revocation = await prisma.revocation.findUnique({
        where: { credentialJti: event.credential_jti },
      });
      if (revocation && revocation.revokedAt <= event.created_at) {
        syncStatus = 'NEEDS_REVIEW';
        reviewReason = `Event occurred after recorded credential revocation (${new Date(revocation.revokedAt * 1000).toISOString()})`;
      }

      // Record offline event
      await prisma.offlineEvent.create({
        data: {
          eventId: event.event_id,
          deviceId: event.device_id,
          credentialJti: event.credential_jti,
          sequenceNumber: event.sequence_number,
          previousEventHash: event.previous_event_hash,
          eventType: event.event_type,
          payloadJson: event.payload_json,
          payloadHash: event.payload_hash,
          createdAtClient: event.created_at,
          deviceSignature: event.device_signature,
          syncStatus,
          reviewReason,
        },
      });

      // Also create SyncReceipt
      try {
        await prisma.syncReceipt.create({
          data: {
            eventId: event.event_id,
            deviceId: event.device_id,
            status: syncStatus,
            signatureVerified: signatureValid,
            details: reviewReason || 'Processed successfully',
          },
        });
      } catch (receiptErr) {}

      results.push({
        event_id: event.event_id,
        status: syncStatus,
        reason: reviewReason || (syncStatus === 'ACCEPTED' ? 'Successfully synchronized and verified.' : 'Flagged for review'),
        server_receipt_time: serverReceiptTime,
      });
    }

    return NextResponse.json({
      success: true,
      processed: results.length,
      results,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
