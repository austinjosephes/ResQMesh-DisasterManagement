import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';
import { appendAuditLog } from '@/lib/audit';

export async function GET() {
  try {
    const pendingEvents = await prisma.offlineEvent.findMany({
      where: { syncStatus: 'NEEDS_REVIEW' },
      orderBy: { serverReceiptTime: 'desc' },
    });

    return NextResponse.json({ events: pendingEvents });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    const actorEmail = user?.email || 'admin@resqmesh.trust';

    const body = await req.json();
    const { eventId, decision, reason = 'Administrative review adjudication' } = body;

    if (!eventId || !['ACCEPTED', 'REJECTED'].includes(decision)) {
      return NextResponse.json({ error: 'Valid eventId and decision (ACCEPTED or REJECTED) required' }, { status: 400 });
    }

    const updated = await prisma.offlineEvent.update({
      where: { eventId },
      data: {
        syncStatus: decision,
        reviewReason: `Adjudicated as ${decision} by ${actorEmail}: ${reason}`,
      },
    });

    await appendAuditLog({
      actor: actorEmail,
      action: 'sync.adjudicate',
      resource: eventId,
      outcome: 'SUCCESS',
      reason: `Adjudicated offline event #${eventId} as ${decision}: ${reason}`,
    });

    return NextResponse.json({ success: true, event: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
