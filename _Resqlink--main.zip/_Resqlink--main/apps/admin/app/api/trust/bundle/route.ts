import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const record = await prisma.trustBundleRecord.findFirst({
      orderBy: { version: 'desc' },
    });

    if (!record) {
      return NextResponse.json({ error: 'No trust bundle initialized' }, { status: 404 });
    }

    const bundle = JSON.parse(record.bundleJson);
    return NextResponse.json({
      bundle,
      rawSignature: record.signature,
      version: record.version,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
