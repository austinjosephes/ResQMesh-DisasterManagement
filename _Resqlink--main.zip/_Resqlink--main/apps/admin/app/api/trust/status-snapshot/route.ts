import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const record = await prisma.signedStatusSnapshot.findFirst({
      orderBy: { version: 'desc' },
    });

    if (!record) {
      return NextResponse.json({ error: 'No status snapshot available' }, { status: 404 });
    }

    const snapshot = JSON.parse(record.snapshotJson);
    return NextResponse.json({
      snapshot,
      version: record.version,
      issuedAt: record.issuedAt,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
