import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { ChallengePayload } from '@resqmesh/shared';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const verifierId = body.verifierId || 'verifier-station-default';
    const audience = body.audience || 'resqmesh:verification';

    const now = Math.floor(Date.now() / 1000);
    const nonce = crypto.randomBytes(16).toString('hex'); // 128-bit cryptographically secure randomness
    const challengeId = crypto.randomUUID();

    const challenge: ChallengePayload = {
      challenge_id: challengeId,
      nonce,
      verifier_id: verifierId,
      audience,
      issued_at: now,
      expires_at: now + 60, // 60 seconds TTL
    };

    return NextResponse.json({ challenge });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
