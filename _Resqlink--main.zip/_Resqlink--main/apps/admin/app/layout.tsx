import './globals.css';
import type { Metadata, Viewport } from 'next';
import { TacticalCursor } from '@/components/shell/TacticalCursor';
import { AdminHeader } from '@/components/AdminHeader';

export const metadata: Metadata = {
  title: 'ResQMesh SEOC Command Centre — State Disaster Operations Platform (Port 3001)',
  description:
    'Dedicated administrative command, live geospatial radar, multi-channel carrier dispatch, and rescue team coordination platform.',
};

export const viewport: Viewport = {
  themeColor: '#07090D',
  width: 'device-width',
  initialScale: 1,
};

export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="min-h-screen bg-[#07090D] text-[#F5F7FA] font-classic antialiased selection:bg-[#FF6B35]/20 selection:text-white">
        <TacticalCursor />
        <AdminHeader />
        <main className="min-h-[calc(100vh-60px)]">{children}</main>
      </body>
    </html>
  );
}
