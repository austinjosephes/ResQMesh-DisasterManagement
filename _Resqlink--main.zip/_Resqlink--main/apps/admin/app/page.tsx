'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminRootRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/admin/dashboard');
  }, [router]);

  return (
    <div className="min-h-screen bg-[#07090D] flex flex-col items-center justify-center p-6 text-center space-y-4 font-mono">
      <div className="w-12 h-12 rounded-2xl bg-[#FF6B35]/15 border border-[#FF6B35]/30 flex items-center justify-center animate-spin">
        <span className="w-4 h-4 rounded-full bg-[#FF6B35]" />
      </div>
      <div className="space-y-1">
        <h2 className="text-lg font-extrabold text-[#F5F7FA]">
          RESQMESH KERALA — SEOC COMMAND CENTRE
        </h2>
        <p className="text-xs text-[#929CAB]">
          Routing to State Disaster Operations Dashboard (Port 3001)...
        </p>
      </div>
    </div>
  );
}
