'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ShieldAlert,
  Radio,
  Sliders,
  Users,
  Compass,
  HeartPulse,
  Activity,
  ArrowRight,
  ExternalLink,
  LifeBuoy,
  Menu,
  X,
  Lock,
  CloudRain,
  FileCheck2,
  Clock,
  Sparkles,
} from 'lucide-react';

export function AdminHeader() {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        }) + ' IST'
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const navLinks = [
    { label: 'Command Overview', href: '/admin/dashboard', icon: Sliders },
    { label: 'Tactical Radar', href: '/admin/live-map', icon: Compass },
    { label: 'Direct Dispatch', href: '/admin/alerts', icon: Radio, highlight: true },
    { label: 'SOS Incidents', href: '/admin/incidents', icon: ShieldAlert },
    { label: 'Rescue Teams', href: '/admin/rescue-teams', icon: Users },
    { label: 'Relief Camps', href: '/admin/shelters', icon: HeartPulse },
    { label: 'Resident Registry', href: '/admin/residents', icon: Users },
    { label: 'Weather Authority', href: '/admin/weather-ingest', icon: CloudRain },
    { label: 'Analytics', href: '/admin/analytics', icon: Activity },
    { label: 'Audit Chain', href: '/admin/audit-logs', icon: FileCheck2 },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#0B1017]/95 backdrop-blur-xl border-b border-white/[0.08] px-4 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs font-mono">
        {/* Left: Authority Crest & System Identity */}
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard" className="flex items-center gap-2.5 hover:opacity-90 transition">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF6B35]/30 to-[#F5A623]/20 border border-[#FF6B35]/40 flex items-center justify-center text-[#FF6B35] shadow-lg shadow-[#FF6B35]/20">
              <ShieldAlert className="w-5 h-5 text-[#FF6B35]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-[#F5F7FA] text-sm tracking-tight font-headline">RESQMESH KERALA</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#FF6B35]/20 text-[#FF6B35] font-bold border border-[#FF6B35]/30">
                  SEOC COMMAND (PORT 3001)
                </span>
              </div>
              <div className="text-[10px] text-[#929CAB]">State Emergency Operations Centre • Official Authority Platform</div>
            </div>
          </Link>
        </div>

        {/* Center: Desktop Navigation Tabs with Active Glow */}
        <nav className="hidden lg:flex items-center gap-1 text-[11px] font-semibold">
          {navLinks.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${
                  isActive
                    ? 'bg-[#FF6B35]/15 text-[#FF6B35] border border-[#FF6B35]/40 shadow-sm font-bold'
                    : item.highlight
                    ? 'text-[#38BDF8] hover:text-white hover:bg-white/[0.04]'
                    : 'text-[#929CAB] hover:text-[#F5F7FA] hover:bg-white/[0.04]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#FF6B35]' : 'text-current'}`} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Right: Clock & Quick Bridge to Citizen Portal (Port 3000) */}
        <div className="flex items-center gap-3">
          {/* Real-time IST Clock */}
          {currentTime && (
            <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/[0.04] border border-white/[0.08] text-[#929CAB] text-[11px]">
              <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span className="font-bold text-[#F5F7FA]">{currentTime}</span>
            </div>
          )}

          {/* Live System Beacon */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#22C55E]/10 border border-[#22C55E]/30 text-[#22C55E] text-[11px] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
            <span>SEOC RESILIENT</span>
          </div>

          {/* Quick Handoff Button to Citizen Portal on Port 3000 */}
          <a
            href="http://localhost:3000"
            target="_blank"
            rel="noreferrer"
            className="ios-button-glass px-3.5 py-1.5 text-xs font-mono font-bold text-[#38BDF8] hover:text-white flex items-center gap-1.5 shadow-lg border-[#38BDF8]/40"
            title="Open Citizen Safety Portal on Port 3000"
          >
            <LifeBuoy className="w-3.5 h-3.5 text-[#FF6B35]" />
            <span className="hidden sm:inline">Citizen Portal (Port 3000)</span>
            <span className="sm:hidden">Port 3000</span>
            <ExternalLink className="w-3 h-3 text-[#38BDF8]" />
          </a>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg bg-white/[0.06] border border-white/[0.1] text-[#929CAB] hover:text-white"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 pt-3 border-t border-white/[0.08] grid grid-cols-2 gap-1.5 animate-fadeIn font-mono text-xs">
          {navLinks.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-2 p-2 rounded-lg ${
                  isActive
                    ? 'bg-[#FF6B35]/20 text-[#FF6B35] font-bold border border-[#FF6B35]/30'
                    : 'text-[#929CAB] hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </div>
      )}
    </header>
  );
}
