'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface ZoomingParticlesBackground3DProps {
  className?: string;
  particleCount?: number;
}

export function ZoomingParticlesBackground3D({
  className = '',
  particleCount = 380,
}: ZoomingParticlesBackground3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [webglSupported, setWebglSupported] = useState(true);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    let width = window.innerWidth;
    let height = window.innerHeight;

    // WebGL Check
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setWebglSupported(false);
        return;
      }
    } catch {
      setWebglSupported(false);
      return;
    }

    // 1. Scene & Camera with deep perspective
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07090d, 0.035);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 0, 16);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas: canvasRef.current,
        alpha: true,
        antialias: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglSupported(false);
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // 2. Procedural Glowing Circular Particle Texture
    const createParticleTexture = () => {
      const pCanvas = document.createElement('canvas');
      pCanvas.width = 64;
      pCanvas.height = 64;
      const ctx = pCanvas.getContext('2d');
      if (!ctx) return null;

      const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.2, 'rgba(255, 255, 255, 0.85)');
      grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.35)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 64, 64);

      const texture = new THREE.CanvasTexture(pCanvas);
      return texture;
    };

    const particleTexture = createParticleTexture();

    // 3. 3D Floating Particle Volume
    const count = particleCount;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    const velocities = new Float32Array(count * 3);
    const basePositions = new Float32Array(count * 3);

    // Color definitions
    const colOrange = new THREE.Color('#FF6B35');
    const colCyan = new THREE.Color('#38BDF8');
    const colAmber = new THREE.Color('#F5A623');
    const colRuby = new THREE.Color('#EF4444');
    const colWhite = new THREE.Color('#F5F7FA');

    for (let i = 0; i < count; i++) {
      // Spread across deep 3D bounds
      const x = (Math.random() - 0.5) * 44;
      const y = (Math.random() - 0.5) * 48;
      const z = (Math.random() - 0.5) * 38;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      basePositions[i * 3] = x;
      basePositions[i * 3 + 1] = y;
      basePositions[i * 3 + 2] = z;

      // Velocities for organic floating
      velocities[i * 3] = (Math.random() - 0.5) * 0.008;
      velocities[i * 3 + 1] = 0.006 + Math.random() * 0.012; // slow upward drift
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.006;

      // Palette assignment: 40% white, 30% cyan, 20% orange, 10% amber
      const rand = Math.random();
      let chosenColor = colWhite;
      if (rand < 0.28) chosenColor = colCyan;
      else if (rand < 0.48) chosenColor = colOrange;
      else if (rand < 0.58) chosenColor = colAmber;
      else if (rand < 0.65) chosenColor = colRuby;

      colors[i * 3] = chosenColor.r;
      colors[i * 3 + 1] = chosenColor.g;
      colors[i * 3 + 2] = chosenColor.b;

      scales[i] = 0.15 + Math.random() * 0.35;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.38,
      vertexColors: true,
      map: particleTexture || undefined,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particleSystem = new THREE.Points(geometry, material);
    scene.add(particleSystem);

    // 4. Subtle Inter-Particle Constellation Network Lines (Dynamic Lattice)
    const lineCount = 90;
    const linePositions = new Float32Array(lineCount * 6);
    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.18,
      blending: THREE.AdditiveBlending,
    });
    const linesMesh = new THREE.LineSegments(lineGeo, lineMat);
    scene.add(linesMesh);

    // 5. Ambient Atmospheric Floating Orbs (Soft glowing depth layers)
    const orbGroup = new THREE.Group();
    scene.add(orbGroup);

    const createAtmosphereOrb = (colorHex: number, x: number, y: number, z: number, scale: number) => {
      const orbGeo = new THREE.SphereGeometry(scale, 16, 16);
      const orbMat = new THREE.MeshBasicMaterial({
        color: colorHex,
        transparent: true,
        opacity: 0.035,
        wireframe: true,
      });
      const orb = new THREE.Mesh(orbGeo, orbMat);
      orb.position.set(x, y, z);
      orbGroup.add(orb);
      return orb;
    };

    const orb1 = createAtmosphereOrb(0xff6b35, -12, 6, -10, 8);
    const orb2 = createAtmosphereOrb(0x38bdf8, 14, -8, -14, 10);
    const orb3 = createAtmosphereOrb(0xf5a623, 0, 15, -18, 12);

    // 6. Interactive Scroll Zoom & Mouse Parallax Handlers
    let scrollY = 0;
    let targetScrollY = 0;
    let mouseX = 0;
    let mouseY = 0;
    let targetMouseX = 0;
    let targetMouseY = 0;

    const handleScroll = () => {
      targetScrollY = window.scrollY || document.documentElement.scrollTop;
    };

    const handleMouseMove = (e: MouseEvent) => {
      targetMouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetMouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    const handleResize = () => {
      if (!canvasRef.current) return;
      width = window.innerWidth;
      height = window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    // 7. Continuous Animation Loop with Zooming Scrolling Effect
    let currentAnimFrame: number;
    let clock = new THREE.Clock();

    const animate = () => {
      currentAnimFrame = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth scroll lerping for fluid zooming effect
      scrollY += (targetScrollY - scrollY) * 0.08;
      mouseX += (targetMouseX - mouseX) * 0.05;
      mouseY += (targetMouseY - mouseY) * 0.05;

      const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const scrollProgress = Math.min(1, Math.max(0, scrollY / maxScroll));

      // ZOOMING SCROLLING EFFECT:
      // Camera zooms in and shifts perspective as visitor scrolls down the page!
      // Position Z zooms from 16 down towards 4.5, creating an exhilarating deep-space navigation feel
      const baseZoomZ = 16;
      const zoomDepth = 11.5; // amount to plunge forward
      camera.position.z = baseZoomZ - scrollProgress * zoomDepth;

      // Vertical parallax with scroll
      camera.position.y = -scrollProgress * 12 + (-mouseY * 1.5);
      camera.position.x = mouseX * 2.2 + Math.sin(scrollProgress * Math.PI) * 1.8;

      // Slight tilt on fast scroll / parallax
      camera.rotation.z = Math.sin(elapsedTime * 0.2) * 0.02 + mouseX * 0.03;
      camera.rotation.x = -mouseY * 0.03 + (scrollProgress * 0.15);

      // Particle Floating Motion
      const posAttr = geometry.attributes.position;
      const posArr = posAttr.array as Float32Array;

      for (let i = 0; i < count; i++) {
        const i3 = i * 3;

        // Upward drift
        posArr[i3 + 1] += velocities[i3 + 1];
        // Harmonic side wobble
        posArr[i3] += Math.sin(elapsedTime * 0.8 + i) * 0.004 + velocities[i3];
        posArr[i3 + 2] += Math.cos(elapsedTime * 0.6 + i) * 0.003;

        // Wrap around bounds so particles endlessly float
        if (posArr[i3 + 1] > 28) posArr[i3 + 1] = -24;
        if (posArr[i3] > 26) posArr[i3] = -26;
        if (posArr[i3] < -26) posArr[i3] = 26;
        if (posArr[i3 + 2] > 22) posArr[i3 + 2] = -22;
        if (posArr[i3 + 2] < -22) posArr[i3 + 2] = 22;
      }
      posAttr.needsUpdate = true;

      // Dynamic Constellation lines between nearby particles
      let lineVertexIndex = 0;
      const linePosArr = lineGeo.attributes.position.array as Float32Array;

      // Sample a subset for 60fps performance
      for (let i = 0; i < 45 && lineVertexIndex < lineCount * 6; i++) {
        const idxA = i * 4;
        const ax = posArr[idxA * 3];
        const ay = posArr[idxA * 3 + 1];
        const az = posArr[idxA * 3 + 2];

        for (let j = i + 1; j < i + 4 && lineVertexIndex < lineCount * 6; j++) {
          const idxB = (j * 4) % count;
          const bx = posArr[idxB * 3];
          const by = posArr[idxB * 3 + 1];
          const bz = posArr[idxB * 3 + 2];

          const distSq = (ax - bx) ** 2 + (ay - by) ** 2 + (az - bz) ** 2;
          if (distSq < 36) {
            linePosArr[lineVertexIndex++] = ax;
            linePosArr[lineVertexIndex++] = ay;
            linePosArr[lineVertexIndex++] = az;
            linePosArr[lineVertexIndex++] = bx;
            linePosArr[lineVertexIndex++] = by;
            linePosArr[lineVertexIndex++] = bz;
          }
        }
      }
      lineGeo.attributes.position.needsUpdate = true;

      // Rotate atmosphere orbs slowly with scroll response
      orbGroup.rotation.y = elapsedTime * 0.04 + scrollProgress * 1.5;
      orb1.rotation.x = elapsedTime * 0.03;
      orb2.rotation.z = elapsedTime * 0.02;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(currentAnimFrame);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      geometry.dispose();
      material.dispose();
      lineGeo.dispose();
      lineMat.dispose();
    };
  }, [particleCount]);

  if (!webglSupported) return null;

  return (
    <div
      ref={containerRef}
      className={`fixed inset-0 pointer-events-none z-0 overflow-hidden ${className}`}
      aria-hidden="true"
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block opacity-85"
      />
      {/* Subtle depth vignette overlay */}
      <div className="absolute inset-0 bg-radial-gradient from-transparent via-transparent to-[#07090D]/80 pointer-events-none" />
    </div>
  );
}
