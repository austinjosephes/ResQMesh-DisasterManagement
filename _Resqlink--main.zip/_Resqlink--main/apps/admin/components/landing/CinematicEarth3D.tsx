'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Globe,
  Radio,
  Wifi,
  Navigation,
  ShieldAlert,
  Layers,
  RotateCw,
  Eye,
  Maximize2,
  Crosshair,
  Activity,
  Zap,
} from 'lucide-react';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

export interface GroundNode {
  id: string;
  name: string;
  type: 'seoc' | 'hazard' | 'hydro' | 'international' | 'national' | 'logistics';
  lat: number;
  lng: number;
  color: string;
  hexColor: number;
  status: 'ACTIVE' | 'CRITICAL' | 'WARNING' | 'STANDBY';
  telemetry: string;
  vector?: THREE.Vector3;
}

export interface SatelliteNode {
  id: string;
  name: string;
  constellation: string;
  color: string;
  hexColor: number;
  radius: number;
  speed: number;
  inclination: number;
  phaseOffset: number;
  downlinkTargetId: string;
  status: 'LOCKED' | 'ACQUIRING' | 'TRANSMITTING';
}

const GLOBAL_NODES: GroundNode[] = [
  {
    id: 'kerala_seoc',
    name: 'Kerala SEOC Command HQ',
    type: 'seoc',
    lat: 10.85,
    lng: 76.27,
    color: '#FF6B35',
    hexColor: 0xff6b35,
    status: 'ACTIVE',
    telemetry: 'Primary State Node • 941 Grama Mesh Synced • ES256 Verified',
  },
  {
    id: 'wayanad_slide',
    name: 'Wayanad Meppadi Hazard Zone',
    type: 'hazard',
    lat: 11.68,
    lng: 76.13,
    color: '#EF4444',
    hexColor: 0xef4444,
    status: 'CRITICAL',
    telemetry: 'Rain Gauge 284mm/24h • Debris Flow Vector Active',
  },
  {
    id: 'idukki_dam',
    name: 'Idukki Reservoir Sensor Hub',
    type: 'hydro',
    lat: 9.85,
    lng: 76.97,
    color: '#F5A623',
    hexColor: 0xf5a623,
    status: 'WARNING',
    telemetry: 'Inflow 810 m³/s • Spillway Gate #3 Standing By',
  },
  {
    id: 'ndma_delhi',
    name: 'NDMA National Grid (Delhi)',
    type: 'national',
    lat: 28.61,
    lng: 77.2,
    color: '#FF6B35',
    hexColor: 0xff6b35,
    status: 'ACTIVE',
    telemetry: 'Inter-Agency Emergency Coordination Direct Trunk',
  },
  {
    id: 'tokyo_jma',
    name: 'Tokyo JMA Pacific Watch',
    type: 'international',
    lat: 35.67,
    lng: 139.65,
    color: '#38BDF8',
    hexColor: 0x38bdf8,
    status: 'ACTIVE',
    telemetry: 'Tsunami & Himawari SAR Atmospheric Telemetry Cross-Feed',
  },
  {
    id: 'singapore_aha',
    name: 'Singapore AHA Disaster Logistics',
    type: 'logistics',
    lat: 1.35,
    lng: 103.82,
    color: '#22C55E',
    hexColor: 0x22c55e,
    status: 'ACTIVE',
    telemetry: 'ASEAN Humanitarian Assistance Strategic Pre-positioning',
  },
  {
    id: 'dubai_airlift',
    name: 'Dubai Humanitarian Airlift Hub',
    type: 'logistics',
    lat: 25.2,
    lng: 55.27,
    color: '#FF6B35',
    hexColor: 0xff6b35,
    status: 'ACTIVE',
    telemetry: 'West-Asia Strategic Emergency Cargo Air-Bridge',
  },
  {
    id: 'geneva_un',
    name: 'Geneva UN WMO / OCHA Center',
    type: 'international',
    lat: 46.2,
    lng: 6.14,
    color: '#38BDF8',
    hexColor: 0x38bdf8,
    status: 'ACTIVE',
    telemetry: 'Global Early Warning Initiative • Global Meteorological Feed',
  },
  {
    id: 'ny_un',
    name: 'UN Disaster Relief (New York)',
    type: 'international',
    lat: 40.71,
    lng: -74.0,
    color: '#38BDF8',
    hexColor: 0x38bdf8,
    status: 'ACTIVE',
    telemetry: 'UN-SPIDER Space-Based Disaster Management Telemetry',
  },
];

const SATELLITES: SatelliteNode[] = [
  {
    id: 'insat_3dr',
    name: 'INSAT-3DR (ISRO)',
    constellation: 'Meteorological & Ocean Imager',
    color: '#FF6B35',
    hexColor: 0xff6b35,
    radius: 3.5,
    speed: 0.5,
    inclination: 0.45,
    phaseOffset: 0.2,
    downlinkTargetId: 'kerala_seoc',
    status: 'LOCKED',
  },
  {
    id: 'sentinel_2',
    name: 'Sentinel-2 SAR (ESA)',
    constellation: 'High-Res Multi-Spectral Radar',
    color: '#38BDF8',
    hexColor: 0x38bdf8,
    radius: 3.15,
    speed: 0.75,
    inclination: 1.25,
    phaseOffset: 2.4,
    downlinkTargetId: 'wayanad_slide',
    status: 'TRANSMITTING',
  },
  {
    id: 'navic_1i',
    name: 'NavIC / IRNSS-1I (ISRO)',
    constellation: 'Subcontinental Precision Geo-Sync',
    color: '#F5A623',
    hexColor: 0xf5a623,
    radius: 3.8,
    speed: 0.35,
    inclination: 0.72,
    phaseOffset: 4.5,
    downlinkTargetId: 'idukki_dam',
    status: 'LOCKED',
  },
];

interface CinematicEarth3DProps {
  onStageChange?: (stage: number, stageName: string) => void;
  className?: string;
  mode?: 'hero' | 'command';
  showControls?: boolean;
}

export function CinematicEarth3D({
  onStageChange,
  className = '',
  mode = 'hero',
  showControls = true,
}: CinematicEarth3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeStage, setActiveStage] = useState(1);
  const [webglSupported, setWebglSupported] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);

  // Active Session Telemetry State
  const [hoveredNode, setHoveredNode] = useState<GroundNode | SatelliteNode | null>(null);
  const [selectedNode, setSelectedNode] = useState<GroundNode | SatelliteNode | null>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [showBeams, setShowBeams] = useState(true);
  const [bitrate, setBitrate] = useState(1248.6);
  const [packetsRouted, setPacketsRouted] = useState(48291);

  // Focus presets trigger
  const cameraTargetRef = useRef<{ x: number; y: number; z: number } | null>(null);
  const globeTargetRotRef = useRef<{ x: number; y: number } | null>(null);

  const STAGE_NAMES = [
    'Global Orbital Intelligence',
    'Pan-Asian Disaster Monitoring',
    'India National Response Grid',
    'Kerala Geospatial Sector Focus',
    'High-Hazard Inundation & Landslide Zones',
    'Live SEOC Incident Command Integration',
  ];

  // Bitrate and packet stream simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setBitrate((prev) => +(prev + (Math.random() * 8 - 4)).toFixed(1));
      setPacketsRouted((prev) => prev + Math.floor(Math.random() * 12 + 6));
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  // Preset camera focus triggers
  const focusOnKerala = useCallback(() => {
    // Focus specifically on Kerala SEOC
    globeTargetRotRef.current = { x: 0.18, y: -Math.PI / 1.7 + 1.15 };
    cameraTargetRef.current = { x: 0.2, y: 0.15, z: 2.85 };
  }, []);

  const focusOnGlobal = useCallback(() => {
    globeTargetRotRef.current = { x: 0.22, y: -Math.PI / 1.7 };
    cameraTargetRef.current = { x: 0, y: 0, z: 6.8 };
  }, []);

  const focusOnAsia = useCallback(() => {
    globeTargetRotRef.current = { x: 0.35, y: -Math.PI / 1.7 + 0.5 };
    cameraTargetRef.current = { x: 0.5, y: 0.3, z: 4.4 };
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    let width = containerRef.current.clientWidth || window.innerWidth;
    let height = containerRef.current.clientHeight || window.innerHeight;

    // 1. WebGL Verification
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setWebglSupported(false);
        return;
      }
    } catch {
      setWebglSupported(false);
      return;
    }

    // 2. Scene, Camera, WebGL Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07090d, 0.045);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0, mode === 'command' ? 5.8 : 7.2);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas: canvasRef.current,
        alpha: true,
        antialias: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglSupported(false);
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;

    // 3. Cinematic Lighting Rig
    const ambientLight = new THREE.AmbientLight(0x0a121e, 2.5);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff6ed, 4.0);
    sunLight.position.set(9, 6, 7);
    scene.add(sunLight);

    const orangeRimLight = new THREE.DirectionalLight(0xff6b35, 3.0);
    orangeRimLight.position.set(-8, -4, -6);
    scene.add(orangeRimLight);

    const cyanFillLight = new THREE.DirectionalLight(0x38bdf8, 1.8);
    cyanFillLight.position.set(0, 8, -4);
    scene.add(cyanFillLight);

    // 4. Background Starfield
    const starsCount = 1200;
    const starPositions = new Float32Array(starsCount * 3);
    const starColors = new Float32Array(starsCount * 3);
    const colCyan = new THREE.Color('#38BDF8');
    const colOrange = new THREE.Color('#FF6B35');
    const colWhite = new THREE.Color('#F5F7FA');

    for (let i = 0; i < starsCount; i++) {
      const radius = 28 + Math.random() * 45;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = radius * Math.cos(phi);

      const colorPick = Math.random();
      const col = colorPick > 0.82 ? colOrange : colorPick > 0.62 ? colCyan : colWhite;
      starColors[i * 3] = col.r;
      starColors[i * 3 + 1] = col.g;
      starColors[i * 3 + 2] = col.b;
    }

    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starMat = new THREE.PointsMaterial({
      size: 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
    });
    const starfield = new THREE.Points(starGeo, starMat);
    scene.add(starfield);

    // 5. Main Globe Root Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Coordinate conversion helper
    const earthRadius = 2.4;
    const latLngToVector3 = (lat: number, lng: number, radius: number = earthRadius) => {
      const phi = (90 - lat) * (Math.PI / 180);
      const theta = (lng + 180) * (Math.PI / 180);
      const x = -radius * Math.sin(phi) * Math.cos(theta);
      const z = radius * Math.sin(phi) * Math.sin(theta);
      const y = radius * Math.cos(phi);
      return new THREE.Vector3(x, y, z);
    };

    // Calculate node 3D vector positions
    GLOBAL_NODES.forEach((node) => {
      node.vector = latLngToVector3(node.lat, node.lng, earthRadius * 1.012);
    });

    // Procedural High-Detail Earth Texture
    const createEarthTexture = () => {
      const texCanvas = document.createElement('canvas');
      texCanvas.width = 2048;
      texCanvas.height = 1024;
      const ctx = texCanvas.getContext('2d');
      if (!ctx) return null;

      // Deep Ocean Bathymetry
      const oceanGrad = ctx.createLinearGradient(0, 0, 0, 1024);
      oceanGrad.addColorStop(0, '#04070D');
      oceanGrad.addColorStop(0.5, '#0B1525');
      oceanGrad.addColorStop(1, '#04070D');
      ctx.fillStyle = oceanGrad;
      ctx.fillRect(0, 0, 2048, 1024);

      // Continent Landmasses
      ctx.fillStyle = '#101B2B';
      ctx.strokeStyle = '#1D304A';
      ctx.lineWidth = 2;

      const drawContinent = (pts: number[][]) => {
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) {
          ctx.lineTo(pts[i][0], pts[i][1]);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      };

      // Eurasia
      drawContinent([
        [1050, 220], [1250, 200], [1500, 210], [1750, 260], [1850, 360],
        [1700, 480], [1550, 480], [1480, 560], [1460, 580], [1440, 540],
        [1420, 460], [1300, 420], [1180, 460], [1080, 410], [1050, 310],
      ]);

      // Detailed India Subcontinent & Western Ghats
      ctx.fillStyle = '#14253B';
      ctx.beginPath();
      ctx.moveTo(1400, 380);
      ctx.lineTo(1420, 440);
      ctx.lineTo(1435, 490);
      ctx.lineTo(1445, 540);
      ctx.lineTo(1455, 570);
      ctx.lineTo(1475, 540);
      ctx.lineTo(1510, 470);
      ctx.lineTo(1525, 410);
      ctx.lineTo(1490, 370);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Kerala Western Coastline Highlight
      ctx.strokeStyle = '#FF6B35';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(1440, 520);
      ctx.lineTo(1445, 540);
      ctx.lineTo(1450, 555);
      ctx.lineTo(1454, 570);
      ctx.stroke();

      // Africa
      ctx.fillStyle = '#0F1A28';
      drawContinent([
        [980, 380], [1160, 380], [1220, 460], [1180, 580], [1130, 680],
        [1080, 720], [1020, 640], [960, 520], [940, 440],
      ]);

      // Americas
      drawContinent([
        [320, 220], [500, 240], [450, 380], [380, 420], [350, 470],
        [410, 530], [460, 610], [420, 750], [360, 780], [340, 650],
        [310, 520], [240, 400], [280, 260],
      ]);

      // Australia
      drawContinent([
        [1680, 620], [1800, 630], [1830, 720], [1720, 750], [1650, 700],
      ]);

      // Lat/Long Coordinate Grid
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
      ctx.lineWidth = 1;
      for (let y = 100; y < 1000; y += 100) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(2048, y);
        ctx.stroke();
      }
      for (let x = 100; x < 2048; x += 150) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 1024);
        ctx.stroke();
      }

      // City light points
      const cities = [
        [1450, 555], [1448, 480], [1480, 420], [1490, 540],
        [1820, 360], [1120, 280], [460, 380], [1620, 600],
      ];
      ctx.fillStyle = '#FFD285';
      cities.forEach(([cx, cy]) => {
        ctx.beginPath();
        ctx.arc(cx, cy, 2.5, 0, Math.PI * 2);
        ctx.fill();
      });

      const texture = new THREE.CanvasTexture(texCanvas);
      texture.wrapS = THREE.RepeatWrapping;
      texture.wrapT = THREE.ClampToEdgeWrapping;
      return texture;
    };

    const earthTexture = createEarthTexture();

    // 6. Earth Sphere Mesh
    const earthGeo = new THREE.SphereGeometry(earthRadius, 64, 64);
    const earthMat = new THREE.MeshStandardMaterial({
      map: earthTexture || undefined,
      color: 0x141f2f,
      roughness: 0.65,
      metalness: 0.25,
      emissive: 0x050c18,
      emissiveIntensity: 0.45,
    });
    const earthMesh = new THREE.Mesh(earthGeo, earthMat);
    globeGroup.add(earthMesh);

    // Glowing Atmosphere Fresnels
    const atmosphereGeo = new THREE.SphereGeometry(earthRadius * 1.045, 48, 48);
    const atmosphereMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.12,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeo, atmosphereMat);
    globeGroup.add(atmosphereMesh);

    const orangeHaloGeo = new THREE.SphereGeometry(earthRadius * 1.085, 36, 36);
    const orangeHaloMat = new THREE.MeshBasicMaterial({
      color: 0xff6b35,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });
    const orangeHaloMesh = new THREE.Mesh(orangeHaloGeo, orangeHaloMat);
    globeGroup.add(orangeHaloMesh);

    // 7. Interactive Ground Stations & Multi-Ring Shockwave Beacons
    const shockwaveRings: { mesh: THREE.Mesh; scale: number; baseScale: number; speed: number; opacity: number }[] = [];
    const interactiveMeshes: { mesh: THREE.Object3D; data: GroundNode | SatelliteNode }[] = [];

    GLOBAL_NODES.forEach((node) => {
      const pos = node.vector || latLngToVector3(node.lat, node.lng, earthRadius * 1.012);
      const beaconGroup = new THREE.Group();
      beaconGroup.position.copy(pos);

      // Core Marker Sphere
      const dotGeo = new THREE.SphereGeometry(node.type === 'seoc' ? 0.075 : 0.05, 16, 16);
      const dotMat = new THREE.MeshBasicMaterial({ color: node.hexColor });
      const dotMesh = new THREE.Mesh(dotGeo, dotMat);
      beaconGroup.add(dotMesh);
      interactiveMeshes.push({ mesh: dotMesh, data: node });

      // Holographic Vertical Directional Beacon Line
      const pillarGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.35, 8);
      const pillarMat = new THREE.MeshBasicMaterial({
        color: node.hexColor,
        transparent: true,
        opacity: 0.75,
      });
      const pillarMesh = new THREE.Mesh(pillarGeo, pillarMat);
      pillarMesh.position.y = 0.175;
      beaconGroup.add(pillarMesh);

      // Multi-layer Expanding Radar Shockwave Rings
      for (let r = 0; r < 2; r++) {
        const ringGeo = new THREE.RingGeometry(0.06, 0.09, 24);
        const ringMat = new THREE.MeshBasicMaterial({
          color: node.hexColor,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.8,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.lookAt(pos.clone().multiplyScalar(2));
        beaconGroup.add(ringMesh);

        shockwaveRings.push({
          mesh: ringMesh,
          scale: 1.0 + r * 0.8,
          baseScale: 1.0,
          speed: 0.018 + r * 0.005,
          opacity: 0.85,
        });
      }

      beaconGroup.lookAt(pos.clone().multiplyScalar(2));
      globeGroup.add(beaconGroup);
    });

    // 8. Great-Circle Curved Conduits & Flowing Photon Packets
    interface FlowingPacket {
      curve: THREE.QuadraticBezierCurve3;
      mesh: THREE.Mesh;
      t: number;
      speed: number;
    }
    const flowingPackets: FlowingPacket[] = [];

    const createConduit = (startNodeId: string, endNodeId: string, colorHex: number) => {
      const sNode = GLOBAL_NODES.find((n) => n.id === startNodeId);
      const eNode = GLOBAL_NODES.find((n) => n.id === endNodeId);
      if (!sNode || !eNode || !sNode.vector || !eNode.vector) return;

      const mid = sNode.vector.clone().lerp(eNode.vector, 0.5);
      const dist = sNode.vector.distanceTo(eNode.vector);
      mid.normalize().multiplyScalar(earthRadius + dist * 0.38);

      const curve = new THREE.QuadraticBezierCurve3(sNode.vector, mid, eNode.vector);
      const pts = curve.getPoints(50);
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({
        color: colorHex,
        transparent: true,
        opacity: 0.55,
      });
      const line = new THREE.Line(geo, mat);
      globeGroup.add(line);

      // Add 2 glowing photon packets flowing along this conduit
      for (let p = 0; p < 2; p++) {
        const pGeo = new THREE.SphereGeometry(0.035, 10, 10);
        const pMat = new THREE.MeshBasicMaterial({ color: colorHex });
        const pMesh = new THREE.Mesh(pGeo, pMat);
        globeGroup.add(pMesh);

        flowingPackets.push({
          curve,
          mesh: pMesh,
          t: p * 0.5,
          speed: 0.0055 + Math.random() * 0.003,
        });
      }
    };

    // Build Interconnecting Conduits
    createConduit('kerala_seoc', 'ndma_delhi', 0xff6b35);
    createConduit('kerala_seoc', 'tokyo_jma', 0x38bdf8);
    createConduit('kerala_seoc', 'singapore_aha', 0x22c55e);
    createConduit('kerala_seoc', 'dubai_airlift', 0xff6b35);
    createConduit('kerala_seoc', 'geneva_un', 0x38bdf8);
    createConduit('ndma_delhi', 'geneva_un', 0x38bdf8);
    createConduit('geneva_un', 'ny_un', 0x38bdf8);
    createConduit('kerala_seoc', 'wayanad_slide', 0xef4444);
    createConduit('kerala_seoc', 'idukki_dam', 0xf5a623);

    // 9. Active Satellite Constellation Models, Trajectories & Downlink Beams
    interface SatelliteInstance {
      data: SatelliteNode;
      group: THREE.Group;
      beamCone: THREE.Mesh;
      telemetryLine: THREE.Line;
      telemetryGeo: THREE.BufferGeometry;
      orbitAngle: number;
    }
    const satelliteInstances: SatelliteInstance[] = [];

    SATELLITES.forEach((sat) => {
      const satGroup = new THREE.Group();

      // Satellite Central Body
      const bodyGeo = new THREE.BoxGeometry(0.08, 0.06, 0.12);
      const bodyMat = new THREE.MeshStandardMaterial({
        color: 0xcccccc,
        metalness: 0.9,
        roughness: 0.2,
      });
      const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
      satGroup.add(bodyMesh);

      // Solar Panels
      const panelGeo = new THREE.BoxGeometry(0.32, 0.015, 0.08);
      const panelMat = new THREE.MeshBasicMaterial({ color: 0x1e3a8a });
      const panelMesh = new THREE.Mesh(panelGeo, panelMat);
      satGroup.add(panelMesh);

      // Optical Beacon / Transmitter Dot
      const lightGeo = new THREE.SphereGeometry(0.045, 12, 12);
      const lightMat = new THREE.MeshBasicMaterial({ color: sat.hexColor });
      const lightMesh = new THREE.Mesh(lightGeo, lightMat);
      satGroup.add(lightMesh);

      globeGroup.add(satGroup);
      interactiveMeshes.push({ mesh: lightMesh, data: sat });

      // Trajectory Ring Line
      const orbitCurve = new THREE.EllipseCurve(
        0, 0,
        sat.radius, sat.radius * 0.96,
        0, 2 * Math.PI,
        false, 0
      );
      const orbitPts = orbitCurve.getPoints(120);
      const orbitGeo = new THREE.BufferGeometry().setFromPoints(
        orbitPts.map((p) => new THREE.Vector3(p.x, 0, p.y))
      );
      const orbitMat = new THREE.LineBasicMaterial({
        color: sat.hexColor,
        transparent: true,
        opacity: 0.35,
      });
      const orbitLine = new THREE.Line(orbitGeo, orbitMat);
      orbitLine.rotation.x = sat.inclination;
      orbitLine.rotation.y = sat.phaseOffset * 0.5;
      globeGroup.add(orbitLine);

      // Conical Downlink Scanning Beam
      const beamHeight = sat.radius - earthRadius;
      const coneGeo = new THREE.ConeGeometry(0.65, beamHeight, 32, 1, true);
      const coneMat = new THREE.MeshBasicMaterial({
        color: sat.hexColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.18,
        depthWrite: false,
      });
      const beamCone = new THREE.Mesh(coneGeo, coneMat);
      globeGroup.add(beamCone);

      // Telemetry Downlink Line to Ground Target
      const telePositions = new Float32Array(6);
      const telemetryGeo = new THREE.BufferGeometry();
      telemetryGeo.setAttribute('position', new THREE.BufferAttribute(telePositions, 3));
      const telemetryLine = new THREE.Line(
        telemetryGeo,
        new THREE.LineBasicMaterial({
          color: sat.hexColor,
          transparent: true,
          opacity: 0.6,
        })
      );
      globeGroup.add(telemetryLine);

      satelliteInstances.push({
        data: sat,
        group: satGroup,
        beamCone,
        telemetryLine,
        telemetryGeo,
        orbitAngle: sat.phaseOffset,
      });
    });

    // 10. Initial Orientations
    globeGroup.rotation.y = -Math.PI / 1.7;
    globeGroup.rotation.x = 0.25;

    setIsLoaded(true);

    // 11. Interactive Trackball Drag & Inertia Controls
    let isDragging = false;
    let prevPointerX = 0;
    let prevPointerY = 0;
    let rotVelocityX = 0;
    let rotVelocityY = 0;
    let dragDistance = 0;

    const onPointerDown = (e: PointerEvent) => {
      isDragging = true;
      dragDistance = 0;
      prevPointerX = e.clientX;
      prevPointerY = e.clientY;
      rotVelocityX = 0;
      rotVelocityY = 0;
    };

    const onPointerMove = (e: PointerEvent) => {
      // Raycasting for interactive hover
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect) {
        const mouseNormX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        const mouseNormY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(mouseNormX, mouseNormY), camera);

        const hits = raycaster.intersectObjects(
          interactiveMeshes.map((im) => im.mesh),
          true
        );
        if (hits.length > 0) {
          const match = interactiveMeshes.find((im) => im.mesh === hits[0].object);
          if (match) {
            setHoveredNode(match.data);
            if (canvasRef.current) canvasRef.current.style.cursor = 'pointer';
          }
        } else {
          setHoveredNode(null);
          if (canvasRef.current) canvasRef.current.style.cursor = isDragging ? 'grabbing' : 'grab';
        }
      }

      if (!isDragging) return;

      const deltaX = e.clientX - prevPointerX;
      const deltaY = e.clientY - prevPointerY;
      dragDistance += Math.abs(deltaX) + Math.abs(deltaY);

      rotVelocityY = deltaX * 0.005;
      rotVelocityX = deltaY * 0.005;

      globeGroup.rotation.y += rotVelocityY;
      globeGroup.rotation.x = Math.max(
        -Math.PI / 2.3,
        Math.min(Math.PI / 2.3, globeGroup.rotation.x + rotVelocityX)
      );

      prevPointerX = e.clientX;
      prevPointerY = e.clientY;
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoomDelta = e.deltaY * 0.004;
      camera.position.z = Math.max(2.2, Math.min(9.0, camera.position.z + zoomDelta));
    };

    const onClick = () => {
      if (dragDistance < 5 && hoveredNode) {
        setSelectedNode(hoveredNode);
        if ('lat' in hoveredNode && hoveredNode.vector) {
          // Orient globe towards clicked ground node
          focusOnKerala();
        }
      }
    };

    const canvasEl = canvasRef.current;
    canvasEl.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    canvasEl.addEventListener('wheel', onWheel, { passive: false });
    canvasEl.addEventListener('click', onClick);

    // 12. Resize Handler
    const handleResize = () => {
      if (!containerRef.current || !canvasRef.current) return;
      width = containerRef.current.clientWidth || window.innerWidth;
      height = containerRef.current.clientHeight || window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    // 13. GSAP ScrollTrigger Sequence (For Hero Mode)
    let trigger: ScrollTrigger | null = null;
    if (mode === 'hero') {
      trigger = ScrollTrigger.create({
        trigger: containerRef.current,
        start: 'top top',
        end: '+=3200',
        scrub: 1.2,
        onUpdate: (self) => {
          if (isDragging) return; // Allow user drag to override scroll zoom

          const p = self.progress;
          let stage = 1;

          if (p < 0.18) {
            stage = 1;
            camera.position.z = THREE.MathUtils.lerp(7.2, 5.8, p / 0.18);
            camera.position.x = THREE.MathUtils.lerp(0, 0.4, p / 0.18);
            camera.position.y = THREE.MathUtils.lerp(0, 0.2, p / 0.18);
          } else if (p < 0.38) {
            stage = 2;
            const subP = (p - 0.18) / 0.2;
            camera.position.z = THREE.MathUtils.lerp(5.8, 4.4, subP);
            camera.position.x = THREE.MathUtils.lerp(0.4, 0.75, subP);
            camera.position.y = THREE.MathUtils.lerp(0.2, 0.35, subP);
          } else if (p < 0.58) {
            stage = 3;
            const subP = (p - 0.38) / 0.2;
            camera.position.z = THREE.MathUtils.lerp(4.4, 3.4, subP);
            camera.position.x = THREE.MathUtils.lerp(0.75, 0.45, subP);
            camera.position.y = THREE.MathUtils.lerp(0.35, 0.22, subP);
          } else if (p < 0.78) {
            stage = 4;
            const subP = (p - 0.58) / 0.2;
            camera.position.z = THREE.MathUtils.lerp(3.4, 2.7, subP);
            camera.position.x = THREE.MathUtils.lerp(0.45, 0.18, subP);
            camera.position.y = THREE.MathUtils.lerp(0.22, 0.12, subP);
          } else if (p < 0.92) {
            stage = 5;
            const subP = (p - 0.78) / 0.14;
            camera.position.z = THREE.MathUtils.lerp(2.7, 2.45, subP);
            camera.position.x = THREE.MathUtils.lerp(0.18, 0.08, subP);
            camera.position.y = THREE.MathUtils.lerp(0.12, 0.06, subP);
          } else {
            stage = 6;
            camera.position.z = 2.4;
            camera.position.x = 0.05;
          }

          setActiveStage(stage);
          if (onStageChange) {
            onStageChange(stage, STAGE_NAMES[stage - 1]);
          }
        },
      });
    }

    // 14. Main Continuous Active Simulation Loop
    let currentAnimFrame: number;
    let clock = new THREE.Clock();

    const animate = () => {
      currentAnimFrame = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Continuous Planetary Motion (Never Static!)
      if (autoRotate && !isDragging) {
        globeGroup.rotation.y += 0.0014; // Constant active spin
      }

      // Smooth Inertia Damping on drag release
      if (!isDragging) {
        globeGroup.rotation.y += rotVelocityY;
        globeGroup.rotation.x = Math.max(
          -Math.PI / 2.3,
          Math.min(Math.PI / 2.3, globeGroup.rotation.x + rotVelocityX)
        );
        rotVelocityX *= 0.92;
        rotVelocityY *= 0.92;
      }

      // Camera preset glide targeting
      if (cameraTargetRef.current) {
        camera.position.lerp(
          new THREE.Vector3(
            cameraTargetRef.current.x,
            cameraTargetRef.current.y,
            cameraTargetRef.current.z
          ),
          0.05
        );
        if (camera.position.distanceTo(new THREE.Vector3(
          cameraTargetRef.current.x,
          cameraTargetRef.current.y,
          cameraTargetRef.current.z
        )) < 0.05) {
          cameraTargetRef.current = null;
        }
      }

      if (globeTargetRotRef.current) {
        globeGroup.rotation.y = THREE.MathUtils.lerp(globeGroup.rotation.y, globeTargetRotRef.current.y, 0.05);
        globeGroup.rotation.x = THREE.MathUtils.lerp(globeGroup.rotation.x, globeTargetRotRef.current.x, 0.05);
        if (
          Math.abs(globeGroup.rotation.y - globeTargetRotRef.current.y) < 0.01 &&
          Math.abs(globeGroup.rotation.x - globeTargetRotRef.current.x) < 0.01
        ) {
          globeTargetRotRef.current = null;
        }
      }

      // Rotate starfield slowly
      starfield.rotation.y = elapsedTime * 0.012;

      // Pulse and expand ground station shockwave rings
      shockwaveRings.forEach((sw) => {
        sw.scale += sw.speed;
        if (sw.scale > 3.0) {
          sw.scale = sw.baseScale;
        }
        const progress = (sw.scale - sw.baseScale) / 2.0;
        const mat = sw.mesh.material as THREE.MeshBasicMaterial;
        mat.opacity = Math.max(0, 0.85 * (1 - progress));
        sw.mesh.scale.set(sw.scale, sw.scale, sw.scale);
      });

      // Flowing Photon Packets along Bezier Conduits
      flowingPackets.forEach((fp) => {
        fp.t = (fp.t + fp.speed) % 1.0;
        const currentPos = fp.curve.getPoint(fp.t);
        fp.mesh.position.copy(currentPos);
      });

      // Orbiting Satellites, Conical Beams & Downlink Telemetry Lines
      satelliteInstances.forEach((inst) => {
        inst.orbitAngle += delta * inst.data.speed;
        const r = inst.data.radius;
        const inc = inst.data.inclination;

        // Position in tilted orbital plane
        const localX = Math.cos(inst.orbitAngle) * r;
        const localZ = Math.sin(inst.orbitAngle) * r;
        const satPos = new THREE.Vector3(
          localX,
          localZ * Math.sin(inc),
          localZ * Math.cos(inc)
        );
        inst.group.position.copy(satPos);

        // Conical Scanning Beam
        if (showBeams) {
          inst.beamCone.visible = true;
          const beamTarget = satPos.clone().normalize().multiplyScalar(earthRadius);
          const midBeam = satPos.clone().lerp(beamTarget, 0.5);
          inst.beamCone.position.copy(midBeam);
          inst.beamCone.lookAt(satPos);
          inst.beamCone.rotateX(Math.PI / 2);
        } else {
          inst.beamCone.visible = false;
        }

        // Downlink Telemetry Line to Target Node
        const targetNode = GLOBAL_NODES.find((n) => n.id === inst.data.downlinkTargetId);
        if (targetNode && targetNode.vector) {
          const positions = inst.telemetryGeo.attributes.position.array as Float32Array;
          positions[0] = satPos.x;
          positions[1] = satPos.y;
          positions[2] = satPos.z;
          positions[3] = targetNode.vector.x;
          positions[4] = targetNode.vector.y;
          positions[5] = targetNode.vector.z;
          inst.telemetryGeo.attributes.position.needsUpdate = true;
        }
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(currentAnimFrame);
      canvasEl.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      canvasEl.removeEventListener('wheel', onWheel);
      canvasEl.removeEventListener('click', onClick);
      window.removeEventListener('resize', handleResize);
      if (trigger) trigger.kill();
      renderer.dispose();
    };
  }, [mode, autoRotate, showBeams, focusOnKerala]);

  return (
    <div ref={containerRef} className={`relative w-full h-full min-h-[580px] select-none ${className}`}>
      {/* 1. Three.js Interactive WebGL Canvas */}
      {webglSupported ? (
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full z-0 block cursor-grab active:cursor-grabbing pointer-events-auto"
        />
      ) : (
        /* Accessible Fallback when WebGL is unavailable */
        <div className="absolute inset-0 flex items-center justify-center bg-[#07090D] p-6 z-0">
          <div className="text-center space-y-4 max-w-md p-8 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)]">
            <div className="w-16 h-16 rounded-full bg-[#FF6B35]/20 border border-[#FF6B35]/40 flex items-center justify-center mx-auto text-[#FF6B35] animate-pulse">
              <Globe className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-[#F5F7FA]">Geospatial Intelligence Network</h3>
            <p className="text-xs text-[#929CAB] leading-relaxed">
              Active Global Session synchronizes 941 Grama Panchayats with INSAT-3DR, Sentinel-2 SAR, and international disaster intelligence.
            </p>
          </div>
        </div>
      )}

      {/* 2. Top-Left Live Session Telemetry HUD (Consolidated with Stage Indicator) */}
      <div className="absolute top-6 left-6 z-20 pointer-events-none space-y-2">
        <div className="p-3.5 rounded-2xl bg-[#101720]/85 backdrop-blur-md border border-[rgba(255,255,255,0.08)] space-y-2 shadow-2xl max-w-sm pointer-events-auto">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E] animate-ping" />
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#F5F7FA]">
                ACTIVE GLOBAL ORBITAL SESSION
              </span>
            </div>
            <span className="text-[10px] font-mono text-[#38BDF8] bg-[#38BDF8]/10 px-2 py-0.5 rounded-md border border-[#38BDF8]/20">
              LIVE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[rgba(255,255,255,0.06)] text-[10px] font-mono">
            <div>
              <span className="text-[#929CAB] block">DOWNLINK BITRATE</span>
              <span className="text-[#F5F7FA] font-bold text-xs">{bitrate} Mbps</span>
            </div>
            <div>
              <span className="text-[#929CAB] block">CONSTELLATION LOCK</span>
              <span className="text-[#22C55E] font-bold text-xs">3/3 ACTIVE</span>
            </div>
            <div>
              <span className="text-[#929CAB] block">PACKETS ROUTED</span>
              <span className="text-[#38BDF8] font-bold text-xs">{packetsRouted.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[#929CAB] block">ENCRYPTION PROTOCOL</span>
              <span className="text-[#FF6B35] font-bold text-xs">JOSE ES256</span>
            </div>
          </div>
        </div>

        {/* Cinematic Stage Pill (Integrated cleanly under top-left HUD so it never collides with hero bar) */}
        {mode === 'hero' && (
          <div className="p-2.5 rounded-xl bg-[#101720]/85 backdrop-blur-md border border-[rgba(255,255,255,0.08)] space-y-1 shadow-lg max-w-sm pointer-events-auto">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#FF6B35] animate-pulse" />
                <span className="text-[9px] font-mono uppercase tracking-widest text-[#929CAB]">
                  STAGE {activeStage}/6
                </span>
              </div>
              <span className="text-[11px] font-bold font-mono text-[#F5F7FA] truncate">
                {STAGE_NAMES[activeStage - 1]}
              </span>
            </div>
            <div className="flex items-center gap-1 pt-0.5">
              {[1, 2, 3, 4, 5, 6].map((num) => (
                <div
                  key={num}
                  className={`h-1 rounded-full transition-all duration-300 ${
                    num === activeStage
                      ? 'w-6 bg-[#FF6B35]'
                      : num < activeStage
                      ? 'w-3 bg-[#FF6B35]/50'
                      : 'w-2 bg-white/10'
                  }`}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 3. Top-Right Global Quick-Focus & Session Controls (Consolidated) */}
      {showControls && (
        <div className="absolute top-6 right-6 z-20 flex flex-col items-end gap-2 pointer-events-auto">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-[#101720]/85 backdrop-blur-md p-1 rounded-xl border border-[rgba(255,255,255,0.08)] shadow-xl text-xs font-mono">
              <button
                onClick={focusOnKerala}
                className="px-3 py-1.5 rounded-lg hover:bg-white/5 text-[#FF6B35] transition flex items-center gap-1.5 font-bold cursor-pointer"
                title="Focus on Kerala Incident Sector"
              >
                <Crosshair className="w-3.5 h-3.5" />
                <span>Kerala Sector</span>
              </button>
              <button
                onClick={focusOnAsia}
                className="px-3 py-1.5 rounded-lg hover:bg-white/5 text-[#38BDF8] transition flex items-center gap-1.5 font-bold cursor-pointer"
                title="Focus on Asia-Pacific Region"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Asia-Pacific</span>
              </button>
              <button
                onClick={focusOnGlobal}
                className="px-3 py-1.5 rounded-lg hover:bg-white/5 text-[#F5F7FA] transition flex items-center gap-1.5 font-bold cursor-pointer"
                title="Wide Global Orbit View"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Global Grid</span>
              </button>
            </div>

            <div className="flex items-center bg-[#101720]/85 backdrop-blur-md p-1 rounded-xl border border-[rgba(255,255,255,0.08)] shadow-xl text-xs font-mono">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`p-1.5 rounded-lg transition cursor-pointer ${
                  autoRotate ? 'text-[#22C55E] bg-[#22C55E]/10' : 'text-[#929CAB] hover:text-white'
                }`}
                title={autoRotate ? 'Pause Continuous Drift' : 'Resume Continuous Drift'}
              >
                <RotateCw className={`w-4 h-4 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
              </button>
              <button
                onClick={() => setShowBeams(!showBeams)}
                className={`p-1.5 rounded-lg transition cursor-pointer ${
                  showBeams ? 'text-[#FF6B35] bg-[#FF6B35]/10' : 'text-[#929CAB] hover:text-white'
                }`}
                title={showBeams ? 'Hide Satellite Downlink Beams' : 'Show Satellite Downlink Beams'}
              >
                <Zap className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Satellite Constellation Lock Status Bar (Cleanly docked under top-right controls) */}
          <div className="px-3 py-1.5 rounded-xl bg-[#101720]/85 backdrop-blur-md border border-[rgba(255,255,255,0.08)] flex items-center gap-3 text-[10px] font-mono text-[#929CAB] shadow-lg">
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF6B35]" />
              <span className="text-[#F5F7FA] font-bold">INSAT-3DR</span>
              <span className="text-[#22C55E] text-[9px]">LOCK</span>
            </div>
            <span className="text-[#6F7C93]">•</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8]" />
              <span className="text-[#F5F7FA] font-bold">SENTINEL-2</span>
              <span className="text-[#22C55E] text-[9px]">DOWNLINK</span>
            </div>
            <span className="text-[#6F7C93]">•</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F5A623]" />
              <span className="text-[#F5F7FA] font-bold">NavIC</span>
              <span className="text-[#22C55E] text-[9px]">SYNC</span>
            </div>
          </div>
        </div>
      )}

      {/* 4. Active Node Hover / Selection Telemetry Card */}
      {(hoveredNode || selectedNode) && (
        <div className="absolute top-24 right-6 z-20 pointer-events-none animate-fadeIn">
          <div className="p-4 rounded-2xl bg-[#101720]/95 backdrop-blur-xl border border-[rgba(255,255,255,0.12)] space-y-2 shadow-2xl max-w-xs pointer-events-auto text-xs font-mono">
            <div className="flex items-center justify-between gap-2 border-b border-[rgba(255,255,255,0.08)] pb-2">
              <span
                className="font-bold text-sm truncate"
                style={{ color: (hoveredNode || selectedNode)?.color }}
              >
                {(hoveredNode || selectedNode)?.name}
              </span>
              <span
                className="text-[9px] px-1.5 py-0.5 rounded uppercase font-bold"
                style={{
                  backgroundColor: `${(hoveredNode || selectedNode)?.color}20`,
                  color: (hoveredNode || selectedNode)?.color,
                }}
              >
                {(hoveredNode || selectedNode)?.status}
              </span>
            </div>

            {'lat' in (hoveredNode || selectedNode)! ? (
              <div className="space-y-1 text-[11px] text-[#929CAB]">
                <div className="flex justify-between">
                  <span>Coordinates:</span>
                  <span className="text-[#F5F7FA]">
                    {((hoveredNode || selectedNode) as GroundNode).lat.toFixed(2)}° N,{' '}
                    {((hoveredNode || selectedNode) as GroundNode).lng.toFixed(2)}° E
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Node Protocol:</span>
                  <span className="text-[#F5F7FA] uppercase">
                    {((hoveredNode || selectedNode) as GroundNode).type}
                  </span>
                </div>
                <p className="text-[10px] text-[#38BDF8] pt-1 leading-snug">
                  {((hoveredNode || selectedNode) as GroundNode).telemetry}
                </p>
              </div>
            ) : (
              <div className="space-y-1 text-[11px] text-[#929CAB]">
                <div className="flex justify-between">
                  <span>Constellation:</span>
                  <span className="text-[#F5F7FA]">
                    {((hoveredNode || selectedNode) as SatelliteNode).constellation}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Downlink Sync:</span>
                  <span className="text-[#22C55E]">STABLE</span>
                </div>
              </div>
            )}

            <div className="pt-2 flex items-center justify-between text-[10px] text-[#6F7C93] border-t border-[rgba(255,255,255,0.06)]">
              <span>DRAG TO ROTATE</span>
              <span>SCROLL TO ZOOM</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
