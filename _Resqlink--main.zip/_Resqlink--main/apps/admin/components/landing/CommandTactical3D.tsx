'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

interface IncidentPin {
  id: string;
  lat: number;
  lng: number;
  category: string;
  severity: string;
  name: string;
}

interface CommandTactical3DProps {
  incidents?: any[];
  activeIncidentCount?: number;
  onSelectIncident?: (incidentId: string) => void;
}

export function CommandTactical3D({
  incidents = [],
  activeIncidentCount = 3,
  onSelectIncident,
}: CommandTactical3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isInteractive, setIsInteractive] = useState(false);
  const [hudStats, setHudStats] = useState({
    activeSatellites: 4,
    meshThroughput: '124 kbps',
    radarCoverage: '98.4%',
  });

  const controlsRef = useRef<OrbitControls | null>(null);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    let width = containerRef.current.clientWidth || window.innerWidth;
    let height = containerRef.current.clientHeight || window.innerHeight;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x060a14, 0.045);

    const camera = new THREE.PerspectiveCamera(46, width / height, 0.1, 100);
    camera.position.set(0, 5.5, 7.5);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    // OrbitControls for commanders
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.15; // Don't go below ground
    controls.minDistance = 3.5;
    controls.maxDistance = 14;
    controls.enabled = false; // Initially cinematic auto-sweep
    controlsRef.current = controls;

    // 2. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0x091428, 2.8);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x55d6e8, 3.5);
    keyLight.position.set(6, 9, 6);
    scene.add(keyLight);

    const redAccent = new THREE.DirectionalLight(0xef4444, 2.0);
    redAccent.position.set(-7, 2, -5);
    scene.add(redAccent);

    const centerPointLight = new THREE.PointLight(0x00f2ff, 4.0, 16);
    centerPointLight.position.set(0, 2.0, 0);
    scene.add(centerPointLight);

    // 3. State-Scale 3D Kerala Geospatial Heightfield
    const terrainWidth = 16;
    const terrainDepth = 16;
    const terrainSegments = 72;
    const terrainGeo = new THREE.PlaneGeometry(terrainWidth, terrainDepth, terrainSegments, terrainSegments);
    terrainGeo.rotateX(-Math.PI / 2);

    const terrainPos = terrainGeo.attributes.position;
    const terrainColors = new Float32Array(terrainPos.count * 3);

    for (let i = 0; i < terrainPos.count; i++) {
      const x = terrainPos.getX(i);
      const z = terrainPos.getZ(i);

      // Model mountain ridges (Western Ghats) to the East (positive X) and coastal plain to the West
      const ridgeFactor = Math.max(0, (x + 1.5) * 0.35);
      const elevation =
        Math.sin(x * 0.6) * Math.cos(z * 0.6) * 0.7 +
        Math.sin(x * 1.5 + z * 0.9) * 0.35 +
        ridgeFactor * 1.2 -
        Math.pow(Math.sqrt(x * x + z * z) / 8.5, 2) * 0.8;

      terrainPos.setY(i, elevation);

      // Elevation gradient colors: Coastal Blue -> Mid Altitude Cyan -> High Peak Amber/Red
      let c = new THREE.Color('#0A1528');
      if (elevation > 1.0) {
        c.lerp(new THREE.Color('#FF9F1C'), Math.min(1, (elevation - 1.0) * 1.2));
      } else if (elevation > 0.2) {
        c.lerp(new THREE.Color('#55D6E8'), (elevation - 0.2) / 0.8);
      } else {
        c.lerp(new THREE.Color('#10223D'), (elevation + 1.2) / 1.4);
      }

      terrainColors[i * 3] = c.r;
      terrainColors[i * 3 + 1] = c.g;
      terrainColors[i * 3 + 2] = c.b;
    }

    terrainGeo.setAttribute('color', new THREE.BufferAttribute(terrainColors, 3));
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.38,
      metalness: 0.62,
      transparent: true,
      opacity: 0.9,
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.position.y = -1.2;
    scene.add(terrainMesh);

    // Glowing Digital Elevation Contour Lines Overlay
    const contourMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.3,
    });
    const contourMesh = new THREE.Mesh(terrainGeo, contourMat);
    contourMesh.position.y = -1.185;
    scene.add(contourMesh);

    // Coordinate spatial grid base
    const grid = new THREE.GridHelper(18, 28, 0x55d6e8, 0x142848);
    grid.position.y = -1.25;
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.22;
    scene.add(grid);

    // 4. Strategic Kerala Incident & Command Pins
    const tacticalPins = [
      { id: 'WYD-01', x: -2.5, z: -2.8, name: 'Wayanad (Chooralmala)', type: 'CRITICAL_SOS', color: 0xef4444 },
      { id: 'IDK-02', x: 2.2, z: 1.5, name: 'Idukki (Devikulam)', type: 'LANDSLIDE_WATCH', color: 0xff9f1c },
      { id: 'EKM-03', x: -1.0, z: 0.5, name: 'Ernakulam (Periyar Basin)', type: 'FLOOD_CORRIDOR', color: 0x00f2ff },
      { id: 'ALP-04', x: -2.8, z: 2.8, name: 'Alappuzha (Kuttanad)', type: 'COASTAL_SURGE', color: 0x38bdf8 },
      { id: 'SEOC-HQ', x: 1.8, z: 3.5, name: 'SEOC State Command HQ', type: 'COMMAND_HQ', color: 0x10b981 },
      { id: 'NDRF-01', x: -1.8, z: -1.5, name: 'NDRF Alpha Battalion', type: 'RESCUE_TEAM', color: 0x55d6e8 },
    ];

    const pinMeshes: THREE.Mesh[] = [];
    const pinRings: THREE.Mesh[] = [];
    const pinBeams: THREE.Mesh[] = [];

    tacticalPins.forEach((pin) => {
      const isCritical = pin.type === 'CRITICAL_SOS';
      const isHQ = pin.type === 'COMMAND_HQ';

      // Pin ground altitude
      const pinAltitude = -1.2 + (Math.sin(pin.x * 0.6) * Math.cos(pin.z * 0.6) * 0.7 + 0.5);

      // 3D Octahedron / Beacon Pin
      const pGeo = new THREE.OctahedronGeometry(isCritical ? 0.26 : 0.18, 0);
      const pMat = new THREE.MeshStandardMaterial({
        color: pin.color,
        emissive: pin.color,
        emissiveIntensity: isCritical ? 1.2 : 0.8,
        roughness: 0.2,
        metalness: 0.8,
      });
      const pMesh = new THREE.Mesh(pGeo, pMat);
      pMesh.position.set(pin.x, pinAltitude + 0.5, pin.z);
      scene.add(pMesh);
      pinMeshes.push(pMesh);

      // Ground Pulsing Ring
      const rGeo = new THREE.RingGeometry(0.2, 0.35, 24);
      rGeo.rotateX(-Math.PI / 2);
      const rMat = new THREE.MeshBasicMaterial({
        color: pin.color,
        transparent: true,
        opacity: isCritical ? 0.9 : 0.6,
        side: THREE.DoubleSide,
      });
      const rMesh = new THREE.Mesh(rGeo, rMat);
      rMesh.position.set(pin.x, pinAltitude + 0.05, pin.z);
      scene.add(rMesh);
      pinRings.push(rMesh);

      // Vertical Tactical Holographic Laser Column
      const bGeo = new THREE.CylinderGeometry(0.015, 0.045, 2.4, 8);
      const bMat = new THREE.MeshBasicMaterial({
        color: pin.color,
        transparent: true,
        opacity: isCritical ? 0.55 : 0.35,
      });
      const bMesh = new THREE.Mesh(bGeo, bMat);
      bMesh.position.set(pin.x, pinAltitude + 1.2, pin.z);
      scene.add(bMesh);
      pinBeams.push(bMesh);
    });

    // 5. Arched Tactical Data Streams connecting field incidents to SEOC HQ
    const hqPos = pinMeshes[4].position; // SEOC State Command HQ
    const streamCurves: THREE.QuadraticBezierCurve3[] = [];
    const streamPackets: THREE.Mesh[] = [];

    [0, 1, 2, 3, 5].forEach((idx) => {
      const fieldPos = pinMeshes[idx].position;
      const mid = new THREE.Vector3(
        (fieldPos.x + hqPos.x) / 2,
        Math.max(fieldPos.y, hqPos.y) + 1.2,
        (fieldPos.z + hqPos.z) / 2
      );

      const curve = new THREE.QuadraticBezierCurve3(fieldPos, mid, hqPos);
      streamCurves.push(curve);

      const lineGeo = new THREE.BufferGeometry().setFromPoints(curve.getPoints(30));
      const lineMat = new THREE.LineBasicMaterial({
        color: idx === 0 ? 0xef4444 : 0x55d6e8,
        transparent: true,
        opacity: 0.45,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      scene.add(line);

      // Traveling packet
      const pktGeo = new THREE.SphereGeometry(0.05, 8, 8);
      const pktMat = new THREE.MeshBasicMaterial({ color: idx === 0 ? 0xff4d4d : 0x00f2ff });
      const pktMesh = new THREE.Mesh(pktGeo, pktMat);
      pktMesh.userData = { curve, progress: Math.random(), speed: 0.007 + Math.random() * 0.006 };
      scene.add(pktMesh);
      streamPackets.push(pktMesh);
    });

    // 6. Geodesic Early-Warning Protective Radar Dome covering State
    const domeGeo = new THREE.IcosahedronGeometry(7.2, 3);
    const domeMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.set(0, 0.5, 0);
    scene.add(domeMesh);

    // Inner protective radar sheen
    const innerRadarMat = new THREE.MeshStandardMaterial({
      color: 0x07152b,
      emissive: 0x00f2ff,
      emissiveIntensity: 0.1,
      roughness: 0.2,
      metalness: 0.8,
      transparent: true,
      opacity: 0.1,
      side: THREE.DoubleSide,
    });
    const innerRadarMesh = new THREE.Mesh(domeGeo, innerRadarMat);
    innerRadarMesh.position.set(0, 0.5, 0);
    innerRadarMesh.scale.set(0.98, 0.98, 0.98);
    scene.add(innerRadarMesh);

    // 7. Atmospheric Telemetry Particles
    const particleCount = 500;
    const pGeo = new THREE.BufferGeometry();
    const pPositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      pPositions[i * 3] = (Math.random() - 0.5) * 22;
      pPositions[i * 3 + 1] = Math.random() * 10 - 1;
      pPositions[i * 3 + 2] = (Math.random() - 0.5) * 22;
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    const pMat = new THREE.PointsMaterial({
      size: 0.045,
      color: 0x55d6e8,
      transparent: true,
      opacity: 0.55,
    });
    const particles = new THREE.Points(pGeo, pMat);
    scene.add(particles);

    // Mouse Parallax (when not in manual orbit mode)
    let mouseX = 0;
    let mouseY = 0;
    let targetParallaxX = 0;
    let targetParallaxY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const normX = (e.clientX / window.innerWidth) * 2 - 1;
      const normY = -(e.clientY / window.innerHeight) * 2 + 1;
      mouseX = normX * 0.45;
      mouseY = normY * 0.3;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // 60FPS Render Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Pin levitation and rotations
      pinMeshes.forEach((mesh, idx) => {
        mesh.rotation.y += 0.02;
        mesh.rotation.z += 0.01;
        mesh.position.y += Math.sin(time * 2.5 + idx) * 0.0015;
      });

      // Ground pulsing rings
      pinRings.forEach((ring, idx) => {
        const pulse = (Math.sin(time * 3.5 + idx * 0.8) + 1) * 0.5;
        ring.scale.set(1 + pulse * 0.45, 1 + pulse * 0.45, 1);
        (ring.material as THREE.MeshBasicMaterial).opacity = 0.4 + pulse * 0.5;
      });

      // Traveling data packets
      streamPackets.forEach((pkt) => {
        pkt.userData.progress += pkt.userData.speed;
        if (pkt.userData.progress > 1) pkt.userData.progress = 0;
        const pos = pkt.userData.curve.getPoint(pkt.userData.progress);
        pkt.position.copy(pos);
      });

      // Dome gentle rotation
      domeMesh.rotation.y += 0.0015;
      innerRadarMesh.rotation.y -= 0.001;

      // Drifting particles
      particles.rotation.y = time * 0.012;

      // Camera navigation: OrbitControls vs Cinematic Auto-Sweep
      if (controls.enabled) {
        controls.update();
      } else {
        // Cinematic Auto-Sweep with Cursor Parallax
        const sweepAngle = time * 0.08;
        const radius = 9.2;
        targetParallaxX += (mouseX - targetParallaxX) * 0.05;
        targetParallaxY += (mouseY - targetParallaxY) * 0.05;

        camera.position.x = Math.sin(sweepAngle) * radius + targetParallaxX;
        camera.position.z = Math.cos(sweepAngle) * radius;
        camera.position.y = 5.2 + Math.sin(time * 0.12) * 0.6 + targetParallaxY * 0.6;
        camera.lookAt(0, 0, 0);
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      width = containerRef.current.clientWidth || window.innerWidth;
      height = containerRef.current.clientHeight || window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      controls.dispose();
      renderer.dispose();
      terrainGeo.dispose();
      domeGeo.dispose();
    };
  }, []);

  const toggleInteractiveMode = () => {
    const next = !isInteractive;
    setIsInteractive(next);
    if (controlsRef.current) {
      controlsRef.current.enabled = next;
    }
  };

  return (
    <div ref={containerRef} className="fixed inset-0 w-full h-full z-0 overflow-hidden">
      <canvas ref={canvasRef} className={`w-full h-full block ${isInteractive ? 'pointer-events-auto cursor-grab active:cursor-grabbing' : 'pointer-events-none'}`} />

      {/* Atmospheric Vignette & Deep Midnight Gradients */}
      <div className="absolute inset-0 bg-gradient-to-t from-canvas via-transparent to-canvas/80 pointer-events-none" />
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none opacity-80" />

      {/* Tactical HUD Header Controls */}
      <div className="absolute top-20 right-6 z-20 pointer-events-auto flex items-center gap-2.5">
        <button
          onClick={toggleInteractiveMode}
          className={`px-3.5 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 transition shadow-glow-cyan backdrop-blur-md ${
            isInteractive
              ? 'bg-primary text-canvas border-primary shadow-glow-cyan'
              : 'bg-surface-1/80 text-primary border-primary/30 hover:border-primary'
          }`}
          title="Toggle interactive 3D radar controls"
        >
          <span className={`w-2 h-2 rounded-full ${isInteractive ? 'bg-canvas' : 'bg-emerald-400 animate-ping'}`} />
          <span>{isInteractive ? '3D RADAR CONTROLS: ACTIVE' : 'CINEMATIC AUTO-SWEEP'}</span>
        </button>

        <div className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-xl bg-surface-1/80 border border-surface-3 backdrop-blur-md text-[11px] font-mono text-text-muted">
          <span>KERALA RADAR: <strong className="text-emerald-400">{hudStats.radarCoverage}</strong></span>
          <span>•</span>
          <span>CITIZEN SIGNALS: <strong className="text-red-400">{activeIncidentCount} PENDING</strong></span>
        </div>
      </div>
    </div>
  );
}
