'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface ResidentSentinel3DProps {
  isSosActive?: boolean;
  isDeliveryVerified?: boolean;
  hasIncomingSms?: boolean;
  sectorName?: string;
}

export function ResidentSentinel3D({
  isSosActive = false,
  isDeliveryVerified = false,
  hasIncomingSms = false,
  sectorName = 'Kerala Sector',
}: ResidentSentinel3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hudStatus, setHudStatus] = useState('SENTINEL_ACTIVE');

  // References to dynamic scene objects
  const sceneRefs = useRef<{
    beaconMesh?: THREE.Mesh;
    beaconRing?: THREE.Mesh;
    domeMesh?: THREE.Mesh;
    domeMat?: THREE.MeshBasicMaterial;
    satelliteMesh?: THREE.Mesh;
    laserBeam?: THREE.Mesh;
    shockwaves?: THREE.Mesh[];
  }>({});

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    let width = containerRef.current.clientWidth || window.innerWidth;
    let height = containerRef.current.clientHeight || window.innerHeight;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x060a14, 0.05);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 3.8, 6.2);
    camera.lookAt(0, 0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    // 2. Lighting
    const ambient = new THREE.AmbientLight(0x081224, 2.5);
    scene.add(ambient);

    const cyanLight = new THREE.DirectionalLight(0x55d6e8, 3.0);
    cyanLight.position.set(4, 7, 5);
    scene.add(cyanLight);

    const blueLight = new THREE.DirectionalLight(0x1e3a8a, 2.0);
    blueLight.position.set(-5, 3, -4);
    scene.add(blueLight);

    const pointLight = new THREE.PointLight(0x00f2ff, 4.5, 12);
    pointLight.position.set(0, 1.2, 0);
    scene.add(pointLight);

    // 3. Localized Topographic Elevation Base (Grama Panchayat Sector)
    const terrainGeo = new THREE.PlaneGeometry(12, 12, 48, 48);
    terrainGeo.rotateX(-Math.PI / 2);
    const pos = terrainGeo.attributes.position;
    const colors = new Float32Array(pos.count * 3);

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const dist = Math.sqrt(x * x + z * z);
      const elevation =
        Math.sin(x * 0.7) * Math.cos(z * 0.7) * 0.45 +
        Math.sin(x * 1.4 - z * 1.2) * 0.2 -
        Math.pow(dist / 5.5, 2) * 0.4;

      pos.setY(i, elevation);

      const c = new THREE.Color('#0A1528');
      if (elevation > 0.3) {
        c.lerp(new THREE.Color('#55D6E8'), (elevation - 0.3) * 1.5);
      } else {
        c.lerp(new THREE.Color('#142540'), elevation + 0.4);
      }
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }

    terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.4,
      metalness: 0.6,
      transparent: true,
      opacity: 0.88,
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.position.y = -0.5;
    scene.add(terrainMesh);

    // Animated Digital Contour Lines Overlay
    const contourMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.28,
    });
    const contourMesh = new THREE.Mesh(terrainGeo, contourMat);
    contourMesh.position.y = -0.485;
    scene.add(contourMesh);

    // Circular Concentric Spatial Radar Rings on ground
    const radarRingsGroup = new THREE.Group();
    radarRingsGroup.position.y = -0.48;
    scene.add(radarRingsGroup);

    [1.5, 2.8, 4.2].forEach((radius, idx) => {
      const rGeo = new THREE.RingGeometry(radius - 0.03, radius, 48);
      rGeo.rotateX(-Math.PI / 2);
      const rMat = new THREE.MeshBasicMaterial({
        color: idx === 0 ? 0x00f2ff : 0x1e3a8a,
        transparent: true,
        opacity: 0.45 - idx * 0.1,
        side: THREE.DoubleSide,
      });
      const rMesh = new THREE.Mesh(rGeo, rMat);
      radarRingsGroup.add(rMesh);
    });

    // 4. Resident Handset Central Beacon
    const beaconGeo = new THREE.OctahedronGeometry(0.22, 0);
    const beaconMat = new THREE.MeshStandardMaterial({
      color: 0x00f2ff,
      emissive: 0x00f2ff,
      emissiveIntensity: 0.9,
      roughness: 0.2,
      metalness: 0.8,
    });
    const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    beaconMesh.position.set(0, 0.4, 0);
    scene.add(beaconMesh);
    sceneRefs.current.beaconMesh = beaconMesh;

    // Beacon Pulsing Base Ground Ring
    const beaconRingGeo = new THREE.RingGeometry(0.18, 0.32, 24);
    beaconRingGeo.rotateX(-Math.PI / 2);
    const beaconRingMat = new THREE.MeshBasicMaterial({
      color: 0x00f2ff,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
    });
    const beaconRing = new THREE.Mesh(beaconRingGeo, beaconRingMat);
    beaconRing.position.set(0, -0.45, 0);
    scene.add(beaconRing);
    sceneRefs.current.beaconRing = beaconRing;

    // Vertical Laser Beacon Telemetry Beam
    const beamGeo = new THREE.CylinderGeometry(0.015, 0.05, 5.0, 12);
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0x00f2ff,
      transparent: true,
      opacity: 0.55,
    });
    const laserBeam = new THREE.Mesh(beamGeo, beamMat);
    laserBeam.position.set(0, 2.5, 0);
    scene.add(laserBeam);
    sceneRefs.current.laserBeam = laserBeam;

    // 5. Protective Geodesic Community Safety Dome (Enveloping resident sector)
    const domeGeo = new THREE.IcosahedronGeometry(3.8, 3);
    const domeMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.set(0, 0.2, 0);
    scene.add(domeMesh);
    sceneRefs.current.domeMesh = domeMesh;
    sceneRefs.current.domeMat = domeMat;

    // Inner protective soft sheen
    const innerSheenMat = new THREE.MeshStandardMaterial({
      color: 0x081e3a,
      emissive: 0x00f2ff,
      emissiveIntensity: 0.12,
      roughness: 0.2,
      metalness: 0.8,
      transparent: true,
      opacity: 0.15,
      side: THREE.DoubleSide,
    });
    const innerSheenMesh = new THREE.Mesh(domeGeo, innerSheenMat);
    innerSheenMesh.position.set(0, 0.2, 0);
    innerSheenMesh.scale.set(0.98, 0.98, 0.98);
    scene.add(innerSheenMesh);

    // 6. Orbital Satellite Link Arc & Satellite in Upper Atmosphere
    const satCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0, 0.4, 0),
      new THREE.Vector3(1.8, 3.5, 1.2),
      new THREE.Vector3(3.2, 4.8, 2.4)
    );
    const satLineGeo = new THREE.BufferGeometry().setFromPoints(satCurve.getPoints(36));
    const satLineMat = new THREE.LineBasicMaterial({
      color: 0x55d6e8,
      transparent: true,
      opacity: 0.45,
    });
    const satLine = new THREE.Line(satLineGeo, satLineMat);
    scene.add(satLine);

    // Traveling packet along satellite link
    const satPktGeo = new THREE.SphereGeometry(0.06, 12, 12);
    const satPktMat = new THREE.MeshBasicMaterial({ color: 0x00f2ff });
    const satPkt = new THREE.Mesh(satPktGeo, satPktMat);
    scene.add(satPkt);

    // High Orbit Satellite Mesh
    const satBodyGeo = new THREE.BoxGeometry(0.2, 0.1, 0.15);
    const satBodyMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 });
    const satelliteMesh = new THREE.Mesh(satBodyGeo, satBodyMat);
    satelliteMesh.position.set(3.2, 4.8, 2.4);

    // Solar panels on satellite
    const panelGeo = new THREE.BoxGeometry(0.5, 0.02, 0.12);
    const panelMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const panelMesh = new THREE.Mesh(panelGeo, panelMat);
    satelliteMesh.add(panelMesh);
    scene.add(satelliteMesh);
    sceneRefs.current.satelliteMesh = satelliteMesh;

    // 7. Designated Relief Camp Shelter Node (Glows Emerald)
    const shelterGeo = new THREE.DodecahedronGeometry(0.18);
    const shelterMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      emissive: 0x10b981,
      emissiveIntensity: 0.8,
      metalness: 0.7,
      roughness: 0.2,
    });
    const shelterMesh = new THREE.Mesh(shelterGeo, shelterMat);
    shelterMesh.position.set(-2.2, 0.15, -1.2);
    scene.add(shelterMesh);

    // Link between resident and relief shelter
    const reliefCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0, 0.4, 0),
      new THREE.Vector3(-1.1, 0.8, -0.6),
      new THREE.Vector3(-2.2, 0.15, -1.2)
    );
    const reliefLineGeo = new THREE.BufferGeometry().setFromPoints(reliefCurve.getPoints(24));
    const reliefLineMat = new THREE.LineBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.4,
    });
    const reliefLine = new THREE.Line(reliefLineGeo, reliefLineMat);
    scene.add(reliefLine);

    // 8. Atmospheric Floating Motes
    const moteCount = 400;
    const moteGeo = new THREE.BufferGeometry();
    const motePositions = new Float32Array(moteCount * 3);
    for (let i = 0; i < moteCount; i++) {
      motePositions[i * 3] = (Math.random() - 0.5) * 16;
      motePositions[i * 3 + 1] = Math.random() * 8 - 1;
      motePositions[i * 3 + 2] = (Math.random() - 0.5) * 16;
    }
    moteGeo.setAttribute('position', new THREE.BufferAttribute(motePositions, 3));
    const moteMat = new THREE.PointsMaterial({
      size: 0.04,
      color: 0x55d6e8,
      transparent: true,
      opacity: 0.5,
    });
    const motes = new THREE.Points(moteGeo, moteMat);
    scene.add(motes);

    // Parallax mouse interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetParallaxX = 0;
    let targetParallaxY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const normX = (e.clientX / window.innerWidth) * 2 - 1;
      const normY = -(e.clientY / window.innerHeight) * 2 + 1;
      mouseX = normX * 0.35;
      mouseY = normY * 0.25;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Animation Loop
    let animId: number;
    const clock = new THREE.Clock();
    let packetProgress = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Rotating beacon
      beaconMesh.rotation.y += 0.025;
      beaconMesh.rotation.z += 0.015;

      // Beacon ring pulsating
      const ringPulse = (Math.sin(time * 3.5) + 1) * 0.5;
      beaconRing.scale.set(1 + ringPulse * 0.4, 1 + ringPulse * 0.4, 1);

      // Rotating protective dome
      domeMesh.rotation.y += 0.002;
      innerSheenMesh.rotation.y -= 0.0015;

      // Traveling satellite packet
      packetProgress += 0.008;
      if (packetProgress > 1) packetProgress = 0;
      const pktPos = satCurve.getPoint(packetProgress);
      satPkt.position.copy(pktPos);

      // Satellite gentle hover
      satelliteMesh.rotation.y += 0.01;
      satelliteMesh.position.y = 4.8 + Math.sin(time * 1.5) * 0.08;

      // Rotating shelter mesh
      shelterMesh.rotation.y += 0.02;

      // Drifting motes
      motes.rotation.y = time * 0.01;

      // Radar rings gentle rotation
      radarRingsGroup.rotation.y += 0.001;

      // Smooth camera parallax
      targetParallaxX += (mouseX - targetParallaxX) * 0.05;
      targetParallaxY += (mouseY - targetParallaxY) * 0.05;

      camera.position.x = targetParallaxX;
      camera.position.y = 3.8 + targetParallaxY * 0.5;
      camera.lookAt(0, 0.4, 0);

      renderer.render(scene, camera);
    };

    animate();

    // Resize
    const handleResize = () => {
      if (!containerRef.current) return;
      width = containerRef.current.clientWidth || window.innerWidth;
      height = containerRef.current.clientHeight || window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      renderer.dispose();
      terrainGeo.dispose();
      domeGeo.dispose();
    };
  }, []);

  // Dynamically update 3D materials based on active emergency states
  useEffect(() => {
    const { beaconMesh, beaconRing, laserBeam, domeMat } = sceneRefs.current;
    if (!beaconMesh || !beaconRing || !laserBeam) return;

    if (isSosActive) {
      // SOS Triggered: Flash Ruby Red
      (beaconMesh.material as THREE.MeshStandardMaterial).color.set('#EF4444');
      (beaconMesh.material as THREE.MeshStandardMaterial).emissive.set('#EF4444');
      (beaconRing.material as THREE.MeshBasicMaterial).color.set('#EF4444');
      (laserBeam.material as THREE.MeshBasicMaterial).color.set('#EF4444');
      if (domeMat) {
        domeMat.color.set('#EF4444');
        domeMat.opacity = 0.55;
      }
      setHudStatus('EMERGENCY_SOS_ACTIVE');
    } else if (isDeliveryVerified) {
      // Delivery Handshake Verified: Emerald Shield
      (beaconMesh.material as THREE.MeshStandardMaterial).color.set('#10B981');
      (beaconMesh.material as THREE.MeshStandardMaterial).emissive.set('#10B981');
      (beaconRing.material as THREE.MeshBasicMaterial).color.set('#10B981');
      (laserBeam.material as THREE.MeshBasicMaterial).color.set('#10B981');
      if (domeMat) {
        domeMat.color.set('#10B981');
        domeMat.opacity = 0.45;
      }
      setHudStatus('HANDSET_DELIVERY_CONFIRMED');
    } else if (hasIncomingSms) {
      // Incoming Carrier SMS Directive: Cyan Alert
      (beaconMesh.material as THREE.MeshStandardMaterial).color.set('#00F2FF');
      (beaconMesh.material as THREE.MeshStandardMaterial).emissive.set('#00F2FF');
      (beaconRing.material as THREE.MeshBasicMaterial).color.set('#00F2FF');
      (laserBeam.material as THREE.MeshBasicMaterial).color.set('#00F2FF');
      if (domeMat) {
        domeMat.color.set('#55D6E8');
        domeMat.opacity = 0.4;
      }
      setHudStatus('DIRECTIVE_SMS_ARRIVED');
    } else {
      // Standard Standby: Ice-Blue Cyan
      (beaconMesh.material as THREE.MeshStandardMaterial).color.set('#55D6E8');
      (beaconMesh.material as THREE.MeshStandardMaterial).emissive.set('#55D6E8');
      (beaconRing.material as THREE.MeshBasicMaterial).color.set('#55D6E8');
      (laserBeam.material as THREE.MeshBasicMaterial).color.set('#55D6E8');
      if (domeMat) {
        domeMat.color.set('#55D6E8');
        domeMat.opacity = 0.35;
      }
      setHudStatus('SENTINEL_STANDBY');
    }
  }, [isSosActive, isDeliveryVerified, hasIncomingSms]);

  return (
    <div ref={containerRef} className="fixed inset-0 w-full h-full pointer-events-none z-0 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Atmospheric Vignette & Deep Midnight Gradients */}
      <div className="absolute inset-0 bg-gradient-to-t from-canvas via-transparent to-canvas/80 pointer-events-none" />
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none opacity-80" />

      {/* Floating Futuristic HUD Telemetry Strip */}
      <div className="absolute top-20 right-6 z-10 pointer-events-auto hidden md:flex items-center gap-3">
        <div className="px-3.5 py-1.5 rounded-full bg-surface-1/80 backdrop-blur-md border border-primary/30 text-[11px] font-mono text-primary flex items-center gap-2 shadow-glow-cyan">
          <span
            className={`w-2 h-2 rounded-full animate-ping ${
              isSosActive ? 'bg-red-500' : isDeliveryVerified ? 'bg-emerald-400' : 'bg-primary'
            }`}
          />
          <span>3D SENTINEL • {sectorName.toUpperCase()}</span>
          <span className="text-[10px] text-text-muted">[{hudStatus}]</span>
        </div>
      </div>
    </div>
  );
}
