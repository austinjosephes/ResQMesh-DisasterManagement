'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface ResilienceNetwork3DProps {
  onStageChange?: (stage: number, progress: number) => void;
  activeStage?: number;
}

export function ResilienceNetwork3D({ onStageChange, activeStage = 1 }: ResilienceNetwork3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [currentStage, setCurrentStage] = useState(1);
  const [manualExplore, setManualExplore] = useState(false);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    let width = containerRef.current.clientWidth || window.innerWidth;
    let height = containerRef.current.clientHeight || window.innerHeight;

    // 1. Scene, Camera, WebGL Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x060a14, 0.055);

    const camera = new THREE.PerspectiveCamera(48, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    // 2. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0x0a1428, 2.5);
    scene.add(ambientLight);

    const cyanDirLight = new THREE.DirectionalLight(0x55d6e8, 3.2);
    cyanDirLight.position.set(5, 8, 5);
    scene.add(cyanDirLight);

    const orangeAccentLight = new THREE.DirectionalLight(0xff6b35, 1.8);
    orangeAccentLight.position.set(-6, -2, -4);
    scene.add(orangeAccentLight);

    const pointLight = new THREE.PointLight(0x00f2ff, 4.0, 15);
    pointLight.position.set(0, 1.5, 0);
    scene.add(pointLight);

    // =========================================================================
    // SCENE 1: ABSTRACT DIGITAL GLOBE & SATELLITE ORBIT CONSTELLATIONS
    // =========================================================================
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Wireframe base sphere
    const globeGeo = new THREE.SphereGeometry(2.4, 32, 32);
    const globeWireMat = new THREE.MeshBasicMaterial({
      color: 0x172b4d,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const globeMesh = new THREE.Mesh(globeGeo, globeWireMat);
    globeGroup.add(globeMesh);

    // Inner glowing sphere core
    const coreGeo = new THREE.SphereGeometry(2.28, 24, 24);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0x06152d,
      transparent: true,
      opacity: 0.85,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    globeGroup.add(coreMesh);

    // Dot constellation nodes on globe surface
    const nodeCount = 380;
    const nodePositions = new Float32Array(nodeCount * 3);
    const nodeColors = new Float32Array(nodeCount * 3);
    const cyanCol = new THREE.Color('#55D6E8');
    const amberCol = new THREE.Color('#FF9F1C');
    const navyCol = new THREE.Color('#1B335A');

    for (let i = 0; i < nodeCount; i++) {
      const phi = Math.acos(-1 + (2 * i) / nodeCount);
      const theta = Math.sqrt(nodeCount * Math.PI) * phi;
      const r = 2.42;

      nodePositions[i * 3] = r * Math.cos(theta) * Math.sin(phi);
      nodePositions[i * 3 + 1] = r * Math.sin(theta) * Math.sin(phi);
      nodePositions[i * 3 + 2] = r * Math.cos(phi);

      const isCluster = i % 7 === 0;
      const isEmergency = i % 31 === 0;
      const c = isEmergency ? amberCol : isCluster ? cyanCol : navyCol;
      nodeColors[i * 3] = c.r;
      nodeColors[i * 3 + 1] = c.g;
      nodeColors[i * 3 + 2] = c.b;
    }

    const nodePointsGeo = new THREE.BufferGeometry();
    nodePointsGeo.setAttribute('position', new THREE.BufferAttribute(nodePositions, 3));
    nodePointsGeo.setAttribute('color', new THREE.BufferAttribute(nodeColors, 3));

    const nodePointsMat = new THREE.PointsMaterial({
      size: 0.065,
      vertexColors: true,
      transparent: true,
      opacity: 0.95,
    });
    const globeNodes = new THREE.Points(nodePointsGeo, nodePointsMat);
    globeGroup.add(globeNodes);

    // Satellite Orbit Ring
    const orbitCurve = new THREE.EllipseCurve(0, 0, 3.2, 3.2, 0, 2 * Math.PI, false, 0);
    const orbitPoints = orbitCurve.getPoints(100);
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(
      orbitPoints.map((p) => new THREE.Vector3(p.x, 0, p.y))
    );
    const orbitMat = new THREE.LineBasicMaterial({
      color: 0x00f2ff,
      transparent: true,
      opacity: 0.35,
    });
    const orbitRing = new THREE.Line(orbitGeo, orbitMat);
    orbitRing.rotation.x = Math.PI / 4;
    orbitRing.rotation.y = Math.PI / 6;
    globeGroup.add(orbitRing);

    // Orbiting Satellite Packet
    const satGeo = new THREE.SphereGeometry(0.08, 12, 12);
    const satMat = new THREE.MeshBasicMaterial({ color: 0x55d6e8 });
    const satMesh = new THREE.Mesh(satGeo, satMat);
    globeGroup.add(satMesh);

    // Outer Atmospheric Glow Halo
    const haloGeo = new THREE.SphereGeometry(2.52, 24, 24);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.09,
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    globeGroup.add(haloMesh);

    // =========================================================================
    // SCENE 2: 3D TOPOGRAPHIC TERRAIN WITH ELEVATION CONTOURS
    // =========================================================================
    const terrainGroup = new THREE.Group();
    terrainGroup.position.set(0, -1.2, 0);
    scene.add(terrainGroup);

    const terrainWidth = 14;
    const terrainDepth = 14;
    const terrainSegments = 70;
    const terrainGeo = new THREE.PlaneGeometry(terrainWidth, terrainDepth, terrainSegments, terrainSegments);
    terrainGeo.rotateX(-Math.PI / 2);

    const terrainPos = terrainGeo.attributes.position;
    const terrainColors = new Float32Array(terrainPos.count * 3);

    // Procedural Elevation (modeling Western Ghats mountain ridges & coastal basin)
    for (let i = 0; i < terrainPos.count; i++) {
      const x = terrainPos.getX(i);
      const z = terrainPos.getZ(i);

      // Multi-octave natural terrain formula
      const distFromCenter = Math.sqrt(x * x + z * z);
      let elevation =
        Math.sin(x * 0.65) * Math.cos(z * 0.65) * 0.85 +
        Math.sin(x * 1.3 + z * 0.8) * 0.45 +
        Math.sin(x * 2.1 - z * 1.7) * 0.22 -
        Math.pow(distFromCenter / 7.5, 2) * 0.7;

      // Ridge accentuation
      if (x > -2 && x < 4 && z > -3 && z < 3) {
        elevation += Math.sin((x + 2) * 1.2) * 0.6;
      }

      terrainPos.setY(i, elevation);

      // Color based on elevation (Deep Navy -> Electric Cyan -> High Altitude Amber)
      let c = new THREE.Color('#0A1528');
      if (elevation > 0.8) {
        c.lerp(new THREE.Color('#FF9F1C'), Math.min(1, (elevation - 0.8) * 1.5));
      } else if (elevation > 0.1) {
        c.lerp(new THREE.Color('#55D6E8'), (elevation - 0.1) / 0.7);
      } else {
        c.lerp(new THREE.Color('#142540'), (elevation + 1.0) / 1.1);
      }

      terrainColors[i * 3] = c.r;
      terrainColors[i * 3 + 1] = c.g;
      terrainColors[i * 3 + 2] = c.b;
    }

    terrainGeo.setAttribute('color', new THREE.BufferAttribute(terrainColors, 3));
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.35,
      metalness: 0.65,
      wireframe: false,
      transparent: true,
      opacity: 0.92,
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainGroup.add(terrainMesh);

    // Animated Digital Elevation Contour Lines (Wireframe Overlay)
    const contourMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.32,
    });
    const contourMesh = new THREE.Mesh(terrainGeo, contourMat);
    contourMesh.position.y = 0.015;
    terrainGroup.add(contourMesh);

    // Base boundary spatial grid
    const gridHelper = new THREE.GridHelper(16, 24, 0x55d6e8, 0x142848);
    gridHelper.position.y = -1.1;
    (gridHelper.material as THREE.Material).transparent = true;
    (gridHelper.material as THREE.Material).opacity = 0.25;
    terrainGroup.add(gridHelper);

    // =========================================================================
    // SCENE 3: INTERCONNECTED EMERGENCY COMMUNICATION NETWORK NODES
    // =========================================================================
    const networkGroup = new THREE.Group();
    terrainGroup.add(networkGroup);

    // Key Strategic Nodes (Grama Panchayats, Weather Stations, Radar, Relief Shelters)
    const nodeCoords = [
      { x: -3.5, z: -2.0, name: 'Meppadi Node', type: 'RADAR' },
      { x: -1.8, z: -0.5, name: 'Chooralmala Hub', type: 'RELIEF' },
      { x: 0.2, z: -2.8, name: 'Vythiri Relay', type: 'GATEWAY' },
      { x: 1.5, z: 0.5, name: 'Kalpetta HQ', type: 'COMMAND' },
      { x: -2.5, z: 2.5, name: 'Nilambur Unit', type: 'RIVER' },
      { x: 2.8, z: -1.2, name: 'Mananthavady Unit', type: 'GATEWAY' },
      { x: 3.2, z: 2.2, name: 'Sultan Bathery Base', type: 'RELIEF' },
      { x: 0.0, z: 3.0, name: 'Periyar Hydrology', type: 'RIVER' },
      { x: -4.0, z: 1.0, name: 'Coastal Tower 01', type: 'COASTAL' },
      { x: 4.0, z: 0.0, name: 'Eastern Escarpment', type: 'GATEWAY' },
    ];

    const nodeMeshes: THREE.Mesh[] = [];
    const beaconRings: THREE.Mesh[] = [];

    nodeCoords.forEach((coord, idx) => {
      // Find ground elevation at coord.x, coord.z
      const y = Math.sin(coord.x * 0.65) * Math.cos(coord.z * 0.65) * 0.85 + 0.3;

      // Holographic node pillar / diamond
      const isCommand = coord.type === 'COMMAND';
      const isRadar = coord.type === 'RADAR';
      const nodeCol = isCommand ? 0xff6b35 : isRadar ? 0x00f2ff : 0x55d6e8;

      const nGeo = new THREE.OctahedronGeometry(isCommand ? 0.22 : 0.16, 0);
      const nMat = new THREE.MeshStandardMaterial({
        color: nodeCol,
        emissive: nodeCol,
        emissiveIntensity: 0.8,
        metalness: 0.8,
        roughness: 0.2,
      });
      const nMesh = new THREE.Mesh(nGeo, nMat);
      nMesh.position.set(coord.x, y + 0.45, coord.z);
      networkGroup.add(nMesh);
      nodeMeshes.push(nMesh);

      // Pulsing Beacon Ground Ring
      const ringGeo = new THREE.RingGeometry(0.15, 0.25, 20);
      ringGeo.rotateX(-Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({
        color: nodeCol,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.set(coord.x, y + 0.05, coord.z);
      networkGroup.add(ringMesh);
      beaconRings.push(ringMesh);

      // Vertical holographic light beam
      const beamGeo = new THREE.CylinderGeometry(0.015, 0.04, 1.8, 8);
      const beamMat = new THREE.MeshBasicMaterial({
        color: nodeCol,
        transparent: true,
        opacity: 0.35,
      });
      const beamMesh = new THREE.Mesh(beamGeo, beamMat);
      beamMesh.position.set(coord.x, y + 0.9, coord.z);
      networkGroup.add(beamMesh);
    });

    // Network Arcs / Dynamic Data Connections between Nodes
    const linkLines: THREE.Line[] = [];
    const dataPackets: THREE.Mesh[] = [];

    for (let i = 0; i < nodeCoords.length; i++) {
      for (let j = i + 1; j < nodeCoords.length; j++) {
        const p1 = nodeMeshes[i].position;
        const p2 = nodeMeshes[j].position;
        const dist = p1.distanceTo(p2);

        // Only connect proximal nodes within mesh distance
        if (dist < 4.8) {
          const midX = (p1.x + p2.x) / 2;
          const midY = (p1.y + p2.y) / 2 + 0.55; // Arched trajectory
          const midZ = (p1.z + p2.z) / 2;

          const curve = new THREE.QuadraticBezierCurve3(
            p1,
            new THREE.Vector3(midX, midY, midZ),
            p2
          );

          const curvePoints = curve.getPoints(24);
          const linkGeo = new THREE.BufferGeometry().setFromPoints(curvePoints);
          const linkMat = new THREE.LineBasicMaterial({
            color: 0x55d6e8,
            transparent: true,
            opacity: 0.45,
          });
          const linkLine = new THREE.Line(linkGeo, linkMat);
          networkGroup.add(linkLine);
          linkLines.push(linkLine);

          // Animated Traveling Data Packet
          const pktGeo = new THREE.SphereGeometry(0.045, 8, 8);
          const pktMat = new THREE.MeshBasicMaterial({ color: 0x00f2ff });
          const pktMesh = new THREE.Mesh(pktGeo, pktMat);
          pktMesh.userData = { curve, progress: Math.random(), speed: 0.006 + Math.random() * 0.008 };
          networkGroup.add(pktMesh);
          dataPackets.push(pktMesh);
        }
      }
    }

    // =========================================================================
    // SCENE 4: TRANSLUCENT PROTECTIVE GEODESIC SAFETY DOME
    // =========================================================================
    const shieldGroup = new THREE.Group();
    terrainGroup.add(shieldGroup);

    const domeGeo = new THREE.IcosahedronGeometry(6.2, 3);
    const domeMat = new THREE.MeshBasicMaterial({
      color: 0x55d6e8,
      wireframe: true,
      transparent: true,
      opacity: 0.0, // Activated on scroll
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.y = 0.5;
    shieldGroup.add(domeMesh);

    // Inner protective energetic sheen
    const innerShieldMat = new THREE.MeshStandardMaterial({
      color: 0x0e2445,
      emissive: 0x00f2ff,
      emissiveIntensity: 0.15,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
    });
    const innerShieldMesh = new THREE.Mesh(domeGeo, innerShieldMat);
    innerShieldMesh.position.y = 0.5;
    innerShieldMesh.scale.set(0.98, 0.98, 0.98);
    shieldGroup.add(innerShieldMesh);

    // =========================================================================
    // ATMOSPHERIC PARTICLES & SPATIAL MOTES
    // =========================================================================
    const moteCount = 650;
    const moteGeo = new THREE.BufferGeometry();
    const motePositions = new Float32Array(moteCount * 3);

    for (let i = 0; i < moteCount; i++) {
      motePositions[i * 3] = (Math.random() - 0.5) * 22;
      motePositions[i * 3 + 1] = Math.random() * 12 - 2;
      motePositions[i * 3 + 2] = (Math.random() - 0.5) * 22;
    }
    moteGeo.setAttribute('position', new THREE.BufferAttribute(motePositions, 3));

    const moteMat = new THREE.PointsMaterial({
      size: 0.045,
      color: 0x55d6e8,
      transparent: true,
      opacity: 0.65,
    });
    const motes = new THREE.Points(moteGeo, moteMat);
    scene.add(motes);

    // =========================================================================
    // SCROLL-CONTROLLED CAMERA & ENVIRONMENT TIMELINE (GSAP SCROLLTRIGGER)
    // =========================================================================
    // Start with Scene 1 visible, Scene 2-4 hidden
    globeGroup.scale.set(1, 1, 1);
    globeGroup.position.set(0, 0, 0);

    terrainGroup.scale.set(0.2, 0.2, 0.2);
    terrainGroup.position.set(0, -6, 0);
    terrainMesh.material.opacity = 0;
    contourMesh.material.opacity = 0;
    networkGroup.visible = false;
    domeMat.opacity = 0;
    innerShieldMat.opacity = 0;

    setIsLoaded(true);

    // Camera target vector
    const lookTarget = new THREE.Vector3(0, 0, 0);

    // Mouse Parallax variables
    let mouseX = 0;
    let mouseY = 0;
    let targetParallaxX = 0;
    let targetParallaxY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const normX = (e.clientX / window.innerWidth) * 2 - 1;
      const normY = -(e.clientY / window.innerHeight) * 2 + 1;
      mouseX = normX * 0.45;
      mouseY = normY * 0.3;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Set up GSAP ScrollTrigger timeline synchronized with page scroll
    const masterTl = gsap.timeline({
      scrollTrigger: {
        trigger: '#cinematic-3d-scroll-track',
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1.2,
        onUpdate: (self) => {
          const prog = self.progress;
          let stage = 1;
          if (prog < 0.22) stage = 1;
          else if (prog < 0.45) stage = 2;
          else if (prog < 0.70) stage = 3;
          else if (prog < 0.88) stage = 4;
          else stage = 5;

          setCurrentStage(stage);
          if (onStageChange) onStageChange(stage, prog);
        },
      },
    });

    // SCENE 1 -> SCENE 2: Zoom from Globe into Topographic Terrain
    masterTl
      // 0.0 -> 0.25
      .to(
        camera.position,
        {
          x: 0,
          y: 3.2,
          z: 5.2,
          ease: 'power2.inOut',
          duration: 2.5,
        },
        0
      )
      .to(
        globeGroup.scale,
        {
          x: 0.01,
          y: 0.01,
          z: 0.01,
          duration: 1.8,
          ease: 'power2.in',
        },
        0.4
      )
      .to(
        terrainGroup.position,
        {
          x: 0,
          y: -1.0,
          z: 0,
          duration: 2.2,
          ease: 'power2.out',
        },
        0.3
      )
      .to(
        terrainGroup.scale,
        {
          x: 1,
          y: 1,
          z: 1,
          duration: 2.2,
          ease: 'power2.out',
        },
        0.3
      )
      .to(
        [terrainMesh.material, contourMesh.material],
        {
          opacity: 0.92,
          duration: 1.8,
          ease: 'power1.out',
          stagger: 0.2,
        },
        0.5
      )

      // SCENE 2 -> SCENE 3: Topography to Interconnected Communication Mesh
      // 0.25 -> 0.55
      .to(
        camera.position,
        {
          x: -1.8,
          y: 2.2,
          z: 3.6,
          ease: 'sine.inOut',
          duration: 2.8,
        },
        2.5
      )
      .call(
        () => {
          networkGroup.visible = true;
        },
        undefined,
        2.6
      )
      .fromTo(
        nodeMeshes.map((m) => m.scale),
        { x: 0, y: 0, z: 0 },
        {
          x: 1,
          y: 1,
          z: 1,
          duration: 1.5,
          stagger: 0.08,
          ease: 'back.out(1.8)',
        },
        2.7
      )
      .fromTo(
        linkLines.map((l) => (l.material as THREE.Material)),
        { opacity: 0 },
        {
          opacity: 0.5,
          duration: 1.8,
          stagger: 0.04,
          ease: 'power2.out',
        },
        3.2
      )

      // SCENE 3 -> SCENE 4: Community Protective Geodesic Energy Shield
      // 0.55 -> 0.80
      .to(
        camera.position,
        {
          x: 0,
          y: 4.8,
          z: 5.6,
          ease: 'power2.inOut',
          duration: 2.8,
        },
        5.2
      )
      .to(
        domeMat,
        {
          opacity: 0.38,
          duration: 2.0,
          ease: 'power2.out',
        },
        5.5
      )
      .to(
        innerShieldMat,
        {
          opacity: 0.18,
          duration: 2.2,
          ease: 'power2.out',
        },
        5.6
      )
      .to(
        domeMesh.rotation,
        {
          y: Math.PI * 0.4,
          duration: 3.0,
          ease: 'none',
        },
        5.4
      )

      // SCENE 4 -> SCENE 5: Dock into Live Operational Dashboard Perspective
      // 0.80 -> 1.0
      .to(
        camera.position,
        {
          x: 0,
          y: 6.8,
          z: 3.8,
          ease: 'power3.out',
          duration: 2.4,
        },
        8.0
      )
      .to(
        lookTarget,
        {
          x: 0,
          y: 0,
          z: -1.2,
          duration: 2.4,
          ease: 'power2.out',
        },
        8.0
      )
      .to(
        terrainGroup.position,
        {
          y: -1.8,
          duration: 2.4,
          ease: 'power2.out',
        },
        8.0
      );

    // =========================================================================
    // CONTINUOUS 60FPS RENDER & SIMULATION LOOP
    // =========================================================================
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // 1. Globe Ambient Rotation & Satellite Orbit
      if (globeGroup.visible) {
        globeGroup.rotation.y += 0.003;
        globeNodes.rotation.y -= 0.001;

        // Satellite trajectory
        const satAngle = elapsedTime * 0.9;
        satMesh.position.set(
          Math.cos(satAngle) * 3.2,
          Math.sin(satAngle * 0.8) * 0.9,
          Math.sin(satAngle) * 3.2
        );
      }

      // 2. Terrain Wave & Contour Pulse
      if (terrainGroup.position.y > -5) {
        contourMesh.position.y = 0.015 + Math.sin(elapsedTime * 2.0) * 0.008;

        // Beacon Ground Rings Pulsing
        beaconRings.forEach((ring, idx) => {
          const pulse = (Math.sin(elapsedTime * 3.0 + idx * 0.7) + 1) * 0.5;
          ring.scale.set(1 + pulse * 0.35, 1 + pulse * 0.35, 1);
          (ring.material as THREE.MeshBasicMaterial).opacity = 0.35 + pulse * 0.45;
        });

        // Floating Nodes gentle levitation
        nodeMeshes.forEach((mesh, idx) => {
          mesh.rotation.y += 0.02;
          mesh.rotation.z += 0.01;
          mesh.position.y += Math.sin(elapsedTime * 2.2 + idx) * 0.0015;
        });

        // Data Packets moving along mesh arcs
        dataPackets.forEach((pkt) => {
          pkt.userData.progress += pkt.userData.speed;
          if (pkt.userData.progress > 1) pkt.userData.progress = 0;
          const pos = pkt.userData.curve.getPoint(pkt.userData.progress);
          pkt.position.copy(pos);
        });

        // Protective Dome gentle rotation
        if (domeMat.opacity > 0.05) {
          domeMesh.rotation.y += 0.0015;
          innerShieldMesh.rotation.y -= 0.001;
        }
      }

      // 3. Stardust Motes Drifting
      motes.rotation.y = elapsedTime * 0.015;

      // 4. Parallax Camera Smoothing
      targetParallaxX += (mouseX - targetParallaxX) * 0.05;
      targetParallaxY += (mouseY - targetParallaxY) * 0.05;

      camera.position.x += (targetParallaxX - camera.position.x * 0.08) * 0.05;
      camera.lookAt(lookTarget.x, lookTarget.y, lookTarget.z);

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!containerRef.current) return;
      width = containerRef.current.clientWidth || window.innerWidth;
      height = containerRef.current.clientHeight || window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      ScrollTrigger.getAll().forEach((t) => t.kill());
      renderer.dispose();
      globeGeo.dispose();
      terrainGeo.dispose();
      domeGeo.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 w-full h-full pointer-events-none z-0 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Cinematic Vignette & Deep Midnight Background Gradients */}
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none opacity-80" />
      <div className="absolute inset-0 bg-gradient-to-t from-canvas via-transparent to-canvas/70 pointer-events-none" />

      {/* Floating Spatial HUD Grid Indicator */}
      <div className="absolute top-20 right-6 z-10 pointer-events-auto hidden md:flex items-center gap-3">
        <div className="px-3.5 py-1.5 rounded-full bg-surface-1/80 backdrop-blur-md border border-primary/30 text-[11px] font-mono text-primary flex items-center gap-2 shadow-glow-cyan">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>RESILIENCE 3D ENGINE • STAGE 0{currentStage}/05</span>
        </div>
      </div>
    </div>
  );
}
