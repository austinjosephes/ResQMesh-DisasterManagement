'use client';

import React, { useState, useEffect } from 'react';
import { OfflineVerifier } from '@resqmesh/verifier';
import { VerificationResultCode, VerificationResult, TrustBundle, SignedStatusSnapshot } from '@resqmesh/shared';
import * as jose from 'jose';
import { ShieldCheck, ShieldX, RefreshCw, AlertTriangle, ArrowRight, Sparkles } from 'lucide-react';

export function TamperDemo() {
  const [roleInput, setRoleInput] = useState('PARAMEDIC_TIER_2');
  const [token, setToken] = useState('');
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [mockTrustBundle, setMockTrustBundle] = useState<TrustBundle | null>(null);

  useEffect(() => {
    async function setupDemo() {
      const issuerKeyPair = await jose.generateKeyPair('ES256', { extractable: true });
      const pubJwk = await jose.exportJWK(issuerKeyPair.publicKey);
      pubJwk.kid = 'issuer-demo-root';

      const now = Math.floor(Date.now() / 1000);
      const bundle: TrustBundle = {
        bundle_version: 1,
        issued_at: now - 3600,
        expires_at: now + 86400 * 30,
        root_authority_id: 'did:resqmesh:demo-root',
        keys: [
          {
            kid: 'issuer-demo-root',
            issuer: 'did:resqmesh:fema',
            publicKeyJwk: pubJwk as any,
            validFrom: now - 86400,
            validUntil: now + 86400 * 30,
            status: 'ACTIVE',
          },
        ],
        signature: 'DEMO_BUNDLE_SIG',
      };

      setMockTrustBundle(bundle);

      // Generate signed baseline credential
      const claims = {
        jti: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
        iss: 'did:resqmesh:fema',
        sub: 'responder-charlie-9',
        iat: now - 60,
        nbf: now - 60,
        exp: now + 86400,
        role: 'PARAMEDIC_TIER_2',
        permissions: ['incident.view', 'triage.record'],
        incident_scope: 'CASCADE-QUAKE',
        credential_version: '1.0',
        policy_version: '2026.1',
        status: { status_list_id: 'sl-1', status_list_index: 10 },
        cnf: {
          jwk_thumbprint: 'SHA256:N7yM9uL3x2K...',
          jwk: pubJwk as any,
        },
      };

      const signed = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(claims)))
        .setProtectedHeader({ alg: 'ES256', kid: 'issuer-demo-root', typ: 'application/resqmesh-credential+jwt' })
        .sign(issuerKeyPair.privateKey);

      setToken(signed);

      // Verify baseline
      const verifier = new OfflineVerifier({ trustBundle: bundle });
      const initialRes = await verifier.verify({ token: signed, requestedAction: 'triage.record' });
      setResult(initialRes);
    }

    setupDemo();
  }, []);

  const handleSimulateTamper = async (tamperedRole: string) => {
    if (!token || !mockTrustBundle) return;
    setRoleInput(tamperedRole);
    setIsVerifying(true);

    try {
      const parts = token.split('.');
      const payload = JSON.parse(atob(parts[1]));
      payload.role = tamperedRole;
      if (tamperedRole === 'INCIDENT_COMMANDER') {
        payload.permissions.push('commander.delegate');
      }

      const tamperedB64 = btoa(JSON.stringify(payload)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
      const tamperedToken = `${parts[0]}.${tamperedB64}.${parts[2]}`;

      const verifier = new OfflineVerifier({ trustBundle: mockTrustBundle });
      const res = await verifier.verify({ token: tamperedToken, requestedAction: 'triage.record' });
      setResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleReset = async () => {
    if (!token || !mockTrustBundle) return;
    setRoleInput('PARAMEDIC_TIER_2');
    const verifier = new OfflineVerifier({ trustBundle: mockTrustBundle });
    const res = await verifier.verify({ token, requestedAction: 'triage.record' });
    setResult(res);
  };

  return (
    <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-surface-3">
        <div>
          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-primary/10 text-primary font-bold">
            Live Verifier Engine
          </span>
          <h3 className="text-base font-bold text-text-primary mt-1">
            Interactive Tamper & Signature Defense Simulator
          </h3>
        </div>
        <button
          onClick={handleReset}
          className="text-xs text-text-muted hover:text-primary transition flex items-center gap-1 font-mono self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reset to Authentic Baseline
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Controls */}
        <div className="space-y-4 text-xs">
          <div>
            <label className="block text-text-secondary font-medium mb-1.5">
              Simulate Modifying Responder Role Payload
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleReset()}
                className={`p-2.5 rounded-lg border text-left transition font-mono ${
                  roleInput === 'PARAMEDIC_TIER_2'
                    ? 'bg-emerald-950/40 border-emerald-600 text-emerald-300 font-bold'
                    : 'bg-surface-2 border-surface-3 text-text-secondary hover:bg-surface-3'
                }`}
              >
                <span>PARAMEDIC_TIER_2</span>
                <span className="text-[10px] block opacity-70">Authentic Signed Claim</span>
              </button>

              <button
                type="button"
                onClick={() => handleSimulateTamper('INCIDENT_COMMANDER')}
                className={`p-2.5 rounded-lg border text-left transition font-mono ${
                  roleInput === 'INCIDENT_COMMANDER'
                    ? 'bg-red-950/40 border-red-600 text-red-300 font-bold'
                    : 'bg-surface-2 border-surface-3 text-text-secondary hover:bg-surface-3'
                }`}
              >
                <span>INCIDENT_COMMANDER</span>
                <span className="text-[10px] block text-red-400">Escalated Attack Claim</span>
              </button>
            </div>
          </div>

          <p className="text-[11px] text-text-muted leading-relaxed">
            When an attacker attempts privilege escalation by modifying claims, the SHA-256 hash of the modified payload no longer matches the ECDSA P-256 digital signature generated by the issuer authority.
          </p>
        </div>

        {/* Live Cryptographic Result */}
        <div className="space-y-3">
          <span className="text-[11px] font-mono uppercase text-text-muted font-semibold block">
            Cryptographic Engine Decision
          </span>

          {result && (
            <div
              className={`p-4 rounded-xl border text-xs font-mono space-y-2 transition-all ${
                result.code === VerificationResultCode.VALID_AND_AUTHORIZED
                  ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
                  : 'bg-red-950/40 border-red-700/60 text-red-200'
              }`}
            >
              <div className="flex items-center gap-2">
                {result.code === VerificationResultCode.VALID_AND_AUTHORIZED ? (
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                ) : (
                  <ShieldX className="w-5 h-5 text-red-400" />
                )}
                <span className="font-bold text-sm">{result.code}</span>
              </div>
              <p className="text-[11px] opacity-90">{result.summary}</p>
              <div className="pt-2 border-t border-current/20 flex justify-between text-[10px] opacity-80">
                <span>Authentic: {result.authentic ? 'PASSED' : 'FAILED'}</span>
                <span>Algorithm: ES256</span>
                <span>Curve: P-256</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
