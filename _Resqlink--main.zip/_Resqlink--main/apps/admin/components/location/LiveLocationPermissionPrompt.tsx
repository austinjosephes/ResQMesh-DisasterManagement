'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  MapPin,
  Navigation,
  Compass,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Search,
  ChevronDown,
  ChevronUp,
  X,
  Radio,
  Crosshair,
  ShieldAlert,
  Globe,
  Sliders,
  Sparkles,
} from 'lucide-react';
import {
  findNearestGramaPanchayat,
  GramaPanchayat,
  getAllDistricts,
  getBlocksForDistrict,
  getGramasForBlock,
  DistrictHierarchy,
  BlockPanchayat,
} from '@/lib/kerala-administrative';

export interface LiveLocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  source: 'GPS' | 'IP' | 'MANUAL';
  sector: GramaPanchayat;
  timestamp: string;
}

interface LiveLocationPermissionPromptProps {
  /** If true, opens the modal immediately if location is not locked */
  autoPrompt?: boolean;
  /** Callback whenever a live location fix is established or updated */
  onLocationAcquired?: (data: LiveLocationData) => void;
  /** Optional custom button trigger */
  className?: string;
  /** Whether to show the top persistent status bar */
  showTopBar?: boolean;
}

export function LiveLocationPermissionPrompt({
  autoPrompt = true,
  onLocationAcquired,
  className = '',
  showTopBar = true,
}: LiveLocationPermissionPromptProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<
    'IDLE' | 'AWAITING_PERMISSION' | 'ACQUIRING_GPS' | 'RESOLVING' | 'LOCKED' | 'DENIED' | 'ERROR'
  >('IDLE');
  const [liveLocation, setLiveLocation] = useState<LiveLocationData | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [showManualPicker, setShowManualPicker] = useState(false);
  const [districts, setDistricts] = useState<DistrictHierarchy[]>([]);

  // Manual picker states
  const [selectedDistrict, setSelectedDistrict] = useState<string>('Wayanad');
  const [selectedBlock, setSelectedBlock] = useState<string>('Kalpetta');
  const [selectedGrama, setSelectedGrama] = useState<string>('Meppadi Grama Panchayat');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // 1. Load cached location on mount & auto-prompt if empty
  useEffect(() => {
    try {
      const allDist = getAllDistricts();
      setDistricts(allDist);
    } catch (e) {
      console.warn('Failed to load Kerala administrative hierarchy:', e);
    }

    const cached = localStorage.getItem('resqlink_user_live_location');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (parsed && typeof parsed.latitude === 'number' && typeof parsed.longitude === 'number') {
          const locData: LiveLocationData = {
            latitude: parsed.latitude,
            longitude: parsed.longitude,
            accuracy: parsed.accuracy || 10,
            source: parsed.source || 'GPS',
            sector: parsed.sector || findNearestGramaPanchayat(parsed.latitude, parsed.longitude),
            timestamp: parsed.timestamp || new Date().toISOString(),
          };
          setLiveLocation(locData);
          setStatus('LOCKED');
          if (onLocationAcquired) onLocationAcquired(locData);
          return;
        }
      } catch (e) {
        console.warn('Invalid cached location');
      }
    }

    // If no live location is cached and autoPrompt is active, immediately ask!
    if (autoPrompt) {
      setIsOpen(true);
      requestLiveGpsLocation();
    }
  }, [autoPrompt]);

  // Broadcast location to window and persistent storage
  const commitLocation = useCallback(
    (lat: number, lng: number, acc: number, src: 'GPS' | 'IP' | 'MANUAL') => {
      setStatus('RESOLVING');
      setStatusMessage('Calibrating with Kerala 941 Grama Panchayat Geospatial Grid...');

      try {
        const sector = findNearestGramaPanchayat(lat, lng);
        const data: LiveLocationData = {
          latitude: lat,
          longitude: lng,
          accuracy: acc,
          source: src,
          sector,
          timestamp: new Date().toISOString(),
        };

        setLiveLocation(data);
        setStatus('LOCKED');
        setStatusMessage(`Real-time lock: ${sector.name}, ${sector.districtName} (±${Math.round(acc)}m)`);

        // Cache in localStorage for all portals
        localStorage.setItem('resqlink_user_live_location', JSON.stringify(data));
        localStorage.setItem(
          'resqlink_resident_calibrated_location',
          JSON.stringify({
            center: { lat, lng },
            accuracy: acc,
            sector,
            source: src,
            calibratedAt: data.timestamp,
          })
        );

        // Dispatch window event so any listening page updates instantly
        if (typeof window !== 'undefined') {
          window.dispatchEvent(
            new CustomEvent('resqlink:location-updated', {
              detail: data,
            })
          );
        }

        if (onLocationAcquired) {
          onLocationAcquired(data);
        }

        // Auto-close modal after brief visual confirmation
        setTimeout(() => {
          setIsOpen(false);
        }, 1400);
      } catch (err: any) {
        console.error('Failed to resolve sector:', err);
        setStatus('ERROR');
        setStatusMessage('Could not map coordinates to Grama Panchayat. Please select sector manually.');
      }
    },
    [onLocationAcquired]
  );

  // 2. High-precision Browser Geolocation Trigger
  const requestLiveGpsLocation = useCallback(() => {
    setStatus('AWAITING_PERMISSION');
    setStatusMessage('Triggering device GPS. Please click "Allow" on the browser prompt...');

    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setStatus('DENIED');
      setStatusMessage('Device or browser does not support Geolocation API. Try IP detection.');
      return;
    }

    setStatus('ACQUIRING_GPS');
    setStatusMessage('Satellite GPS acquiring high-accuracy fix (WGS-84)...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const acc = pos.coords.accuracy || 8.0;
        commitLocation(lat, lng, acc, 'GPS');
      },
      (err) => {
        console.warn('Geolocation error:', err);
        if (err.code === err.PERMISSION_DENIED) {
          setStatus('DENIED');
          setStatusMessage('Location permission denied by browser. Click "Allow" or detect via IP.');
        } else if (err.code === err.TIMEOUT) {
          setStatus('ERROR');
          setStatusMessage('GPS acquisition timed out. Attempting IP network fallback...');
          requestIpLocation();
        } else {
          setStatus('ERROR');
          setStatusMessage('GPS unavailable. Attempting IP network fallback...');
          requestIpLocation();
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  }, [commitLocation]);

  // 3. Fallback: Network IP Geolocation
  const requestIpLocation = async () => {
    setStatus('RESOLVING');
    setStatusMessage('Querying Network IP Geolocation fallback...');

    try {
      const res = await fetch('https://ipapi.co/json/');
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data.latitude === 'number' && typeof data.longitude === 'number') {
          // If IP coordinates are somewhere in India/Kerala
          commitLocation(data.latitude, data.longitude, 1200, 'IP');
          return;
        }
      }
    } catch (e) {
      console.warn('IP geolocation query failed:', e);
    }

    // Default to Kerala Center (Meppadi, Wayanad) if IP fails
    commitLocation(11.5512, 76.1284, 500, 'IP');
  };

  // 4. Manual Sector Selection Commit
  const handleManualCommit = () => {
    const dObj = districts.find((d) => d.name.toLowerCase() === selectedDistrict.toLowerCase());
    if (!dObj) return;

    let targetGrama: GramaPanchayat | undefined;
    for (const b of dObj.blocks) {
      if (b.name.toLowerCase() === selectedBlock.toLowerCase()) {
        targetGrama = b.gramaPanchayats.find(
          (g) => g.name.toLowerCase() === selectedGrama.toLowerCase() || g.id === selectedGrama
        );
        if (targetGrama) break;
      }
    }

    if (!targetGrama && dObj.blocks[0]?.gramaPanchayats[0]) {
      targetGrama = dObj.blocks[0].gramaPanchayats[0];
    }

    if (targetGrama) {
      commitLocation(targetGrama.center.lat, targetGrama.center.lng, 50, 'MANUAL');
      setShowManualPicker(false);
    }
  };

  // Filtered blocks and gramas for manual picker
  const currentBlocks = districts.find((d) => d.name === selectedDistrict)?.blocks || [];
  const currentGramas = currentBlocks.find((b) => b.name === selectedBlock)?.gramaPanchayats || [];

  return (
    <>
      {/* PERSISTENT TOP LIVE LOCATION BAR (If enabled) */}
      {showTopBar && (
        <div className="relative z-40 bg-[#0B1017]/90 backdrop-blur-md border-b border-white/[0.08] px-4 py-2 text-xs">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    liveLocation ? 'bg-[#22C55E]' : 'bg-[#FF6B35]'
                  }`}
                />
                <span
                  className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                    liveLocation ? 'bg-[#22C55E]' : 'bg-[#FF6B35]'
                  }`}
                />
              </span>

              {liveLocation ? (
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-[#38BDF8] font-bold">LIVE GPS FIX:</span>
                  <span className="text-[#F5F7FA] font-extrabold">{liveLocation.sector.name}</span>
                  <span className="text-[#929CAB] font-semibold">({liveLocation.sector.districtName})</span>
                  <span className="text-[#6F7C93] text-[11px] hidden sm:inline">
                    • {liveLocation.latitude.toFixed(4)}°N, {liveLocation.longitude.toFixed(4)}°E (±
                    {Math.round(liveLocation.accuracy)}m)
                  </span>
                  <span className="ios-capsule text-[10px] py-0.5 px-2 font-bold text-[#22C55E] bg-[#22C55E]/10 border-[#22C55E]/30">
                    {liveLocation.source}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 font-mono text-[#FF6B35]">
                  <span className="font-bold animate-pulse">AWAITING REAL-TIME LOCATION TELEMETRY</span>
                  <span className="text-[#929CAB] text-[11px] hidden md:inline">
                    — Required for local disaster radius &amp; relief camps
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsOpen(true);
                  requestLiveGpsLocation();
                }}
                className="ios-button-glass py-1 px-3 text-[11px] font-mono font-bold flex items-center gap-1.5 text-[#38BDF8] hover:text-white"
              >
                <Crosshair className="w-3.5 h-3.5 text-[#FF6B35] animate-spin" style={{ animationDuration: '6s' }} />
                <span>{liveLocation ? 'Recalibrate GPS' : 'Enable Live Location'}</span>
              </button>

              <button
                onClick={() => {
                  setIsOpen(true);
                  setShowManualPicker(true);
                }}
                className="text-[#929CAB] hover:text-white text-[11px] font-mono underline decoration-dotted hidden sm:inline"
              >
                Change Sector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* APPLE IOS GLASS PROMPT MODAL */}
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fadeIn">
          <div className="ios-glass-card-elevated max-w-lg w-full p-6 sm:p-8 space-y-6 relative border border-white/[0.15] shadow-2xl overflow-hidden rounded-[28px]">
            {/* Top Atmospheric Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 bg-[#FF6B35]/20 blur-3xl pointer-events-none rounded-full" />
            <div className="absolute top-0 right-10 w-48 h-24 bg-[#38BDF8]/20 blur-2xl pointer-events-none rounded-full" />

            {/* Header / Dismiss */}
            <div className="flex items-start justify-between relative z-10">
              <div className="space-y-1">
                <div className="ios-capsule text-[#FF6B35] text-[11px] font-bold uppercase tracking-wider mb-1">
                  <Radio className="w-3.5 h-3.5 text-[#FF6B35] animate-pulse" />
                  <span>STATEWIDE REAL-TIME TELEMETRY</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
                  Real-Time Disaster Location
                </h3>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.15] border border-white/[0.08] flex items-center justify-center text-[#929CAB] hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Radar Scanning Visual Reticle */}
            <div className="relative flex flex-col items-center justify-center py-6 px-4 rounded-[20px] bg-[#07090D]/80 border border-white/[0.06] overflow-hidden">
              <div className="relative w-28 h-28 flex items-center justify-center">
                {/* Concentric Radar Rings */}
                <span className="absolute inset-0 rounded-full border border-[#38BDF8]/20 animate-ping" style={{ animationDuration: '3s' }} />
                <span className="absolute inset-3 rounded-full border border-[#FF6B35]/30 animate-pulse" />
                <span className="absolute inset-7 rounded-full border border-white/10" />

                {/* Center Reticle Icon */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#FF6B35] to-[#F5A623] flex items-center justify-center shadow-lg shadow-[#FF6B35]/30 relative z-10">
                  <Navigation className="w-7 h-7 text-[#07090D] transform -rotate-45" />
                </div>
              </div>

              {/* Status Text */}
              <div className="text-center mt-4 space-y-1 z-10">
                <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#38BDF8] flex items-center justify-center gap-1.5">
                  {status === 'ACQUIRING_GPS' && <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#38BDF8]" />}
                  {status === 'LOCKED' && <CheckCircle2 className="w-3.5 h-3.5 text-[#22C55E]" />}
                  {status === 'DENIED' && <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444]" />}
                  <span>
                    {status === 'IDLE' && 'Awaiting Calibration'}
                    {status === 'AWAITING_PERMISSION' && 'Waiting for Browser Permission'}
                    {status === 'ACQUIRING_GPS' && 'Acquiring Satellite GPS Fix...'}
                    {status === 'RESOLVING' && 'Mapping to Grama Panchayat...'}
                    {status === 'LOCKED' && 'GPS Telemetry Active'}
                    {status === 'DENIED' && 'Permission Blocked'}
                    {status === 'ERROR' && 'Location Request Failed'}
                  </span>
                </div>
                <p className="text-xs text-[#929CAB] font-classic max-w-sm">
                  {statusMessage ||
                    'ResQMesh Kerala requires your exact coordinates to calculate flood/landslide danger radius and route you to verified relief shelters.'}
                </p>
              </div>

              {/* Current Coords Preview if Locked */}
              {liveLocation && (
                <div className="mt-4 w-full p-3 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-between text-xs font-mono">
                  <div className="space-y-0.5">
                    <div className="text-[#929CAB] text-[10px] uppercase font-bold">SECTOR JURISDICTION</div>
                    <div className="text-white font-extrabold text-sm">{liveLocation.sector.name}</div>
                    <div className="text-[#38BDF8] text-[11px]">
                      {liveLocation.sector.blockName} • {liveLocation.sector.districtName}
                    </div>
                  </div>
                  <div className="text-right space-y-0.5">
                    <div className="text-[#929CAB] text-[10px] uppercase font-bold">ACCURACY RADIUS</div>
                    <div className="text-[#22C55E] font-bold">±{Math.round(liveLocation.accuracy)} Meters</div>
                    <div className="text-[#6F7C93] text-[10px]">
                      {liveLocation.latitude.toFixed(4)}°N, {liveLocation.longitude.toFixed(4)}°E
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Actions Section */}
            <div className="space-y-3">
              {/* Primary High-Impact Button */}
              <button
                type="button"
                onClick={requestLiveGpsLocation}
                disabled={status === 'ACQUIRING_GPS'}
                className="w-full ios-button-primary py-4 px-6 text-sm font-extrabold flex items-center justify-center gap-2 shadow-2xl cursor-pointer"
              >
                <Compass className="w-4 h-4 text-[#07090D]" />
                <span>
                  {status === 'ACQUIRING_GPS' ? 'Acquiring Satellite Fix...' : '📍 Allow Real-Time Location Access'}
                </span>
              </button>

              {/* Secondary Options Grid */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={requestIpLocation}
                  className="ios-button-glass py-2.5 px-3 text-xs font-mono font-bold text-[#38BDF8] flex items-center justify-center gap-1.5"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>IP Geolocation</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowManualPicker(!showManualPicker)}
                  className="ios-button-glass py-2.5 px-3 text-xs font-mono font-bold text-[#F5F7FA] flex items-center justify-center gap-1.5"
                >
                  <Sliders className="w-3.5 h-3.5 text-[#F5A623]" />
                  <span>{showManualPicker ? 'Hide Manual Picker' : 'Select District'}</span>
                </button>
              </div>
            </div>

            {/* EXPANDABLE MANUAL KERALA SECTOR SELECTOR */}
            {showManualPicker && (
              <div className="pt-4 border-t border-white/[0.08] space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#929CAB] font-mono">
                    Manual Administrative Selection (All 14 Districts)
                  </span>
                  <span className="text-[11px] text-[#38BDF8] font-mono">941 Grama Panchayats</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-classic">
                  {/* District Dropdown */}
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-[#6F7C93] mb-1">District</label>
                    <select
                      value={selectedDistrict}
                      onChange={(e) => {
                        const d = e.target.value;
                        setSelectedDistrict(d);
                        const bList = getBlocksForDistrict(d);
                        if (bList.length > 0) {
                          setSelectedBlock(bList[0].name);
                          const gList = bList[0].gramaPanchayats;
                          if (gList.length > 0) setSelectedGrama(gList[0].name);
                        }
                      }}
                      className="w-full bg-[#151E29] border border-white/[0.1] rounded-xl px-2.5 py-2 text-white font-medium focus:outline-none focus:border-[#FF6B35]"
                    >
                      {districts.map((d) => (
                        <option key={d.id} value={d.name}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Block Dropdown */}
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-[#6F7C93] mb-1">Block Panchayat</label>
                    <select
                      value={selectedBlock}
                      onChange={(e) => {
                        const b = e.target.value;
                        setSelectedBlock(b);
                        const gList = getGramasForBlock(selectedDistrict, b);
                        if (gList.length > 0) setSelectedGrama(gList[0].name);
                      }}
                      className="w-full bg-[#151E29] border border-white/[0.1] rounded-xl px-2.5 py-2 text-white font-medium focus:outline-none focus:border-[#FF6B35]"
                    >
                      {currentBlocks.map((b) => (
                        <option key={b.id} value={b.name}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Grama Dropdown */}
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-[#6F7C93] mb-1">Grama Panchayat</label>
                    <select
                      value={selectedGrama}
                      onChange={(e) => setSelectedGrama(e.target.value)}
                      className="w-full bg-[#151E29] border border-white/[0.1] rounded-xl px-2.5 py-2 text-white font-medium focus:outline-none focus:border-[#FF6B35]"
                    >
                      {currentGramas.map((g) => (
                        <option key={g.id} value={g.name}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleManualCommit}
                  className="w-full py-2.5 rounded-xl bg-[#38BDF8]/10 hover:bg-[#38BDF8]/20 border border-[#38BDF8]/30 text-[#38BDF8] font-bold font-mono text-xs transition flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Set Manual Location to {selectedGrama}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
