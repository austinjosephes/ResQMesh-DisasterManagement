'use client';

import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  MapPin,
  LifeBuoy,
  Users,
  Radio,
  Layers,
  HeartPulse,
  Info,
  Maximize2,
  Navigation,
  Compass,
  AlertTriangle,
  CheckCircle2,
  Phone,
  Clock,
} from 'lucide-react';
import { KERALA_DISTRICTS, haversineDistanceKm } from '@/lib/geospatial';

export interface MapHazardZone {
  id: string;
  district: string;
  hazardType: string;
  severity: 'EMERGENCY' | 'WARNING' | 'WATCH' | 'ADVISORY';
  headline: string;
  source: string;
  polygon: [number, number][]; // [lng, lat]
}

export interface MapSosIncident {
  id: string;
  trackingNumber: string;
  category: string;
  priorityCategory: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW' | 'NEEDS_VERIFICATION';
  priorityScore: number;
  peopleCount: number;
  district: string;
  latitude: number;
  longitude: number;
  address: string;
  description: string;
  status: string;
  hasInjuries: boolean;
  assignedTeamName?: string | null;
}

export interface MapHousehold {
  id: string;
  district: string;
  latitude: number;
  longitude: number;
  householdSize: number;
  requiresEvacuationAssist: boolean;
  isExposed: boolean;
  address: string;
}

export interface MapRescueTeam {
  id: string;
  name: string;
  agency: string;
  baseDistrict: string;
  captainName: string;
  status: string;
  latitude: number;
  longitude: number;
  boatCapacity: number;
  contactPhone: string;
}

export interface MapShelter {
  id: string;
  name: string;
  district: string;
  totalCapacity: number;
  currentOccupacy: number;
  latitude: number;
  longitude: number;
  inChargeName: string;
  inChargePhone: string;
  status: string;
  foodStockDays: number;
}

interface KeralaTacticalMapProps {
  hazards?: MapHazardZone[];
  incidents?: MapSosIncident[];
  households?: MapHousehold[];
  rescueTeams?: MapRescueTeam[];
  shelters?: MapShelter[];
  selectedDistrict?: string;
  onDistrictChange?: (district: string) => void;
  height?: string;
  interactive?: boolean;
  userLocation?: {
    latitude: number;
    longitude: number;
    label?: string;
    accuracy?: number;
    source?: string;
  } | null;
}

export function KeralaTacticalMap({
  hazards = [],
  incidents = [],
  households = [],
  rescueTeams = [],
  shelters = [],
  selectedDistrict = 'ALL',
  onDistrictChange,
  height = '620px',
  interactive = true,
  userLocation,
}: KeralaTacticalMapProps) {
  // Layer visibility toggles
  const [showHazards, setShowHazards] = useState(true);
  const [showIncidents, setShowIncidents] = useState(true);
  const [showHouseholds, setShowHouseholds] = useState(true);
  const [showTeams, setShowTeams] = useState(true);
  const [showShelters, setShowShelters] = useState(true);

  // Inspector selection
  const [selectedItem, setSelectedItem] = useState<{
    type: 'HAZARD' | 'INCIDENT' | 'HOUSEHOLD' | 'TEAM' | 'SHELTER' | 'DISTRICT';
    data: any;
  } | null>(null);

  // Kerala coordinate bounds:
  // Longitude: 74.8 (West) to 77.4 (East) -> width: ~2.6 deg
  // Latitude: 8.2 (South) to 12.8 (North) -> height: ~4.6 deg
  const bounds = {
    minLng: 74.8,
    maxLng: 77.4,
    minLat: 8.2,
    maxLat: 12.8,
  };

  // Convert GPS (lng, lat) to SVG coordinate percentages
  const toSvgCoords = (lng: number, lat: number) => {
    const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
    // Invert Y because SVG origin is top-left
    const y = ((bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat)) * 100;
    return { x, y };
  };

  // Filter items by district if specified
  const filteredIncidents = useMemo(() => {
    if (selectedDistrict === 'ALL') return incidents;
    return incidents.filter((i) => i.district === selectedDistrict);
  }, [incidents, selectedDistrict]);

  const filteredHouseholds = useMemo(() => {
    if (selectedDistrict === 'ALL') return households;
    return households.filter((h) => h.district === selectedDistrict);
  }, [households, selectedDistrict]);

  const filteredHazards = useMemo(() => {
    if (selectedDistrict === 'ALL') return hazards;
    return hazards.filter((h) => h.district === selectedDistrict);
  }, [hazards, selectedDistrict]);

  // Convert polygon coordinates to SVG path string
  const polygonToPath = (polygon: [number, number][]) => {
    if (!polygon || polygon.length === 0) return '';
    return (
      polygon
        .map((pt, idx) => {
          const { x, y } = toSvgCoords(pt[0], pt[1]);
          return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
        })
        .join(' ') + ' Z'
    );
  };

  return (
    <div
      className="relative w-full rounded-xl bg-surface-1 border border-surface-3 overflow-hidden select-none shadow-2xl flex flex-col"
      style={{ height }}
    >
      {/* Top Map Header & Controls Strip */}
      <div className="absolute top-3 left-3 right-3 z-30 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* District Selector & Status */}
        <div className="flex items-center gap-2 bg-surface-2/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-surface-3 shadow-lg pointer-events-auto">
          <Compass className="w-4 h-4 text-primary animate-pulse" />
          <span className="text-xs font-mono font-semibold text-text-primary">KERALA GEOSPATIAL RADAR</span>
          <span className="text-surface-3">|</span>
          <select
            value={selectedDistrict}
            onChange={(e) => onDistrictChange && onDistrictChange(e.target.value)}
            className="bg-surface-3 text-text-primary text-xs rounded px-2 py-1 font-sans border-0 focus:ring-1 focus:ring-primary"
          >
            <option value="ALL">All 14 Kerala Districts</option>
            {KERALA_DISTRICTS.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name} ({d.nameMl})
              </option>
            ))}
          </select>
        </div>

        {/* Tactical Layer Toggles */}
        {interactive && (
          <div className="flex items-center gap-1.5 bg-surface-2/90 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-surface-3 shadow-lg pointer-events-auto text-xs">
            <button
              onClick={() => setShowHazards(!showHazards)}
              className={`px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px] transition ${
                showHazards
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'text-text-muted hover:text-text-primary'
              }`}
              title="Toggle Official Hazard Warning Polygons"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Hazards</span>
            </button>

            <button
              onClick={() => setShowIncidents(!showIncidents)}
              className={`px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px] transition ${
                showIncidents
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'text-text-muted hover:text-text-primary'
              }`}
              title="Toggle Active SOS Incidents"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>SOS ({filteredIncidents.length})</span>
            </button>

            <button
              onClick={() => setShowHouseholds(!showHouseholds)}
              className={`px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px] transition ${
                showHouseholds
                  ? 'bg-primary/20 text-primary border border-primary/30'
                  : 'text-text-muted hover:text-text-primary'
              }`}
              title="Toggle Registered Resident Households (Digital Twin)"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Twin ({filteredHouseholds.length})</span>
            </button>

            <button
              onClick={() => setShowTeams(!showTeams)}
              className={`px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px] transition ${
                showTeams
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'text-text-muted hover:text-text-primary'
              }`}
              title="Toggle Rescue Teams"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Teams</span>
            </button>

            <button
              onClick={() => setShowShelters(!showShelters)}
              className={`px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px] transition ${
                showShelters
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'text-text-muted hover:text-text-primary'
              }`}
              title="Toggle Relief Shelters"
            >
              <HeartPulse className="w-3.5 h-3.5" />
              <span>Shelters</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Interactive SVG Vector Viewport */}
      <div className="relative flex-1 w-full h-full overflow-hidden flex items-center justify-center p-2 bg-[#07090D]">
        {/* Subtle Background Tactical Radar Grid */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle, #38BDF8 1px, transparent 1px), linear-gradient(to right, #151E29 1px, transparent 1px), linear-gradient(to bottom, #151E29 1px, transparent 1px)`,
            backgroundSize: '24px 24px, 48px 48px, 48px 48px',
          }}
        />

        {/* SVG Tactical Projection */}
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full max-h-[95%] max-w-[95%] preserve-3d"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Pulsing Hazard Glow Filter */}
            <filter id="hazardGlowRed" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="hazardGlowAmber" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1.2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <pattern id="hazardDiagonal" width="4" height="4" patternUnits="userSpaceOnUse">
              <path d="M-1,1 l2,-2 M0,4 l4,-4 M3,5 l2,-2" stroke="#EF4444" strokeWidth="0.5" opacity="0.4" />
            </pattern>
          </defs>

          {/* Base Kerala Geographic Outline (Tactical Geo-Curvature) */}
          <g className="cursor-crosshair">
            {/* Arabian Sea Coastline Backdrop */}
            <path
              d="M 12 5 C 18 18, 25 35, 35 55 C 42 70, 55 85, 68 95"
              fill="none"
              stroke="#55D6E8"
              strokeWidth="0.8"
              strokeDasharray="2 2"
              opacity="0.3"
            />

            {/* Stylized Kerala 14 Districts Connected Mesh */}
            {KERALA_DISTRICTS.map((dist, idx) => {
              const { x, y } = toSvgCoords(dist.center.lng, dist.center.lat);
              const isSelected = selectedDistrict === dist.name;

              return (
                <g
                  key={dist.id}
                  className="transition-all duration-200"
                  onClick={() => setSelectedItem({ type: 'DISTRICT', data: dist })}
                >
                  {/* District Boundary Radial Halo */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 6 : 4}
                    fill={isSelected ? '#55D6E8' : '#172033'}
                    fillOpacity={isSelected ? 0.25 : 0.4}
                    stroke={isSelected ? '#55D6E8' : '#334155'}
                    strokeWidth={isSelected ? 0.8 : 0.4}
                    className="hover:stroke-primary hover:fill-primary/20 cursor-pointer"
                  />

                  {/* District Node Pin */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 1.4 : 1.0}
                    fill={isSelected ? '#55D6E8' : '#94A3B8'}
                  />

                  {/* District Label */}
                  <text
                    x={x + 2}
                    y={y + 0.8}
                    fill={isSelected ? '#55D6E8' : '#64748B'}
                    fontSize={isSelected ? '2.4' : '2.0'}
                    fontWeight={isSelected ? 'bold' : 'normal'}
                    fontFamily="monospace"
                    className="pointer-events-none"
                  >
                    {dist.name}
                  </text>
                </g>
              );
            })}
          </g>

          {/* Layer 1: Official Hazard Warning Polygons */}
          {showHazards && (
            <g id="layer-hazards">
              {filteredHazards.map((hz) => {
                const pathStr = polygonToPath(hz.polygon);
                const isEmergency = hz.severity === 'EMERGENCY';
                const strokeColor = isEmergency ? '#EF4444' : '#F59E0B';
                const fillColor = isEmergency ? '#EF4444' : '#F59E0B';

                return (
                  <g
                    key={hz.id}
                    className="cursor-pointer group"
                    onClick={() => setSelectedItem({ type: 'HAZARD', data: hz })}
                  >
                    <path
                      d={pathStr}
                      fill={fillColor}
                      fillOpacity="0.25"
                      stroke={strokeColor}
                      strokeWidth="0.8"
                      strokeDasharray={isEmergency ? 'none' : '1.5 1'}
                      filter={isEmergency ? 'url(#hazardGlowRed)' : 'url(#hazardGlowAmber)'}
                      className="group-hover:fill-opacity-40 transition-all"
                    />
                    <path d={pathStr} fill="url(#hazardDiagonal)" />
                  </g>
                );
              })}
            </g>
          )}

          {/* Layer 2: Registered Resident Households (Digital Twin) */}
          {showHouseholds && (
            <g id="layer-households">
              {filteredHouseholds.map((hh) => {
                const { x, y } = toSvgCoords(hh.longitude, hh.latitude);
                const color = hh.isExposed ? '#EF4444' : '#10B981';

                return (
                  <g
                    key={hh.id}
                    className="cursor-pointer"
                    onClick={() => setSelectedItem({ type: 'HOUSEHOLD', data: hh })}
                  >
                    {hh.isExposed && (
                      <circle
                        cx={x}
                        cy={y}
                        r="2.2"
                        fill="#EF4444"
                        fillOpacity="0.3"
                        className="animate-ping"
                      />
                    )}
                    <circle
                      cx={x}
                      cy={y}
                      r={hh.requiresEvacuationAssist ? '1.2' : '0.9'}
                      fill={color}
                      stroke="#0B1020"
                      strokeWidth="0.3"
                      className="hover:scale-150 transition-transform"
                    />
                  </g>
                );
              })}
            </g>
          )}

          {/* Layer 3: Relief Shelters */}
          {showShelters && (
            <g id="layer-shelters">
              {shelters.map((s) => {
                const { x, y } = toSvgCoords(s.longitude, s.latitude);
                return (
                  <g
                    key={s.id}
                    className="cursor-pointer"
                    onClick={() => setSelectedItem({ type: 'SHELTER', data: s })}
                  >
                    <rect
                      x={x - 1.2}
                      y={y - 1.2}
                      width="2.4"
                      height="2.4"
                      rx="0.4"
                      fill="#10B981"
                      stroke="#0B1020"
                      strokeWidth="0.3"
                      className="hover:scale-125 transition-transform"
                    />
                    <text
                      x={x}
                      y={y + 0.7}
                      fontSize="1.6"
                      fontWeight="bold"
                      fill="#0B1020"
                      textAnchor="middle"
                      className="pointer-events-none"
                    >
                      +
                    </text>
                  </g>
                );
              })}
            </g>
          )}

          {/* Layer 4: Rescue Teams */}
          {showTeams && (
            <g id="layer-rescue-teams">
              {rescueTeams.map((team) => {
                const { x, y } = toSvgCoords(team.longitude, team.latitude);
                return (
                  <g
                    key={team.id}
                    className="cursor-pointer"
                    onClick={() => setSelectedItem({ type: 'TEAM', data: team })}
                  >
                    <polygon
                      points={`${x},${y - 1.8} ${x + 1.5},${y + 1.2} ${x - 1.5},${y + 1.2}`}
                      fill="#3B82F6"
                      stroke="#0B1020"
                      strokeWidth="0.3"
                      className="hover:scale-150 transition-transform"
                    />
                  </g>
                );
              })}
            </g>
          )}

          {/* Layer 5: Active SOS Emergency Incidents (Top Priority Layer) */}
          {showIncidents && (
            <g id="layer-incidents">
              {filteredIncidents.map((sos) => {
                const { x, y } = toSvgCoords(sos.longitude, sos.latitude);
                const isCritical = sos.priorityCategory === 'CRITICAL';
                const color = isCritical
                  ? '#EF4444'
                  : sos.priorityCategory === 'HIGH'
                  ? '#F59E0B'
                  : '#3B82F6';

                return (
                  <g
                    key={sos.id}
                    className="cursor-pointer"
                    onClick={() => setSelectedItem({ type: 'INCIDENT', data: sos })}
                  >
                    {/* Pulsing Danger Ping */}
                    <circle
                      cx={x}
                      cy={y}
                      r="3.5"
                      fill={color}
                      fillOpacity="0.4"
                      className="animate-ping"
                    />
                    {/* Core SOS Pin Marker */}
                    <circle
                      cx={x}
                      cy={y}
                      r="1.6"
                      fill={color}
                      stroke="#FFFFFF"
                      strokeWidth="0.4"
                      className="hover:scale-150 transition-transform"
                    />
                    <text
                      x={x}
                      y={y + 0.6}
                      fontSize="1.3"
                      fontWeight="bold"
                      fill="#FFFFFF"
                      textAnchor="middle"
                      className="pointer-events-none font-mono"
                    >
                      !
                    </text>
                  </g>
                );
              })}
            </g>
          )}

          {/* Layer 6: Real-Time Live User Device GPS Position (Pulsing Reticle) */}
          {userLocation && (
            <g
              id="layer-user-gps"
              className="cursor-pointer"
              onClick={() =>
                setSelectedItem({
                  type: 'USER_GPS' as any,
                  data: {
                    name: userLocation.label || 'Your Device Location',
                    latitude: userLocation.latitude,
                    longitude: userLocation.longitude,
                    accuracy: userLocation.accuracy || 10,
                    source: userLocation.source || 'GPS',
                  },
                })
              }
            >
              {(() => {
                const { x, y } = toSvgCoords(userLocation.longitude, userLocation.latitude);
                return (
                  <>
                    {/* Concentric Radar Ping Waves */}
                    <circle
                      cx={x}
                      cy={y}
                      r="4.5"
                      fill="none"
                      stroke="#38BDF8"
                      strokeWidth="0.5"
                      opacity="0.8"
                      className="animate-ping"
                      style={{ animationDuration: '2.5s' }}
                    />
                    <circle
                      cx={x}
                      cy={y}
                      r="2.8"
                      fill="#38BDF8"
                      fillOpacity="0.25"
                      stroke="#FF6B35"
                      strokeWidth="0.4"
                      className="animate-pulse"
                    />
                    {/* Core Point Marker */}
                    <circle
                      cx={x}
                      cy={y}
                      r="1.5"
                      fill="#38BDF8"
                      stroke="#FFFFFF"
                      strokeWidth="0.4"
                      className="hover:scale-150 transition-transform"
                    />
                    {/* Reticle Target Crosshairs */}
                    <line x1={x - 2.5} y1={y} x2={x + 2.5} y2={y} stroke="#38BDF8" strokeWidth="0.25" />
                    <line x1={x} y1={y - 2.5} x2={x} y2={y + 2.5} stroke="#38BDF8" strokeWidth="0.25" />
                    <text
                      x={x}
                      y={y - 2.2}
                      fontSize="1.1"
                      fontWeight="bold"
                      fill="#38BDF8"
                      textAnchor="middle"
                      className="font-mono pointer-events-none"
                      style={{ textShadow: '0 0 3px #000' }}
                    >
                      YOU ARE HERE
                    </text>
                  </>
                );
              })()}
            </g>
          )}
        </svg>

        {/* Tactical Legend Floating Widget */}
        <div className="absolute bottom-3 left-3 z-30 bg-surface-2/95 backdrop-blur-md p-2.5 rounded-lg border border-surface-3 shadow-xl max-w-xs text-[11px] font-mono space-y-1.5 hidden md:block">
          <div className="text-[10px] uppercase font-bold text-text-muted flex items-center justify-between border-b border-surface-3 pb-1">
            <span>Tactical Map Legend</span>
            <span className="text-primary font-mono">WGS84</span>
          </div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-text-secondary">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <span>Critical SOS</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>High / Mod SOS</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-red-500/40 border border-red-500 rounded-sm" />
              <span>Hazard Polygon</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Safe Household</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-blue-500 rounded-sm" />
              <span>Rescue Team</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-600 rounded-sm flex items-center justify-center text-[8px] text-white font-bold">
                +
              </span>
              <span>Relief Shelter</span>
            </div>
            {userLocation && (
              <div className="flex items-center gap-1.5 col-span-2 pt-1 border-t border-surface-3">
                <span className="w-2.5 h-2.5 rounded-full bg-[#38BDF8] animate-ping" />
                <span className="text-[#38BDF8] font-bold">
                  Live Position: {userLocation.label || 'Active GPS'}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Selected Item Inspector Modal Drawer */}
        {selectedItem && (
          <div className="absolute bottom-3 right-3 z-40 bg-surface-2 border border-surface-3 shadow-2xl rounded-xl p-4 max-w-sm w-full animate-in slide-in-from-bottom-3">
            <div className="flex items-start justify-between gap-2 border-b border-surface-3 pb-2.5 mb-2.5">
              <div className="flex items-center gap-2">
                {selectedItem.type === 'HAZARD' && <ShieldAlert className="w-5 h-5 text-red-400" />}
                {selectedItem.type === 'INCIDENT' && <AlertTriangle className="w-5 h-5 text-red-400" />}
                {selectedItem.type === 'HOUSEHOLD' && <Users className="w-5 h-5 text-primary" />}
                {selectedItem.type === 'TEAM' && <Radio className="w-5 h-5 text-blue-400" />}
                {selectedItem.type === 'SHELTER' && <HeartPulse className="w-5 h-5 text-emerald-400" />}
                {selectedItem.type === 'DISTRICT' && <Compass className="w-5 h-5 text-primary" />}
                {selectedItem.type === ('USER_GPS' as any) && <Navigation className="w-5 h-5 text-[#38BDF8]" />}
                <div>
                  <h4 className="text-xs font-bold font-mono text-text-primary uppercase">
                    {selectedItem.type === ('USER_GPS' as any)
                      ? 'LIVE GPS POSITION'
                      : `${selectedItem.type}: ${
                          selectedItem.type === 'DISTRICT'
                            ? selectedItem.data.name
                            : selectedItem.data.id || selectedItem.data.code
                        }`}
                  </h4>
                  <span className="text-[10px] text-text-muted">
                    {selectedItem.type === ('USER_GPS' as any)
                      ? selectedItem.data.name
                      : selectedItem.data.district || selectedItem.data.name}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="text-text-muted hover:text-text-primary p-1 rounded"
              >
                ✕
              </button>
            </div>

            {/* Inspector Details by Type */}
            {selectedItem.type === ('USER_GPS' as any) && (
              <div className="space-y-2 text-xs font-mono">
                <div className="p-2.5 rounded-lg bg-[#38BDF8]/10 border border-[#38BDF8]/30 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[#929CAB]">Status:</span>
                    <span className="text-[#22C55E] font-bold">LOCKED &amp; VERIFIED</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#929CAB]">Source:</span>
                    <span className="text-[#38BDF8] font-bold">{selectedItem.data.source}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#929CAB]">Accuracy:</span>
                    <span className="text-white font-bold">±{Math.round(selectedItem.data.accuracy)} Meters</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Latitude:</span>
                  <span className="font-bold text-text-primary">{selectedItem.data.latitude?.toFixed(6)}° N</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Longitude:</span>
                  <span className="font-bold text-text-primary">{selectedItem.data.longitude?.toFixed(6)}° E</span>
                </div>
              </div>
            )}
            {selectedItem.type === 'INCIDENT' && (
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Tracking No:</span>
                  <span className="font-mono font-bold text-text-primary">
                    {selectedItem.data.trackingNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Priority:</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-500/20 text-red-400">
                    {selectedItem.data.priorityCategory} (Score: {selectedItem.data.priorityScore}/100)
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">People Trapped:</span>
                  <span className="font-bold text-text-primary">{selectedItem.data.peopleCount} Persons</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Status:</span>
                  <span className="font-mono text-amber-400">{selectedItem.data.status}</span>
                </div>
                <p className="text-text-secondary text-[11px] bg-surface-3/50 p-2 rounded">
                  {selectedItem.data.description}
                </p>
                {selectedItem.data.assignedTeamName && (
                  <div className="text-[11px] text-primary font-mono border-t border-surface-3 pt-1.5">
                    Assigned: {selectedItem.data.assignedTeamName}
                  </div>
                )}
              </div>
            )}

            {selectedItem.type === 'HAZARD' && (
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Severity:</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-500/20 text-red-400">
                    {selectedItem.data.severity}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Authority:</span>
                  <span className="text-text-primary font-semibold">{selectedItem.data.source}</span>
                </div>
                <p className="text-text-secondary text-[11px] leading-relaxed">
                  {selectedItem.data.headline}
                </p>
              </div>
            )}

            {selectedItem.type === 'HOUSEHOLD' && (
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Exposure Status:</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      selectedItem.data.isExposed
                        ? 'bg-red-500/20 text-red-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {selectedItem.data.isExposed ? 'INSIDE HAZARD ZONE' : 'OUTSIDE HAZARD ZONE'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Household Size:</span>
                  <span className="font-bold text-text-primary">
                    {selectedItem.data.householdSize} Residents
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Evacuation Support:</span>
                  <span className="text-amber-400 font-semibold">
                    {selectedItem.data.requiresEvacuationAssist ? 'REQUIRED (FLAGGED)' : 'Standard'}
                  </span>
                </div>
                <p className="text-text-muted text-[11px] truncate">{selectedItem.data.address}</p>
              </div>
            )}

            {selectedItem.type === 'SHELTER' && (
              <div className="space-y-2 text-xs">
                <h5 className="font-bold text-text-primary">{selectedItem.data.name}</h5>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Capacity:</span>
                  <span className="font-bold text-emerald-400">
                    {selectedItem.data.currentOccupacy} / {selectedItem.data.totalCapacity} (
                    {Math.round((selectedItem.data.currentOccupacy / selectedItem.data.totalCapacity) * 100)}%
                    Occupied)
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Food Supplies:</span>
                  <span className="text-text-primary">{selectedItem.data.foodStockDays} Days Stock</span>
                </div>
                <div className="flex items-center justify-between text-text-secondary">
                  <span>Officer: {selectedItem.data.inChargeName}</span>
                  <span className="font-mono text-primary">{selectedItem.data.inChargePhone}</span>
                </div>
              </div>
            )}

            {selectedItem.type === 'TEAM' && (
              <div className="space-y-2 text-xs">
                <h5 className="font-bold text-text-primary">{selectedItem.data.name}</h5>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Agency:</span>
                  <span className="font-mono text-blue-400 font-bold">{selectedItem.data.agency}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Status:</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-400">
                    {selectedItem.data.status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">Rescue Boats:</span>
                  <span className="font-bold text-text-primary">
                    {selectedItem.data.boatCapacity} Crafts Ready
                  </span>
                </div>
                <div className="flex items-center justify-between text-text-secondary">
                  <span>Leader: {selectedItem.data.captainName}</span>
                  <span className="font-mono text-primary">{selectedItem.data.contactPhone}</span>
                </div>
              </div>
            )}

            {selectedItem.type === 'DISTRICT' && (
              <div className="space-y-2 text-xs">
                <h5 className="font-bold text-text-primary">
                  {selectedItem.data.name} ({selectedItem.data.nameMl})
                </h5>
                <p className="text-[11px] text-text-secondary">
                  <strong>HQ:</strong> {selectedItem.data.headquarters}
                </p>
                <p className="text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded">
                  <strong>Vulnerability Profile:</strong> {selectedItem.data.vulnerabilityFocus}
                </p>
                <div className="text-[11px] text-text-muted">
                  <strong>Key Local Bodies:</strong> {selectedItem.data.localBodies.join(', ')}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
