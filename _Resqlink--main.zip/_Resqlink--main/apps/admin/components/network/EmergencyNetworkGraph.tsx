'use client';

import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  ShieldAlert,
  Sliders,
  Layers,
  CheckCircle2,
  Radio,
  ArrowRight,
  Lock,
  Smartphone,
  Navigation,
  Activity,
  Clock,
  Send,
  Zap,
} from 'lucide-react';

interface NetworkNode {
  id: string;
  stage: number;
  label: string;
  sublabel: string;
  icon: any;
  status: 'ACTIVE' | 'PENDING' | 'SECURED';
  accentColor: string;
  details: {
    title: string;
    description: string;
    telemetry: Record<string, string>;
  };
}

export function EmergencyNetworkGraph({ className = '' }: { className?: string }) {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-seoc');
  const [pulsePosition, setPulsePosition] = useState(0);

  const nodes: NetworkNode[] = [
    {
      id: 'node-resident',
      stage: 1,
      label: 'Resident Node',
      sublabel: 'Citizen in Distress (GPS & Sector)',
      icon: Smartphone,
      status: 'ACTIVE',
      accentColor: '#38BDF8', // Cyan
      details: {
        title: 'Resident Emergency Beacon Intake',
        description:
          'Citizen activates SOS via Resident Safety Portal or offline SMS relay. Exact GPS coordinates (±8m) or 3-mode calibrated Grama Panchayat sector are securely captured.',
        telemetry: {
          Sector: 'Meppadi Grama, Wayanad',
          Coordinates: '11.5542° N, 76.1284° E',
          'Vulnerability Check': 'Elderly (2) • Trapped on Roof',
          'Intake Channel': 'Direct Web PWA / Local Cellular SMS',
        },
      },
    },
    {
      id: 'node-sos',
      stage: 2,
      label: 'SOS Request Node',
      sublabel: 'Cryptographic Signature & DLT SMS',
      icon: ShieldAlert,
      status: 'SECURED',
      accentColor: '#EF4444', // Emergency Red
      details: {
        title: 'Cryptographic Signature & Triage Tagging',
        description:
          'Distress payload is signed with JOSE ES256 keypair for non-repudiation. Auto-categorized by urgency (P1 Critical: Trapped/Medical, P2 High: Evacuation Needed).',
        telemetry: {
          'Signature Standard': 'JOSE ES256 Digital Twin',
          'Priority Tier': 'P1 — LIFE THREATENING (Score 94/100)',
          'DLT Header': 'VK-KSDMA Carrier SMS Pipeline',
          'Anti-Spoofing': 'Validated Hardware Root-of-Trust',
        },
      },
    },
    {
      id: 'node-seoc',
      stage: 3,
      label: 'Authority / SEOC',
      sublabel: 'State Disaster Command Centre',
      icon: Sliders,
      status: 'ACTIVE',
      accentColor: '#FF6B35', // Aerospace Orange
      details: {
        title: 'State Emergency Operations Centre (SEOC) Engine',
        description:
          'Real-time ingestion engine plots incident onto Kerala Tactical Map. Calculates Point-in-Polygon hazard zone overlap and automatically assigns nearest unflooded relief shelter.',
        telemetry: {
          Clearance: 'SEOC Duty Commander Level-1',
          'Spatial Match': 'Within Red Flood Polygon #KZ-44',
          'Allocated Shelter': 'Meppadi Govt Higher Secondary School',
          'AI Triage Latency': '< 140ms from Beacon Reception',
        },
      },
    },
    {
      id: 'node-rescue',
      stage: 4,
      label: 'Rescue Battalion',
      sublabel: 'NDRF / Fire & Rescue / Coastal',
      icon: Layers,
      status: 'ACTIVE',
      accentColor: '#F5A623', // Warning Amber
      details: {
        title: 'Tactical Rescue Battalion Dispatch',
        description:
          'Order broadcast to field rescue teams via Field Rescue Mission Console. Teams receive direct turn-by-turn evacuation coordinates and resident casualty count.',
        telemetry: {
          'Dispatched Unit': 'NDRF 04 Battalion Alpha Team',
          'Rescue Assets': '2 Zodiac Boats • Medical Stretcher Team',
          'Current Status': 'EN_ROUTE (~9 min ETA)',
          'Field Radio': 'VHF Channel 16 / Secure Mesh Link',
        },
      },
    },
    {
      id: 'node-response',
      stage: 5,
      label: 'Response Status',
      sublabel: '2-Way Delivery Handshake & Safety',
      icon: CheckCircle2,
      status: 'SECURED',
      accentColor: '#22C55E', // Success Green
      details: {
        title: 'Two-Way Carrier Delivery Handshake',
        description:
          'Bi-directional confirmation: citizen acknowledges SMS instruction ("✓ Confirm Received"), and rescue unit confirms extraction. Incident transitions to RESOLVED on chain.',
        telemetry: {
          'Citizen Handshake': 'Acknowledged at 14:48:12 IST',
          'Rescue Outcome': 'SAFE EVACUATION COMPLETED',
          'Shelter Admitted': 'Manifest ID #KSDMA-SH-902',
          'Audit Log': 'Immutable Audit Block #0941-KSDMA',
        },
      },
    },
  ];

  // Animate pulse position across the nodes
  useEffect(() => {
    const interval = setInterval(() => {
      setPulsePosition((prev) => (prev + 1) % 100);
    }, 45);
    return () => clearInterval(interval);
  }, []);

  const activeNode = nodes.find((n) => n.id === selectedNodeId) || nodes[2];

  return (
    <div className={`space-y-6 ${className} font-classic`}>
      {/* Visual Network Architecture Bar (Apple iOS Squircle Glass Card) */}
      <div className="ios-glass-card-elevated p-7 sm:p-8 relative overflow-hidden">
        {/* Subtle Ambient Background Accent */}
        <div
          className="absolute -top-24 -right-24 w-80 h-80 rounded-full blur-3xl opacity-15 pointer-events-none transition-colors duration-500"
          style={{ backgroundColor: activeNode.accentColor }}
        />

        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-6 border-b border-white/[0.08]">
          <div>
            <div className="ios-capsule text-[#FF6B35] font-extrabold text-[10px] uppercase tracking-widest mb-1.5">
              <Zap className="w-3.5 h-3.5 text-[#FF6B35]" />
              <span>EMERGENCY RESPONSE NETWORK VISUALIZATION</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
              End-to-End Disaster Telemetry &amp; Response Chain
            </h3>
            <p className="text-xs text-[#929CAB] mt-0.5 font-classic">
              Live progression of an emergency distress signal from resident activation through SEOC command triage to field rescue confirmation.
            </p>
          </div>

          <div className="ios-capsule bg-[#22C55E]/10 border-[#22C55E]/25 text-[#22C55E]">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-ping" />
            <span className="text-[11px] font-mono font-extrabold">
              PIPELINE INTEGRITY: 100% SECURE
            </span>
          </div>
        </div>

        {/* 5-Node Interactive Pathway */}
        <div className="py-8 relative">
          {/* Connecting Conduit Line (Desktop) */}
          <div className="hidden lg:block absolute top-[52px] left-[5%] right-[5%] h-1 bg-white/[0.08] rounded-full overflow-hidden">
            <div
              className="h-full w-28 bg-gradient-to-r from-transparent via-[#FF6B35] to-transparent transition-all duration-75"
              style={{
                marginLeft: `${pulsePosition}%`,
                filter: 'drop-shadow(0 0 10px #FF6B35)',
              }}
            />
          </div>

          {/* Nodes Grid (Apple Squircles) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 relative z-10">
            {nodes.map((node, index) => {
              const Icon = node.icon;
              const isSelected = node.id === selectedNodeId;

              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`text-left p-5 rounded-[22px] border transition-all duration-300 relative flex flex-col justify-between cursor-pointer active:scale-[0.98] ${
                    isSelected
                      ? 'bg-white/[0.12] border-white/[0.3] shadow-2xl scale-[1.03] backdrop-blur-2xl'
                      : 'bg-white/[0.04] border-white/[0.08] hover:bg-white/[0.08] hover:border-white/[0.18]'
                  }`}
                  style={{
                    boxShadow: isSelected
                      ? `inset 0 1px 1px 0 rgba(255,255,255,0.25), 0 16px 36px -8px ${node.accentColor}50`
                      : 'inset 0 1px 0.5px 0 rgba(255,255,255,0.1)',
                  }}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div
                        className="w-11 h-11 rounded-[16px] flex items-center justify-center border transition-all shadow-inner"
                        style={{
                          backgroundColor: `${node.accentColor}20`,
                          borderColor: `${node.accentColor}55`,
                          color: node.accentColor,
                        }}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-mono text-[#929CAB] font-extrabold">
                        0{node.stage}
                      </span>
                    </div>

                    <div>
                      <div className="text-sm font-extrabold text-[#F5F7FA] font-classic tracking-tight flex items-center gap-1.5">
                        <span>{node.label}</span>
                      </div>
                      <div className="text-xs text-[#929CAB] leading-snug mt-1 font-medium">
                        {node.sublabel}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono">
                    <span
                      className="font-extrabold flex items-center gap-1.5"
                      style={{ color: node.accentColor }}
                    >
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: node.accentColor }}
                      />
                      {node.status}
                    </span>
                    <span className="text-[#929CAB] font-bold hover:text-white">Inspect →</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Node Detailed Telemetry Drawer (Apple Glass Box) */}
        <div className="ios-glass-card p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div
                className="w-3.5 h-3.5 rounded-full"
                style={{ backgroundColor: activeNode.accentColor }}
              />
              <h4 className="text-base font-extrabold text-[#F5F7FA] font-classic">
                {activeNode.details.title}
              </h4>
            </div>
            <span className="ios-capsule text-[11px] font-mono font-bold text-[#929CAB]">
              STAGE {activeNode.stage} OF 5 IN ACTIVE RESILIENCE PIPELINE
            </span>
          </div>

          <p className="text-xs sm:text-sm text-[#929CAB] leading-relaxed font-classic">
            {activeNode.details.description}
          </p>

          {/* Telemetry Key-Value Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {Object.entries(activeNode.details.telemetry).map(([key, val]) => (
              <div
                key={key}
                className="p-3.5 rounded-[16px] bg-white/[0.05] border border-white/[0.08] space-y-1 font-mono shadow-inner"
              >
                <div className="text-[10px] font-bold uppercase text-[#6F7C93] tracking-wider">{key}</div>
                <div className="text-xs font-bold text-[#F5F7FA] truncate" title={val}>
                  {val}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
