'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useConnectivity } from './ConnectivityContext';
import { useI18n } from '@/lib/i18n';
import {
  ShieldAlert,
  MapPin,
  Radio,
  Sliders,
  BookOpen,
  Wifi,
  WifiOff,
  User,
  LogOut,
  ChevronDown,
  Globe,
  LifeBuoy,
  FileCheck2,
  Menu,
  X,
  HeartPulse,
  Bell,
  Layers,
  Activity,
  Users,
  Compass,
  CloudRain,
} from 'lucide-react';

export function AppHeader() {
  const pathname = usePathname();
  const { setSimulatedOffline, isEffectiveOffline } = useConnectivity();
  const { language, setLanguage, t } = useI18n();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [localProfile, setLocalProfile] = useState<{ name: string; email: string; phone: string } | null>(null);
  const [showResidentMenu, setShowResidentMenu] = useState(false);
  const [showAdminMenu, setShowAdminMenu] = useState(false);
  const [showAccountMenu, setShowAccountMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedAdmin = localStorage.getItem('resqlink_admin_clearance_token');
      setIsAdminUnlocked(storedAdmin === 'SEOC-KERALA-2026-HQ');

      const storedResident = localStorage.getItem('resqlink_resident_profile');
      if (storedResident) {
        try {
          const parsed = JSON.parse(storedResident);
          if (parsed && parsed.name) setLocalProfile(parsed);
        } catch (e) {}
      }
    }
  }, [pathname]);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.authenticated) {
          setCurrentUser(data.user);
        } else {
          setCurrentUser(null);
        }
      })
      .catch(() => {});
  }, [pathname]);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setCurrentUser(null);
    setShowAccountMenu(false);
    window.location.href = '/';
  };

  const residentLinks = [
    { label: t.nav.residentDashboard, href: '/resident/dashboard', icon: LifeBuoy },
    { label: t.nav.residentAlerts, href: '/resident/alerts', icon: Bell },
    { label: t.nav.residentRequestHelp, href: '/resident/request-help', icon: ShieldAlert, highlight: true },
    { label: t.nav.residentRequests, href: '/resident/requests', icon: Activity },
    { label: t.nav.residentLocations, href: '/resident/locations', icon: MapPin },
    { label: t.nav.residentProfile, href: '/resident/profile', icon: User },
    { label: t.nav.residentSettings, href: '/resident/settings', icon: Sliders },
  ];

  const adminLinks = [
    { label: 'Forecast Authority & Weather Ingest', href: '/admin/weather-ingest', icon: CloudRain, highlight: true },
    { label: t.nav.adminDashboard, href: '/admin/dashboard', icon: Sliders },
    { label: t.nav.adminLiveMap, href: '/admin/live-map', icon: Compass, highlight: true },
    { label: t.nav.adminResidents, href: '/admin/residents', icon: Users },
    { label: t.nav.adminAlerts, href: '/admin/alerts', icon: Bell },
    { label: t.nav.adminNotifications, href: '/admin/notifications', icon: Radio },
    { label: t.nav.adminIncidents, href: '/admin/incidents', icon: ShieldAlert },
    { label: t.nav.adminRescueTeams, href: '/admin/rescue-teams', icon: Layers },
    { label: t.nav.adminShelters, href: '/admin/shelters', icon: HeartPulse },
    { label: t.nav.adminAnalytics, href: '/admin/analytics', icon: Activity },
    { label: t.nav.adminAuditLogs, href: '/admin/audit-logs', icon: FileCheck2 },
  ];

  return (
    <header className="w-full bg-[#07090D]/80 backdrop-blur-3xl backdrop-saturate-[180%] border-b border-white/[0.12] sticky top-0 z-50 transition-all shadow-[inset_0_-1px_0_0_rgba(255,255,255,0.06),0_12px_32px_-10px_rgba(0,0,0,0.6)]">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3 font-classic">
        {/* Brand */}
        <Link href="/" className="flex items-center gap-2.5 group shrink-0">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-[#FF6B35]/25 via-[#101720] to-[#151E29] border border-[#FF6B35]/50 flex items-center justify-center text-[#FF6B35] group-hover:border-[#FF6B35] transition shadow-md shadow-[#FF6B35]/20 group-hover:scale-105">
            <ShieldAlert className="w-5 h-5 text-[#FF6B35]" />
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold tracking-tight text-[#F5F7FA] text-base flex items-center gap-1.5 font-headline">
              ResQMesh <span className="text-[#FF6B35] font-mono text-xs font-bold">KERALA</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#22C55E]/15 border border-[#22C55E]/30 text-[#22C55E] font-mono font-bold">
                DISASTER NETWORK
              </span>
            </span>
            <span className="text-[10px] text-[#929CAB] font-mono font-semibold tracking-wider">
              Intelligent Disaster Management &bull; SEOC 2026
            </span>
          </div>
        </Link>

        {/* Quick Access Top Bar Pills (Desktop iOS Capsules) */}
        <div className="hidden md:flex items-center gap-2">
          <Link
            href="/resident/dashboard"
            className={`px-4 py-2 rounded-full text-xs font-mono font-extrabold transition-all flex items-center gap-1.5 border ${
              pathname.startsWith('/resident')
                ? 'bg-[#FF6B35]/20 text-[#FF6B35] border-[#FF6B35]/60 shadow-lg shadow-[#FF6B35]/25 scale-[1.02]'
                : 'bg-white/[0.06] text-[#929CAB] border-white/[0.12] hover:text-[#F5F7FA] hover:border-[#FF6B35]/50 hover:bg-white/[0.1]'
            }`}
          >
            <LifeBuoy className="w-3.5 h-3.5 text-[#FF6B35]" />
            <span>Resident Safety Portal</span>
          </Link>

          <Link
            href="/admin/dashboard"
            className={`px-4 py-2 rounded-full text-xs font-mono font-extrabold transition-all flex items-center gap-1.5 border ${
              pathname.startsWith('/admin')
                ? 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/60 shadow-lg shadow-[#EF4444]/25 scale-[1.02]'
                : 'bg-white/[0.06] text-[#929CAB] border-white/[0.12] hover:text-[#F5F7FA] hover:border-[#EF4444]/40 hover:bg-white/[0.1]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-[#EF4444]" />
            <span>State Command Center</span>
          </Link>
        </div>

        {/* Navigation Items (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1.5">
          {/* Resident Portal Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowResidentMenu(!showResidentMenu);
                setShowAdminMenu(false);
              }}
              className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1 ${
                pathname.startsWith('/resident')
                  ? 'bg-surface-2 text-primary border border-surface-3'
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface-2/60'
              }`}
            >
              <LifeBuoy className="w-3.5 h-3.5 text-primary" />
              <span>{t.common.portal}</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>

            {showResidentMenu && (
              <div
                className="absolute left-0 mt-2 w-56 rounded-lg bg-surface-2 border border-surface-3 shadow-2xl p-1.5 z-50 animate-in fade-in slide-in-from-top-1"
                onMouseLeave={() => setShowResidentMenu(false)}
              >
                {residentLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setShowResidentMenu(false)}
                      className={`flex items-center gap-2.5 px-3 py-2 rounded-md text-xs transition ${
                        item.highlight
                          ? 'bg-red-500/10 text-red-400 font-semibold hover:bg-red-500/20'
                          : pathname === item.href
                          ? 'bg-surface-3 text-primary'
                          : 'text-text-secondary hover:text-text-primary hover:bg-surface-3/50'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          {/* Rescue Operator */}
          <Link
            href="/rescue/dashboard"
            className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 ${
              pathname.startsWith('/rescue')
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                : 'text-text-secondary hover:text-text-primary hover:bg-surface-2/60'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.common.responderPortal}</span>
          </Link>

          {/* Admin Command Center Dropdown (Locked & Visible Only to Cleared SEOC Officers) */}
          {isAdminUnlocked && (
            <div className="relative">
              <button
                onClick={() => {
                  setShowAdminMenu(!showAdminMenu);
                  setShowResidentMenu(false);
                }}
                className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1 ${
                  pathname.startsWith('/admin')
                    ? 'bg-surface-2 text-primary border border-surface-3'
                    : 'text-text-secondary hover:text-text-primary hover:bg-surface-2/60'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-primary" />
                <span>{t.common.commandAdmin}</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>

              {showAdminMenu && (
                <div
                  className="absolute right-0 mt-2 w-64 rounded-lg bg-surface-2 border border-surface-3 shadow-2xl p-1.5 z-50 animate-in fade-in slide-in-from-top-1"
                  onMouseLeave={() => setShowAdminMenu(false)}
                >
                  <div className="px-3 py-1.5 text-[10px] uppercase font-mono text-text-muted border-b border-surface-3 mb-1">
                    Disaster Command Operations
                  </div>
                  {adminLinks.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={() => setShowAdminMenu(false)}
                        className={`flex items-center gap-2.5 px-3 py-2 rounded-md text-xs transition ${
                          item.highlight
                            ? 'bg-primary/10 text-primary font-semibold hover:bg-primary/20'
                            : pathname === item.href
                            ? 'bg-surface-3 text-primary'
                            : 'text-text-secondary hover:text-text-primary hover:bg-surface-3/50'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        <span>{item.label}</span>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </nav>

        {/* Action Controls & User Area */}
        <div className="flex items-center gap-2">
          {/* Network-Loss Survival Mode Toggle */}
          <button
            onClick={() => setSimulatedOffline(!isEffectiveOffline)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-mono transition border ${
              isEffectiveOffline
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 shadow-sm'
                : 'bg-surface-2 text-status-valid border-status-valid/30 hover:border-status-valid/60'
            }`}
            title="Toggle Offline Survival Mode Simulation"
          >
            {isEffectiveOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Survival Mode</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-status-valid" />
                <span className="hidden sm:inline">Live Network</span>
              </>
            )}
          </button>

          {/* User Account / Identity Display */}
          {currentUser || localProfile ? (
            <div className="relative">
              <Link
                href="/resident/dashboard"
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.08] border border-white/[0.14] hover:border-[#FF6B35]/60 hover:bg-white/[0.12] transition shadow-md"
              >
                <div className="w-6 h-6 rounded-full bg-[#FF6B35]/25 border border-[#FF6B35]/50 text-[#FF6B35] flex items-center justify-center font-bold text-xs">
                  {(currentUser?.name || localProfile?.name)?.[0]?.toUpperCase() || 'U'}
                </div>
                <span className="text-[#F5F7FA] font-bold text-xs max-w-[120px] truncate">
                  {currentUser?.name || localProfile?.name}
                </span>
                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-full bg-[#22C55E]/15 text-[#22C55E] font-extrabold border border-[#22C55E]/30">
                  {currentUser?.role || 'CITIZEN'}
                </span>
              </Link>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <Link
                href="/resident/dashboard"
                className="ios-button-primary px-3.5 py-1.5 text-xs font-bold shadow-md cursor-pointer"
              >
                <span>Register Identity</span>
              </Link>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-md bg-surface-2 border border-surface-3 text-text-secondary hover:text-text-primary"
            aria-label="Toggle Mobile Menu"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-surface-1 border-b border-surface-3 px-4 py-4 space-y-4 animate-in slide-in-from-top-2">
          <div className="space-y-1">
            <p className="text-[11px] font-mono text-text-muted uppercase px-2">Navigation</p>
            <Link
              href="/"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-2.5 py-2 rounded-md text-sm text-text-secondary hover:bg-surface-2"
            >
              {t.nav.home}
            </Link>
            <Link
              href="/privacy"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-2.5 py-2 rounded-md text-sm text-text-secondary hover:bg-surface-2"
            >
              {t.nav.privacy}
            </Link>
          </div>

          <div className="space-y-1 border-t border-surface-3 pt-3">
            <p className="text-[11px] font-mono text-primary uppercase px-2 flex items-center gap-1.5">
              <LifeBuoy className="w-3.5 h-3.5" /> {t.common.portal}
            </p>
            {residentLinks.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-2.5 py-2 rounded-md text-sm ${
                  item.highlight
                    ? 'text-red-400 font-semibold bg-red-500/10'
                    : 'text-text-secondary hover:bg-surface-2'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          <div className="space-y-1 border-t border-surface-3 pt-3">
            <p className="text-[11px] font-mono text-amber-400 uppercase px-2 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5" /> Rescue Operator
            </p>
            <Link
              href="/rescue/dashboard"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-2.5 py-2 rounded-md text-sm text-text-secondary hover:bg-surface-2"
            >
              {t.nav.rescueDashboard}
            </Link>
            <Link
              href="/rescue/assignments"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-2.5 py-2 rounded-md text-sm text-text-secondary hover:bg-surface-2"
            >
              {t.nav.rescueAssignments}
            </Link>
          </div>

          {isAdminUnlocked && (
            <div className="space-y-1 border-t border-surface-3 pt-3">
              <p className="text-[11px] font-mono text-primary uppercase px-2 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" /> State Command Center
              </p>
              <div className="grid grid-cols-2 gap-1">
                {adminLinks.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="px-2 py-1.5 rounded text-xs text-text-secondary hover:bg-surface-2 truncate"
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
