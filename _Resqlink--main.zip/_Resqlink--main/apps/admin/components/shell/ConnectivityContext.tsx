'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type ConnectivityMode = 'ONLINE' | 'OFFLINE_DETECTED' | 'OFFLINE_SIMULATED';

interface ConnectivityContextType {
  mode: ConnectivityMode;
  setSimulatedOffline: (simulated: boolean) => void;
  isEffectiveOffline: boolean;
  lastSyncTime: number | null;
  setLastSyncTime: (time: number) => void;
}

const ConnectivityContext = createContext<ConnectivityContextType>({
  mode: 'ONLINE',
  setSimulatedOffline: () => {},
  isEffectiveOffline: false,
  lastSyncTime: null,
  setLastSyncTime: () => {},
});

export function ConnectivityProvider({ children }: { children: React.ReactNode }) {
  const [isBrowserOnline, setIsBrowserOnline] = useState(true);
  const [isSimulatedOffline, setIsSimulatedOffline] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<number | null>(Date.now());

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOnline = () => setIsBrowserOnline(true);
    const handleOffline = () => setIsBrowserOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    setIsBrowserOnline(navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  let mode: ConnectivityMode = 'ONLINE';
  if (isSimulatedOffline) {
    mode = 'OFFLINE_SIMULATED';
  } else if (!isBrowserOnline) {
    mode = 'OFFLINE_DETECTED';
  }

  const isEffectiveOffline = mode !== 'ONLINE';

  return (
    <ConnectivityContext.Provider
      value={{
        mode,
        setSimulatedOffline: setIsSimulatedOffline,
        isEffectiveOffline,
        lastSyncTime,
        setLastSyncTime,
      }}
    >
      {children}
    </ConnectivityContext.Provider>
  );
}

export function useConnectivity() {
  return useContext(ConnectivityContext);
}
