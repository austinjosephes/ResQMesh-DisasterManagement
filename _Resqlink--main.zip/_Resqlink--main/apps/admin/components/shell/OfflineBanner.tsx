'use client';

import React from 'react';
import { useConnectivity } from './ConnectivityContext';
import { WifiOff, AlertTriangle, RefreshCw, Radio } from 'lucide-react';

export function OfflineBanner() {
  const { mode, setSimulatedOffline, isEffectiveOffline, lastSyncTime } = useConnectivity();

  return (
    <div className="w-full text-xs border-b border-surface-3 bg-surface-1">
      {/* Dev Key Security Banner */}
      <div className="bg-amber-950/60 text-amber-300 border-b border-amber-800/40 px-4 py-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="font-semibold tracking-wide uppercase">Development Key Active</span>
          <span className="text-amber-400/80 hidden sm:inline">— Ephemeral ES256 development keys. Unsafe for production operations.</span>
        </div>
        <span className="text-amber-400/60 font-mono text-[10px]">HSM/KMS Simulation Mode</span>
      </div>

      {/* Connectivity & Sync Status Bar */}
      {isEffectiveOffline && (
        <div
          className={`px-4 py-2 flex flex-wrap items-center justify-between gap-2 transition-colors ${
            mode === 'OFFLINE_SIMULATED'
              ? 'bg-cyan-950/40 text-cyan-200 border-b border-cyan-800/50'
              : 'bg-red-950/40 text-red-200 border-b border-red-800/50'
          }`}
        >
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-primary shrink-0 animate-pulse" />
            <span className="font-semibold">
              {mode === 'OFFLINE_SIMULATED' ? 'SIMULATED OFFLINE MODE' : 'NETWORK CONNECTION LOST'}
            </span>
            <span className="opacity-80 hidden md:inline">
              — Offline verification using cached trust bundle and signed revocation status.
            </span>
          </div>
          <div className="flex items-center gap-3">
            {lastSyncTime && (
              <span className="text-[11px] opacity-70">
                Cached trust age: {Math.max(1, Math.floor((Date.now() - lastSyncTime) / 60000))} min
              </span>
            )}
            {mode === 'OFFLINE_SIMULATED' && (
              <button
                onClick={() => setSimulatedOffline(false)}
                className="px-2 py-0.5 rounded bg-surface-3 hover:bg-surface-2 text-text-primary text-[11px] border border-surface-3 transition"
              >
                Disable Simulation
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
