'use client';

import React from 'react';

interface ResQLinkLogoProps {
  size?: number | string;
  className?: string;
  idSuffix?: string;
}

/**
 * ResQLink Master Lettermark Symbol
 * Distinctive uppercase letter 'R' with emerging emergency red radio-wave transmission arcs (#FF3B30).
 * Metallic silver / pure surgical white letterform on transparent background.
 */
export function ResQLinkLogo({
  size = 32,
  className = '',
  idSuffix = 'admin',
}: ResQLinkLogoProps) {
  const metalGradId = `resqMetalGrad-${idSuffix}`;
  const sheenGradId = `resqSheenGrad-${idSuffix}`;
  const signalGradPrimaryId = `resqSignalGradPrimary-${idSuffix}`;
  const signalGradSecondaryId = `resqSignalGradSecondary-${idSuffix}`;
  const signalGlowId = `resqSignalGlow-${idSuffix}`;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      width={size}
      height={size}
      fill="none"
      className={className}
      role="img"
      aria-label="ResQLink Lettermark R Logo"
    >
      <defs>
        {/* Metallic Titanium Silver / Surgical White Gradient */}
        <linearGradient
          id={metalGradId}
          x1="80"
          y1="124"
          x2="344"
          y2="452"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="28%" stopColor="#F8FAFC" />
          <stop offset="62%" stopColor="#CBD5E1" />
          <stop offset="100%" stopColor="#94A3B8" />
        </linearGradient>

        {/* Specular Edge Highlight Sheen */}
        <linearGradient
          id={sheenGradId}
          x1="80"
          y1="124"
          x2="80"
          y2="452"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="50%" stopColor="#E2E8F0" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#64748B" stopOpacity="0.2" />
        </linearGradient>

        {/* Vibrant Emergency Red (#FF3B30) Primary Signal Wave Gradient */}
        <linearGradient
          id={signalGradPrimaryId}
          x1="294"
          y1="107"
          x2="346"
          y2="233"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#FF453A" />
          <stop offset="50%" stopColor="#FF3B30" />
          <stop offset="100%" stopColor="#D70015" />
        </linearGradient>

        {/* Vibrant Emergency Red (#FF3B30) Secondary Signal Wave Gradient */}
        <linearGradient
          id={signalGradSecondaryId}
          x1="326"
          y1="78"
          x2="387"
          y2="244"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#FF5A4F" />
          <stop offset="55%" stopColor="#FF3B30" />
          <stop offset="100%" stopColor="#C91B10" />
        </linearGradient>

        {/* Subtle Optical Glow Filter for Radio Transmission Arcs */}
        <filter
          id={signalGlowId}
          x="-20%"
          y="-20%"
          width="140%"
          height="140%"
          filterUnits="userSpaceOnUse"
        >
          <feGaussianBlur stdDeviation="3.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* ========================================================= */}
      {/* 1. UPPERCASE LETTER 'R' CORE LETTERFORM                  */}
      {/* ========================================================= */}
      <g id="lettermark-r-body">
        {/* Left Vertical Stem (Solid Engineered Pillar with 45-degree Chamfer) */}
        <path
          d="M 80 148 L 104 124 L 154 124 L 154 452 L 80 452 Z"
          fill={`url(#${metalGradId})`}
        />

        {/* Upper Loop / Bowl (Aerodynamic Contour with Precision Geometric Cutout) */}
        <path
          d="M 154 124 L 228 124 A 80 80 0 0 1 308 204 A 80 80 0 0 1 228 284 L 154 284 Z
             M 154 174 L 220 174 A 30 30 0 0 1 250 204 A 30 30 0 0 1 220 234 L 154 234 Z"
          fill={`url(#${metalGradId})`}
          fillRule="evenodd"
        />

        {/* Dynamic Right Leg (Forward-Thrusting Stencil Wedge) */}
        <path
          d="M 200 268 L 258 268 L 344 452 L 276 452 L 176 300 L 200 268 Z"
          fill={`url(#${metalGradId})`}
        />

        {/* Specular Bevel Accent */}
        <path
          d="M 80 148 L 104 124 L 154 124 L 154 132 L 108 132 L 88 152 L 88 452 L 80 452 Z"
          fill={`url(#${sheenGradId})`}
          opacity="0.75"
        />
      </g>

      {/* ========================================================= */}
      {/* 2. EMERGENCY SIGNAL / RADIO-WAVE ARCS (#FF3B30)           */}
      {/* ========================================================= */}
      <g id="emergency-radio-arcs" filter={`url(#${signalGlowId})`}>
        {/* Arc 1: Primary Concentric Emergency Radio Wave */}
        <path
          d="M 294 107 A 112 112 0 0 1 346 233"
          stroke={`url(#${signalGradPrimaryId})`}
          strokeWidth="18"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Arc 2: Secondary Outer Telemetry Broadcast Wave */}
        <path
          d="M 326 78 A 154 154 0 0 1 387 244"
          stroke={`url(#${signalGradSecondaryId})`}
          strokeWidth="14"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Arc 3: Distant High-Reach Satellite Signal Wave */}
        <path
          d="M 374 64 A 196 196 0 0 1 430 220"
          stroke="#FF3B30"
          strokeWidth="10"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.8"
        />

        {/* Beacon Pulse Origin Node */}
        <circle cx="266" cy="140" r="5" fill="#FF3B30" />
      </g>
    </svg>
  );
}
