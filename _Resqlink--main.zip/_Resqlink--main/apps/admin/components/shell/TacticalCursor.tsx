'use client';

import React, { useEffect, useState, useRef } from 'react';

export function TacticalCursor() {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [isPointer, setIsPointer] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(true);

  const cursorRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const targetPos = useRef({ x: -100, y: -100 });
  const currentPos = useRef({ x: -100, y: -100 });

  useEffect(() => {
    // Only activate for devices with a fine mouse pointer
    if (typeof window !== 'undefined') {
      const finePointer = window.matchMedia('(pointer: fine)').matches;
      if (!finePointer) {
        setIsTouchDevice(true);
        return;
      }
      setIsTouchDevice(false);
    }

    const onMouseMove = (e: MouseEvent) => {
      targetPos.current = { x: e.clientX, y: e.clientY };
      if (!isVisible) setIsVisible(true);

      // Check if hovering over an interactive element
      const target = e.target as HTMLElement | null;
      if (target) {
        const isInteractive = Boolean(
          target.closest('a') ||
          target.closest('button') ||
          target.closest('input') ||
          target.closest('select') ||
          target.closest('textarea') ||
          target.closest('[role="button"]') ||
          target.closest('.cursor-pointer') ||
          target.closest('canvas') ||
          target.tagName === 'A' ||
          target.tagName === 'BUTTON'
        );
        setIsPointer(isInteractive);
      }
    };

    const onMouseDown = () => setIsClicking(true);
    const onMouseUp = () => setIsClicking(false);
    const onMouseLeave = () => setIsVisible(false);
    const onMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    // Smooth trailing lerp loop
    let animId: number;
    const render = () => {
      // 0.2 lerp factor for snappy tactical responsiveness
      currentPos.current.x += (targetPos.current.x - currentPos.current.x) * 0.22;
      currentPos.current.y += (targetPos.current.y - currentPos.current.y) * 0.22;

      if (cursorRef.current && dotRef.current) {
        cursorRef.current.style.transform = `translate3d(${currentPos.current.x}px, ${currentPos.current.y}px, 0)`;
        dotRef.current.style.transform = `translate3d(${targetPos.current.x}px, ${targetPos.current.y}px, 0)`;
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
    };
  }, [isVisible]);

  if (isTouchDevice || !isVisible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[999999] overflow-hidden">
      {/* 1. Precision Center Core Dot (Follows exact mouse immediately) */}
      <div
        ref={dotRef}
        className={`fixed top-0 left-0 -ml-1 -mt-1 w-2 h-2 rounded-full transition-colors duration-200 pointer-events-none shadow-sm ${
          isPointer
            ? 'bg-[#38BDF8] shadow-[0_0_8px_#38BDF8]'
            : 'bg-[#FF6B35] shadow-[0_0_8px_#FF6B35]'
        }`}
      />

      {/* 2. Tactical Radar Reticle (Smooth lerp trailing with crosshairs) */}
      <div
        ref={cursorRef}
        className={`fixed top-0 left-0 transition-all duration-200 ease-out pointer-events-none ${
          isPointer
            ? '-ml-5 -mt-5 w-10 h-10 border-2 border-[#38BDF8]/80 scale-110 rotate-45 shadow-[0_0_15px_rgba(56,189,248,0.4)]'
            : isClicking
            ? '-ml-3 -mt-3 w-6 h-6 border-2 border-[#FF6B35] scale-90 shadow-[0_0_10px_rgba(255,107,53,0.6)]'
            : '-ml-4 -mt-4 w-8 h-8 border border-[#FF6B35]/50 scale-100 shadow-[0_0_8px_rgba(255,107,53,0.2)]'
        } rounded-full flex items-center justify-center`}
      >
        {/* Crosshair Corner Tick Marks */}
        <div
          className={`w-full h-full relative transition-transform duration-300 ${
            isPointer ? 'rotate-90' : 'rotate-0'
          }`}
        >
          {/* Top Tick */}
          <span className="absolute -top-1 left-1/2 -ml-[1px] w-[2px] h-1.5 bg-[#FF6B35]/60 rounded-full" />
          {/* Bottom Tick */}
          <span className="absolute -bottom-1 left-1/2 -ml-[1px] w-[2px] h-1.5 bg-[#FF6B35]/60 rounded-full" />
          {/* Left Tick */}
          <span className="absolute top-1/2 -left-1 -mt-[1px] h-[2px] w-1.5 bg-[#FF6B35]/60 rounded-full" />
          {/* Right Tick */}
          <span className="absolute top-1/2 -right-1 -mt-[1px] h-[2px] w-1.5 bg-[#FF6B35]/60 rounded-full" />
        </div>
      </div>
    </div>
  );
}
