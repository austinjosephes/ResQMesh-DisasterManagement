import crypto from 'crypto';
import { prisma } from './prisma';

export const GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

export function calculateRecordHash(
  previousHash: string,
  seq: number,
  actor: string,
  action: string,
  resource: string,
  timestamp: number,
  outcome: string,
  correlationId: string
): string {
  const canonical = `${previousHash}|${seq}|${actor}|${action}|${resource}|${timestamp}|${outcome}|${correlationId}`;
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export async function appendAuditLog({
  actor,
  action,
  resource,
  outcome,
  reason,
  correlationId,
}: {
  actor: string;
  action: string;
  resource: string;
  outcome: 'SUCCESS' | 'FAILURE' | 'BLOCKED';
  reason?: string;
  correlationId?: string;
}) {
  const timestamp = Math.floor(Date.now() / 1000);
  const corr = correlationId || `corr-${crypto.randomBytes(8).toString('hex')}`;

  // Use database transaction to serialize append and guarantee monotonic sequence
  return await prisma.$transaction(async (tx) => {
    const lastRecord = await tx.auditLog.findFirst({
      orderBy: { sequence: 'desc' },
    });

    const nextSeq = lastRecord ? lastRecord.sequence + 1 : 1;
    const prevHash = lastRecord ? lastRecord.currentHash : GENESIS_HASH;
    const currentHash = calculateRecordHash(
      prevHash,
      nextSeq,
      actor,
      action,
      resource,
      timestamp,
      outcome,
      corr
    );

    return await tx.auditLog.create({
      data: {
        sequence: nextSeq,
        actor,
        action,
        resource,
        timestamp,
        outcome,
        reason,
        correlationId: corr,
        previousHash: prevHash,
        currentHash,
      },
    });
  });
}

export interface AuditVerificationReport {
  valid: boolean;
  totalRecords: number;
  firstFailedSequence?: number;
  expectedHash?: string;
  actualHash?: string;
  error?: string;
  verifiedAt: number;
}

export async function verifyAuditChain(): Promise<AuditVerificationReport> {
  const records = await prisma.auditLog.findMany({
    orderBy: { sequence: 'asc' },
  });

  const verifiedAt = Math.floor(Date.now() / 1000);

  if (records.length === 0) {
    return {
      valid: true,
      totalRecords: 0,
      verifiedAt,
    };
  }

  let expectedPrevHash = GENESIS_HASH;

  for (let i = 0; i < records.length; i++) {
    const rec = records[i];
    const expectedSeq = i + 1;

    if (rec.sequence !== expectedSeq) {
      return {
        valid: false,
        totalRecords: records.length,
        firstFailedSequence: rec.sequence,
        error: `Sequence gap or mismatch detected: expected ${expectedSeq}, found ${rec.sequence}`,
        verifiedAt,
      };
    }

    if (rec.previousHash !== expectedPrevHash) {
      return {
        valid: false,
        totalRecords: records.length,
        firstFailedSequence: rec.sequence,
        error: `Previous hash linkage broken at sequence ${rec.sequence}`,
        expectedHash: expectedPrevHash,
        actualHash: rec.previousHash,
        verifiedAt,
      };
    }

    const recomputedCurrentHash = calculateRecordHash(
      rec.previousHash,
      rec.sequence,
      rec.actor,
      rec.action,
      rec.resource,
      rec.timestamp,
      rec.outcome,
      rec.correlationId
    );

    if (recomputedCurrentHash !== rec.currentHash) {
      return {
        valid: false,
        totalRecords: records.length,
        firstFailedSequence: rec.sequence,
        error: `Hash recalculation mismatch at sequence ${rec.sequence}: content tampered`,
        expectedHash: recomputedCurrentHash,
        actualHash: rec.currentHash,
        verifiedAt,
      };
    }

    expectedPrevHash = rec.currentHash;
  }

  return {
    valid: true,
    totalRecords: records.length,
    verifiedAt,
  };
}
