/**
 * ResQLink Kerala — Centralized Application Configuration
 * Primary Local Development Environment:
 * - Citizen Safety Portal: http://localhost:3000
 * - SEOC Command Center:   http://localhost:3001
 */

export const APP_CONFIG = {
  // Primary Canonical URLs (Default: Localhost)
  SITE_URL: 'http://localhost:3000',
  ADMIN_URL: 'http://localhost:3001',

  DEV_SITE_URL: 'http://localhost:3000',
  DEV_ADMIN_URL: 'http://localhost:3001',

  /**
   * Resolves the current User / Citizen Safety Portal base URL.
   * Priority:
   * 1. NEXT_PUBLIC_SITE_URL / NEXT_PUBLIC_APP_URL environment variable
   * 2. Default fallback: http://localhost:3000
   */
  getSiteUrl(): string {
    if (process.env.NEXT_PUBLIC_SITE_URL) return process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, '');
    if (process.env.NEXT_PUBLIC_APP_URL) return process.env.NEXT_PUBLIC_APP_URL.replace(/\/$/, '');
    return this.SITE_URL;
  },

  /**
   * Resolves the current SEOC Emergency Command Centre base URL.
   * Priority:
   * 1. NEXT_PUBLIC_ADMIN_URL environment variable
   * 2. Current browser window.location.origin
   * 3. Default fallback: http://localhost:3001
   */
  getAdminUrl(): string {
    if (process.env.NEXT_PUBLIC_ADMIN_URL) return process.env.NEXT_PUBLIC_ADMIN_URL.replace(/\/$/, '');
    if (typeof window !== 'undefined' && window.location) {
      return window.location.origin;
    }
    return this.ADMIN_URL;
  },

  /**
   * Builds an absolute URL for either the user website or the admin website.
   */
  getAbsoluteUrl(path: string = '', target: 'site' | 'admin' = 'site'): string {
    const base = target === 'admin' ? this.getAdminUrl() : this.getSiteUrl();
    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    return `${base}${cleanPath}`;
  },

  /**
   * Checks whether the current runtime environment is production.
   */
  isProduction(): boolean {
    return process.env.NODE_ENV === 'production';
  },

  /**
   * Checks whether running over a secure HTTPS protocol.
   */
  isSecure(): boolean {
    if (typeof window !== 'undefined') {
      return window.location.protocol === 'https:';
    }
    return false;
  },
};

export default APP_CONFIG;
