/**
 * ResQLink Kerala — Geospatial & Resident Risk Digital Twin Engine
 * Pure TypeScript implementation of spatial calculations for Kerala hazard mapping.
 */

export interface Point {
  lat: number;
  lng: number;
}

export type PolygonCoords = [number, number][]; // [longitude, latitude] pairs (GeoJSON standard)

export interface DistrictInfo {
  id: string;
  name: string;
  nameMl: string;
  headquarters: string;
  center: Point;
  vulnerabilityFocus: string;
  localBodies: string[];
}

export const KERALA_DISTRICTS: DistrictInfo[] = [
  {
    id: 'Kasaragod',
    name: 'Kasaragod',
    nameMl: 'കാസർഗോഡ്',
    headquarters: 'Kasaragod',
    center: { lat: 12.4996, lng: 74.9869 },
    vulnerabilityFocus: 'Coastal erosion, riverine floods (Chandragiri, Payaswini)',
    localBodies: ['Kasaragod Municipality', 'Kanhangad Municipality', 'Nileshwaram', 'Manjeshwar'],
  },
  {
    id: 'Kannur',
    name: 'Kannur',
    nameMl: 'കണ്ണൂർ',
    headquarters: 'Kannur',
    center: { lat: 11.8745, lng: 75.3704 },
    vulnerabilityFocus: 'Flash floods, hill tract landslides (Iritty, Taliparamba)',
    localBodies: ['Kannur Corporation', 'Thalassery', 'Payyanur', 'Iritty', 'Taliparamba'],
  },
  {
    id: 'Wayanad',
    name: 'Wayanad',
    nameMl: 'വയനാട്',
    headquarters: 'Kalpetta',
    center: { lat: 11.6854, lng: 76.1320 },
    vulnerabilityFocus: 'Severe debris flow, landslide hazard zones (Meppadi, Chooralmala, Mundakkai, Vythiri)',
    localBodies: ['Kalpetta Municipality', 'Meppadi Grama Panchayat', 'Vythiri', 'Mananthavady', 'Sulthan Bathery'],
  },
  {
    id: 'Kozhikode',
    name: 'Kozhikode',
    nameMl: 'കോഴിക്കോട്',
    headquarters: 'Kozhikode',
    center: { lat: 11.2588, lng: 75.7804 },
    vulnerabilityFocus: 'Chaliyar/Iruvanji river flooding, urban inundation, high ranges landslides',
    localBodies: ['Kozhikode Corporation', 'Vadakara', 'Koyilandy', 'Feroke', 'Thamarassery'],
  },
  {
    id: 'Malappuram',
    name: 'Malappuram',
    nameMl: 'മലപ്പുറം',
    headquarters: 'Malappuram',
    center: { lat: 11.0735, lng: 76.0740 },
    vulnerabilityFocus: 'Kavalappara debris flow history, Kadalundi river swelling, coastal surge',
    localBodies: ['Malappuram Municipality', 'Manjeri', 'Ponnani', 'Tirur', 'Nilambur'],
  },
  {
    id: 'Palakkad',
    name: 'Palakkad',
    nameMl: 'പാലക്കാട്',
    headquarters: 'Palakkad',
    center: { lat: 10.7867, lng: 76.6548 },
    vulnerabilityFocus: 'Palakkad gap wind gusts, Bharathapuzha catchment flooding, Attappadi landslides',
    localBodies: ['Palakkad Municipality', 'Ottapalam', 'Chittur-Thathamangalam', 'Mannarkkad', 'Pattambi'],
  },
  {
    id: 'Thrissur',
    name: 'Thrissur',
    nameMl: 'തൃശ്ശൂർ',
    headquarters: 'Thrissur',
    center: { lat: 10.5276, lng: 76.2144 },
    vulnerabilityFocus: 'Kole wetlands waterlogging, Chalakudy river floodplains, coastal inundation',
    localBodies: ['Thrissur Corporation', 'Chalakudy', 'Kodungallur', 'Kunnamkulam', 'Guruvayur'],
  },
  {
    id: 'Ernakulam',
    name: 'Ernakulam',
    nameMl: 'എറണാകുളം',
    headquarters: 'Kochi (Kakkanad)',
    center: { lat: 9.9816, lng: 76.2999 },
    vulnerabilityFocus: 'Periyar river dam discharge floods (Aluva, Paravur), Chellanam coastal storm surge',
    localBodies: ['Kochi Corporation', 'Aluva Municipality', 'North Paravur', 'Kalamassery', 'Chellanam Panchayat'],
  },
  {
    id: 'Idukki',
    name: 'Idukki',
    nameMl: 'ഇടുക്കി',
    headquarters: 'Painavu',
    center: { lat: 9.8494, lng: 76.9806 },
    vulnerabilityFocus: 'Idukki/Mullaperiyar dam spillway, steep slope landslides, Pettimudi debris flows',
    localBodies: ['Thodupuzha Municipality', 'Kattappana', 'Munnar', 'Devikulam', 'Cheruthoni'],
  },
  {
    id: 'Kottayam',
    name: 'Kottayam',
    nameMl: 'കോട്ടയം',
    headquarters: 'Kottayam',
    center: { lat: 9.5916, lng: 76.5222 },
    vulnerabilityFocus: 'Meenachil river flooding, Kuttanad fringe lowlands, Koottickal flash landslides',
    localBodies: ['Kottayam Municipality', 'Changanassery', 'Pala', 'Vaikom', 'Kanjirappally'],
  },
  {
    id: 'Alappuzha',
    name: 'Alappuzha',
    nameMl: 'ആലപ്പുഴ',
    headquarters: 'Alappuzha',
    center: { lat: 9.4981, lng: 76.3388 },
    vulnerabilityFocus: 'Below-sea-level Kuttanad waterlogging, coastal sea surge, Pamba river flood exit',
    localBodies: ['Alappuzha Municipality', 'Cherthala', 'Kayamkulam', 'Mavelikkara', 'Kuttanad Taluk'],
  },
  {
    id: 'Pathanamthitta',
    name: 'Pathanamthitta',
    nameMl: 'പത്തനംതിട്ട',
    headquarters: 'Pathanamthitta',
    center: { lat: 9.2648, lng: 76.7870 },
    vulnerabilityFocus: 'Pamba and Achankovil river floods (Ranni, Kozhencherry, Pandalam, Aranmula)',
    localBodies: ['Pathanamthitta Municipality', 'Thiruvalla', 'Adoor', 'Ranni', 'Kozhencherry'],
  },
  {
    id: 'Kollam',
    name: 'Kollam',
    nameMl: 'കൊല്ലം',
    headquarters: 'Kollam',
    center: { lat: 8.8932, lng: 76.6141 },
    vulnerabilityFocus: 'Ashtamudi estuary backwater surge, Kallada river flooding, coastal erosion',
    localBodies: ['Kollam Corporation', 'Karunagappally', 'Paravur', 'Punalur', 'Kottarakkara'],
  },
  {
    id: 'Thiruvananthapuram',
    name: 'Thiruvananthapuram',
    nameMl: 'തിരുവനന്തപുരം',
    headquarters: 'Thiruvananthapuram',
    center: { lat: 8.5241, lng: 76.9366 },
    vulnerabilityFocus: 'Karamana/Killi river flash floods, Neyyar river swelling, Vizhinjam coastal surge',
    localBodies: ['Thiruvananthapuram Corporation', 'Neyyattinkara', 'Attingal', 'Nedumangad', 'Varkala'],
  },
];

/**
 * Robust Point-in-Polygon Ray Casting Algorithm
 * GeoJSON polygon convention: [lng, lat]
 */
export function isPointInPolygon(point: Point, polygon: PolygonCoords): boolean {
  const x = point.lng;
  const y = point.lat;
  let inside = false;

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i][0];
    const yi = polygon[i][1];
    const xj = polygon[j][0];
    const yj = polygon[j][1];

    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }

  return inside;
}

/**
 * Calculates Great-circle distance between two GPS coordinates using Haversine formula
 */
export function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Parses GeoJSON geometry and checks point containment
 */
export function checkHazardExposure(
  point: Point,
  polygonGeoJsonStr: string
): boolean {
  try {
    const geo = JSON.parse(polygonGeoJsonStr);
    let coords: PolygonCoords[] = [];

    if (geo.type === 'Polygon') {
      coords = geo.coordinates; // array of linear rings
    } else if (geo.type === 'Feature' && geo.geometry?.type === 'Polygon') {
      coords = geo.geometry.coordinates;
    } else if (geo.coordinates) {
      coords = geo.coordinates;
    }

    if (coords && coords.length > 0) {
      // Exterior ring is at coords[0]
      const exteriorRing = coords[0];
      return isPointInPolygon(point, exteriorRing);
    }
    return false;
  } catch (err) {
    console.error('Failed to parse polygon GeoJSON:', err);
    return false;
  }
}

/**
 * Finds the geographically closest Kerala district from GPS coordinates
 */
export function findNearestKeralaDistrict(lat: number, lng: number): DistrictInfo {
  let nearest = KERALA_DISTRICTS[0];
  let minDistance = Infinity;

  for (const district of KERALA_DISTRICTS) {
    const dist = haversineDistanceKm(lat, lng, district.center.lat, district.center.lng);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = district;
    }
  }

  return nearest;
}

