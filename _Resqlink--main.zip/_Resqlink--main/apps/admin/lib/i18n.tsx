'use client';

import React, { createContext, useContext } from 'react';
import { en } from '../locales/en';

export type Language = 'en' | 'ml';

interface I18nContextType {
  language: 'en';
  setLanguage: (lang: Language) => void;
  t: typeof en;
}

const I18nContext = createContext<I18nContextType>({
  language: 'en',
  setLanguage: () => {},
  t: en,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  return (
    <I18nContext.Provider value={{ language: 'en', setLanguage: () => {}, t: en }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
