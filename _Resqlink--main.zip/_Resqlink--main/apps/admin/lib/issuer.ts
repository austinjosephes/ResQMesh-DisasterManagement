import * as jose from 'jose';
import fs from 'fs';
import path from 'path';
import { prisma } from './prisma';
import { TrustBundle, SignedStatusSnapshot } from '@resqmesh/shared';

const KEY_DIR = path.join(process.cwd(), '.keys');
const PRIVATE_KEY_PATH = path.join(KEY_DIR, 'issuer-dev-private.jwk.json');
const PUBLIC_KEY_PATH = path.join(KEY_DIR, 'issuer-dev-public.jwk.json');

export interface IssuerKeyMaterial {
  kid: string;
  privateKey: any; // KeyLike
  publicKeyJwk: any;
  isDevelopment: boolean;
}

let cachedIssuerKey: IssuerKeyMaterial | null = null;

export async function getOrCreateIssuerKey(): Promise<IssuerKeyMaterial> {
  if (cachedIssuerKey) return cachedIssuerKey;

  if (!fs.existsSync(KEY_DIR)) {
    fs.mkdirSync(KEY_DIR, { recursive: true });
  }

  let kid = 'issuer-fema-alpha-2026';
  let privJwk: any;
  let pubJwk: any;

  if (fs.existsSync(PRIVATE_KEY_PATH) && fs.existsSync(PUBLIC_KEY_PATH)) {
    privJwk = JSON.parse(fs.readFileSync(PRIVATE_KEY_PATH, 'utf-8'));
    pubJwk = JSON.parse(fs.readFileSync(PUBLIC_KEY_PATH, 'utf-8'));
    kid = pubJwk.kid || kid;
  } else {
    // Generate new development ES256 key
    const pair = await jose.generateKeyPair('ES256', { extractable: true });
    privJwk = await jose.exportJWK(pair.privateKey);
    pubJwk = await jose.exportJWK(pair.publicKey);
    pubJwk.kid = kid;
    privJwk.kid = kid;

    fs.writeFileSync(PRIVATE_KEY_PATH, JSON.stringify(privJwk, null, 2), 'utf-8');
    fs.writeFileSync(PUBLIC_KEY_PATH, JSON.stringify(pubJwk, null, 2), 'utf-8');
  }

  const privateKey = await jose.importJWK(privJwk, 'ES256');

  cachedIssuerKey = {
    kid,
    privateKey,
    publicKeyJwk: pubJwk,
    isDevelopment: true,
  };

  return cachedIssuerKey;
}

export async function signCredentialJwt(claims: Record<string, any>): Promise<string> {
  const { kid, privateKey } = await getOrCreateIssuerKey();

  const header = {
    alg: 'ES256',
    typ: 'application/resqmesh-credential+jwt',
    kid,
  };

  return await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(claims)))
    .setProtectedHeader(header)
    .sign(privateKey);
}

export async function signTrustBundle(bundlePayload: Omit<TrustBundle, 'signature'>): Promise<TrustBundle> {
  const { privateKey } = await getOrCreateIssuerKey();
  const canonicalBytes = new TextEncoder().encode(JSON.stringify(bundlePayload));
  
  // Compact sign to produce bundle signature
  const sig = await new jose.CompactSign(canonicalBytes)
    .setProtectedHeader({ alg: 'ES256', typ: 'application/resqmesh-trust-bundle' })
    .sign(privateKey);

  return {
    ...bundlePayload,
    signature: sig,
  };
}

export async function signStatusSnapshot(
  snapshotPayload: Omit<SignedStatusSnapshot, 'signature'>
): Promise<SignedStatusSnapshot> {
  const { privateKey } = await getOrCreateIssuerKey();
  const canonicalBytes = new TextEncoder().encode(JSON.stringify(snapshotPayload));

  const sig = await new jose.CompactSign(canonicalBytes)
    .setProtectedHeader({ alg: 'ES256', typ: 'application/resqmesh-status-snapshot' })
    .sign(privateKey);

  return {
    ...snapshotPayload,
    signature: sig,
  };
}
