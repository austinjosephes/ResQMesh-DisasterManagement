/**
 * ResQLink Kerala — 2026 State Demographic & Administrative Hierarchy Engine
 * Population Estimate (2026): 3.73 Crore (37,300,000)
 * Administrative Tiers: Exactly 14 Districts, 152 Block Panchayats, 941 Grama Panchayats
 */

import rawHierarchy from './data/kerala-full-administrative.json' with { type: 'json' };

export const KERALA_STATISTICS_2026 = {
  TOTAL_POPULATION_ESTIMATE: 37300000, // 3.73 Crore
  TOTAL_DISTRICTS: 14,
  TOTAL_BLOCK_PANCHAYATS: 152,
  TOTAL_GRAMA_PANCHAYATS: 941,
  TOTAL_WARDS_APPROX: 15962,
  AVERAGE_GRAMA_POPULATION: 39638,
  AVERAGE_BLOCK_POPULATION: 245394,
  STATE_AREA_SQ_KM: 38863,
};

export type TargetScope = 'DISTRICT' | 'BLOCK_PANCHAYAT' | 'GRAMA_PANCHAYAT';

export interface GramaPanchayat {
  id: string;
  name: string;
  blockName: string;
  districtName: string;
  population2026Est: number;
  center: { lat: number; lng: number };
  primaryVulnerability: 'LANDSLIDE' | 'FLOOD' | 'HEAVY_RAIN' | 'DAM_DISCHARGE' | 'COASTAL_EROSION' | 'CYCLONE';
  designatedReliefCamp: string;
  localAreas: string[];
}

export interface BlockPanchayat {
  id: string;
  name: string;
  districtName: string;
  population2026Est: number;
  center: { lat: number; lng: number };
  gramaPanchayats: GramaPanchayat[];
}

export interface DistrictHierarchy {
  id: string;
  name: string;
  headquarters: string;
  population2026Est: number;
  center: { lat: number; lng: number };
  totalBlockCount: number;
  totalGramaCount: number;
  blocks: BlockPanchayat[];
}

export const KERALA_ADMINISTRATIVE_HIERARCHY: DistrictHierarchy[] = rawHierarchy as unknown as DistrictHierarchy[];

/**
 * Helper to retrieve all districts
 */
export function getAllDistricts(): DistrictHierarchy[] {
  return KERALA_ADMINISTRATIVE_HIERARCHY;
}

/**
 * Helper to retrieve blocks for a district
 */
export function getBlocksForDistrict(districtName: string): BlockPanchayat[] {
  const d = KERALA_ADMINISTRATIVE_HIERARCHY.find(
    (item) => item.name.toLowerCase() === districtName.toLowerCase() || item.id.toLowerCase() === districtName.toLowerCase()
  );
  return d ? d.blocks : [];
}

/**
 * Helper to retrieve Grama Panchayats for a Block
 */
export function getGramasForBlock(districtName: string, blockName: string): GramaPanchayat[] {
  const blocks = getBlocksForDistrict(districtName);
  const b = blocks.find(
    (item) => item.name.toLowerCase() === blockName.toLowerCase() || item.id.toLowerCase() === blockName.toLowerCase()
  );
  return b ? b.gramaPanchayats : [];
}

/**
 * Flatten all 941 Grama Panchayats across the state
 */
export function getAllGramaPanchayats(): GramaPanchayat[] {
  const all: GramaPanchayat[] = [];
  for (const d of KERALA_ADMINISTRATIVE_HIERARCHY) {
    for (const b of d.blocks) {
      all.push(...b.gramaPanchayats);
    }
  }
  return all;
}

/**
 * Calculate estimated population and centroid for an alert scope
 */
export function calculateRegionalPopulation(
  scope: TargetScope,
  districtName: string,
  blockName?: string,
  gramaName?: string
): {
  populationEst: number;
  label: string;
  center: { lat: number; lng: number };
  vulnerabilities: string[];
} {
  const dist = KERALA_ADMINISTRATIVE_HIERARCHY.find(
    (d) => d.name.toLowerCase() === districtName.toLowerCase() || d.id.toLowerCase() === districtName.toLowerCase()
  );

  if (!dist) {
    return {
      populationEst: KERALA_STATISTICS_2026.AVERAGE_GRAMA_POPULATION,
      label: `${districtName} (Kerala Region)`,
      center: { lat: 10.5, lng: 76.2 },
      vulnerabilities: ['FLOOD', 'HEAVY_RAIN'],
    };
  }

  if (scope === 'GRAMA_PANCHAYAT' && gramaName) {
    for (const b of dist.blocks) {
      const g = b.gramaPanchayats.find(
        (gp) => gp.name.toLowerCase() === gramaName.toLowerCase() || gp.id.toLowerCase() === gramaName.toLowerCase()
      );
      if (g) {
        return {
          populationEst: g.population2026Est,
          label: `${g.name}, ${b.name}, ${dist.name} District`,
          center: g.center,
          vulnerabilities: [g.primaryVulnerability],
        };
      }
    }
  }

  if (scope === 'BLOCK_PANCHAYAT' && blockName) {
    const b = dist.blocks.find(
      (blk) => blk.name.toLowerCase() === blockName.toLowerCase() || blk.id.toLowerCase() === blockName.toLowerCase()
    );
    if (b) {
      const vulns = Array.from(new Set(b.gramaPanchayats.map((gp) => gp.primaryVulnerability)));
      return {
        populationEst: b.population2026Est,
        label: `${b.name}, ${dist.name} District (Coverage: ${b.gramaPanchayats.length} Grama Panchayats)`,
        center: b.center,
        vulnerabilities: vulns,
      };
    }
  }

  // Fallback to District wide
  return {
    populationEst: dist.population2026Est,
    label: `${dist.name} District (All ${dist.totalBlockCount} Blocks & ${dist.totalGramaCount} Grama Panchayats)`,
    center: dist.center,
    vulnerabilities: ['LANDSLIDE', 'FLOOD', 'HEAVY_RAIN'],
  };
}

/**
 * Generates an authentic bounding polygon (GeoJSON Polygon) centered on the administrative target
 */
export function generateRegionalBoundingPolygon(
  center: { lat: number; lng: number },
  scope: TargetScope
): string {
  // Grama Panchayat is hyper-local (~0.03 deg box), Block is intermediate (~0.08 deg), District is wide (~0.25 deg)
  const delta = scope === 'GRAMA_PANCHAYAT' ? 0.035 : scope === 'BLOCK_PANCHAYAT' ? 0.085 : 0.25;

  return JSON.stringify({
    type: 'Polygon',
    coordinates: [
      [
        [Number((center.lng - delta).toFixed(4)), Number((center.lat - delta).toFixed(4))],
        [Number((center.lng + delta).toFixed(4)), Number((center.lat - delta).toFixed(4))],
        [Number((center.lng + delta).toFixed(4)), Number((center.lat + delta).toFixed(4))],
        [Number((center.lng - delta).toFixed(4)), Number((center.lat + delta).toFixed(4))],
        [Number((center.lng - delta).toFixed(4)), Number((center.lat - delta).toFixed(4))],
      ],
    ],
  });
}

export interface SearchAdministrativeResult {
  type: 'DISTRICT' | 'BLOCK' | 'GRAMA' | 'LOCAL_AREA';
  name: string;
  district: string;
  block?: string;
  grama?: string;
  populationEst: number;
  reliefCamp?: string;
  primaryVulnerability?: string;
  matchedLocalArea?: string;
  center: { lat: number; lng: number };
}

/**
 * High-speed search across all 14 Districts, 152 Blocks, 941 Grama Panchayats, and all constituent local areas / wards
 */
export function searchAdministrativeAreas(query: string, maxResults: number = 30): SearchAdministrativeResult[] {
  const cleanQ = query.trim().toLowerCase();
  if (!cleanQ) return [];

  const results: SearchAdministrativeResult[] = [];

  for (const d of KERALA_ADMINISTRATIVE_HIERARCHY) {
    if (d.name.toLowerCase().includes(cleanQ) || d.headquarters.toLowerCase().includes(cleanQ)) {
      results.push({
        type: 'DISTRICT',
        name: d.name,
        district: d.name,
        populationEst: d.population2026Est,
        center: d.center,
      });
      if (results.length >= maxResults) return results;
    }

    for (const b of d.blocks) {
      if (b.name.toLowerCase().includes(cleanQ)) {
        results.push({
          type: 'BLOCK',
          name: b.name,
          district: d.name,
          block: b.name,
          populationEst: b.population2026Est,
          center: b.center,
        });
        if (results.length >= maxResults) return results;
      }

      for (const g of b.gramaPanchayats) {
        if (g.name.toLowerCase().includes(cleanQ)) {
          results.push({
            type: 'GRAMA',
            name: g.name,
            district: d.name,
            block: b.name,
            grama: g.name,
            populationEst: g.population2026Est,
            reliefCamp: g.designatedReliefCamp,
            primaryVulnerability: g.primaryVulnerability,
            center: g.center,
          });
          if (results.length >= maxResults) return results;
        }

        // Check local areas / wards
        if (g.localAreas && Array.isArray(g.localAreas)) {
          for (const area of g.localAreas) {
            if (area.toLowerCase().includes(cleanQ)) {
              results.push({
                type: 'LOCAL_AREA',
                name: area,
                district: d.name,
                block: b.name,
                grama: g.name,
                populationEst: g.population2026Est,
                reliefCamp: g.designatedReliefCamp,
                primaryVulnerability: g.primaryVulnerability,
                matchedLocalArea: area,
                center: g.center,
              });
              if (results.length >= maxResults) return results;
            }
          }
        }
      }
    }
  }

  return results;
}

/**
 * High-speed GPS nearest neighbor matcher:
 * Resolves the exact Grama Panchayat, Block Panchayat, District, and Relief Shelter from any latitude and longitude in Kerala
 */
export function findNearestGramaPanchayat(lat: number, lng: number): GramaPanchayat {
  let closest: GramaPanchayat | null = null;
  let minDistance = Infinity;

  for (const d of KERALA_ADMINISTRATIVE_HIERARCHY) {
    for (const b of d.blocks) {
      for (const g of b.gramaPanchayats) {
        const dLat = g.center.lat - lat;
        const dLng = g.center.lng - lng;
        const distSq = dLat * dLat + dLng * dLng;
        if (distSq < minDistance) {
          minDistance = distSq;
          closest = g;
        }
      }
    }
  }

  return closest || KERALA_ADMINISTRATIVE_HIERARCHY[2].blocks[0].gramaPanchayats[0];
}
