import * as jose from 'jose';
import { TrustBundle, SignedStatusSnapshot, OfflineEventRecord } from '@resqmesh/shared';

const DB_NAME = 'resqmesh_trust_db';
const DB_VERSION = 2;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported or running on server'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (e: any) => {
      const db: IDBDatabase = e.target.result;
      if (!db.objectStoreNames.contains('keys')) {
        db.createObjectStore('keys', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('trust_bundles')) {
        db.createObjectStore('trust_bundles', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('status_snapshots')) {
        db.createObjectStore('status_snapshots', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('credentials')) {
        db.createObjectStore('credentials', { keyPath: 'jti' });
      }
      if (!db.objectStoreNames.contains('offline_events')) {
        db.createObjectStore('offline_events', { keyPath: 'event_id' });
      }
      if (!db.objectStoreNames.contains('metadata')) {
        db.createObjectStore('metadata', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('sos_requests')) {
        db.createObjectStore('sos_requests', { keyPath: 'trackingNumber' });
      }
      if (!db.objectStoreNames.contains('cached_incidents')) {
        db.createObjectStore('cached_incidents', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// -------------------------------------------------------------
// 1. Device Key Management (Non-extractable WebCrypto ECDSA P-256)
// -------------------------------------------------------------
export async function generateAndStoreDeviceKey(): Promise<{
  thumbprint: string;
  publicJwk: any;
}> {
  const keyPair = await window.crypto.subtle.generateKey(
    {
      name: 'ECDSA',
      namedCurve: 'P-256',
    },
    false, // non-extractable private key
    ['sign']
  );

  const publicJwk = await window.crypto.subtle.exportKey('jwk', keyPair.publicKey);
  const thumbprint = await jose.calculateJwkThumbprint(publicJwk as any, 'sha256');

  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction('keys', 'readwrite');
    const store = tx.objectStore('keys');
    store.put({
      id: 'active_device_key',
      thumbprint,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
      publicJwk,
      createdAt: Date.now(),
    });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });

  return { thumbprint, publicJwk };
}

export async function getActiveDeviceKeyInfo(): Promise<{
  thumbprint: string;
  publicJwk: any;
  hasPrivateKey: boolean;
} | null> {
  try {
    const db = await openDB();
    const result = await new Promise<any>((resolve, reject) => {
      const tx = db.transaction('keys', 'readonly');
      const store = tx.objectStore('keys');
      const req = store.get('active_device_key');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });

    if (!result) return null;
    return {
      thumbprint: result.thumbprint,
      publicJwk: result.publicJwk,
      hasPrivateKey: !!result.privateKey,
    };
  } catch (e) {
    return null;
  }
}

export async function signChallengeWithDeviceKey(nonce: string): Promise<string> {
  const db = await openDB();
  const keyRecord = await new Promise<any>((resolve, reject) => {
    const tx = db.transaction('keys', 'readonly');
    const req = tx.objectStore('keys').get('active_device_key');
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  if (!keyRecord || !keyRecord.privateKey) {
    throw new Error('No enrolled non-extractable device key available.');
  }

  const nonceBytes = new TextEncoder().encode(nonce);
  const sigBuffer = await window.crypto.subtle.sign(
    { name: 'ECDSA', hash: { name: 'SHA-256' } },
    keyRecord.privateKey,
    nonceBytes
  );

  return jose.base64url.encode(new Uint8Array(sigBuffer));
}

// -------------------------------------------------------------
// 2. Trust Material Caching
// -------------------------------------------------------------
export async function cacheTrustBundle(bundle: TrustBundle): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('trust_bundles', 'readwrite');
    tx.objectStore('trust_bundles').put({ id: 'latest', ...bundle });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getCachedTrustBundle(): Promise<TrustBundle | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('trust_bundles', 'readonly');
      const req = tx.objectStore('trust_bundles').get('latest');
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return null;
  }
}

export async function cacheStatusSnapshot(snapshot: SignedStatusSnapshot): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('status_snapshots', 'readwrite');
    tx.objectStore('status_snapshots').put({ id: 'latest', ...snapshot });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getCachedStatusSnapshot(): Promise<SignedStatusSnapshot | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('status_snapshots', 'readonly');
      const req = tx.objectStore('status_snapshots').get('latest');
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return null;
  }
}

// -------------------------------------------------------------
// 3. Credential & Offline Event Storage
// -------------------------------------------------------------
export async function cacheCredential(cred: { jti: string; tokenJws: string; claims: any }): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('credentials', 'readwrite');
    tx.objectStore('credentials').put(cred);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getCachedCredentials(): Promise<any[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('credentials', 'readonly');
      const req = tx.objectStore('credentials').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return [];
  }
}

export async function storeOfflineEvent(event: OfflineEventRecord): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('offline_events', 'readwrite');
    tx.objectStore('offline_events').put(event);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getPendingOfflineEvents(): Promise<OfflineEventRecord[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('offline_events', 'readonly');
      const req = tx.objectStore('offline_events').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return [];
  }
}

export async function clearSyncedEvents(eventIds: string[]): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('offline_events', 'readwrite');
    const store = tx.objectStore('offline_events');
    for (const id of eventIds) {
      store.delete(id);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// -------------------------------------------------------------
// 4. Offline Citizen SOS Requests Storage
// -------------------------------------------------------------
export interface OfflineSOSRecord {
  trackingNumber: string;
  category: string;
  description: string;
  peopleCount: number;
  hasInjuries: boolean;
  immediateDanger: boolean;
  latitude: number | null;
  longitude: number | null;
  address: string | null;
  accessibilityNeeds: string | null;
  contactPreference: string | null;
  status: 'QUEUED_LOCAL' | 'RECEIVED' | 'VERIFIED' | 'ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED';
  priority: string;
  createdAt: number;
  synced: boolean;
  deviceSignature?: string;
}

export async function storeOfflineSOS(sos: OfflineSOSRecord): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('sos_requests', 'readwrite');
    tx.objectStore('sos_requests').put(sos);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getOfflineSOSList(): Promise<OfflineSOSRecord[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sos_requests', 'readonly');
      const req = tx.objectStore('sos_requests').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return [];
  }
}

export async function updateOfflineSOSStatus(trackingNumber: string, status: OfflineSOSRecord['status'], synced = true): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sos_requests', 'readwrite');
      const store = tx.objectStore('sos_requests');
      const req = store.get(trackingNumber);
      req.onsuccess = () => {
        const item = req.result;
        if (item) {
          item.status = status;
          item.synced = synced;
          store.put(item);
        }
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  } catch (e) {}
}

export async function clearOfflineSOS(trackingNumbers: string[]): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('sos_requests', 'readwrite');
    const store = tx.objectStore('sos_requests');
    for (const t of trackingNumbers) {
      store.delete(t);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// -------------------------------------------------------------
// 5. Cached Incident Records for Map & Responder Offline View
// -------------------------------------------------------------
export async function cacheIncidents(incidents: any[]): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction('cached_incidents', 'readwrite');
    const store = tx.objectStore('cached_incidents');
    for (const inc of incidents) {
      store.put({ ...inc, cachedAt: Date.now() });
    }
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {}
}

export async function getCachedIncidents(): Promise<any[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('cached_incidents', 'readonly');
      const req = tx.objectStore('cached_incidents').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    return [];
  }
}
