/**
 * ResQLink Kerala — Rescue Priority Engine
 * Transparent, rules-based urgency assessment with human coordinator override controls.
 */

export interface SOSInputData {
  category: string;
  peopleCount: number;
  hasInjuries: boolean;
  immediateDanger: boolean;
  locationConfidence: number; // 0.0 to 1.0
  accessibilityNeeds?: string | null;
  reportedAt: Date | string | number;
}

export interface PriorityScoreResult {
  totalScore: number;
  priorityCategory: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW' | 'NEEDS_VERIFICATION';
  breakdown: {
    threatScore: number;
    trappedInjuredScore: number;
    waitTimeScore: number;
    locationConfidenceScore: number;
    vulnerabilityBonus: number;
    reasons: string[];
  };
  requiresVerification: boolean;
}

export function calculateRescuePriority(input: SOSInputData): PriorityScoreResult {
  const reasons: string[] = [];
  let threatScore = 0;
  let trappedInjuredScore = 0;
  let waitTimeScore = 0;
  let locationConfidenceScore = 0;
  let vulnerabilityBonus = 0;

  // 1. Immediate Threat to Life (0 - 35 points)
  if (input.immediateDanger) {
    threatScore += 25;
    reasons.push('Immediate life-threatening danger reported (+25)');
  }
  const highThreatCategories = ['LANDSLIDE', 'FLOOD', 'TRAPPED', 'STRUCTURAL_COLLAPSE'];
  if (highThreatCategories.includes(input.category.toUpperCase())) {
    threatScore += 10;
    reasons.push(`High hazard category: ${input.category} (+10)`);
  } else if (input.category.toUpperCase() === 'MEDICAL') {
    threatScore += 8;
    reasons.push('Medical urgency (+8)');
  }

  // 2. Trapped or Injured / People Count (0 - 25 points)
  if (input.hasInjuries) {
    trappedInjuredScore += 15;
    reasons.push('Active trauma / injuries confirmed (+15)');
  }
  const count = Math.max(1, input.peopleCount || 1);
  if (count >= 10) {
    trappedInjuredScore += 10;
    reasons.push(`Large group trapped (${count} people) (+10)`);
  } else if (count >= 4) {
    trappedInjuredScore += 7;
    reasons.push(`Family / group trapped (${count} people) (+7)`);
  } else if (count > 1) {
    trappedInjuredScore += 4;
    reasons.push(`Multiple persons affected (${count} people) (+4)`);
  }

  // 3. Elapsed Waiting Time (0 - 20 points)
  const reportedTime = new Date(input.reportedAt).getTime();
  const elapsedMinutes = Math.max(0, Math.floor((Date.now() - reportedTime) / (60 * 1000)));
  if (elapsedMinutes >= 120) {
    waitTimeScore = 20;
    reasons.push(`Prolonged waiting duration (${elapsedMinutes} mins) (+20)`);
  } else if (elapsedMinutes >= 60) {
    waitTimeScore = 15;
    reasons.push(`Elevated waiting duration (${elapsedMinutes} mins) (+15)`);
  } else if (elapsedMinutes >= 30) {
    waitTimeScore = 10;
    reasons.push(`Moderate waiting duration (${elapsedMinutes} mins) (+10)`);
  } else if (elapsedMinutes >= 10) {
    waitTimeScore = 5;
    reasons.push(`Initial response window (${elapsedMinutes} mins) (+5)`);
  }

  // 4. Location Confidence (0 - 10 points)
  const confidence = Math.max(0, Math.min(1, input.locationConfidence ?? 0.85));
  if (confidence >= 0.8) {
    locationConfidenceScore = 10;
    reasons.push(`High GPS confidence (${Math.round(confidence * 100)}%) (+10)`);
  } else if (confidence >= 0.5) {
    locationConfidenceScore = 6;
    reasons.push(`Moderate location accuracy (${Math.round(confidence * 100)}%) (+6)`);
  } else {
    locationConfidenceScore = 2;
    reasons.push(`Low location confidence (${Math.round(confidence * 100)}%) (+2)`);
  }

  // 5. Accessibility / Special Needs Vulnerability (0 - 10 points)
  if (input.accessibilityNeeds && input.accessibilityNeeds.trim().length > 0) {
    const text = input.accessibilityNeeds.toLowerCase();
    if (
      text.includes('wheelchair') ||
      text.includes('bedridden') ||
      text.includes('oxygen') ||
      text.includes('infant') ||
      text.includes('elderly') ||
      text.includes('dialysis') ||
      text.includes('disabled')
    ) {
      vulnerabilityBonus = 10;
      reasons.push('Critical special assistance needs (mobility/oxygen/infant/elderly) (+10)');
    } else {
      vulnerabilityBonus = 5;
      reasons.push('Evacuation assistance constraint flagged (+5)');
    }
  }

  const totalScore = Math.min(
    100,
    threatScore + trappedInjuredScore + waitTimeScore + locationConfidenceScore + vulnerabilityBonus
  );

  let requiresVerification = false;
  let priorityCategory: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW' | 'NEEDS_VERIFICATION' = 'MODERATE';

  if (confidence < 0.4) {
    priorityCategory = 'NEEDS_VERIFICATION';
    requiresVerification = true;
    reasons.unshift('⚠️ Low-confidence location triggers mandatory operator verification');
  } else if (totalScore >= 75) {
    priorityCategory = 'CRITICAL';
  } else if (totalScore >= 55) {
    priorityCategory = 'HIGH';
  } else if (totalScore >= 35) {
    priorityCategory = 'MODERATE';
  } else {
    priorityCategory = 'LOW';
  }

  return {
    totalScore,
    priorityCategory,
    breakdown: {
      threatScore,
      trappedInjuredScore,
      waitTimeScore,
      locationConfidenceScore,
      vulnerabilityBonus,
      reasons,
    },
    requiresVerification,
  };
}
