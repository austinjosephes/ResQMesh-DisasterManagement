/**
 * ResQLink Kerala — Adaptive Alert Delivery Intelligence & SMS Gateway Adapter
 * Implements provider abstraction, Indian telecom DLT compliance formatting,
 * and delivery tracking states.
 */

export interface DeliveryResult {
  success: boolean;
  providerMsgId: string;
  status: 'SUBMITTED' | 'DELIVERED' | 'FAILED';
  error?: string;
  latencyMs: number;
}

export interface NotificationProvider {
  name: string;
  send(
    recipientPhone: string,
    messageBody: string,
    metadata?: {
      dltTemplateId?: string;
      alertId?: string;
      district?: string;
      severity?: string;
    }
  ): Promise<DeliveryResult>;
}

export class SimulatedSmsAdapter implements NotificationProvider {
  name = 'SIMULATED_KERALA_TELECOM_GATEWAY';

  async send(
    recipientPhone: string,
    messageBody: string,
    metadata?: {
      dltTemplateId?: string;
      alertId?: string;
      district?: string;
      severity?: string;
    }
  ): Promise<DeliveryResult> {
    const startTime = Date.now();
    // Simulate slight network transmission delay (15-50ms)
    await new Promise((resolve) => setTimeout(resolve, 25));

    // Validate phone number format (E.164 or Indian 10-digit)
    const cleanPhone = recipientPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      return {
        success: false,
        providerMsgId: `ERR_${Date.now()}`,
        status: 'FAILED',
        error: 'INVALID_TELECOM_DESTINATION_NUMBER',
        latencyMs: Date.now() - startTime,
      };
    }

    // Realistic delivery simulation: 92% instant submission, 6% transient carrier queue, 2% unroutable/silent drop
    const random = Math.random();
    if (random > 0.05) {
      return {
        success: true,
        providerMsgId: `DLT_KER_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
        status: 'SUBMITTED', // Note: A submission is NOT treated as delivered until ACK
        latencyMs: Date.now() - startTime,
      };
    } else {
      return {
        success: false,
        providerMsgId: `FAIL_${Date.now()}`,
        status: 'FAILED',
        error: 'NETWORK_CONGESTION_TOWER_RETRYABLE',
        latencyMs: Date.now() - startTime,
      };
    }
  }
}

export const defaultSmsProvider: NotificationProvider = new SimulatedSmsAdapter();

/**
 * Validated Template Formatter meeting Indian Telecom DLT (Distributed Ledger Technology) requirements
 */
export function formatKeralaAlertSms(params: {
  area: string;
  hazardType: string;
  authority: string;
  issuedTime: string;
  expiryTime: string;
  language?: 'en' | 'ml';
}): { body: string; dltTemplateId: string } {
  if (params.language === 'ml') {
    return {
      dltTemplateId: 'DLT_KL_DISASTER_EMG_ML_1007',
      body: `റെസ്ക്യൂലിങ്ക് കേരളം: ${params.area} മേഖലയിൽ അതിതീവ്ര ${params.hazardType} മുന്നറിയിപ്പ്. വെള്ളപ്പൊക്ക/ഉരുൾപൊട്ടൽ സാധ്യത കൂടുതൽ. സുരക്ഷിത സ്ഥാനങ്ങളിലേക്ക് മാറുക. ദുരന്ത നിവാരണ നിർദ്ദേശങ്ങൾ പാലിക്കുക. ഉറവിടം: ${params.authority}. സമയം: ${params.issuedTime}. കാലാവധി: ${params.expiryTime}.`,
    };
  }

  return {
    dltTemplateId: 'DLT_KL_DISASTER_EMG_EN_1001',
    body: `RESQLINK KERALA: Urgent ${params.hazardType} warning for ${params.area}. Flooding or landslide risk may increase. Follow official safety instructions and avoid dangerous roads and slopes. Source: ${params.authority}. Issued: ${params.issuedTime}. Valid until: ${params.expiryTime}.`,
  };
}

/**
 * Calculates exponential backoff delay in milliseconds
 */
export function getRetryBackoffMs(retryCount: number): number {
  const baseMs = 2000; // 2 seconds
  const maxMs = 60000; // 1 minute max
  const jitter = Math.random() * 500;
  return Math.min(maxMs, baseMs * Math.pow(2, retryCount) + jitter);
}
