// ResQMesh Service Worker - App Shell & Emergency Guidance Offline Caching
const CACHE_NAME = 'resqmesh-cache-v1';
const PRECACHE_URLS = [
  '/',
  '/portal',
  '/portal/sos/new',
  '/portal/sos',
  '/portal/offline',
  '/portal/map',
  '/portal/identity',
  '/emergency-guidance',
  '/how-it-works',
  '/security',
  '/verify-credential',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_URLS).catch((err) => {
        console.warn('Pre-caching partial failure (likely dev mode):', err);
      });
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((name) => {
          if (name !== CACHE_NAME) {
            return caches.delete(name);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // Only handle GET requests and exclude Next.js hot reload / webpack
  if (event.request.method !== 'GET' || event.request.url.includes('/_next/webpack-hmr')) {
    return;
  }

  // Stale-while-revalidate for page navigation and cache-first for guidance
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // If offline and no cachedResponse, fallback to root or emergency-guidance
          return cachedResponse;
        });

      return cachedResponse || fetchPromise;
    })
  );
});
