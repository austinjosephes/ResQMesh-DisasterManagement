const path = require('path');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    path.join(__dirname, 'app/**/*.{js,ts,jsx,tsx,mdx}'),
    path.join(__dirname, 'components/**/*.{js,ts,jsx,tsx,mdx}'),
    path.join(__dirname, 'features/**/*.{js,ts,jsx,tsx,mdx}'),
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // ResQMesh Unified Dark Cinematic Emergency Palette
        canvas: '#07090D', // Primary background
        surface: {
          0: '#07090D',
          1: '#0B1017', // Secondary background
          2: '#101720', // Card background
          3: '#151E29', // Elevated background
          4: '#1C2736',
        },
        primary: {
          DEFAULT: '#FF6B35', // Primary accent (Aerospace Orange)
          hover: '#E85A24',
          foreground: '#07090D',
          cyan: '#38BDF8',
        },
        emergency: {
          red: '#EF4444',
          amber: '#F5A623',
          green: '#22C55E',
          cyan: '#38BDF8',
          orange: '#FF6B35',
        },
        text: {
          primary: '#F5F7FA', // Primary text
          secondary: '#929CAB', // Secondary text
          muted: '#6F7C93',
          dim: '#475569',
        },
        status: {
          valid: '#22C55E',
          warning: '#F5A623',
          revoked: '#EF4444',
          neutral: '#64748B',
        },
        border: {
          subtle: 'rgba(255, 255, 255, 0.08)',
          medium: 'rgba(255, 255, 255, 0.14)',
          strong: 'rgba(255, 255, 255, 0.22)',
        },
      },
      fontFamily: {
        sans: ['var(--font-geist-sans)', 'Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'var(--font-geist-mono)', 'monospace'],
        display: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        'glow-orange': '0 0 25px -4px rgba(255, 107, 53, 0.35)',
        'glow-cyan': '0 0 25px -4px rgba(56, 189, 248, 0.35)',
        'glow-emerald': '0 0 25px -4px rgba(34, 197, 94, 0.35)',
        'glow-ruby': '0 0 25px -4px rgba(239, 68, 68, 0.35)',
      },
    },
  },
  plugins: [],
};
