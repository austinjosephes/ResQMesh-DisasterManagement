'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldAlert,
  MapPin,
  Radio,
  Sliders,
  Users,
  Bell,
  HeartPulse,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Compass,
  LifeBuoy,
  Smartphone,
  Navigation,
  CloudRain,
  ShieldCheck,
  CheckCheck,
  Flame,
  Waves,
  RefreshCw,
  Phone,
  Layers,
  FileCheck2,
  Lock,
  Zap,
  Activity,
  Globe,
} from 'lucide-react';
import { CinematicEarth3D } from '@/components/landing/CinematicEarth3D';
import { KeralaTacticalMap } from '@/components/map/KeralaTacticalMap';
import { EmergencyNetworkGraph } from '@/components/network/EmergencyNetworkGraph';
import { ZoomingParticlesBackground3D } from '@/components/background/ZoomingParticlesBackground3D';
import {
  LiveLocationPermissionPrompt,
  LiveLocationData,
} from '@/components/location/LiveLocationPermissionPrompt';

export default function HomePage() {
  const [mapData, setMapData] = useState<{
    hazards: any[];
    households: any[];
    incidents: any[];
    rescueTeams: any[];
    shelters: any[];
  }>({
    hazards: [],
    households: [],
    incidents: [],
    rescueTeams: [],
    shelters: [],
  });
  const [metrics, setMetrics] = useState<any>(null);
  const [activeAlerts, setActiveAlerts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeStage, setActiveStage] = useState(1);
  const [activeStageName, setActiveStageName] = useState('Global Orbital Intelligence');
  const [userLiveLocation, setUserLiveLocation] = useState<LiveLocationData | null>(null);

  useEffect(() => {
    Promise.all([
      fetch('/api/admin/map-data').then((res) => (res.ok ? res.json() : null)),
      fetch('/api/admin/overview').then((res) => (res.ok ? res.json() : null)),
    ])
      .then(([mMapData, mOverview]) => {
        if (mMapData) setMapData(mMapData);
        if (mOverview) {
          setMetrics(mOverview.metrics);
          if (mOverview.activeAlerts) setActiveAlerts(mOverview.activeAlerts);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));

    // Listen for live location updates across the application
    const handleLocationUpdate = (e: any) => {
      if (e.detail) {
        setUserLiveLocation(e.detail);
      }
    };

    window.addEventListener('resqlink:location-updated', handleLocationUpdate);
    return () => {
      window.removeEventListener('resqlink:location-updated', handleLocationUpdate);
    };
  }, []);

  const handleStageChange = (stage: number, name: string) => {
    setActiveStage(stage);
    setActiveStageName(name);
  };

  return (
    <div className="relative min-h-screen bg-[#07090D] text-[#F5F7FA] font-classic selection:bg-[#FF6B35]/20 selection:text-white overflow-x-hidden">
      {/* 0. PROACTIVE REAL-TIME LIVE LOCATION PROMPT & TELEMETRY STRIP */}
      <LiveLocationPermissionPrompt
        autoPrompt={true}
        showTopBar={true}
        onLocationAcquired={(data) => setUserLiveLocation(data)}
      />

      {/* 0. 3D FLOATING PARTICLES & ZOOMING SCROLL BACKGROUND */}
      <ZoomingParticlesBackground3D particleCount={400} className="fixed inset-0 z-0" />

      {/* 1. CINEMATIC 3D EARTH HERO SECTION */}
      <section className="relative min-h-[96vh] flex flex-col justify-between overflow-hidden border-b border-white/[0.08] bg-gradient-to-b from-[#07090D]/60 via-[#0B1017]/80 to-[#07090D]">
        {/* Full-screen Cinematic 3D Earth Canvas */}
        <div className="absolute inset-0 z-0">
          <CinematicEarth3D onStageChange={handleStageChange} className="w-full h-full" />
        </div>

        {/* Atmospheric Gradient Vignette Masks */}
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#07090D] via-transparent to-[#07090D]/75 z-[1]" />
        <div className="absolute inset-0 pointer-events-none bg-radial-gradient from-transparent via-[#07090D]/30 to-[#07090D]/90 z-[1]" />

        {/* Hero Top Authority Capsule (Apple Dynamic Island Style) */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-10 flex flex-wrap items-center justify-between gap-4">
          <div className="ios-capsule shadow-xl">
            <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E] animate-ping" />
            <span className="text-[#FF6B35] font-extrabold tracking-wider text-xs">RESQMESH KERALA</span>
            <span className="text-white/30">•</span>
            <span className="text-[#929CAB] font-semibold text-xs tracking-tight">
              STATE DISASTER NETWORK • SEOC
            </span>
          </div>

          {/* Dynamic Real-Time Live Location Telemetry Pill */}
          {userLiveLocation && (
            <div className="ios-capsule shadow-xl border-[#38BDF8]/30 font-mono text-xs">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
              <span className="text-[#38BDF8] font-bold">LIVE SECTOR:</span>
              <span className="text-white font-extrabold">{userLiveLocation.sector.name}</span>
              <span className="text-[#929CAB]">({userLiveLocation.sector.districtName})</span>
              <span className="text-[#22C55E] font-bold text-[10px] bg-[#22C55E]/10 px-2 py-0.5 rounded-full">
                ±{Math.round(userLiveLocation.accuracy)}m
              </span>
            </div>
          )}
        </div>

        {/* Hero Main Copy & Actions */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
          <div className="max-w-3xl space-y-7">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-[#F5F7FA] font-headline tracking-tight leading-[1.06]">
              WHEN DISASTER STRIKES,<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] via-[#F5A623] to-[#38BDF8]">
                EVERY SECOND MATTERS.
              </span>
            </h1>

            <p className="text-base sm:text-xl text-[#929CAB] leading-relaxed font-normal max-w-2xl font-classic">
              An intelligent disaster management and emergency response network connecting <strong className="text-white font-bold">941 Grama Panchayats</strong>, authorities, and rescue teams through real-time geospatial intelligence.
            </p>

            {/* Direct iOS Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-3">
              <a
                href="#live-intelligence"
                className="ios-button-primary px-7 py-4 text-sm font-bold shadow-2xl"
              >
                <Compass className="w-4 h-4 text-[#07090D]" />
                <span className="font-extrabold">Explore Live Intelligence</span>
              </a>

              <Link
                href="/resident/dashboard"
                className="ios-button-glass px-7 py-4 text-sm font-bold shadow-xl"
              >
                <LifeBuoy className="w-4 h-4 text-[#FF6B35]" />
                <span className="font-bold">Access Emergency Portal</span>
              </Link>

              <a
                href="http://localhost:3001"
                target="_blank"
                rel="noreferrer"
                className="ios-capsule px-5 py-3.5 text-xs font-mono font-bold text-[#FF6B35] hover:text-[#F5F7FA] transition flex items-center gap-2 border-[#FF6B35]/30 shadow-lg"
              >
                <Sliders className="w-3.5 h-3.5 text-[#FF6B35]" />
                <span className="font-bold">Admin Command Website (Port 3001) →</span>
              </a>
            </div>
          </div>
        </div>

        {/* Hero Bottom Telemetry Metrics Strip (Apple iOS Frosted Glass Box) */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pb-10">
          <div className="ios-glass-card-elevated p-6 sm:p-7">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-xs">
              <div className="space-y-1">
                <div className="text-[#6F7C93] font-bold uppercase tracking-widest text-[10px] flex items-center gap-1.5">
                  <Globe className="w-3 h-3 text-[#38BDF8]" />
                  <span>JURISDICTION</span>
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-[#F5F7FA] font-classic tracking-tight">
                  All 14 Districts
                </div>
                <div className="text-[#929CAB] text-xs font-medium">
                  <strong className="text-white font-bold">152</strong> Blocks • <strong className="text-white font-bold">941</strong> Gramas
                </div>
              </div>

              <div className="space-y-1">
                <div className="text-[#6F7C93] font-bold uppercase tracking-widest text-[10px] flex items-center gap-1.5">
                  <Radio className="w-3 h-3 text-[#F5A623]" />
                  <span>CARRIER DLT SMS</span>
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-[#F5A623] font-classic tracking-tight">
                  VK-KSDMA Gateway
                </div>
                <div className="text-[#929CAB] text-xs font-medium">
                  2-Way Verified Handshake
                </div>
              </div>

              <div className="space-y-1">
                <div className="text-[#6F7C93] font-bold uppercase tracking-widest text-[10px] flex items-center gap-1.5">
                  <Lock className="w-3 h-3 text-[#38BDF8]" />
                  <span>CRYPTO INTEGRITY</span>
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-[#38BDF8] font-classic tracking-tight">
                  JOSE ES256
                </div>
                <div className="text-[#929CAB] text-xs font-medium">
                  Tamper-Proof Audit Chain
                </div>
              </div>

              <div className="space-y-1">
                <div className="text-[#6F7C93] font-bold uppercase tracking-widest text-[10px] flex items-center gap-1.5">
                  <ShieldCheck className="w-3 h-3 text-[#22C55E]" />
                  <span>NETWORK RESILIENCE</span>
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-[#22C55E] font-classic tracking-tight">
                  Offline-First
                </div>
                <div className="text-[#929CAB] text-xs font-medium">
                  Multi-Hop Survival Mesh
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. EMERGENCY RESPONSE NETWORK VISUALIZATION (Apple Glass Box) */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="ios-glass-card p-6 sm:p-8">
          <EmergencyNetworkGraph />
        </div>
      </section>

      {/* 3. INTERACTIVE KERALA GEOSPATIAL INTELLIGENCE MAP */}
      <section id="live-intelligence" className="relative z-10 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="ios-capsule text-[#FF6B35] font-bold text-xs uppercase tracking-wider mb-2">
              <Radio className="w-3.5 h-3.5 text-[#FF6B35] animate-pulse" />
              <span>GEOSPATIAL INCIDENT TELEMETRY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
              Statewide Early Warning &amp; Hazard Radar
            </h2>
            <p className="text-sm text-[#929CAB] mt-1 font-classic">
              Real-time <strong className="text-white font-bold">Point-in-Polygon</strong> spatial exposure mapping across Kerala&apos;s disaster grid.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/admin/live-map"
              className="ios-button-glass px-5 py-2.5 text-xs font-mono font-bold text-[#F5F7FA]"
            >
              <Compass className="w-4 h-4 text-[#38BDF8]" />
              <span>Full Screen Tactical Radar →</span>
            </Link>
          </div>
        </div>

        {/* Map Container (Apple Elevated Squircle Glass Box) */}
        <div className="ios-glass-card-elevated overflow-hidden p-2 sm:p-3 shadow-2xl">
          <div className="rounded-[24px] overflow-hidden">
            <KeralaTacticalMap
              height="540px"
              hazards={mapData.hazards}
              incidents={mapData.incidents}
              rescueTeams={mapData.rescueTeams}
              shelters={mapData.shelters}
              households={mapData.households}
              userLocation={
                userLiveLocation
                  ? {
                      latitude: userLiveLocation.latitude,
                      longitude: userLiveLocation.longitude,
                      label: `${userLiveLocation.sector.name} (${userLiveLocation.sector.districtName})`,
                      accuracy: userLiveLocation.accuracy,
                      source: userLiveLocation.source,
                    }
                  : null
              }
            />
          </div>
        </div>
      </section>

      {/* 4. LIVE CALAMITY BULLETINS & INCIDENT OVERVIEW (Apple Squircle Boxes) */}
      <section className="relative z-10 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="ios-capsule text-[#EF4444] font-extrabold text-[11px] uppercase tracking-wider mb-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444]" />
              <span>OFFICIAL KSDMA / IMD ACTIVE BULLETINS</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
              Active Kerala Calamity Directives
            </h3>
          </div>

          <Link
            href="/resident/alerts"
            className="ios-capsule text-xs font-mono text-[#FF6B35] font-bold hover:text-white transition flex items-center gap-1.5"
          >
            <span>View All Regional Alerts</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Wayanad Landslide Card (Apple Red Alert Box) */}
          <div className="ios-glass-card p-6 space-y-4 border-[#EF4444]/30 shadow-[inset_0_1px_1.5px_0_rgba(239,68,68,0.4),0_20px_48px_-12px_rgba(239,68,68,0.18)]">
            <div className="flex items-center justify-between">
              <span className="ios-capsule bg-[#EF4444]/15 border-[#EF4444]/40 text-[#EF4444] text-[10px] font-extrabold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#EF4444] animate-ping" />
                RED ALERT • EVACUATION
              </span>
              <span className="text-xs font-mono font-bold text-[#929CAB]">Meppadi, Wayanad</span>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-extrabold text-[#F5F7FA] tracking-tight leading-snug">
                Chooralmala &amp; Mundakkai Landslide Debris Flow
              </h4>
              <p className="text-xs text-[#929CAB] leading-relaxed">
                Extreme slope saturation in Kalpetta Block. Residents ordered to immediately move to <strong className="text-white font-bold">Meppadi Govt Higher Secondary School</strong> relief shelter.
              </p>
            </div>

            <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-mono">
              <span className="text-[#6F7C93] font-medium">VK-KSDMA Carrier SMS</span>
              <span className="text-[#22C55E] font-bold">✓ Signed JOSE ES256</span>
            </div>
          </div>

          {/* Idukki Dam Card (Apple Orange Alert Box) */}
          <div className="ios-glass-card p-6 space-y-4 border-[#F5A623]/30 shadow-[inset_0_1px_1.5px_0_rgba(245,166,35,0.4),0_20px_48px_-12px_rgba(245,166,35,0.18)]">
            <div className="flex items-center justify-between">
              <span className="ios-capsule bg-[#F5A623]/15 border-[#F5A623]/40 text-[#F5A623] text-[10px] font-extrabold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F5A623]" />
                ORANGE ALERT • DAM RELEASE
              </span>
              <span className="text-xs font-mono font-bold text-[#929CAB]">Idukki &amp; Ernakulam</span>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-extrabold text-[#F5F7FA] tracking-tight leading-snug">
                Periyar Basin Spillway Controlled Discharge
              </h4>
              <p className="text-xs text-[#929CAB] leading-relaxed">
                Cheruthoni shutter #3 raised 40cm. Water discharge ~120 cumecs. Riverside residents in <strong className="text-white font-bold">Aluva and Paravur</strong> must maintain standby readiness.
              </p>
            </div>

            <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-mono">
              <span className="text-[#6F7C93] font-medium">Inundation Zone #KZ-82</span>
              <span className="text-[#38BDF8] font-bold">Hydrology Synced</span>
            </div>
          </div>

          {/* Kuttanad Flood Watch Card (Apple Cyan Alert Box) */}
          <div className="ios-glass-card p-6 space-y-4 border-[#38BDF8]/30 shadow-[inset_0_1px_1.5px_0_rgba(56,189,248,0.4),0_20px_48px_-12px_rgba(56,189,248,0.18)]">
            <div className="flex items-center justify-between">
              <span className="ios-capsule bg-[#38BDF8]/15 border-[#38BDF8]/40 text-[#38BDF8] text-[10px] font-extrabold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8]" />
                YELLOW WATCH • LOW-LYING
              </span>
              <span className="text-xs font-mono font-bold text-[#929CAB]">Kuttanad, Alappuzha</span>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-extrabold text-[#F5F7FA] tracking-tight leading-snug">
                Pamba &amp; Achankovil River Basin Inundation
              </h4>
              <p className="text-xs text-[#929CAB] leading-relaxed">
                Water logging on AC Road. <strong className="text-white font-bold">12 community relief camps</strong> activated across Champakulam and Nedumudi panchayats.
              </p>
            </div>

            <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-mono">
              <span className="text-[#6F7C93] font-medium">Boats Deployed: 14</span>
              <span className="text-[#22C55E] font-bold">Shelters Ready</span>
            </div>
          </div>
        </div>
      </section>

      {/* 5. FOUR ENGINEERED PILLARS (Apple iOS Squircles with Beveled Icon Badges) */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 border-t border-white/[0.08]">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="ios-capsule text-[#FF6B35] font-extrabold text-xs uppercase tracking-widest">
            ARCHITECTED FOR REAL EMERGENCIES
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
            Four Core Tenets of ResQMesh
          </h2>
          <p className="text-sm text-[#929CAB] font-classic">
            Engineered specifically to solve the communication failures of catastrophic floods and landslides in Kerala.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="ios-glass-card p-7 space-y-4">
            <div className="ios-icon-squircle w-12 h-12 bg-[#FF6B35]/20 text-[#FF6B35]">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-[#F5F7FA] tracking-tight">
              Resident Risk Digital Twin
            </h3>
            <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
              Every household is mapped to its exact <strong className="text-white font-bold">Grama Panchayat</strong>, Block, and District centroid, with automatic vulnerability tracking for elderly and infants.
            </p>
          </div>

          <div className="ios-glass-card p-7 space-y-4">
            <div className="ios-icon-squircle w-12 h-12 bg-[#38BDF8]/20 text-[#38BDF8]">
              <Radio className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-[#F5F7FA] tracking-tight">
              2-Way DLT SMS Engine
            </h3>
            <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
              TRAI-compliant carrier push with <strong className="text-white font-bold">verifiable receipts</strong>. Citizens confirm safety with one tap, updating the State Command live.
            </p>
          </div>

          <div className="ios-glass-card p-7 space-y-4">
            <div className="ios-icon-squircle w-12 h-12 bg-[#EF4444]/20 text-[#EF4444]">
              <Sliders className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-[#F5F7FA] tracking-tight">
              Rescue Priority Engine
            </h3>
            <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
              Multi-factor triage algorithms rank distress calls by water ingress velocity, building hazard, <strong className="text-white font-bold">medical urgency</strong>, and camp accessibility.
            </p>
          </div>

          <div className="ios-glass-card p-7 space-y-4">
            <div className="ios-icon-squircle w-12 h-12 bg-[#22C55E]/20 text-[#22C55E]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-[#F5F7FA] tracking-tight">
              Network-Loss Survival Mode
            </h3>
            <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
              When cell towers submerge or power fails, the PWA functions <strong className="text-white font-bold">offline</strong>, queuing distress packets and synchronizing when signal flickers.
            </p>
          </div>
        </div>
      </section>

      {/* 6. DIRECT PORTAL ENTRY CALLOUTS (Elevated Apple Glass Boxes) */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Resident Portal Entry */}
          <Link
            href="/resident/dashboard"
            className="ios-glass-card-elevated p-8 space-y-5 group block"
          >
            <div className="ios-icon-squircle w-14 h-14 bg-[#FF6B35]/25 text-[#FF6B35] group-hover:scale-105 transition">
              <LifeBuoy className="w-7 h-7" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-extrabold text-[#F5F7FA] font-headline tracking-tight flex items-center justify-between">
                <span>Resident Safety Portal</span>
                <ArrowRight className="w-5 h-5 text-[#FF6B35] group-hover:translate-x-1.5 transition" />
              </h3>
              <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
                Emergency SOS broadcasts, hyper-local early warnings, <strong className="text-white font-bold">3-mode location calibration</strong>, and 2-way SMS receipt handshake.
              </p>
            </div>
          </Link>

          {/* Admin Command Center Entry */}
          <Link
            href="/admin/dashboard"
            className="ios-glass-card-elevated p-8 space-y-5 group block"
          >
            <div className="ios-icon-squircle w-14 h-14 bg-[#EF4444]/25 text-[#EF4444] group-hover:scale-105 transition">
              <Sliders className="w-7 h-7" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-extrabold text-[#F5F7FA] font-headline tracking-tight flex items-center justify-between">
                <span>State Command Center</span>
                <ArrowRight className="w-5 h-5 text-[#EF4444] group-hover:translate-x-1.5 transition" />
              </h3>
              <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
                State Emergency Operations Centre console with analytical metrics, tactical radar, <strong className="text-white font-bold">GeoJSON hazard polygons</strong>, and triage dispatch.
              </p>
            </div>
          </Link>

          {/* Rescue Battalion Console Entry */}
          <Link
            href="/rescue/dashboard"
            className="ios-glass-card-elevated p-8 space-y-5 group block"
          >
            <div className="ios-icon-squircle w-14 h-14 bg-[#F5A623]/25 text-[#F5A623] group-hover:scale-105 transition">
              <Layers className="w-7 h-7" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-extrabold text-[#F5F7FA] font-headline tracking-tight flex items-center justify-between">
                <span>Field Rescue Battalions</span>
                <ArrowRight className="w-5 h-5 text-[#F5A623] group-hover:translate-x-1.5 transition" />
              </h3>
              <p className="text-xs text-[#929CAB] leading-relaxed font-classic">
                Tactical mobile console for deployed <strong className="text-white font-bold">NDRF, Police, and Fire &amp; Rescue</strong> teams to receive dispatch orders and advance triage.
              </p>
            </div>
          </Link>
        </div>
      </section>

      {/* 7. FOOTER */}
      <footer className="relative z-10 border-t border-white/[0.08] py-10 px-4 text-center text-xs font-mono text-[#6F7C93] space-y-2">
        <p className="font-bold text-[#929CAB]">ResQMesh Kerala &bull; State Emergency Operations Centre (SEOC) &bull; Disaster Management Act 2005</p>
        <p className="text-[11px] text-[#475569]">Calibrated to 14 Revenue Districts, 152 Block Panchayats, and 941 Grama Panchayats.</p>
      </footer>
    </div>
  );
}
