'use client';

import React, { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { ShieldAlert, ExternalLink, LifeBuoy } from 'lucide-react';
import Link from 'next/link';

export default function AdminSubrouteHandoffPage() {
  const pathname = usePathname();
  const [countdown, setCountdown] = useState(3);
  const targetUrl = `http://localhost:3001${pathname}`;

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          window.location.href = targetUrl;
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [targetUrl]);

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 bg-[#07090D] font-classic">
      <div className="ios-glass-card-elevated max-w-lg w-full p-8 text-center space-y-6 border border-white/[0.15] shadow-2xl relative overflow-hidden rounded-[28px]">
        {/* Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-60 h-32 bg-[#FF6B35]/20 blur-3xl pointer-events-none rounded-full" />

        <div className="w-16 h-16 rounded-2xl bg-[#FF6B35]/15 border border-[#FF6B35]/30 flex items-center justify-center mx-auto text-[#FF6B35] shadow-lg shadow-[#FF6B35]/20">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <div className="ios-capsule text-[#FF6B35] text-[11px] font-bold uppercase tracking-wider">
            <span>SEOC DISASTER OPERATIONS SEPARATION</span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
            Admin Module Relocated
          </h2>
          <p className="text-xs text-[#929CAB] leading-relaxed max-w-sm mx-auto font-classic">
            This administrative module is now served through the dedicated <strong className="text-white font-bold">Admin Platform on Port 3001</strong>.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/[0.08] text-xs font-mono space-y-2">
          <div className="flex items-center justify-between text-[#929CAB]">
            <span>Destination:</span>
            <span className="text-[#38BDF8] font-bold truncate max-w-[220px]">{targetUrl}</span>
          </div>
          <div className="flex items-center justify-between text-[#929CAB]">
            <span>Auto-Routing in:</span>
            <span className="text-[#22C55E] font-bold">{countdown} Seconds</span>
          </div>
        </div>

        <div className="space-y-3">
          <a
            href={targetUrl}
            className="w-full ios-button-primary py-4 px-6 text-sm font-bold flex items-center justify-center gap-2 shadow-2xl cursor-pointer"
          >
            <span>Proceed to Admin Platform</span>
            <ExternalLink className="w-4 h-4 text-[#07090D]" />
          </a>

          <Link
            href="/resident/dashboard"
            className="w-full ios-button-glass py-3 px-4 text-xs font-mono font-bold text-[#929CAB] hover:text-white flex items-center justify-center gap-1.5"
          >
            <LifeBuoy className="w-3.5 h-3.5 text-[#FF6B35]" />
            <span>Stay on Citizen Safety Portal (Port 3000)</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
