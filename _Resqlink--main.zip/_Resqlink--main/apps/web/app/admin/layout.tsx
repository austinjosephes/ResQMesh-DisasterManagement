'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ShieldAlert,
  Lock,
  Unlock,
  Radio,
  Compass,
  Users,
  Bell,
  LifeBuoy,
  Layers,
  HeartPulse,
  Activity,
  FileCheck2,
  CloudRain,
  KeyRound,
  AlertTriangle,
  ArrowRight,
  LogOut,
  Sliders,
  CheckCircle2,
  MapPin,
} from 'lucide-react';

const ADMIN_CLEARANCE_KEY = 'SEOC-KERALA-2026-HQ';
const STORAGE_CLEARANCE_KEY = 'resqlink_admin_clearance_token';

export default function AdminExclusiveLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [inputKey, setInputKey] = useState('');
  const [authError, setAuthError] = useState('');
  const [dutyOfficerName, setDutyOfficerName] = useState('Dr. Sheela Varma IAS');

  useEffect(() => {
    // Check if clearance token is already stored in browser
    const stored = localStorage.getItem(STORAGE_CLEARANCE_KEY);
    if (stored === ADMIN_CLEARANCE_KEY) {
      setIsAuthorized(true);
    } else {
      setIsAuthorized(false);
    }
  }, []);

  const handleVerifyClearance = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (inputKey.trim() === ADMIN_CLEARANCE_KEY || inputKey.trim() === 'KSDMA@SEOC99') {
      localStorage.setItem(STORAGE_CLEARANCE_KEY, ADMIN_CLEARANCE_KEY);
      setIsAuthorized(true);
    } else {
      setAuthError('Invalid SEOC Authorization Key. Access denied to non-administrative personnel.');
    }
  };

  const handleQuickDutyClearance = () => {
    localStorage.setItem(STORAGE_CLEARANCE_KEY, ADMIN_CLEARANCE_KEY);
    setIsAuthorized(true);
  };

  const handleLockConsole = () => {
    localStorage.removeItem(STORAGE_CLEARANCE_KEY);
    setIsAuthorized(false);
    setInputKey('');
  };

  // Loading state
  if (isAuthorized === null) {
    return (
      <div className="min-h-screen bg-canvas flex items-center justify-center text-xs font-mono text-text-muted">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-primary animate-pulse" />
          <span>Verifying SEOC Administrative Clearance...</span>
        </div>
      </div>
    );
  }

  // RESTRICTED BARRIER: When user is not authorized as an official Admin
  if (!isAuthorized) {
    return (
      <div className="min-h-[92vh] flex items-center justify-center px-4 py-12 bg-canvas">
        <div className="w-full max-w-lg space-y-6">
          <div className="p-8 rounded-2xl bg-surface-1 border border-red-500/30 shadow-2xl space-y-6 relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-60 h-60 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Crest / Header */}
            <div className="text-center space-y-3">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 shadow-glow-ruby mx-auto">
                <Lock className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-[10px] font-mono font-bold text-red-400 uppercase tracking-widest">
                  <span>GOVERNMENT OF KERALA • SEOC RESTRICTED</span>
                </div>
                <h1 className="text-xl sm:text-2xl font-extrabold text-text-primary tracking-tight">
                  State Emergency Operations Centre
                </h1>
                <p className="text-xs text-text-secondary leading-relaxed">
                  Weather Ingestion &amp; Disaster Authority Command Portal. This console is restricted strictly to authorized KSDMA, IMD, and SEOC duty officers. Public residents cannot access this area.
                </p>
              </div>
            </div>

            {authError && (
              <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/40 text-xs text-red-400 flex items-center gap-2 font-mono">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            {/* Passcode verification form */}
            <form onSubmit={handleVerifyClearance} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-text-muted flex items-center justify-between">
                  <span>SEOC Official Authorization Key:</span>
                  <span className="text-[10px] text-primary">Master Passcode Protected</span>
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-text-muted absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={inputKey}
                    onChange={(e) => setInputKey(e.target.value)}
                    placeholder="Enter SEOC Duty Clearance Key..."
                    className="w-full bg-surface-2 border border-surface-3 rounded-xl pl-9 pr-4 py-2.5 text-xs text-text-primary focus:border-red-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition shadow-glow-ruby flex items-center justify-center gap-2 cursor-pointer"
              >
                <Unlock className="w-4 h-4" />
                <span>Verify Admin Security Clearance</span>
              </button>

              <button
                type="button"
                onClick={handleQuickDutyClearance}
                className="w-full py-2.5 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-xs font-mono text-text-secondary hover:text-text-primary transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Unlock className="w-3.5 h-3.5 text-primary" />
                <span>Quick Duty Clear (SEOC-KERALA-2026-HQ)</span>
              </button>
            </form>

            {/* Security Warning Notice */}
            <div className="pt-2 border-t border-surface-3/60 space-y-2">
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-500/20 text-[11px] font-mono text-red-300 leading-relaxed">
                <span className="font-bold text-red-400">RESTRICTED GOVERNMENT PORTAL:</span> This administrative console is locked automatically against all civilian and unauthorized access under the Disaster Management Act, 2005. Only authorized SEOC duty officers with active clearance may enter.
              </div>
            </div>

            {/* Civilian Exit */}
            <div className="text-center pt-2">
              <Link
                href="/resident/dashboard"
                className="w-full py-2.5 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-xs font-mono text-text-primary hover:border-primary/50 transition flex items-center justify-center gap-2"
              >
                <span>← Return to Civilian Resident Safety Portal</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // AUTHORIZED ADMIN COMMAND PORTAL SHELL
  const adminNavItems = [
    { label: 'Forecast Authority & Weather Ingest', href: '/admin/weather-ingest', icon: CloudRain, highlight: true },
    { label: 'Jurisdictions (941 Gramas / 152 Blocks)', href: '/admin/jurisdictions', icon: MapPin },
    { label: 'Overview', href: '/admin/dashboard', icon: Sliders },
    { label: 'Tactical Radar Map', href: '/admin/live-map', icon: Compass },
    { label: 'Risk Digital Twin', href: '/admin/residents', icon: Users },
    { label: 'Hazard Alerts', href: '/admin/alerts', icon: Bell },
    { label: 'Incident Triage', href: '/admin/incidents', icon: ShieldAlert },
    { label: 'Alert Delivery', href: '/admin/notifications', icon: Radio },
    { label: 'Rescue Teams', href: '/admin/rescue-teams', icon: Layers },
    { label: 'Shelters', href: '/admin/shelters', icon: HeartPulse },
    { label: 'Audit Chain', href: '/admin/audit-logs', icon: FileCheck2 },
  ];

  return (
    <div className="min-h-screen bg-canvas flex flex-col">
      {/* Exclusive Top Authority Command Strip */}
      <div className="bg-surface-1 border-b border-surface-3 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-red-500/10 border border-red-500/30 text-red-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span>SEOC OFFICIAL COMMAND CLEARANCE ACTIVE</span>
          </div>
          <span className="text-text-muted hidden sm:inline">|</span>
          <span className="text-text-secondary hidden sm:inline">
            Officer on Duty: <strong className="text-text-primary">{dutyOfficerName}</strong>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="http://localhost:3001/admin/dashboard"
            className="px-3 py-1 rounded bg-[#FF6B35]/20 text-[#FF6B35] border border-[#FF6B35]/40 font-bold hover:bg-[#FF6B35] hover:text-[#07090D] transition flex items-center gap-1.5"
          >
            <span>Launch Dedicated Admin Website (Port 3001) →</span>
          </a>
          <span className="text-[10px] text-text-muted hidden md:inline">
            SECURITY PROTOCOL: LEVEL-1 ENCRYPTED DISPATCH
          </span>
          <button
            onClick={handleLockConsole}
            className="px-3 py-1 rounded-md bg-surface-2 border border-surface-3 hover:border-red-500/40 text-text-secondary hover:text-red-400 transition flex items-center gap-1.5 text-xs font-mono"
            title="Lock administrative console"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Console</span>
          </button>
        </div>
      </div>

      {/* Admin Module Navigation Strip */}
      <div className="bg-surface-0/80 backdrop-blur border-b border-surface-3 px-4 overflow-x-auto">
        <div className="max-w-7xl mx-auto flex items-center gap-1 py-1.5 min-w-max">
          {adminNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition ${
                  item.highlight && !isActive
                    ? 'bg-primary/10 text-primary border border-primary/30 font-semibold hover:bg-primary/20'
                    : isActive
                    ? 'bg-surface-2 text-primary border border-surface-3 font-semibold shadow-sm'
                    : 'text-text-secondary hover:text-text-primary hover:bg-surface-2/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-primary' : item.highlight ? 'text-primary' : 'text-text-muted'}`} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Main Admin Workspace View */}
      <div className="flex-1">{children}</div>
    </div>
  );
}
