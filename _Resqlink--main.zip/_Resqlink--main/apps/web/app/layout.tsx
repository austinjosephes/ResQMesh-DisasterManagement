import './globals.css';
import type { Metadata, Viewport } from 'next';
import { ConnectivityProvider } from '@/components/shell/ConnectivityContext';
import { LanguageProvider } from '@/lib/i18n';
import { AppHeader } from '@/components/shell/AppHeader';
import { OfflineBanner } from '@/components/shell/OfflineBanner';
import { TacticalCursor } from '@/components/shell/TacticalCursor';

export const metadata: Metadata = {
  title: 'ResQLink Kerala — Predict, Reach, Rescue | Disaster Warning & Coordination Platform',
  description:
    'Kerala-focused disaster preparedness and rescue coordination platform. Resident Risk Digital Twin, Adaptive Alert Delivery Intelligence, Rescue Priority Engine, and Network-Loss Survival Mode.',
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.ico',
    apple: '/icon-192.png',
  },
};

export const viewport: Viewport = {
  themeColor: '#0B1020',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="min-h-screen bg-canvas text-text-primary antialiased selection:bg-primary/20 selection:text-primary">
        <TacticalCursor />
        <LanguageProvider>
          <ConnectivityProvider>
            <div className="flex min-h-screen flex-col">
              <AppHeader />
              <OfflineBanner />
              <main className="flex-1">{children}</main>
            </div>
          </ConnectivityProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
