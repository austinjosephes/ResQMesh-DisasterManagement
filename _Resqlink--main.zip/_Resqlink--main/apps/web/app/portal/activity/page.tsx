'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  History,
  ShieldCheck,
  LifeBuoy,
  Wifi,
  WifiOff,
  Clock,
  ArrowRight,
  Filter,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export default function UserActivityPage() {
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Generate/fetch user activity log entries
    const sampleActivities = [
      {
        id: 'act-01',
        action: 'sos.create',
        title: 'Emergency SOS Submitted',
        description: 'Distress ticket SOS-2026-4481 submitted for TRAPPED occupant in Sector 4 Collapse Zone.',
        timestamp: Date.now() - 3600 * 1000 * 2,
        status: 'SUCCESS',
        icon: LifeBuoy,
      },
      {
        id: 'act-02',
        action: 'device.key.enrolled',
        title: 'Device WebCrypto Key Pair Enrolled',
        description: 'Generated non-extractable ECDSA P-256 key pair bound to local browser IndexedDB.',
        timestamp: Date.now() - 3600 * 1000 * 4,
        status: 'SUCCESS',
        icon: ShieldCheck,
      },
      {
        id: 'act-03',
        action: 'guidance.cache',
        title: 'Emergency Guidance Pre-cached Offline',
        description: 'Earthquake, flood, and trauma life support guides stored in Service Worker cache.',
        timestamp: Date.now() - 86400 * 1000,
        status: 'SUCCESS',
        icon: CheckCircle2,
      },
      {
        id: 'act-04',
        action: 'auth.login',
        title: 'Citizen Session Authenticated',
        description: 'Session cookie initialized with HttpOnly SameSite=Lax protection.',
        timestamp: Date.now() - 86400 * 1000 * 2,
        status: 'SUCCESS',
        icon: Clock,
      },
    ];

    setActivities(sampleActivities);
    setLoading(false);
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono">
          <History className="w-4 h-4" />
          <span>IMMUTABLE AUDIT LOG &bull; USER TRAIL</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-text-primary">
          Personal Activity & Event History
        </h1>
        <p className="text-xs text-text-muted">
          Chronological audit trail of emergency requests, cryptographic signings, and gateway synchronizations.
        </p>
      </div>

      <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-4">
        {activities.map((act) => {
          const Icon = act.icon;
          return (
            <div
              key={act.id}
              className="p-4 rounded-xl bg-surface-2 border border-surface-3 flex items-start gap-4 text-xs"
            >
              <div className="w-9 h-9 rounded-lg bg-surface-1 border border-surface-3 flex items-center justify-center text-primary shrink-0 mt-0.5">
                <Icon className="w-4 h-4" />
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-text-primary text-xs">{act.title}</h3>
                  <span className="font-mono text-[10px] text-text-muted">
                    {new Date(act.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-text-secondary text-[11px] leading-relaxed">
                  {act.description}
                </p>
                <div className="pt-1 flex items-center gap-2 text-[10px] font-mono text-text-muted">
                  <span className="text-primary font-semibold">Action: {act.action}</span>
                  <span>&bull;</span>
                  <span className="text-emerald-400">Status: {act.status}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
