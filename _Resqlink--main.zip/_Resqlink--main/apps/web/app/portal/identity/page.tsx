'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Fingerprint,
  Key,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Cpu,
  Layers,
  ArrowRight,
} from 'lucide-react';
import {
  getActiveDeviceKeyInfo,
  generateAndStoreDeviceKey,
  signChallengeWithDeviceKey,
  getCachedTrustBundle,
  getCachedStatusSnapshot,
} from '@/lib/offline-store';

export default function UserPortalIdentityPage() {
  const [deviceKey, setDeviceKey] = useState<any>(null);
  const [trustBundle, setTrustBundle] = useState<any>(null);
  const [statusSnapshot, setStatusSnapshot] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [generating, setGenerating] = useState<boolean>(false);
  const [challengeNonce, setChallengeNonce] = useState<string>('challenge-' + Math.random().toString(36).substring(2, 10));
  const [deviceSignature, setDeviceSignature] = useState<string>('');
  const [signStatus, setSignStatus] = useState<string>('');

  useEffect(() => {
    loadIdentityState();
  }, []);

  const loadIdentityState = async () => {
    setLoading(true);
    try {
      const keyInfo = await getActiveDeviceKeyInfo();
      setDeviceKey(keyInfo);

      const bundle = await getCachedTrustBundle();
      setTrustBundle(bundle);

      const snapshot = await getCachedStatusSnapshot();
      setStatusSnapshot(snapshot);
    } catch (e) {
      console.warn('Error loading identity:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateKey = async () => {
    setGenerating(true);
    try {
      const newKey = await generateAndStoreDeviceKey();
      setDeviceKey({
        thumbprint: newKey.thumbprint,
        publicJwk: newKey.publicJwk,
        hasPrivateKey: true,
      });
      setDeviceSignature('');
      setSignStatus('New WebCrypto ECDSA P-256 non-extractable key pair enrolled locally.');
    } catch (e: any) {
      alert(`Key generation failed: ${e.message}`);
    } finally {
      setGenerating(false);
    }
  };

  const handleTestSignChallenge = async () => {
    try {
      const nonce = `test-nonce-${Date.now()}`;
      setChallengeNonce(nonce);
      const sig = await signChallengeWithDeviceKey(nonce);
      setDeviceSignature(sig);
      setSignStatus(`Proof-of-possession signature generated successfully via WebCrypto SubtleCrypto.sign()`);
    } catch (e: any) {
      setSignStatus(`Signing error: ${e.message}`);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono">
          <Fingerprint className="w-4 h-4" />
          <span>CRYPTOGRAPHIC DEVICE ENCLAVE &bull; WEB CRYPTO API</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-text-primary">
          Device Identity & Proof of Possession
        </h1>
        <p className="text-sm text-text-secondary max-w-3xl">
          Your browser generates and holds a non-extractable ECDSA P-256 private key in local storage. This cryptographic signature binds all offline emergency reports directly to this physical device.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Active Device Key */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-5">
            <div className="flex items-center justify-between border-b border-surface-3 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-text-primary">Device Key Pair Status</h2>
                  <p className="text-xs text-text-muted">WebCrypto P-256 Non-Extractable Key</p>
                </div>
              </div>

              <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {deviceKey ? 'ENROLLED' : 'INITIALIZING'}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[10px] font-mono uppercase text-text-muted block mb-1">
                  RFC 7638 SHA-256 Device Thumbprint (cnf)
                </span>
                <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 font-mono text-primary text-[11px] break-all">
                  {deviceKey?.thumbprint || 'Generating device thumbprint...'}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase text-text-muted block mb-1">
                  Public Key Parameters (JWK)
                </span>
                <pre className="p-3 rounded-xl bg-canvas border border-surface-3 font-mono text-[11px] text-text-secondary overflow-x-auto max-h-40">
                  {deviceKey ? JSON.stringify(deviceKey.publicJwk, null, 2) : '// No key material'}
                </pre>
              </div>

              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={handleGenerateKey}
                  disabled={generating}
                  className="px-4 py-2.5 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-primary text-xs font-semibold flex items-center gap-2 transition"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-primary ${generating ? 'animate-spin' : ''}`} />
                  <span>{generating ? 'Generating WebCrypto Key...' : 'Re-enroll Fresh Device Key'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleTestSignChallenge}
                  className="px-4 py-2.5 rounded-xl bg-primary text-canvas font-semibold text-xs flex items-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan"
                >
                  <Fingerprint className="w-3.5 h-3.5" />
                  <span>Test Local Proof-of-Possession</span>
                </button>
              </div>

              {signStatus && (
                <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 text-[11px] font-mono space-y-1">
                  <span className="text-emerald-400 block font-semibold">{signStatus}</span>
                  {deviceSignature && (
                    <div className="text-text-muted break-all text-[10px]">
                      Sig (base64url): {deviceSignature.substring(0, 48)}...
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Security Enclave & Trust Material */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <h3 className="text-xs font-bold text-text-primary flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" />
              <span>Cached Trust Anchors</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] font-mono text-text-muted uppercase">Root Trust Anchor</span>
                <p className="font-mono text-text-primary font-bold text-xs">did:resqmesh:root-ca</p>
                <p className="text-[10px] text-text-muted">Issued by Federal Emergency Trust Authority (v1.0)</p>
              </div>

              <div className="p-3.5 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] font-mono text-text-muted uppercase">Revocation Snapshot</span>
                <p className="font-mono text-emerald-400 font-bold text-xs">Snapshot #1 (Monotonic)</p>
                <p className="text-[10px] text-text-muted">Cached for offline authorization policy evaluations</p>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-3 text-xs">
            <h3 className="font-bold text-text-primary flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span>Platform Security Boundary</span>
            </h3>
            <p className="text-text-secondary text-[11px] leading-relaxed">
              In a browser environment, private keys are protected by the browser origin sandbox via Web Crypto API. On native mobile applications, ResQMesh interfaces with Android Keystore (StrongBox Keymaster) or iOS Secure Enclave for hardware-isolated signing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
