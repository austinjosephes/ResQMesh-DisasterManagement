'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  MapPin,
  AlertTriangle,
  Navigation,
  ShieldAlert,
  Compass,
  Layers,
  Clock,
  WifiOff,
  Info,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { getOfflineSOSList, getCachedIncidents, cacheIncidents } from '@/lib/offline-store';

export default function IncidentMapPage() {
  const { isEffectiveOffline } = useConnectivity();

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>({
    lat: 37.7749,
    lng: -122.4194,
  });
  const [userLocationLabel, setUserLocationLabel] = useState('Sector 4 Center (Approximate)');
  const [incidents, setIncidents] = useState<any[]>([]);
  const [sosList, setSosList] = useState<any[]>([]);
  const [selectedPin, setSelectedPin] = useState<any>(null);
  const [cachedTime, setCachedTime] = useState<string>('Cached at 2026-10-29 20:30 UTC');
  const [locating, setLocating] = useState<boolean>(false);

  useEffect(() => {
    loadMapData();
  }, [isEffectiveOffline]);

  const loadMapData = async () => {
    try {
      // 1. Fetch incidents
      if (!isEffectiveOffline) {
        const res = await fetch('/api/incidents');
        if (res.ok) {
          const data = await res.json();
          if (data.incidents && data.incidents.length > 0) {
            setIncidents(data.incidents);
            await cacheIncidents(data.incidents);
            setCachedTime(`Updated: ${new Date().toLocaleTimeString()}`);
          }
        }
      } else {
        const cached = await getCachedIncidents();
        if (cached && cached.length > 0) {
          setIncidents(cached);
        } else {
          // Fallback initial disaster sectors
          setIncidents([
            {
              id: 'inc-cascade',
              incidentCode: 'INC-2026-CASCADE',
              title: 'Sector 4 Structural Collapse & Gas Leak',
              severity: 'CATASTROPHIC',
              sector: 'Sector 4 Collapse Zone',
              latitude: 37.7749,
              longitude: -122.4194,
              radiusMeters: 750,
            },
            {
              id: 'inc-flood',
              incidentCode: 'INC-2026-FLOOD-SOUTH',
              title: 'South Canal Levee Breach',
              severity: 'SEVERE',
              sector: 'Sector 7 Riverside',
              latitude: 37.765,
              longitude: -122.412,
              radiusMeters: 1200,
            },
          ]);
        }
      }

      // 2. Fetch SOS reports
      const localSos = await getOfflineSOSList();
      setSosList(localSos);
    } catch (e) {
      console.warn('Map data load error:', e);
    }
  };

  const handleAcquireLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setUserLocationLabel(`Acquired GPS Fix: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
        setLocating(false);
      },
      (err) => {
        setUserLocationLabel('GPS access denied or timed out');
        setLocating(false);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono mb-2">
            <Compass className="w-4 h-4" />
            <span>TACTICAL DISASTER MAP &bull; OFFLINE VECTOR GRID</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            Incident Perimeters & Emergency Resources
          </h1>
          <p className="text-xs text-text-muted">
            Vectorized sector boundaries, hazard exclusion perimeters, and reported distress beacons.
          </p>
        </div>

        <button
          onClick={handleAcquireLocation}
          disabled={locating}
          className="px-4 py-2.5 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-primary text-xs font-semibold flex items-center gap-2 transition shrink-0"
        >
          <Navigation className={`w-4 h-4 text-primary ${locating ? 'animate-spin' : ''}`} />
          <span>{locating ? 'Acquiring Coordinates...' : 'Center on My Device GPS'}</span>
        </button>
      </div>

      {/* Honest Offline Warning Banner */}
      <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 flex items-start gap-3 text-xs">
        <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-text-primary">Offline Map Data Freshness Notice</p>
          <p className="text-text-muted text-[11px]">
            {cachedTime}. Commercial online map tiles require live cellular backhaul. In offline mode, ResQMesh displays vector coordinates, hazard radii, and cached incident waypoints safely without internet.
          </p>
        </div>
      </div>

      {/* Tactical Vector Map Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 p-6 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-surface-3 pb-3">
            <span className="font-mono text-xs text-primary flex items-center gap-1.5 font-bold">
              <Layers className="w-4 h-4" /> SECTOR GRID: SAN FRANCISCO DISASTER ZONE 01
            </span>
            <span className="text-[11px] font-mono text-text-muted">Scale 1:25,000</span>
          </div>

          {/* Interactive SVG Radar/Vector Grid */}
          <div className="relative w-full h-[420px] rounded-xl bg-canvas border border-surface-3 overflow-hidden flex items-center justify-center">
            {/* Grid Lines */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  'linear-gradient(to right, #55D6E8 1px, transparent 1px), linear-gradient(to bottom, #55D6E8 1px, transparent 1px)',
                backgroundSize: '40px 40px',
              }}
            />

            {/* Radar Sweep Animation */}
            <div className="absolute inset-0 pointer-events-none opacity-10 flex items-center justify-center">
              <div className="w-[380px] h-[380px] rounded-full border border-primary animate-ping" />
            </div>

            {/* SVG Elements */}
            <svg className="w-full h-full absolute inset-0">
              {/* Sector 4 Hazard Zone Circle */}
              <circle
                cx="50%"
                cy="45%"
                r="110"
                fill="rgba(239, 68, 68, 0.12)"
                stroke="#EF4444"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />
              <text x="46%" y="40%" fill="#EF4444" fontSize="10" fontFamily="monospace" fontWeight="bold">
                SECTOR 4 HOT ZONE (COLLAPSE)
              </text>

              {/* Sector 7 Flood Zone Circle */}
              <circle
                cx="68%"
                cy="65%"
                r="85"
                fill="rgba(59, 130, 246, 0.12)"
                stroke="#3B82F6"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />
              <text x="64%" y="62%" fill="#3B82F6" fontSize="10" fontFamily="monospace" fontWeight="bold">
                FLOOD SURGE PERIMETER
              </text>
            </svg>

            {/* Interactive Pins */}
            {/* User GPS Pin */}
            <div
              onClick={() =>
                setSelectedPin({
                  type: 'USER',
                  title: 'Your Device Location',
                  details: userLocationLabel,
                  status: 'ACTIVE_BEACON',
                })
              }
              className="absolute top-[48%] left-[48%] -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
            >
              <div className="w-6 h-6 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 animate-bounce">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-emerald-400 whitespace-nowrap bg-canvas/80 px-1 rounded">
                YOU
              </span>
            </div>

            {/* Incident Alpha Pin */}
            <div
              onClick={() =>
                setSelectedPin({
                  type: 'INCIDENT',
                  title: 'INC-2026-CASCADE',
                  details: 'Sector 4 Structural Collapse & Gas Leak. 750m containment radius.',
                  status: 'CATASTROPHIC HAZARD',
                })
              }
              className="absolute top-[43%] left-[52%] -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
            >
              <div className="w-7 h-7 rounded-full bg-red-500/20 border-2 border-red-500 flex items-center justify-center text-red-500 hover:scale-125 transition">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-red-400 whitespace-nowrap bg-canvas/80 px-1 rounded">
                CASCADE QUAKE
              </span>
            </div>

            {/* Incident Beta Pin */}
            <div
              onClick={() =>
                setSelectedPin({
                  type: 'INCIDENT',
                  title: 'INC-2026-FLOOD-SOUTH',
                  details: 'South Canal Levee Breach. 1200m flood warning perimeter.',
                  status: 'SEVERE FLOOD',
                })
              }
              className="absolute top-[68%] left-[70%] -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
            >
              <div className="w-7 h-7 rounded-full bg-blue-500/20 border-2 border-blue-400 flex items-center justify-center text-blue-400 hover:scale-125 transition">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-blue-400 whitespace-nowrap bg-canvas/80 px-1 rounded">
                LEVEE BREACH
              </span>
            </div>

            {/* Shelter Resource Pin */}
            <div
              onClick={() =>
                setSelectedPin({
                  type: 'RESOURCE',
                  title: 'Emergency Shelter & Triage Base',
                  details: 'Civic Center Auditorium - Stocked with clean water, emergency power, trauma supplies.',
                  status: 'OPERATIONAL',
                })
              }
              className="absolute top-[25%] left-[35%] -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
            >
              <div className="w-7 h-7 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center text-primary hover:scale-125 transition">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-mono font-bold text-primary whitespace-nowrap bg-canvas/80 px-1 rounded">
                CIVIC SHELTER #01
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 text-[11px] font-mono text-text-muted">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> My Location
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500" /> Collapse Hazard
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-400" /> Flood Breach
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-primary" /> Active Shelter
              </span>
            </div>
            <span>Click any waypoint for tactical intelligence</span>
          </div>
        </div>

        {/* Tactical Waypoint Intelligence Panel */}
        <div className="lg:col-span-4 space-y-5">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <h3 className="text-xs font-bold text-text-primary flex items-center gap-2">
              <Compass className="w-4 h-4 text-primary" />
              <span>Waypoint Intelligence</span>
            </h3>

            {!selectedPin ? (
              <div className="p-8 text-center rounded-xl bg-surface-2 border border-surface-3 text-text-muted text-xs space-y-2">
                <MapPin className="w-8 h-8 mx-auto text-surface-3" />
                <p>Click on any marker or hazard zone on the vector map to inspect situational details.</p>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-primary font-bold text-xs">
                    {selectedPin.title}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface-1 text-text-secondary uppercase">
                    {selectedPin.status}
                  </span>
                </div>

                <p className="text-text-primary text-[11px] leading-relaxed">
                  {selectedPin.details}
                </p>

                <div className="pt-2 border-t border-surface-3 text-[10px] font-mono text-text-muted flex justify-between">
                  <span>Type: {selectedPin.type}</span>
                  <span className="text-emerald-400">Cached Locally</span>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-3 text-xs">
            <h3 className="font-bold text-text-primary flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Active Hazard Exclusion Perimeters</span>
            </h3>

            <div className="space-y-2 font-mono text-[11px]">
              <div className="p-3 rounded-lg bg-surface-2 border border-surface-3 space-y-1">
                <div className="flex justify-between font-bold text-red-400">
                  <span>Sector 4 Hot Zone</span>
                  <span>750m</span>
                </div>
                <p className="text-[10px] text-text-muted">Unstable masonry, downed 12kV electrical feed lines.</p>
              </div>

              <div className="p-3 rounded-lg bg-surface-2 border border-surface-3 space-y-1">
                <div className="flex justify-between font-bold text-blue-400">
                  <span>Sector 7 Flood Surge</span>
                  <span>1200m</span>
                </div>
                <p className="text-[10px] text-text-muted">South levee breached; ground level transit prohibited.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
