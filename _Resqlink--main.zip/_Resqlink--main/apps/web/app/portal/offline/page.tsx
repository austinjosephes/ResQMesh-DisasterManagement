'use client';

import React, { useState, useEffect } from 'react';
import {
  WifiOff,
  Wifi,
  Radio,
  RefreshCw,
  Send,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  ArrowRight,
  ShieldCheck,
  Server,
  Smartphone,
  Truck,
  Activity,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import {
  getOfflineSOSList,
  getPendingOfflineEvents,
  OfflineSOSRecord,
  clearOfflineSOS,
} from '@/lib/offline-store';
import {
  VirtualMeshSimulator,
  createSignedMeshPacket,
  VirtualNode,
} from '@/lib/mesh-transport';

export default function OfflineQueueAndMeshPage() {
  const { mode, isEffectiveOffline, setSimulatedOffline } = useConnectivity();

  const [offlineSOS, setOfflineSOS] = useState<OfflineSOSRecord[]>([]);
  const [offlineEvents, setOfflineEvents] = useState<any[]>([]);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [syncLogs, setSyncLogs] = useState<string[]>([]);
  const [activeSimulationLog, setActiveSimulationLog] = useState<string[]>([]);
  const [simulatingHop, setSimulatingHop] = useState<boolean>(false);
  const [currentHopNode, setCurrentHopNode] = useState<string | null>(null);

  const simulator = VirtualMeshSimulator.getInstance();

  useEffect(() => {
    loadOfflineData();
  }, [isEffectiveOffline]);

  const loadOfflineData = async () => {
    try {
      const sosList = await getOfflineSOSList();
      setOfflineSOS(sosList);

      const events = await getPendingOfflineEvents();
      setOfflineEvents(events);
    } catch (e) {
      console.warn('Error loading offline items:', e);
    }
  };

  const handleSyncNow = async () => {
    if (isEffectiveOffline) {
      alert('Cannot sync while Offline Mode is toggled active. Turn offline mode off to synchronize with gateway.');
      return;
    }

    setSyncing(true);
    const logs: string[] = [];
    logs.push(`Initiating synchronization with Gateway at ${new Date().toLocaleTimeString()}...`);

    try {
      // Sync unsynced SOS tickets
      const unsyncedSOS = offlineSOS.filter((s) => !s.synced || s.status === 'QUEUED_LOCAL');
      logs.push(`Found ${unsyncedSOS.length} pending local emergency tickets.`);

      for (const item of unsyncedSOS) {
        logs.push(`Transmitting ticket ${item.trackingNumber} (${item.category})...`);
        const res = await fetch('/api/sos', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item),
        });

        if (res.ok) {
          logs.push(`✓ Ticket ${item.trackingNumber} acknowledged by emergency gateway.`);
        } else {
          logs.push(`⚠ Gateway returned status ${res.status} for ${item.trackingNumber}`);
        }
      }

      logs.push(`Synchronization completed successfully.`);
      await loadOfflineData();
    } catch (err: any) {
      logs.push(`Sync failed: ${err.message}`);
    } finally {
      setSyncLogs(logs);
      setSyncing(false);
    }
  };

  const handleSimulateMeshRelay = async () => {
    setSimulatingHop(true);
    setActiveSimulationLog([]);

    const packet = await createSignedMeshPacket(
      'node-citizen-01',
      'SOS_BEACON',
      {
        summary: 'Emergency Beacon Relay Test',
        timestamp: Date.now(),
        urgency: 'CRITICAL',
      }
    );

    setActiveSimulationLog((prev) => [
      ...prev,
      `[Citizen Device] Generated cryptographically hashed beacon packet: ${packet.packetId}`,
    ]);

    await simulator.simulateRelayRoute(packet, (hopNum, node, log) => {
      setCurrentHopNode(node.id);
      setActiveSimulationLog((prev) => [...prev, log]);
    });

    setSimulatingHop(false);
    setCurrentHopNode(null);
    setActiveSimulationLog((prev) => [
      ...prev,
      `[Incident Gateway] Beacon successfully delivered and recorded in gateway review queue.`,
    ]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono">
          <Radio className="w-4 h-4" />
          <span>OFFLINE ENGINE &bull; P2P RELAY TRANSPORT</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-text-primary">
          Offline Mode & Local Queue Manager
        </h1>
        <p className="text-sm text-text-secondary max-w-3xl">
          Manage local storage queues, monitor synchronization status, and simulate multi-node peer-to-peer packet hops across severed connectivity paths.
        </p>
      </div>

      {/* Network State Card */}
      <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              isEffectiveOffline
                ? 'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
            }`}
          >
            {isEffectiveOffline ? <WifiOff className="w-6 h-6" /> : <Wifi className="w-6 h-6" />}
          </div>
          <div>
            <h2 className="text-base font-bold text-text-primary flex items-center gap-2">
              <span>Current Network State:</span>
              <span className={`font-mono ${isEffectiveOffline ? 'text-amber-400' : 'text-emerald-400'}`}>
                {isEffectiveOffline ? 'OFFLINE (Severed Backhaul)' : 'ONLINE (Gateway Connected)'}
              </span>
            </h2>
            <p className="text-xs text-text-muted">
              {isEffectiveOffline
                ? 'All actions and emergency requests are preserved in IndexedDB and ready for mesh forwarding.'
                : 'Direct connection to command base server active.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setSimulatedOffline(!isEffectiveOffline)}
            className="px-4 py-2.5 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-primary text-xs font-semibold flex items-center gap-2 transition"
          >
            <Radio className="w-4 h-4 text-primary" />
            <span>{isEffectiveOffline ? 'Disable Offline Mode' : 'Simulate Offline Disconnection'}</span>
          </button>

          <button
            onClick={handleSyncNow}
            disabled={syncing || isEffectiveOffline}
            className="px-5 py-2.5 rounded-xl bg-primary text-canvas font-bold text-xs flex items-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            <span>{syncing ? 'Synchronizing...' : 'Sync Gateway Now'}</span>
          </button>
        </div>
      </div>

      {/* Mesh Relay Simulation Section (Prompt Section 11) */}
      <div className="p-6 md:p-8 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 text-[10px] font-mono uppercase tracking-wider text-primary font-bold">
              <Radio className="w-3.5 h-3.5" />
              <span>Simulated Transport Layer &bull; Multi-Node Relay</span>
            </div>
            <h3 className="text-lg font-bold text-text-primary mt-1">
              Virtual Mesh Hopping Demonstration
            </h3>
            <p className="text-xs text-text-muted">
              Demonstrates packet relay from a disconnected citizen phone through intermediate field nodes to a satellite command gateway.
            </p>
          </div>

          <button
            type="button"
            onClick={handleSimulateMeshRelay}
            disabled={simulatingHop}
            className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shrink-0 disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>{simulatingHop ? 'Relaying Packet Across Nodes...' : 'Transmit Test Mesh Packet'}</span>
          </button>
        </div>

        {/* Node Graph Visual */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {simulator.nodes.map((node) => {
            const isCurrent = currentHopNode === node.id;
            const Icon =
              node.role === 'CITIZEN'
                ? Smartphone
                : node.role === 'VOLUNTEER_RELAY'
                ? Activity
                : node.role === 'RESPONDER_AMBULANCE'
                ? Truck
                : Server;

            return (
              <div
                key={node.id}
                className={`p-4 rounded-xl border transition space-y-2 ${
                  isCurrent
                    ? 'bg-primary/20 border-primary shadow-glow-cyan animate-pulse'
                    : 'bg-surface-2 border-surface-3'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-lg bg-surface-1 border border-surface-3 flex items-center justify-center text-primary">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400">
                    {node.rssi} dBm
                  </span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-text-primary leading-tight">
                    {node.name}
                  </h4>
                  <span className="text-[10px] font-mono text-text-muted uppercase">
                    Role: {node.role}
                  </span>
                </div>

                <div className="text-[10px] font-mono text-text-secondary pt-1 border-t border-surface-3/50 flex justify-between">
                  <span>Hops to Base:</span>
                  <span className="text-primary font-bold">{node.hopsToGateway}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Simulation Hop Log */}
        {activeSimulationLog.length > 0 && (
          <div className="p-4 rounded-xl bg-canvas border border-surface-3 space-y-2 text-xs font-mono">
            <span className="text-[11px] text-primary uppercase tracking-wider block font-bold">
              Packet Hop Telemetry
            </span>
            <div className="space-y-1 text-text-secondary max-h-40 overflow-y-auto text-[11px]">
              {activeSimulationLog.map((log, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-primary">&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Queued Items List */}
      <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-5">
        <div className="flex items-center justify-between border-b border-surface-3 pb-4">
          <div>
            <h3 className="text-base font-bold text-text-primary">Locally Queued Emergency Records</h3>
            <p className="text-xs text-text-muted">Stored inside browser IndexedDB v2 store</p>
          </div>
          <span className="text-xs font-mono text-primary font-bold">
            {offlineSOS.length} tickets recorded
          </span>
        </div>

        {offlineSOS.length === 0 ? (
          <div className="py-8 text-center text-text-muted text-xs">
            No local offline records in storage.
          </div>
        ) : (
          <div className="space-y-3">
            {offlineSOS.map((sos) => (
              <div
                key={sos.trackingNumber}
                className="p-4 rounded-xl bg-surface-2 border border-surface-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-primary font-bold">
                      {sos.trackingNumber}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface-1 text-text-primary uppercase">
                      {sos.category}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        sos.synced
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-amber-500/10 text-amber-400'
                      }`}
                    >
                      {sos.synced ? 'SYNCHRONIZED' : 'PENDING SYNC'}
                    </span>
                  </div>
                  <p className="text-text-secondary text-[11px] line-clamp-1">
                    {sos.description}
                  </p>
                </div>

                <div className="text-[11px] font-mono text-text-muted text-right">
                  <span>{new Date(sos.createdAt).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
