'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  LifeBuoy,
  AlertTriangle,
  MapPin,
  RefreshCw,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Radio,
  WifiOff,
  User,
  HeartPulse,
  Share2,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { getOfflineSOSList, updateOfflineSOSStatus } from '@/lib/offline-store';

export default function SOSDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string;
  const { isEffectiveOffline } = useConnectivity();

  const [request, setRequest] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [updating, setUpdating] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    loadRequest();
  }, [id, isEffectiveOffline]);

  const loadRequest = async () => {
    setLoading(true);
    setError('');
    try {
      // 1. Try local IndexedDB first
      const localList = await getOfflineSOSList();
      const localMatch = localList.find((r) => r.trackingNumber === id);
      if (localMatch) {
        setRequest(localMatch);
      }

      // 2. If online or to get latest updates, fetch from server
      if (!isEffectiveOffline) {
        const res = await fetch(`/api/sos/${id}`);
        if (res.ok) {
          const data = await res.json();
          if (data.request) {
            setRequest(data.request);
          }
        }
      }
    } catch (e: any) {
      console.warn('Error fetching request:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkResolved = async () => {
    if (!confirm('Are you sure you want to mark this emergency request as Resolved / Safe?')) return;
    setUpdating(true);
    try {
      await updateOfflineSOSStatus(request.trackingNumber, 'RESOLVED');

      if (!isEffectiveOffline) {
        await fetch(`/api/sos/${request.trackingNumber}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'RESOLVED' }),
        });
      }

      setRequest((prev: any) => ({ ...prev, status: 'RESOLVED' }));
    } catch (e) {
      alert('Error updating status');
    } finally {
      setUpdating(false);
    }
  };

  const timelineSteps = [
    { key: 'QUEUED_LOCAL', label: 'Ticket Created & Queued Locally' },
    { key: 'RECEIVED', label: 'Ingested by Emergency Gateway' },
    { key: 'VERIFIED', label: 'Verified by Field Commander' },
    { key: 'ASSIGNED', label: 'Responder Dispatched' },
    { key: 'RESOLVED', label: 'Incident Safely Resolved' },
  ];

  const getStepState = (stepKey: string, currentStatus: string) => {
    const order = ['QUEUED_LOCAL', 'RECEIVED', 'VERIFIED', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED'];
    const currentIndex = order.indexOf(currentStatus);
    const stepIndex = order.indexOf(stepKey);

    if (currentStatus === 'RESOLVED') return 'completed';
    if (currentIndex >= stepIndex) return 'completed';
    if (currentIndex === stepIndex - 1) return 'active';
    return 'pending';
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center text-xs text-text-muted">
        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-primary mb-2" />
        <p>Loading emergency ticket {id}...</p>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <AlertTriangle className="w-10 h-10 mx-auto text-amber-400" />
        <h2 className="text-lg font-bold text-text-primary">Emergency Request Not Found</h2>
        <p className="text-xs text-text-muted">Ticket reference &apos;{id}&apos; was not found in local memory or on the gateway.</p>
        <Link href="/portal/sos" className="text-xs text-primary hover:underline font-mono">
          &larr; Return to SOS Registry
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link
            href="/portal/sos"
            className="text-xs text-text-muted hover:text-primary transition font-mono flex items-center gap-1 mb-2"
          >
            &larr; Back to Requests
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-text-primary font-mono">
              {request.trackingNumber}
            </h1>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded bg-surface-2 border border-surface-3 text-primary uppercase font-bold">
              {request.category}
            </span>
            {request.immediateDanger && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-red-950/60 border border-red-800/40 text-red-300 font-bold uppercase">
                LIFE THREAT
              </span>
            )}
          </div>
        </div>

        {request.status !== 'RESOLVED' && (
          <button
            onClick={handleMarkResolved}
            disabled={updating}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-2 transition shadow-lg shrink-0"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Mark as Safe / Resolved</span>
          </button>
        )}
      </div>

      {/* Actual Truthful Status Banner */}
      <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono uppercase text-text-muted">Lifecycle Verification State</span>
          <span className="text-xs font-mono text-text-secondary">
            Priority: <strong className="text-primary">{request.priority || 'MEDIUM'}</strong>
          </span>
        </div>

        {/* Step Progression Timeline */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 pt-2">
          {timelineSteps.map((step) => {
            const state = getStepState(step.key, request.status);
            return (
              <div
                key={step.key}
                className={`p-3 rounded-xl border text-center space-y-1 transition ${
                  state === 'completed'
                    ? 'bg-primary/10 border-primary/40 text-primary'
                    : state === 'active'
                    ? 'bg-amber-950/20 border-amber-500/40 text-amber-300 animate-pulse'
                    : 'bg-surface-2 border-surface-3 text-text-muted opacity-50'
                }`}
              >
                <span className="text-[10px] font-mono block">
                  {state === 'completed' ? '✓' : state === 'active' ? '●' : '○'}
                </span>
                <p className="text-[11px] font-semibold leading-tight">{step.label}</p>
              </div>
            );
          })}
        </div>

        {/* Status Meaning Explanation */}
        <div className="p-3.5 rounded-xl bg-surface-2 border border-surface-3 text-xs text-text-secondary flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-text-primary text-[11px]">ResQMesh Verification Truthfulness Policy</p>
            <p className="text-[11px] text-text-muted mt-0.5">
              {request.status === 'ASSIGNED' || request.status === 'IN_PROGRESS'
                ? 'A verified field responder credential has been dispatched to this coordinate.'
                : request.status === 'QUEUED_LOCAL'
                ? 'Your request is safely queued on your device and waiting for mesh relay hop or network connectivity.'
                : 'Your distress request has been ingested into the incident database and is pending responder assignment.'}
            </p>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Situation Details */}
        <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4 text-xs">
          <h2 className="font-bold text-text-primary text-sm border-b border-surface-3 pb-3">
            Situation Summary
          </h2>

          <div className="space-y-3">
            <div>
              <span className="text-text-muted text-[11px] block">Description:</span>
              <p className="text-text-primary mt-1 leading-relaxed bg-surface-2 p-3 rounded-xl border border-surface-3">
                {request.description}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
              <div className="p-2.5 rounded-lg bg-surface-2 border border-surface-3">
                <span className="text-text-muted block text-[10px]">People Count:</span>
                <span className="font-bold text-text-primary">{request.peopleCount || 1}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-surface-2 border border-surface-3">
                <span className="text-text-muted block text-[10px]">Injuries:</span>
                <span className={`font-bold ${request.hasInjuries ? 'text-red-400' : 'text-emerald-400'}`}>
                  {request.hasInjuries ? 'YES' : 'NONE'}
                </span>
              </div>
            </div>

            {request.accessibilityNeeds && (
              <div>
                <span className="text-text-muted text-[11px] block">Accessibility / Medical Needs:</span>
                <p className="text-text-primary mt-1 bg-surface-2 p-2.5 rounded-lg border border-surface-3 text-[11px]">
                  {request.accessibilityNeeds}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Location & Responder Notes */}
        <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4 text-xs">
          <h2 className="font-bold text-text-primary text-sm border-b border-surface-3 pb-3">
            Location & Dispatch Updates
          </h2>

          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
              <span className="text-text-muted text-[10px] font-mono uppercase block flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-primary" /> Target Location
              </span>
              <p className="text-text-primary font-medium text-xs">
                {request.address || 'No street address specified'}
              </p>
              {request.latitude && request.longitude && (
                <p className="font-mono text-[11px] text-primary">
                  GPS: {request.latitude.toFixed(5)}, {request.longitude.toFixed(5)}
                </p>
              )}
            </div>

            <div className="p-3.5 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
              <span className="text-text-muted text-[10px] font-mono uppercase block flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-primary" /> Verified Responder Notes
              </span>
              <p className="text-text-primary text-[11px] leading-relaxed italic">
                {request.responderNotes || 'No responder notes recorded yet. Dispatch queue active.'}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 flex items-center justify-between text-[11px] font-mono">
              <span className="text-text-muted">Transport Signaling:</span>
              <span className="text-primary font-bold">{request.contactPreference || 'MESH'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
