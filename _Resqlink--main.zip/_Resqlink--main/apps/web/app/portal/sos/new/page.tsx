'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  AlertTriangle,
  LifeBuoy,
  MapPin,
  Users,
  HeartPulse,
  Flame,
  Waves,
  UserX,
  HelpCircle,
  Radio,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  WifiOff,
  Navigation,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { useI18n } from '@/lib/i18n';
import { storeOfflineSOS, OfflineSOSRecord } from '@/lib/offline-store';

export default function NewSOSRequestPage() {
  const router = useRouter();
  const { isEffectiveOffline } = useConnectivity();
  const { t } = useI18n();

  const [category, setCategory] = useState<string>('MEDICAL');
  const [description, setDescription] = useState<string>('');
  const [peopleCount, setPeopleCount] = useState<number>(1);
  const [hasInjuries, setHasInjuries] = useState<boolean>(false);
  const [immediateDanger, setImmediateDanger] = useState<boolean>(false);
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [address, setAddress] = useState<string>('');
  const [accessibilityNeeds, setAccessibilityNeeds] = useState<string>('');
  const [contactPreference, setContactPreference] = useState<string>('MESH');

  const [locating, setLocating] = useState<boolean>(false);
  const [locationStatus, setLocationStatus] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus('Geolocation is not supported by your browser');
      return;
    }

    setLocating(true);
    setLocationStatus('Acquiring satellite / device GPS fix...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
        setLocationStatus(
          `GPS Acquired: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)} (±${Math.round(pos.coords.accuracy)}m)`
        );
        setLocating(false);
      },
      (err) => {
        setLocationStatus(`GPS unavailable: ${err.message}. Please enter address or landmark manually.`);
        setLocating(false);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!description.trim()) {
      setError('Please provide a brief description of the emergency');
      return;
    }

    setSubmitting(true);

    const trackingNumber = `SOS-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const sosPayload: OfflineSOSRecord = {
      trackingNumber,
      category,
      description: description.trim(),
      peopleCount: Number(peopleCount) || 1,
      hasInjuries,
      immediateDanger,
      latitude,
      longitude,
      address: address.trim() || null,
      accessibilityNeeds: accessibilityNeeds.trim() || null,
      contactPreference,
      status: isEffectiveOffline ? 'QUEUED_LOCAL' : 'RECEIVED',
      priority: immediateDanger ? 'CRITICAL' : hasInjuries ? 'HIGH' : 'MEDIUM',
      createdAt: Date.now(),
      synced: !isEffectiveOffline,
    };

    try {
      // 1. Always store locally in IndexedDB first (Offline-First guarantee)
      await storeOfflineSOS(sosPayload);

      // 2. If online, send to backend API
      if (!isEffectiveOffline) {
        const res = await fetch('/api/sos', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(sosPayload),
        });

        if (!res.ok) {
          console.warn('Backend rejected online SOS; retained in local IndexedDB store');
        }
      }

      // Route to view ticket
      router.push(`/portal/sos/${trackingNumber}`);
    } catch (err: any) {
      setError(err.message || 'Error recording emergency request');
    } finally {
      setSubmitting(false);
    }
  };

  const categories = [
    { id: 'MEDICAL', label: t.emergency.categories.MEDICAL, icon: HeartPulse, color: 'text-red-400' },
    { id: 'FLOOD', label: t.emergency.categories.FLOOD, icon: Waves, color: 'text-blue-400' },
    { id: 'FIRE', label: t.emergency.categories.FIRE, icon: Flame, color: 'text-amber-400' },
    { id: 'TRAPPED', label: t.emergency.categories.TRAPPED, icon: LifeBuoy, color: 'text-purple-400' },
    { id: 'MISSING', label: t.emergency.categories.MISSING, icon: UserX, color: 'text-orange-400' },
    { id: 'OTHER', label: t.emergency.categories.OTHER, icon: HelpCircle, color: 'text-text-muted' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <Link
          href="/portal"
          className="text-xs text-text-muted hover:text-primary transition font-mono flex items-center gap-1"
        >
          &larr; Return to Portal Overview
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-text-primary">
              Submit Emergency SOS Request
            </h1>
            <p className="text-xs text-text-muted">
              {isEffectiveOffline
                ? 'Offline Mode Active: Your request will be queued locally and broadcast over local mesh transport.'
                : 'Direct Gateway Submission: Real-time relay to incident dispatch and active responders.'}
            </p>
          </div>
        </div>
      </div>

      {isEffectiveOffline && (
        <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 flex items-start gap-3">
          <WifiOff className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-200/90 space-y-1">
            <p className="font-semibold text-amber-300">Offline Assurance Active</p>
            <p>
              Your emergency SOS is cryptographically saved to device IndexedDB. It will not be lost if your phone turns off or reloads, and will automatically synchronize when connection to an emergency relay or gateway is restored.
            </p>
          </div>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 md:p-8 rounded-2xl bg-surface-1 border border-surface-3 space-y-6 shadow-2xl">
        {error && (
          <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/40 text-red-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* 1. Category Selection */}
        <div className="space-y-3">
          <label className="block text-xs font-semibold text-text-primary uppercase tracking-wider font-mono">
            1. Select Emergency Category *
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isSelected = category === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition ${
                    isSelected
                      ? 'bg-primary/10 border-primary shadow-glow-cyan text-text-primary'
                      : 'bg-surface-2 hover:bg-surface-3 border-surface-3 text-text-secondary'
                  }`}
                >
                  <Icon className={`w-5 h-5 shrink-0 ${cat.color}`} />
                  <div>
                    <p className="text-xs font-bold leading-tight">{cat.label}</p>
                    <span className="text-[10px] text-text-muted font-mono">{cat.id}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Emergency Description */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-text-primary uppercase tracking-wider font-mono">
            2. Situation Description *
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            required
            placeholder="Describe what happened, what obstacles exist (blocked doors, water depth, smoke), and what immediate help is required..."
            className="w-full p-3 rounded-xl bg-surface-2 border border-surface-3 text-text-primary text-xs focus:outline-none focus:border-primary transition"
          />
        </div>

        {/* 3. Triage & Danger Flags */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-surface-3 pt-6">
          <div>
            <label className="block text-xs font-semibold text-text-primary mb-1.5 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-primary" />
              <span>People Affected</span>
            </label>
            <input
              type="number"
              min={1}
              max={100}
              value={peopleCount}
              onChange={(e) => setPeopleCount(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary font-mono text-xs focus:outline-none focus:border-primary"
            />
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-surface-2 border border-surface-3">
            <input
              type="checkbox"
              id="injuries"
              checked={hasInjuries}
              onChange={(e) => setHasInjuries(e.target.checked)}
              className="w-4 h-4 accent-primary rounded cursor-pointer"
            />
            <label htmlFor="injuries" className="text-xs font-semibold text-text-primary cursor-pointer">
              Injuries Reported
              <span className="block text-[10px] text-text-muted font-normal">Cuts, fractures, burns, shock</span>
            </label>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-red-950/20 border border-red-500/30">
            <input
              type="checkbox"
              id="danger"
              checked={immediateDanger}
              onChange={(e) => setImmediateDanger(e.target.checked)}
              className="w-4 h-4 accent-red-500 rounded cursor-pointer"
            />
            <label htmlFor="danger" className="text-xs font-semibold text-red-300 cursor-pointer">
              Immediate Life Threat
              <span className="block text-[10px] text-red-200/70 font-normal">Rapidly rising water, collapse</span>
            </label>
          </div>
        </div>

        {/* 4. Location Details */}
        <div className="space-y-3 border-t border-surface-3 pt-6">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-semibold text-text-primary uppercase tracking-wider font-mono">
              4. Location & Access Information
            </label>
            <button
              type="button"
              onClick={handleGetLocation}
              disabled={locating}
              className="text-xs text-primary hover:underline flex items-center gap-1.5 font-mono"
            >
              <Navigation className={`w-3.5 h-3.5 ${locating ? 'animate-spin' : ''}`} />
              <span>{locating ? 'Acquiring GPS...' : 'Use Device GPS'}</span>
            </button>
          </div>

          {locationStatus && (
            <p className="text-[11px] font-mono text-emerald-400 bg-surface-2 p-2 rounded-lg border border-surface-3">
              {locationStatus}
            </p>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-text-secondary text-[11px] mb-1">Street Address / Landmark</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. 742 Mission Blvd, Unit 2B, near City Park"
                className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary text-xs focus:outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="block text-text-secondary text-[11px] mb-1">Accessibility / Medical Needs</label>
              <input
                type="text"
                value={accessibilityNeeds}
                onChange={(e) => setAccessibilityNeeds(e.target.value)}
                placeholder="e.g. Wheelchair user, oxygen dependency, infant..."
                className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary text-xs focus:outline-none focus:border-primary"
              />
            </div>
          </div>
        </div>

        {/* 5. Contact Preference */}
        <div className="space-y-2 border-t border-surface-3 pt-6">
          <label className="block text-xs font-semibold text-text-primary uppercase tracking-wider font-mono">
            5. Contact / Signaling Preference
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'MESH', label: t.emergency.contactOptions.mesh },
              { id: 'SMS', label: t.emergency.contactOptions.sms },
              { id: 'RADIO', label: t.emergency.contactOptions.radio },
              { id: 'IN_PERSON', label: t.emergency.contactOptions.inPerson },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setContactPreference(opt.id)}
                className={`p-2.5 rounded-xl border text-left text-xs transition ${
                  contactPreference === opt.id
                    ? 'bg-surface-2 border-primary text-primary font-semibold'
                    : 'bg-surface-2 border-surface-3 text-text-secondary hover:text-text-primary'
                }`}
              >
                <span className="block font-mono text-[10px] text-text-muted">{opt.id}</span>
                <span className="leading-tight text-[11px] block">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 border-t border-surface-3 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-text-muted">
            By clicking submit, your distress ticket and approximate coordinates will be broadcast to emergency responders.
          </p>

          <button
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-red-900/30 disabled:opacity-50"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>{submitting ? 'Recording Ticket...' : 'Confirm & Transmit Emergency SOS'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
