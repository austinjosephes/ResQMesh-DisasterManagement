'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  LifeBuoy,
  AlertTriangle,
  MapPin,
  RefreshCw,
  WifiOff,
  CheckCircle2,
  Clock,
  ArrowRight,
  Filter,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { useI18n } from '@/lib/i18n';
import { getOfflineSOSList } from '@/lib/offline-store';

export default function SOSListPage() {
  const { isEffectiveOffline } = useConnectivity();
  const { t } = useI18n();

  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('ALL');

  useEffect(() => {
    fetchRequests();
  }, [isEffectiveOffline]);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      let serverRequests: any[] = [];
      if (!isEffectiveOffline) {
        const res = await fetch('/api/sos');
        if (res.ok) {
          const data = await res.json();
          serverRequests = data.requests || [];
        }
      }

      // Merge with IndexedDB offline stored tickets
      const localRequests = await getOfflineSOSList();
      const combined = [...localRequests, ...serverRequests];

      // Deduplicate by trackingNumber
      const map = new Map();
      for (const req of combined) {
        map.set(req.trackingNumber, req);
      }

      setRequests(Array.from(map.values()));
    } catch (e) {
      console.warn('Error loading SOS list:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (filter === 'ALL') return true;
    if (filter === 'ACTIVE') return r.status !== 'RESOLVED';
    if (filter === 'RESOLVED') return r.status === 'RESOLVED';
    return r.status === filter;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'QUEUED_LOCAL':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <WifiOff className="w-3 h-3" /> Queued Locally
          </span>
        );
      case 'RECEIVED':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
            Received by Gateway
          </span>
        );
      case 'VERIFIED':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            Verified by Responder
          </span>
        );
      case 'ASSIGNED':
      case 'IN_PROGRESS':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-primary/20 text-primary border border-primary/40 font-bold flex items-center gap-1">
            <RefreshCw className="w-3 h-3 animate-spin" /> Rescue Team Dispatched
          </span>
        );
      case 'RESOLVED':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Resolved / Safe
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-surface-3 text-text-muted">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono mb-2">
            <LifeBuoy className="w-4 h-4" />
            <span>SOS DISPATCH REGISTRY</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            My Emergency SOS Requests
          </h1>
          <p className="text-xs text-text-muted">
            Track status updates, verified responder assignments, and triage notes.
          </p>
        </div>

        <Link
          href="/portal/sos/new"
          className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-red-900/30 shrink-0"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>New SOS Request</span>
        </Link>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-3 pb-3 text-xs">
        <span className="text-text-muted flex items-center gap-1 mr-2 font-mono">
          <Filter className="w-3.5 h-3.5" /> Filter:
        </span>
        {['ALL', 'ACTIVE', 'QUEUED_LOCAL', 'ASSIGNED', 'RESOLVED'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg font-mono text-[11px] transition ${
              filter === f
                ? 'bg-primary text-canvas font-bold'
                : 'bg-surface-2 hover:bg-surface-3 text-text-secondary border border-surface-3'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {loading ? (
          <div className="py-12 text-center text-text-muted text-xs">Loading requests...</div>
        ) : filteredRequests.length === 0 ? (
          <div className="py-16 text-center rounded-2xl bg-surface-1 border border-surface-3 text-text-muted text-xs space-y-3">
            <LifeBuoy className="w-10 h-10 mx-auto text-surface-3" />
            <p className="text-sm font-semibold text-text-primary">No emergency requests found matching &apos;{filter}&apos;</p>
            <p>If you require immediate help, use the New SOS Request button.</p>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <Link
              key={req.trackingNumber || req.id}
              href={`/portal/sos/${req.trackingNumber || req.id}`}
              className="p-5 rounded-2xl bg-surface-1 hover:bg-surface-2 border border-surface-3 block transition group space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-sm font-bold text-primary">
                    {req.trackingNumber}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded bg-surface-2 border border-surface-3 font-semibold text-text-primary uppercase">
                    {req.category}
                  </span>
                  {req.immediateDanger && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-red-950/60 border border-red-800/40 text-red-300 font-bold uppercase">
                      CRITICAL DANGER
                    </span>
                  )}
                </div>
                {getStatusBadge(req.status)}
              </div>

              <p className="text-xs text-text-primary leading-relaxed">
                {req.description}
              </p>

              <div className="pt-2 border-t border-surface-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-text-muted font-mono">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-primary" />
                    {req.address || (req.latitude ? `${req.latitude.toFixed(4)}, ${req.longitude.toFixed(4)}` : 'Location not pinned')}
                  </span>
                  <span>{req.peopleCount || 1} people affected</span>
                </div>
                <span className="group-hover:text-primary transition flex items-center gap-1">
                  Inspect Timeline & Responder Notes <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
