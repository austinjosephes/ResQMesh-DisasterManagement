'use client';

import React from 'react';
import Link from 'next/link';
import { ShieldCheck, Lock, MapPin, Eye, FileText, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-12">
      <div className="space-y-3">
        <span className="px-3 py-1 rounded-full text-xs font-mono uppercase bg-primary/10 text-primary border border-primary/20">
          Responsible Data Governance &amp; Ethics
        </span>
        <h1 className="text-3xl md:text-4xl font-extrabold text-text-primary">
          Privacy &amp; Location Data Handling Policy
        </h1>
        <p className="text-sm text-text-secondary leading-relaxed">
          ResQLink Kerala is designed with privacy-by-design principles, complying with the Digital
          Personal Data Protection (DPDP) Act 2023. We treat location and vulnerability data as critical,
          sensitive emergency assets.
        </p>
      </div>

      <div className="space-y-8 text-xs leading-relaxed text-text-secondary">
        {/* Section 1 */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-3">
          <div className="flex items-center gap-2 text-primary">
            <Lock className="w-4 h-4" />
            <h2 className="text-sm font-bold text-text-primary">1. No Continuous Background Tracking</h2>
          </div>
          <p>
            The platform does not engage in real-time or passive background GPS tracking. Your live
            device location is requested strictly through standard browser/system permission prompts
            only at the precise moment you tap &quot;Acquire Device GPS Position&quot; during an Emergency SOS submission.
          </p>
        </div>

        {/* Section 2 */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-3">
          <div className="flex items-center gap-2 text-emerald-400">
            <MapPin className="w-4 h-4" />
            <h2 className="text-sm font-bold text-text-primary">2. Registered Home Location vs Device Position</h2>
          </div>
          <p>
            We strictly differentiate between your <strong>Registered Residential Address</strong>
            (used exclusively for Resident Risk Digital Twin exposure estimates) and your{' '}
            <strong>Current Device Incident Position</strong> (used exclusively by dispatched rescue units
            to navigate to your rescue coordinates).
          </p>
        </div>

        {/* Section 3 */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-3">
          <div className="flex items-center gap-2 text-amber-400">
            <Eye className="w-4 h-4" />
            <h2 className="text-sm font-bold text-text-primary">3. Public Map Anonymization</h2>
          </div>
          <p>
            Public maps and aggregate dashboard indicators display heatmaps and statistical exposure counts.
            Identifiable personal names, exact house door numbers, and mobile phone contacts are never exposed
            to public viewers. Only authenticated, authorized district coordinators and designated rescue team
            leaders have access to operational contact details.
          </p>
        </div>

        {/* Section 4 */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-3">
          <div className="flex items-center gap-2 text-primary">
            <FileText className="w-4 h-4" />
            <h2 className="text-sm font-bold text-text-primary">4. Voluntary Evacuation Support Disclosures</h2>
          </div>
          <p>
            Information concerning household size, infants, wheelchair mobility needs, or oxygen cylinder
            dependence is collected on a strictly voluntary consent basis. This data is utilized solely for
            evacuation asset planning (e.g. dispatching a stretcher or 4x4 ambulance rather than a standard truck).
          </p>
        </div>

        {/* Section 5 */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-3">
          <div className="flex items-center gap-2 text-blue-400">
            <ShieldCheck className="w-4 h-4" />
            <h2 className="text-sm font-bold text-text-primary">5. Consent Management &amp; Data Deletion</h2>
          </div>
          <p>
            Residents can update their registered location coordinates, revoke emergency SMS delivery consent,
            or delete their account profile at any time through their Resident Profile settings.
          </p>
        </div>
      </div>

      <div className="flex items-center justify-between p-4 rounded-xl bg-surface-2 border border-surface-3">
        <span className="text-xs text-text-muted">Questions regarding disaster data handling?</span>
        <Link
          href="/admin/dashboard"
          className="text-xs text-primary font-mono hover:underline flex items-center gap-1 font-semibold"
        >
          <span>View Command Dashboard</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
