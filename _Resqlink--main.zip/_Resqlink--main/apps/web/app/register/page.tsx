'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ShieldAlert,
  User,
  Mail,
  Lock,
  Phone,
  MapPin,
  Users,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Compass,
  HeartPulse,
  Radio,
  RefreshCw,
  Sliders,
  Check,
  ChevronDown,
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { KERALA_DISTRICTS, findNearestKeralaDistrict } from '@/lib/geospatial';

type AutoStage = 'ACQUIRING_GPS' | 'MATCHING_SECTOR' | 'REGISTERING' | 'SUCCESS' | 'PERMISSION_BLOCKED' | 'ERROR';

export default function RegisterPage() {
  const router = useRouter();
  const { t } = useI18n();

  // Mode: Automatic GPS (default) vs Manual form
  const [isManualMode, setIsManualMode] = useState(false);

  // Auto-registration state machine
  const [stage, setStage] = useState<AutoStage>('ACQUIRING_GPS');
  const [telemetry, setTelemetry] = useState<{
    latitude: number | null;
    longitude: number | null;
    accuracy: number | null;
    district: string;
    localBody: string;
    accountRef: string;
  }>({
    latitude: null,
    longitude: null,
    accuracy: null,
    district: 'Wayanad',
    localBody: 'Meppadi Grama Panchayat',
    accountRef: '',
  });

  const [statusMessage, setStatusMessage] = useState('Accessing device coordinates automatically...');
  const [errorMessage, setErrorMessage] = useState('');
  const hasTriggeredRef = useRef(false);

  // Manual Form States
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+91');
  const [password, setPassword] = useState('');
  const [preferredLanguage, setPreferredLanguage] = useState<'en' | 'ml'>('en');
  const [district, setDistrict] = useState('Wayanad');
  const [localBody, setLocalBody] = useState('Meppadi Grama Panchayat');
  const [ward, setWard] = useState('Ward 10');
  const [address, setAddress] = useState('');
  const [manualLat, setManualLat] = useState(11.5545);
  const [manualLng, setManualLng] = useState(76.1285);
  const [householdSize, setHouseholdSize] = useState(4);
  const [hasElderly, setHasElderly] = useState(false);
  const [hasInfants, setHasInfants] = useState(false);
  const [requiresEvacuationAssist, setRequiresEvacuationAssist] = useState(false);
  const [medicalNeedsSummary, setMedicalNeedsSummary] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [consentLocation, setConsentLocation] = useState(true);
  const [consentSms, setConsentSms] = useState(true);
  const [isSubmittingManual, setIsSubmittingManual] = useState(false);

  // Automatically execute registration using acquired coordinates
  const executeAutoRegistration = async (lat: number, lng: number, acc: number, distName: string, lb: string) => {
    setStage('REGISTERING');
    setStatusMessage(`Registering household in ${distName} into Kerala Digital Twin...`);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          autoRegister: true,
          latitude: lat,
          longitude: lng,
          accuracy: acc,
          district: distName,
          localBody: lb,
          ward: 'Sector 01',
          autoDetectDistrict: true,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setStage('SUCCESS');
        setTelemetry((prev) => ({
          ...prev,
          latitude: lat,
          longitude: lng,
          accuracy: acc,
          district: distName,
          localBody: lb,
          accountRef: data.user?.email || 'Authenticated Resident',
        }));
        setStatusMessage('Registration complete! Synchronized with SEOC Kerala.');

        // Seamless redirect to resident dashboard
        setTimeout(() => {
          router.push('/resident/dashboard');
        }, 1200);
      } else {
        setStage('ERROR');
        setErrorMessage(data.error || 'Auto-registration failed. You can proceed manually.');
      }
    } catch (err: any) {
      setStage('ERROR');
      setErrorMessage(err.message || 'Network error during auto-registration.');
    }
  };

  // Automatic Location Acquisition on Mount
  const startAutoLocationAccess = () => {
    setStage('ACQUIRING_GPS');
    setErrorMessage('');
    setStatusMessage('Querying device GPS sensors & Kerala Geospatial Grid...');

    if (typeof window === 'undefined' || !navigator.geolocation) {
      setStage('PERMISSION_BLOCKED');
      setStatusMessage('Geolocation API not supported by browser. Choose sector below.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        const acc = Math.round(pos.coords.accuracy || 5);

        setStage('MATCHING_SECTOR');
        setStatusMessage(`Fix acquired (${lat}°N, ${lng}°E). Matching nearest Kerala district...`);

        // Find nearest Kerala district
        const matchedDistrict = findNearestKeralaDistrict(lat, lng);
        const matchedLocalBody =
          matchedDistrict.localBodies && matchedDistrict.localBodies.length > 0
            ? matchedDistrict.localBodies[0]
            : `${matchedDistrict.name} Central`;

        setTelemetry({
          latitude: lat,
          longitude: lng,
          accuracy: acc,
          district: matchedDistrict.name,
          localBody: matchedLocalBody,
          accountRef: '',
        });

        // Trigger automatic registration immediately
        executeAutoRegistration(lat, lng, acc, matchedDistrict.name, matchedLocalBody);
      },
      (err) => {
        console.warn('Geolocation prompt denied or timed out:', err);
        setStage('PERMISSION_BLOCKED');
        setStatusMessage('Location permission denied or timed out. Auto-register with default Kerala centroid below.');
      },
      {
        enableHighAccuracy: true,
        timeout: 9000,
        maximumAge: 0,
      }
    );
  };

  useEffect(() => {
    if (!hasTriggeredRef.current) {
      hasTriggeredRef.current = true;
      startAutoLocationAccess();
    }
  }, []);

  // Quick Fallback: Instant 1-tap Auto-Register with selected Kerala district centroid
  const handleQuickCentroidRegister = (selectedDistName: string) => {
    const distInfo = KERALA_DISTRICTS.find((d) => d.name === selectedDistName) || KERALA_DISTRICTS[2];
    const lat = distInfo.center.lat;
    const lng = distInfo.center.lng;
    const lb = distInfo.localBodies[0] || `${distInfo.name} Panchayat`;

    executeAutoRegistration(lat, lng, 10, distInfo.name, lb);
  };

  // Manual Form Submit
  const handleManualRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (password.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    setIsSubmittingManual(true);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          password,
          preferredLanguage,
          district,
          localBody,
          ward,
          address,
          latitude: manualLat,
          longitude: manualLng,
          householdSize,
          hasElderly,
          hasInfants,
          requiresEvacuationAssist,
          medicalNeedsSummary,
          emergencyContactName: contactName,
          emergencyContactPhone: contactPhone,
          consentLocation,
          consentSms,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        router.push('/resident/dashboard');
      } else {
        setErrorMessage(data.error || 'Registration failed');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Network error');
    } finally {
      setIsSubmittingManual(false);
    }
  };

  return (
    <div className="min-h-[92vh] py-12 px-4 flex items-center justify-center bg-canvas">
      <div className="w-full max-w-xl space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-xs font-mono text-primary shadow-glow-cyan">
            <Radio className="w-3.5 h-3.5 text-primary animate-pulse" />
            <span>Autonomous Resident Onboarding</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary tracking-tight">
            Kerala Disaster Digital Twin Registration
          </h1>
          <p className="text-xs text-text-secondary max-w-md mx-auto leading-relaxed">
            Your device location automatically registers your household to the State Emergency Operations
            Centre for localized flood, landslide, and evacuation alerts.
          </p>
        </div>

        {/* PRIMARY: AUTOMATIC GPS REGISTRATION COCKPIT */}
        {!isManualMode ? (
          <div className="p-6 sm:p-8 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-6 relative overflow-hidden">
            {/* Ambient Background Radar Glow */}
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

            {/* Stage Indicator Badge */}
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider text-text-muted flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-primary" />
                <span>Zero-Touch Auto Registration</span>
              </span>

              <span
                className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  stage === 'SUCCESS'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : stage === 'REGISTERING'
                    ? 'bg-primary/20 text-primary border border-primary/40 animate-pulse'
                    : stage === 'PERMISSION_BLOCKED'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-surface-2 text-text-secondary border border-surface-3'
                }`}
              >
                {stage === 'ACQUIRING_GPS' && 'Acquiring GPS...'}
                {stage === 'MATCHING_SECTOR' && 'Sector Matching'}
                {stage === 'REGISTERING' && 'Registering...'}
                {stage === 'SUCCESS' && 'Verified & Logged In'}
                {stage === 'PERMISSION_BLOCKED' && 'GPS Prompt Pending'}
                {stage === 'ERROR' && 'Action Required'}
              </span>
            </div>

            {/* Central Animated Radar / Sonar Graphic */}
            <div className="py-6 flex flex-col items-center justify-center space-y-4">
              <div className="relative w-28 h-28 flex items-center justify-center">
                {/* Concentric Pulsing Rings */}
                <div
                  className={`absolute inset-0 rounded-full border border-primary/30 ${
                    stage === 'ACQUIRING_GPS' || stage === 'REGISTERING' ? 'animate-ping opacity-30' : 'opacity-20'
                  }`}
                />
                <div className="absolute inset-2 rounded-full border border-primary/40 opacity-40" />
                <div className="absolute inset-5 rounded-full bg-surface-2 border border-surface-3 shadow-inner" />

                {/* Center Status Icon */}
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all ${
                    stage === 'SUCCESS'
                      ? 'bg-emerald-500 text-canvas'
                      : stage === 'REGISTERING'
                      ? 'bg-primary text-canvas animate-pulse'
                      : stage === 'PERMISSION_BLOCKED'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                      : 'bg-primary/20 text-primary border border-primary/50'
                  }`}
                >
                  {stage === 'SUCCESS' ? (
                    <CheckCircle2 className="w-7 h-7" />
                  ) : stage === 'PERMISSION_BLOCKED' ? (
                    <MapPin className="w-7 h-7 animate-bounce" />
                  ) : (
                    <Compass className="w-7 h-7 animate-spin" style={{ animationDuration: '6s' }} />
                  )}
                </div>
              </div>

              {/* Status Message Text */}
              <div className="text-center space-y-1">
                <p className="text-sm font-bold text-text-primary">{statusMessage}</p>
                <p className="text-xs text-text-muted font-mono">
                  {stage === 'SUCCESS'
                    ? `Account Ref: ${telemetry.accountRef}`
                    : 'Coordinates are processed securely on-device'}
                </p>
              </div>
            </div>

            {/* Live Telemetry Readout Grid */}
            <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="space-y-0.5">
                <span className="text-[10px] text-text-muted">LATITUDE</span>
                <p className="font-semibold text-text-primary">
                  {telemetry.latitude ? `${telemetry.latitude.toFixed(4)}° N` : 'Acquiring...'}
                </p>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] text-text-muted">LONGITUDE</span>
                <p className="font-semibold text-text-primary">
                  {telemetry.longitude ? `${telemetry.longitude.toFixed(4)}° E` : 'Acquiring...'}
                </p>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] text-text-muted">ACCURACY</span>
                <p className="font-semibold text-primary">
                  {telemetry.accuracy ? `±${telemetry.accuracy}m (WGS84)` : 'GPS Sensor'}
                </p>
              </div>

              <div className="space-y-0.5 col-span-2 sm:col-span-2">
                <span className="text-[10px] text-text-muted">DETECTED KERALA DISTRICT</span>
                <p className="font-semibold text-amber-400">
                  {telemetry.district ? `${telemetry.district} District` : 'Scanning sector...'}
                </p>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] text-text-muted">LOCAL PANCHAYAT</span>
                <p className="font-semibold text-text-primary truncate">
                  {telemetry.localBody || 'Auto-assigning'}
                </p>
              </div>
            </div>

            {/* Error or Permission Blocked Fallback Action Panel */}
            {(stage === 'PERMISSION_BLOCKED' || stage === 'ERROR') && (
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-3">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-xs">
                    <p className="font-semibold text-amber-300">
                      Browser Location Access Prompt
                    </p>
                    <p className="text-text-secondary leading-relaxed">
                      If your browser did not show the GPS permission dialog, you can retry or tap any Kerala district below to complete auto-registration instantly.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={startAutoLocationAccess}
                    className="px-3 py-1.5 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary hover:border-primary/50 transition flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-primary" />
                    <span>Retry GPS Prompt</span>
                  </button>

                  <button
                    onClick={() => handleQuickCentroidRegister('Wayanad')}
                    className="px-3 py-1.5 rounded-lg bg-primary text-canvas text-xs font-bold font-mono hover:bg-primary/90 transition flex items-center gap-1.5 shadow-glow-cyan"
                  >
                    <span>Auto-Register in Wayanad</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* 14 District 1-Tap Pills */}
                <div className="pt-2 border-t border-surface-3/50 space-y-1.5">
                  <span className="text-[10px] font-mono text-text-muted">
                    OR 1-TAP AUTO-REGISTER IN OTHER DISTRICTS:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {KERALA_DISTRICTS.map((d) => (
                      <button
                        key={d.id}
                        onClick={() => handleQuickCentroidRegister(d.name)}
                        className="px-2 py-1 rounded bg-surface-2 border border-surface-3 hover:border-primary/40 text-[11px] font-mono text-text-secondary hover:text-text-primary transition"
                      >
                        {d.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Toggle to Full Manual Form */}
            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => setIsManualMode(true)}
                className="text-xs text-text-muted hover:text-primary transition font-mono underline underline-offset-4 flex items-center justify-center gap-1 mx-auto"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Want to specify custom family members or medical notes? Open detailed form</span>
              </button>
            </div>
          </div>
        ) : (
          /* SECONDARY: MANUAL DETAILED FORM */
          <div className="p-6 sm:p-8 rounded-2xl bg-surface-1 border border-surface-3 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-surface-3 pb-3">
              <div>
                <h3 className="text-sm font-bold text-text-primary">Detailed Household Registration</h3>
                <p className="text-xs text-text-secondary">Custom vulnerability and medical assistance notes</p>
              </div>
              <button
                type="button"
                onClick={() => setIsManualMode(false)}
                className="text-xs font-mono text-primary hover:underline flex items-center gap-1"
              >
                <span>Back to Auto-GPS</span>
              </button>
            </div>

            {errorMessage && (
              <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-xs text-red-400">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleManualRegister} className="space-y-6">
              {/* Account info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Anoop Chandran"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+919847256789"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="anoop@sample.resqlink.in"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Password (min 8 chars) *</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* District & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">District *</label>
                  <select
                    value={district}
                    onChange={(e) => {
                      setDistrict(e.target.value);
                      const found = KERALA_DISTRICTS.find((d) => d.name === e.target.value);
                      if (found) {
                        setManualLat(found.center.lat);
                        setManualLng(found.center.lng);
                      }
                    }}
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none"
                  >
                    {KERALA_DISTRICTS.map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name} ({d.nameMl})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Local Body</label>
                  <input
                    type="text"
                    value={localBody}
                    onChange={(e) => setLocalBody(e.target.value)}
                    placeholder="e.g. Meppadi Panchayat"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-text-muted">Ward</label>
                  <input
                    type="text"
                    value={ward}
                    onChange={(e) => setWard(e.target.value)}
                    placeholder="e.g. Ward 10"
                    className="w-full bg-surface-2 border border-surface-3 rounded-lg px-3 py-2 text-xs text-text-primary focus:border-primary focus:outline-none"
                  />
                </div>
              </div>

              {/* Vulnerabilities */}
              <div className="space-y-2 pt-2 border-t border-surface-3">
                <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasElderly}
                    onChange={(e) => setHasElderly(e.target.checked)}
                    className="rounded border-surface-3 text-primary focus:ring-primary"
                  />
                  <span>Elderly Residents (Age 65+) Present</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requiresEvacuationAssist}
                    onChange={(e) => setRequiresEvacuationAssist(e.target.checked)}
                    className="rounded border-surface-3 text-primary focus:ring-primary"
                  />
                  <span className="text-amber-400 font-semibold">
                    Requires Priority Evacuation Assistance (Wheelchair, Bedridden, Oxygen)
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmittingManual}
                className="w-full py-3.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmittingManual ? <span>Submitting...</span> : <span>Complete Registration</span>}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
