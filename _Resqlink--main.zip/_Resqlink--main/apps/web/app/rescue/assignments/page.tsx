'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Radio,
  LifeBuoy,
  Clock,
  Compass,
  ArrowRight,
  Filter,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function RescueAssignmentsPage() {
  const [assignedSos, setAssignedSos] = useState<any[]>([]);
  const [selectedDistrict, setSelectedDistrict] = useState('ALL');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/rescue/assignments')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.assignedSos) setAssignedSos(data.assignedSos);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const filtered = assignedSos.filter((sos) => {
    if (selectedDistrict !== 'ALL' && sos.district !== selectedDistrict) return false;
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-3 pb-4">
        <div>
          <span className="text-xs font-mono uppercase text-blue-400 font-semibold flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-blue-400" />
            <span>Operational Roster</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
            Dispatched Field Operations
          </h1>
          <p className="text-xs text-text-secondary mt-1">
            Active search, rescue, and evacuation missions assigned by the State Command Center.
          </p>
        </div>

        {/* District Filter */}
        <select
          value={selectedDistrict}
          onChange={(e) => setSelectedDistrict(e.target.value)}
          className="bg-surface-2 text-text-primary border border-surface-3 rounded-lg px-3 py-1.5 text-xs font-sans focus:border-primary"
        >
          <option value="ALL">All Kerala Districts</option>
          {KERALA_DISTRICTS.map((d) => (
            <option key={d.id} value={d.name}>
              {d.name}
            </option>
          ))}
        </select>
      </div>

      {/* Assignments Stream */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="p-12 rounded-xl bg-surface-1 border border-surface-3 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-status-valid mx-auto" />
            <p className="text-sm font-bold text-text-primary">No Active Dispatches for Selected Filter</p>
          </div>
        ) : (
          filtered.map((sos) => (
            <div
              key={sos.id}
              className="p-5 rounded-xl bg-surface-1 border border-surface-3 space-y-3 shadow-lg hover:border-surface-3/80 transition"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-surface-3 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-sm text-text-primary">
                    {sos.trackingNumber}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      sos.priorityCategory === 'CRITICAL'
                        ? 'bg-red-500 text-canvas'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {sos.priorityCategory} (Score: {sos.priorityScore})
                  </span>
                  <span className="text-xs text-text-muted font-mono">{sos.category}</span>
                </div>

                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  {sos.status}
                </span>
              </div>

              <p className="text-xs text-text-secondary leading-relaxed">{sos.description}</p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono text-text-muted">
                <span>Sector: {sos.district || 'Wayanad'}</span>
                <span>Victims: {sos.peopleCount} Persons</span>
                <span>Injuries: {sos.hasInjuries ? 'CONFIRMED' : 'NONE'}</span>
                <span className="text-primary font-bold">{sos.assignedTeamName}</span>
              </div>

              <div className="pt-2 border-t border-surface-3 flex items-center justify-between">
                <span className="text-[11px] text-text-muted font-mono">
                  Reported: {new Date(sos.createdAt).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })}
                </span>
                <Link
                  href={`/rescue/incidents/${sos.id}`}
                  className="px-3 py-1.5 rounded bg-surface-2 border border-surface-3 hover:border-primary/50 text-xs font-mono text-primary font-bold flex items-center gap-1.5 transition"
                >
                  <span>Open Operational Console</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
