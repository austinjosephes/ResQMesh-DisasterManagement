'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Radio,
  LifeBuoy,
  MapPin,
  Clock,
  Compass,
  CheckCircle2,
  AlertTriangle,
  Phone,
  Navigation,
  ArrowRight,
  RefreshCw,
  Users,
  Layers,
  HeartPulse,
  ShieldAlert,
  Zap,
} from 'lucide-react';

export default function RescueDashboardPage() {
  const [data, setData] = useState<any>({ assignments: [], assignedSos: [] });
  const [activeIncident, setActiveIncident] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  const fetchAssignments = () => {
    setIsLoading(true);
    fetch('/api/rescue/assignments')
      .then((res) => (res.ok ? res.json() : null))
      .then((resData) => {
        if (resData) {
          setData(resData);
          if (resData.assignedSos && resData.assignedSos.length > 0) {
            setActiveIncident(resData.assignedSos[0]);
          }
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchAssignments();
  }, []);

  const handleAdvanceStatus = async (newStatus: string) => {
    if (!activeIncident) return;
    setIsUpdating(true);
    setStatusMsg('');

    try {
      const res = await fetch(`/api/rescue/incidents/${activeIncident.id}/triage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: newStatus,
          fieldNotes: `Advanced status to ${newStatus} by field team leader`,
        }),
      });

      if (res.ok) {
        setStatusMsg(`Mission status advanced to ${newStatus}`);
        fetchAssignments();
      }
    } catch (e) {
    } finally {
      setIsUpdating(false);
    }
  };

  const nextStatusMap: Record<string, string> = {
    ASSIGNED: 'EN_ROUTE',
    EN_ROUTE: 'ON_SCENE',
    ON_SCENE: 'IN_PROGRESS',
    IN_PROGRESS: 'RESOLVED',
  };

  const nextAction = activeIncident ? nextStatusMap[activeIncident.status] : null;

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
              <Radio className="w-3.5 h-3.5 text-[#FF6B35] animate-pulse" />
              <span>FIELD RESPONDER TACTICAL COCKPIT &bull; LEVEL-1 DISPATCH</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA]">
              Active Rescue Mission Console
            </h1>
            <p className="text-xs text-[#929CAB] font-mono">
              Mobile-optimized operational view for deployed NDRF 04 Battalion, Kerala Fire Force, and Coastal Units.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchAssignments}
              disabled={isLoading}
              className="px-3.5 py-2 rounded-xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] text-xs font-mono flex items-center gap-2 transition cursor-pointer"
              title="Refresh Assignments"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#FF6B35]' : ''}`} />
              <span>Sync</span>
            </button>
          </div>
        </div>

        {statusMsg && (
          <div className="p-3.5 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/30 flex items-center gap-2 text-xs text-[#22C55E] font-mono">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{statusMsg}</span>
          </div>
        )}

        {/* Active High-Priority Mission Card */}
        {activeIncident ? (
          <div className="p-6 sm:p-7 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#EF4444] via-[#FF6B35] to-[#22C55E]" />

            {/* Mission Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[rgba(255,255,255,0.08)] pb-4">
              <div className="space-y-1">
                <span className="text-[10px] font-mono px-2.5 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] font-bold border border-[#EF4444]/30">
                  PRIORITY: {activeIncident.priorityCategory || 'P1 CRITICAL'} (Score: {activeIncident.priorityScore || 92})
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-[#F5F7FA] mt-1">
                  #{activeIncident.trackingNumber} &bull; {activeIncident.category}
                </h2>
                <div className="text-xs font-mono text-[#929CAB] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#FF6B35]" />
                  <span>Sector: {activeIncident.district || 'Kerala Sector'}, Kerala</span>
                </div>
              </div>

              <div className="text-right self-start sm:self-auto">
                <span className="text-[10px] font-mono text-[#6F7C93] block">MISSION PROGRESS</span>
                <span className="text-sm font-mono font-bold text-[#F5A623] px-3 py-1 rounded bg-[#F5A623]/10 border border-[#F5A623]/30 inline-block mt-0.5">
                  {activeIncident.status}
                </span>
              </div>
            </div>

            {/* Description & Situation */}
            <div className="p-4 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-2 text-xs">
              <div className="text-[10px] font-mono text-[#6F7C93] uppercase font-bold tracking-wider">
                FIELD SITUATION TELEMETRY:
              </div>
              <p className="text-[#F5F7FA] leading-relaxed text-sm">
                {activeIncident.description}
              </p>
              {activeIncident.accessibilityNeeds && (
                <p className="text-[#F5A623] font-mono text-xs pt-1 border-t border-[rgba(255,255,255,0.06)]">
                  ⚠️ Special Needs: {activeIncident.accessibilityNeeds}
                </p>
              )}
            </div>

            {/* Key Telemetry Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-0.5">
                <span className="text-[10px] text-[#6F7C93]">VICTIMS TRAPPED</span>
                <p className="text-lg font-bold text-[#F5F7FA]">{activeIncident.peopleCount} Persons</p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-0.5">
                <span className="text-[10px] text-[#6F7C93]">INJURIES</span>
                <p className="text-lg font-bold text-[#EF4444]">
                  {activeIncident.hasInjuries ? 'TRAUMA CONFIRMED' : 'NONE'}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-0.5">
                <span className="text-[10px] text-[#6F7C93]">LOCATION CONFIDENCE</span>
                <p className="text-lg font-bold text-[#38BDF8]">
                  {Math.round((activeIncident.locationConfidence || 0.95) * 100)}% GPS Fix
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-0.5">
                <span className="text-[10px] text-[#6F7C93]">COORDINATES</span>
                <p className="text-xs font-bold text-[#929CAB] truncate">
                  {activeIncident.latitude ? `${activeIncident.latitude}, ${activeIncident.longitude}` : 'Coarse Sector'}
                </p>
              </div>
            </div>

            {/* Rapid Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              {nextAction && (
                <button
                  onClick={() => handleAdvanceStatus(nextAction)}
                  disabled={isUpdating}
                  className="w-full sm:flex-1 py-3.5 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-extrabold text-xs uppercase tracking-wider transition shadow-lg shadow-[#FF6B35]/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Advance Mission to: {nextAction.replace('_', ' ')}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}

              <Link
                href={`/rescue/incidents/${activeIncident.id}`}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-[#151E29] hover:bg-[#1C2736] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA] font-bold text-xs font-mono transition flex items-center justify-center gap-1.5"
              >
                <span>Field Triage Form</span>
              </Link>
            </div>
          </div>
        ) : (
          <div className="p-12 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-center space-y-3">
            <CheckCircle2 className="w-8 h-8 text-[#22C55E] mx-auto" />
            <h3 className="text-sm font-bold text-[#F5F7FA]">No Active Dispatches Pending</h3>
            <p className="text-xs text-[#929CAB] max-w-sm mx-auto">
              Your unit is currently standing by. New dispatches from the State Command Center will appear here in real-time.
            </p>
          </div>
        )}

        {/* Assigned Operations Total Strip */}
        <div className="flex items-center justify-between p-4 rounded-xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-xs font-mono">
          <span className="text-[#929CAB]">
            Total Assigned Operations: <strong className="text-[#F5F7FA]">{data.assignedSos.length}</strong>
          </span>
          <Link
            href="/rescue/assignments"
            className="text-[#FF6B35] hover:underline font-bold flex items-center gap-1"
          >
            <span>View All Assigned Missions</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
