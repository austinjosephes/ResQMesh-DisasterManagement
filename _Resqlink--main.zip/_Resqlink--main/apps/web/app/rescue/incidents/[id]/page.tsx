'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Radio,
  LifeBuoy,
  MapPin,
  Clock,
  Compass,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft,
  Users,
  HeartPulse,
} from 'lucide-react';

export default function RescueIncidentConsolePage() {
  const params = useParams();
  const id = params?.id as string;
  const router = useRouter();

  const [sos, setSos] = useState<any | null>(null);
  const [shelters, setShelters] = useState<any[]>([]);
  const [status, setStatus] = useState('ON_SCENE');
  const [victimsAided, setVictimsAided] = useState(4);
  const [selectedShelter, setSelectedShelter] = useState('');
  const [fieldNotes, setFieldNotes] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!id) return;
    Promise.all([
      fetch('/api/resident/requests').then((r) => (r.ok ? r.json() : null)),
      fetch('/api/admin/shelters').then((r) => (r.ok ? r.json() : null)),
    ])
      .then(([reqData, shelterData]) => {
        if (reqData && reqData.requests) {
          const found = reqData.requests.find((r: any) => r.id === id || r.trackingNumber === id);
          if (found) {
            setSos(found);
            setStatus(found.status || 'ON_SCENE');
            setVictimsAided(found.peopleCount || 1);
          }
        }
        if (shelterData && shelterData.shelters) setShelters(shelterData.shelters);
      })
      .catch(() => {});
  }, [id]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sos) return;
    setIsUpdating(true);
    setMsg('');

    try {
      const res = await fetch(`/api/rescue/incidents/${sos.id}/triage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          victimsAided,
          fieldNotes: `${fieldNotes}${selectedShelter ? ` | Transferred to ${selectedShelter}` : ''}`,
        }),
      });

      if (res.ok) {
        setMsg('Field triage report committed and transmitted to Command HQ.');
        setTimeout(() => router.push('/rescue/dashboard'), 1500);
      }
    } catch (e) {
    } finally {
      setIsUpdating(false);
    }
  };

  if (!sos) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <p className="text-xs font-mono text-text-muted">Loading incident coordinates...</p>
        <Link href="/rescue/dashboard" className="text-xs text-primary hover:underline">
          Return to Cockpit
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center gap-3 border-b border-surface-3 pb-4">
        <Link
          href="/rescue/dashboard"
          className="p-1.5 rounded-lg bg-surface-2 border border-surface-3 text-text-secondary hover:text-text-primary"
        >
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div>
          <span className="text-xs font-mono uppercase text-primary font-bold">
            Tactical Response Console
          </span>
          <h1 className="text-xl font-bold text-text-primary">
            Mission {sos.trackingNumber} ({sos.category})
          </h1>
        </div>
      </div>

      {msg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400 font-mono">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{msg}</span>
        </div>
      )}

      {/* Incident Summary Card */}
      <div className="p-5 rounded-xl bg-surface-1 border border-surface-3 space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <span className="font-mono text-amber-400 font-bold">SECTOR: {sos.district}, KERALA</span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-500/20 text-red-400">
            {sos.priorityCategory} (Score: {sos.priorityScore})
          </span>
        </div>
        <p className="text-text-secondary leading-relaxed bg-surface-2 p-3 rounded-lg">
          {sos.description}
        </p>
        <div className="grid grid-cols-2 gap-2 text-text-muted font-mono text-[11px]">
          <span>Victims: {sos.peopleCount} Persons</span>
          <span>Injuries: {sos.hasInjuries ? 'CONFIRMED' : 'NONE'}</span>
          <span>Address: {sos.address || 'N/A'}</span>
          <span>
            GPS: {sos.latitude?.toFixed(4)}, {sos.longitude?.toFixed(4)}
          </span>
        </div>
      </div>

      {/* Field Report Form */}
      <form onSubmit={handleUpdate} className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-6">
        <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
          Field Status Update &amp; Victim Triage
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
          <div className="space-y-1">
            <label className="text-text-muted">Lifecycle Status:</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary focus:border-primary"
            >
              <option value="EN_ROUTE">EN_ROUTE (Traveling to Scene)</option>
              <option value="ON_SCENE">ON_SCENE (At Coordinates)</option>
              <option value="IN_PROGRESS">IN_PROGRESS (Extrication Active)</option>
              <option value="RESOLVED">RESOLVED (Victims Safe)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-text-muted">Victims Extricated / Aided:</label>
            <input
              type="number"
              min={0}
              value={victimsAided}
              onChange={(e) => setVictimsAided(parseInt(e.target.value) || 0)}
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary"
            />
          </div>
        </div>

        <div className="space-y-1 text-xs font-mono">
          <label className="text-text-muted">Relief Shelter Destination Transfer:</label>
          <select
            value={selectedShelter}
            onChange={(e) => setSelectedShelter(e.target.value)}
            className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-text-primary font-sans"
          >
            <option value="">No Shelter Transfer (Treated on Site)</option>
            {shelters.map((s) => (
              <option key={s.id} value={s.name}>
                {s.name} ({s.district} • {s.currentOccupacy}/{s.totalCapacity} Occupied)
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1 text-xs">
          <label className="font-mono text-text-muted">Field Tactical Notes:</label>
          <textarea
            rows={3}
            value={fieldNotes}
            onChange={(e) => setFieldNotes(e.target.value)}
            placeholder="e.g. Navigated via inflatable boat. Extricated 4 residents from attic. Grandfather transferred to St. Joseph School relief medical post."
            className="w-full bg-surface-2 border border-surface-3 rounded-lg p-3 text-text-primary focus:border-primary"
          />
        </div>

        <button
          type="submit"
          disabled={isUpdating}
          className="w-full py-3.5 rounded-xl bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
        >
          {isUpdating ? 'Transmitting Field Telemetry...' : 'Submit Field Report to Command'}
        </button>
      </form>
    </div>
  );
}
