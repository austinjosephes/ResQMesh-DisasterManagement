'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function RescueIncidentsRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/rescue/assignments');
  }, [router]);

  return (
    <div className="min-h-[50vh] flex items-center justify-center text-xs font-mono text-text-muted">
      <span>Redirecting to Operational Assignments...</span>
    </div>
  );
}
