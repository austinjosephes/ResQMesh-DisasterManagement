'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function RescueIndexRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/rescue/dashboard');
  }, [router]);

  return (
    <div className="min-h-[50vh] flex items-center justify-center text-xs font-mono text-text-muted">
      <span>Redirecting to Rescue Mission Cockpit...</span>
    </div>
  );
}
