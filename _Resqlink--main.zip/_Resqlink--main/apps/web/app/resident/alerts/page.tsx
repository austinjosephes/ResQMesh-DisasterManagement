'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Bell,
  ShieldAlert,
  MapPin,
  Clock,
  Compass,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Globe,
  ArrowLeft,
  LifeBuoy,
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function ResidentAlertsPage() {
  const { t } = useI18n();
  const [alerts, setAlerts] = useState<any[]>([]);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/resident/alerts')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.alerts) setAlerts(data.alerts);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const filteredAlerts = alerts.filter((a) => {
    if (selectedDistrict !== 'ALL' && a.affectedDistrict !== selectedDistrict) return false;
    if (selectedSeverity !== 'ALL' && a.severity !== selectedSeverity) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Link
                href="/resident/dashboard"
                className="p-1.5 rounded-lg bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
                title="Return to Dashboard"
              >
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
                <Bell className="w-3.5 h-3.5 text-[#FF6B35]" />
                <span>OFFICIAL CALAMITY FEED</span>
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA]">
              Active Hazard &amp; Weather Warnings
            </h1>
            <p className="text-xs text-[#929CAB] font-mono">
              Verified meteorological alerts from KSDMA, IMD, and Central Water Commission.
            </p>
          </div>

          <Link
            href="/resident/dashboard"
            className="px-4 py-2 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-mono font-bold text-xs uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-[#EF4444]/20 self-start sm:self-center"
          >
            <LifeBuoy className="w-4 h-4" />
            <span>Emergency SOS</span>
          </Link>
        </div>

        {/* Filters Strip */}
        <div className="flex flex-wrap items-center gap-3 bg-[#101720] p-3 rounded-2xl border border-[rgba(255,255,255,0.08)] text-xs font-mono">
          <div className="flex items-center gap-1.5 text-[#6F7C93]">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter:</span>
          </div>

          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            className="bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-1.5 text-[#F5F7FA] focus:border-[#FF6B35] focus:outline-none"
          >
            <option value="ALL">All Kerala Districts</option>
            {KERALA_DISTRICTS.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name} ({d.nameMl})
              </option>
            ))}
          </select>

          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="bg-[#0B1017] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-1.5 text-[#F5F7FA] focus:border-[#FF6B35] focus:outline-none"
          >
            <option value="ALL">All Severities</option>
            <option value="EMERGENCY">EMERGENCY (Critical Red)</option>
            <option value="WARNING">WARNING (High Orange)</option>
            <option value="WATCH">WATCH (Amber)</option>
            <option value="ADVISORY">ADVISORY</option>
          </select>

          <span className="ml-auto text-[11px] text-[#6F7C93]">
            Showing {filteredAlerts.length} of {alerts.length} warnings
          </span>
        </div>

        {/* Alerts Stream */}
        {filteredAlerts.length === 0 ? (
          <div className="p-12 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-[#22C55E] mx-auto" />
            <p className="text-sm font-bold text-[#F5F7FA]">No Active Warnings for Selected Filter</p>
            <p className="text-xs text-[#929CAB]">
              The selected area currently has no active flood, landslide, or storm surge warnings.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAlerts.map((alert) => {
              const isRed = alert.severity === 'EMERGENCY' || alert.severity === 'CRITICAL';
              const isOrange = alert.severity === 'WARNING';

              return (
                <div
                  key={alert.id}
                  className={`p-6 rounded-2xl border space-y-4 transition ${
                    isRed
                      ? 'bg-[#101720] border-[#EF4444]/40 shadow-xl'
                      : 'bg-[#101720] border-[rgba(255,255,255,0.08)]'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[rgba(255,255,255,0.06)] pb-3">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full ${
                          isRed
                            ? 'bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]'
                            : isOrange
                            ? 'bg-[#FF6B35]/15 border border-[#FF6B35]/30 text-[#FF6B35]'
                            : 'bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623]'
                        }`}
                      >
                        {alert.severity} • {alert.hazardType}
                      </span>
                      <span className="text-xs font-mono text-[#929CAB]">
                        Authority: {alert.source}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-[#6F7C93] flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>
                        Valid Until: {new Date(alert.expiresAt).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-base font-bold text-[#F5F7FA]">
                      {alert.headline}
                    </h3>
                    <p className="text-xs text-[#929CAB] leading-relaxed">
                      {alert.description}
                    </p>
                  </div>

                  {/* Safety Instruction Box */}
                  <div className="p-3.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-1 text-xs">
                    <p className="font-mono text-[10px] text-[#F5A623] font-bold uppercase tracking-wider">
                      OFFICIAL SAFETY DIRECTIVE:
                    </p>
                    <p className="text-[#F5F7FA] leading-relaxed">
                      {alert.instruction}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 font-mono">
                    <span className="text-[#929CAB]">
                      Affected District: <strong className="text-[#F5F7FA]">{alert.affectedDistrict}</strong>
                    </span>
                    <Link
                      href="/resident/dashboard"
                      className="text-xs text-[#EF4444] hover:underline font-bold"
                    >
                      Need Help in this Zone? Open Safety Portal →
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
