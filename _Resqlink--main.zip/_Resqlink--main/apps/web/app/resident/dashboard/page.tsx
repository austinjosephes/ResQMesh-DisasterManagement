'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  ShieldAlert,
  LifeBuoy,
  Phone,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Send,
  Smartphone,
  Navigation,
  RefreshCw,
  HeartPulse,
  Mountain,
  Waves,
  CloudRain,
  ChevronDown,
  ChevronUp,
  X,
  Radio,
  Building2,
  Check,
  Compass,
  MessageSquare,
  Bell,
  ShieldCheck,
  CheckCheck,
  Flame,
  ArrowRight,
  Sliders,
  Search,
  Target,
  LocateFixed,
  Zap,
  Info,
  Shield,
  Home,
  FileText,
  User,
} from 'lucide-react';
import {
  findNearestGramaPanchayat,
  GramaPanchayat,
  getAllDistricts,
  getBlocksForDistrict,
  getGramasForBlock,
  searchAdministrativeAreas,
  SearchAdministrativeResult,
} from '@/lib/kerala-administrative';

export default function ResidentSafetyPortalPage() {
  // Mobile Phone & Enrollment State
  const [phone, setPhone] = useState<string>('');
  const [enrolledPhone, setEnrolledPhone] = useState<string | null>(null);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [enrollMsg, setEnrollMsg] = useState('');
  const [enrollError, setEnrollError] = useState('');

  // Resident Personal Identity State (Name, Gmail, Phone)
  const [residentName, setResidentName] = useState<string>('');
  const [residentEmail, setResidentEmail] = useState<string>('');
  const [showIdentityModal, setShowIdentityModal] = useState<boolean>(false);
  const [isSavingIdentity, setIsSavingIdentity] = useState<boolean>(false);
  const [identityError, setIdentityError] = useState<string>('');

  // Location Calibration & Interactive Sector State
  const [coords, setCoords] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [isDetectingGps, setIsDetectingGps] = useState(true);
  const [detectedSector, setDetectedSector] = useState<GramaPanchayat | null>(null);
  const [gpsError, setGpsError] = useState('');
  const [locationSource, setLocationSource] = useState<'GPS' | 'CALIBRATED'>('GPS');
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [calibTab, setCalibTab] = useState<'SEARCH' | 'HIERARCHY' | 'GPS'>('SEARCH');
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [calibDistrict, setCalibDistrict] = useState('Wayanad');
  const [calibBlock, setCalibBlock] = useState('Kalpetta Block');
  const [calibGrama, setCalibGrama] = useState('Meppadi Grama Panchayat');
  const [calibWard, setCalibWard] = useState('Chooralmala');
  const [selectedWard, setSelectedWard] = useState<string>('');
  const [calibToast, setCalibToast] = useState('');
  const [isAcquiringGps, setIsAcquiringGps] = useState(false);
  const [gpsFixError, setGpsFixError] = useState('');

  // Active Navigation Tab (Left Sidebar)
  const [activeTab, setActiveTab] = useState<
    'overview' | 'alerts' | 'location' | 'sos' | 'evacuation' | 'contacts' | 'profile'
  >('overview');

  // Alerts & Incoming SMS State (From Admin Portal)
  const [alerts, setAlerts] = useState<any[]>([]);
  const [incomingSms, setIncomingSms] = useState<any | null>(null);
  const [allSmsMessages, setAllSmsMessages] = useState<any[]>([]);
  const [isLoadingAlerts, setIsLoadingAlerts] = useState(true);
  const [isAckingSms, setIsAckingSms] = useState(false);
  const [smsAckConfirmed, setSmsAckConfirmed] = useState(false);

  // Heads-up SMS Push Notification Banner State
  const [showPushBanner, setShowPushBanner] = useState(false);
  const [dismissedSmsIds, setDismissedSmsIds] = useState<string[]>([]);

  // SOS Emergency Action State
  const [isSosBroadcasting, setIsSosBroadcasting] = useState(false);
  const [confirmingSos, setConfirmingSos] = useState(false);
  const [sosCountdown, setSosCountdown] = useState<number | null>(null);
  const [sosSuccessTicket, setSosSuccessTicket] = useState<any | null>(null);
  const [sosError, setSosError] = useState('');

  // Register an Issue Modal / Form State
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [issueCategory, setIssueCategory] = useState('TRAPPED');
  const [issueDescription, setIssueDescription] = useState('');
  const [issuePeopleCount, setIssuePeopleCount] = useState(1);
  const [hasInjuries, setHasInjuries] = useState(false);
  const [immediateDanger, setImmediateDanger] = useState(false);
  const [isSubmittingIssue, setIsSubmittingIssue] = useState(false);
  const [issueSubmittedTicket, setIssueSubmittedTicket] = useState<any | null>(null);
  const [issueFormError, setIssueFormError] = useState('');

  // Resident's Registered Issues / SOS Requests
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [ackingRequestIds, setAckingRequestIds] = useState<Record<string, boolean>>({});

  // Dynamic Time Greeting
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'GOOD MORNING';
    if (hour < 17) return 'GOOD AFTERNOON';
    if (hour < 21) return 'GOOD EVENING';
    return 'GOOD NIGHT';
  }, []);

  // 1. On Mount: Check stored citizen identity, auto-prompt onboarding modal, and acquire LIVE GPS
  useEffect(() => {
    // Check stored resident personal profile
    const savedProfileStr = localStorage.getItem('resqlink_resident_profile');
    if (savedProfileStr) {
      try {
        const parsed = JSON.parse(savedProfileStr);
        if (parsed.name) setResidentName(parsed.name);
        if (parsed.email) setResidentEmail(parsed.email);
        if (parsed.phone) {
          setEnrolledPhone(parsed.phone);
          setPhone(parsed.phone);
        }
      } catch (e) {}
    } else {
      // User entered website without registered profile -> automatically open identity section!
      setShowIdentityModal(true);
    }

    const savedPhone = localStorage.getItem('resqlink_resident_phone');
    if (savedPhone && !enrolledPhone) {
      setEnrolledPhone(savedPhone);
      setPhone(savedPhone);
    }

    // Check if live location was captured by site-wide prompt
    const savedLiveLocStr = localStorage.getItem('resqlink_user_live_location');
    if (savedLiveLocStr) {
      try {
        const parsedLoc = JSON.parse(savedLiveLocStr);
        if (parsedLoc && typeof parsedLoc.latitude === 'number' && typeof parsedLoc.longitude === 'number') {
          const nearest = parsedLoc.sector || findNearestGramaPanchayat(parsedLoc.latitude, parsedLoc.longitude);
          setCoords({ lat: parsedLoc.latitude, lng: parsedLoc.longitude, accuracy: parsedLoc.accuracy || 8.0 });
          setDetectedSector(nearest);
          setCalibDistrict(nearest.districtName);
          setCalibBlock(nearest.blockName);
          setCalibGrama(nearest.name);
          setLocationSource(parsedLoc.source === 'GPS' ? 'GPS' : 'CALIBRATED');
          setIsDetectingGps(false);
        }
      } catch (e) {}
    }

    // Always acquire live exact GPS on mount
    detectDeviceLocation();

    // Listen for real-time location updates across the application
    const handleLocationUpdate = (e: any) => {
      if (e.detail) {
        const d = e.detail;
        setCoords({ lat: d.latitude, lng: d.longitude, accuracy: d.accuracy });
        if (d.sector) {
          setDetectedSector(d.sector);
          setCalibDistrict(d.sector.districtName);
          setCalibBlock(d.sector.blockName);
          setCalibGrama(d.sector.name);
        }
        setLocationSource(d.source === 'GPS' ? 'GPS' : 'CALIBRATED');
        setIsDetectingGps(false);
      }
    };
    window.addEventListener('resqlink:location-updated', handleLocationUpdate);

    // Continuous real-time GPS position tracking
    let watchId: number | null = null;
    if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const acc = pos.coords.accuracy || 6.0;
          setCoords({ lat, lng, accuracy: acc });
          const nearest = findNearestGramaPanchayat(lat, lng);
          setDetectedSector(nearest);
          setLocationSource('GPS');
          setIsDetectingGps(false);
          setGpsError('');
        },
        () => {},
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 12000 }
      );
    }

    return () => {
      if (watchId !== null && typeof navigator !== 'undefined') {
        navigator.geolocation.clearWatch(watchId);
      }
      if (typeof window !== 'undefined') {
        window.removeEventListener('resqlink:location-updated', handleLocationUpdate);
      }
    };
  }, []);

  const detectDeviceLocation = () => {
    setIsDetectingGps(true);
    setGpsError('');

    if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const acc = pos.coords.accuracy || 5.0;
          setCoords({ lat, lng, accuracy: acc });
          const nearest = findNearestGramaPanchayat(lat, lng);
          setDetectedSector(nearest);
          setLocationSource('GPS');
          setIsDetectingGps(false);
          setGpsError('');

          // Cache verified live GPS coordinates
          localStorage.setItem(
            'resqlink_resident_calibrated_location',
            JSON.stringify({
              center: { lat, lng },
              accuracy: acc,
              sector: nearest,
              source: 'GPS',
              calibratedAt: new Date().toISOString(),
            })
          );
        },
        async (err) => {
          console.warn('Satellite GPS not acquired, querying IP geolocation fallback...', err);
          // Try IP Geolocation fallback to locate anywhere in Kerala
          try {
            const res = await fetch('https://ipapi.co/json/');
            if (res.ok) {
              const ipData = await res.json();
              if (ipData && typeof ipData.latitude === 'number' && typeof ipData.longitude === 'number') {
                const lat = ipData.latitude;
                const lng = ipData.longitude;
                const nearest = findNearestGramaPanchayat(lat, lng);
                setCoords({ lat, lng, accuracy: 80.0 });
                setDetectedSector(nearest);
                setLocationSource('CALIBRATED');
                setIsDetectingGps(false);
                setGpsError(`Located via Network IP (${ipData.city || 'Kerala Sector'}). Tap "Refresh GPS" to acquire satellite lock.`);
                return;
              }
            }
          } catch (e) {}

          // Central Kerala fallback (Kochi / Ernakulam)
          const fallbackLat = 9.9312;
          const fallbackLng = 76.2673;
          const nearest = findNearestGramaPanchayat(fallbackLat, fallbackLng);
          setCoords({ lat: fallbackLat, lng: fallbackLng, accuracy: 25.0 });
          setDetectedSector(nearest);
          setLocationSource('GPS');
          setIsDetectingGps(false);
          setGpsError('Satellite GPS permission required. Please allow browser location access or calibrate your sector.');
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      const fallbackLat = 9.9312;
      const fallbackLng = 76.2673;
      const nearest = findNearestGramaPanchayat(fallbackLat, fallbackLng);
      setCoords({ lat: fallbackLat, lng: fallbackLng, accuracy: 25.0 });
      setDetectedSector(nearest);
      setLocationSource('GPS');
      setIsDetectingGps(false);
    }
  };

  // Handler: Save Resident Identity (Name, Gmail, Phone)
  const handleSaveIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!residentName.trim()) {
      setIdentityError('Please enter your full name');
      return;
    }
    if (!residentEmail.trim() || !residentEmail.includes('@')) {
      setIdentityError('Please enter a valid Gmail / Email account');
      return;
    }
    if (!phone.trim() || phone.trim().length < 8) {
      setIdentityError('Please enter your mobile phone number');
      return;
    }

    setIsSavingIdentity(true);
    setIdentityError('');

    try {
      // Sync with backend API
      const res = await fetch('/api/resident/quick-enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: residentName.trim(),
          email: residentEmail.trim(),
          phone: phone.trim(),
          latitude: coords?.lat || 9.9312,
          longitude: coords?.lng || 76.2673,
          accuracy: coords?.accuracy || 10.0,
          district: detectedSector?.districtName,
          block: detectedSector?.blockName,
          grama: detectedSector?.name,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setEnrolledPhone(data.user.phone);
        setPhone(data.user.phone);
        localStorage.setItem('resqlink_resident_phone', data.user.phone);
        localStorage.setItem(
          'resqlink_resident_profile',
          JSON.stringify({
            name: residentName.trim(),
            email: residentEmail.trim(),
            phone: data.user.phone,
            enrolledAt: new Date().toISOString(),
          })
        );
        setShowIdentityModal(false);
      } else {
        setIdentityError(data.error || 'Failed to save identity');
      }
    } catch (err: any) {
      setIdentityError(err.message || 'Network error saving identity');
    } finally {
      setIsSavingIdentity(false);
    }
  };

  // Location Calibration Handler
  const applyCalibratedLocation = (
    sector: GramaPanchayat,
    centerLat: number,
    centerLng: number,
    accuracy: number,
    source: 'GPS' | 'CALIBRATED',
    wardName?: string
  ) => {
    setDetectedSector(sector);
    setCoords({ lat: centerLat, lng: centerLng, accuracy });
    setLocationSource(source);
    if (wardName) setSelectedWard(wardName);

    localStorage.setItem(
      'resqlink_resident_calibrated_location',
      JSON.stringify({
        center: { lat: centerLat, lng: centerLng },
        accuracy,
        sector,
        source,
        ward: wardName || sector.localAreas?.[0] || 'Ward 01',
        calibratedAt: new Date().toISOString(),
      })
    );

    setCalibToast(`Location calibrated to ${sector.name}, ${sector.districtName}`);
    setTimeout(() => setCalibToast(''), 4000);
    setShowLocationModal(false);
  };

  // Live administrative area search (across all 14 Districts, 152 Blocks & 941 Gramas)
  const searchResults = useMemo(() => {
    if (locationSearchQuery.trim().length >= 2) {
      return searchAdministrativeAreas(locationSearchQuery.trim(), 20);
    }
    return [];
  }, [locationSearchQuery]);

  const handleSelectSearchResult = (item: SearchAdministrativeResult) => {
    const sector = findNearestGramaPanchayat(item.center.lat, item.center.lng);
    applyCalibratedLocation(
      sector,
      item.center.lat,
      item.center.lng,
      5.0,
      'CALIBRATED',
      item.matchedLocalArea || (item.type === 'GRAMA' ? item.name : undefined)
    );
  };

  const handleDistrictChange = (distName: string) => {
    setCalibDistrict(distName);
    const blks = getBlocksForDistrict(distName);
    if (blks.length > 0) {
      setCalibBlock(blks[0].name);
      const grms = blks[0].gramaPanchayats;
      if (grms.length > 0) {
        setCalibGrama(grms[0].name);
        setCalibWard(grms[0].localAreas?.[0] || 'Ward 01');
      }
    }
  };

  const handleBlockChange = (blkName: string) => {
    setCalibBlock(blkName);
    const grms = getGramasForBlock(calibDistrict, blkName);
    if (grms.length > 0) {
      setCalibGrama(grms[0].name);
      setCalibWard(grms[0].localAreas?.[0] || 'Ward 01');
    }
  };

  const handleApplyHierarchy = () => {
    const blks = getBlocksForDistrict(calibDistrict);
    const blk = blks.find((b) => b.name === calibBlock) || blks[0];
    const grm = blk?.gramaPanchayats.find((g) => g.name === calibGrama) || blk?.gramaPanchayats[0];

    if (grm) {
      applyCalibratedLocation(grm, grm.center.lat, grm.center.lng, 5.0, 'CALIBRATED', calibWard);
    }
  };

  const handleAcquireHighAccuracyGps = () => {
    setIsAcquiringGps(true);
    setGpsFixError('');

    if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const acc = pos.coords.accuracy;
          const nearest = findNearestGramaPanchayat(lat, lng);
          setIsAcquiringGps(false);
          applyCalibratedLocation(nearest, lat, lng, acc, 'GPS');
        },
        (err) => {
          setIsAcquiringGps(false);
          setGpsFixError(
            err.code === 1
              ? 'GPS Permission Denied. Please enable location permissions.'
              : 'GPS Timeout. Falling back to Kerala administrative centroid.'
          );
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      setIsAcquiringGps(false);
      setGpsFixError('Browser does not support geolocation. Please use Instant Search or Hierarchy tabs.');
    }
  };

  // 2. Fetch Active Alerts and Incoming Carrier SMS for this phone / sector
  const fetchResidentFeed = (activePhone?: string) => {
    const targetPhone = activePhone || enrolledPhone || phone || '+919847256789';
    setIsLoadingAlerts(true);

    fetch(`/api/resident/alerts?phone=${encodeURIComponent(targetPhone)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          setAlerts(data.alerts || []);
          if (data.allSmsMessages) {
            setAllSmsMessages(data.allSmsMessages);
          }
          if (data.incomingSms) {
            setIncomingSms(data.incomingSms);
            if (data.incomingSms.acknowledgedAt) {
              setSmsAckConfirmed(true);
            } else {
              setSmsAckConfirmed(false);
              if (!dismissedSmsIds.includes(data.incomingSms.id)) {
                setShowPushBanner(true);
              }
            }
          }
        }
      })
      .catch(() => {})
      .finally(() => setIsLoadingAlerts(false));

    fetch(`/api/resident/requests?phone=${encodeURIComponent(targetPhone)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.requests) {
          setMyRequests(data.requests);
          const unackedDirective = data.requests.find(
            (r: any) => r.adminMessage && !r.userMessageAckAt
          );
          if (unackedDirective && !dismissedSmsIds.includes(`req-${unackedDirective.id}`)) {
            setShowPushBanner(true);
          }
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    fetchResidentFeed();
    const interval = setInterval(() => fetchResidentFeed(), 5000);
    return () => clearInterval(interval);
  }, [enrolledPhone, dismissedSmsIds]);

  // 3. One-Step Phone Number Enrollment
  const handleQuickEnroll = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setEnrollError('');
    setEnrollMsg('');

    if (!phone || phone.trim().length < 8) {
      setEnrollError('Please enter a valid mobile phone number.');
      return;
    }

    setIsEnrolling(true);
    const lat = coords?.lat || detectedSector?.center.lat || 11.5545;
    const lng = coords?.lng || detectedSector?.center.lng || 76.1285;
    const acc = coords?.accuracy || 5.0;

    try {
      const res = await fetch('/api/resident/quick-enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: phone.trim(),
          latitude: lat,
          longitude: lng,
          accuracy: acc,
          district: detectedSector?.districtName,
          blockPanchayat: detectedSector?.blockName,
          gramaPanchayat: detectedSector?.name,
          designatedReliefCamp: detectedSector?.designatedReliefCamp,
          ward: selectedWard || detectedSector?.localAreas?.[0] || 'Ward 01',
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        const clean = data.user.phone;
        setEnrolledPhone(clean);
        localStorage.setItem('resqlink_resident_phone', clean);
        setEnrollMsg(`Mobile phone ${clean} successfully linked to official disaster broadcast grid.`);
        fetchResidentFeed(clean);
      } else {
        setEnrollError(data.error || 'Failed to enroll phone number.');
      }
    } catch (err: any) {
      setEnrollError(err.message || 'Network error enrolling phone.');
    } finally {
      setIsEnrolling(false);
    }
  };

  // 4. Two-Step Emergency SOS Dispatch with Accidental-Activation Protection
  const startSosConfirmation = () => {
    setConfirmingSos(true);
    setSosCountdown(5);
  };

  useEffect(() => {
    if (!confirmingSos || sosCountdown === null) return;
    if (sosCountdown <= 0) {
      setConfirmingSos(false);
      setSosCountdown(null);
      return;
    }
    const timer = setTimeout(() => {
      setSosCountdown((prev) => (prev ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [confirmingSos, sosCountdown]);

  const handleBroadcastSOS = async () => {
    setConfirmingSos(false);
    setSosCountdown(null);
    const activePhone = enrolledPhone || phone || '+919447100004';
    setIsSosBroadcasting(true);
    setSosError('');
    setSosSuccessTicket(null);

    const lat = coords?.lat || detectedSector?.center.lat || 11.5545;
    const lng = coords?.lng || detectedSector?.center.lng || 76.1285;
    const district = detectedSector?.districtName || 'Wayanad';
    const block = detectedSector?.blockName || 'Kalpetta Block';
    const grama = detectedSector?.name || 'Local Sector';
    const address = `${selectedWard || detectedSector?.localAreas?.[0] || 'Ward 01'}, ${grama}, ${block}, ${district}, Kerala`;

    try {
      const res = await fetch('/api/resident/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: activePhone,
          category: 'FLOOD',
          description: 'EMERGENCY SOS BROADCAST: Citizen requested immediate emergency rescue assistance via mobile phone.',
          peopleCount: 1,
          hasInjuries: false,
          immediateDanger: true,
          latitude: lat,
          longitude: lng,
          address,
          district,
          blockPanchayat: block,
          gramaPanchayat: grama,
          ward: selectedWard || detectedSector?.localAreas?.[0] || 'Ward 01',
          contactPreference: 'SMS',
          locationSource: locationSource === 'GPS' ? 'DEVICE_GPS' : 'CALIBRATED_GRID',
          locationConfidence: locationSource === 'GPS' ? 0.98 : 0.95,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSosSuccessTicket(data);
        fetchResidentFeed(activePhone);
      } else {
        setSosError(data.error || 'Failed to dispatch SOS signal.');
      }
    } catch (err: any) {
      setSosError(err.message || 'Network error triggering SOS.');
    } finally {
      setIsSosBroadcasting(false);
    }
  };

  // 5. Register an Issue (Request Help)
  const handleRegisterIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    setIssueFormError('');

    if (!issueDescription.trim()) {
      setIssueFormError('Please describe the issue or assistance required.');
      return;
    }

    setIsSubmittingIssue(true);
    const activePhone = enrolledPhone || phone || '+919447100004';
    const lat = coords?.lat || detectedSector?.center.lat || 11.5545;
    const lng = coords?.lng || detectedSector?.center.lng || 76.1285;
    const district = detectedSector?.districtName || 'Wayanad';
    const block = detectedSector?.blockName || 'Kalpetta Block';
    const grama = detectedSector?.name || 'Local Sector';
    const address = `${selectedWard || detectedSector?.localAreas?.[0] || 'Ward 01'}, ${grama}, ${block}, ${district}, Kerala`;

    try {
      const res = await fetch('/api/resident/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: activePhone,
          category: issueCategory,
          description: issueDescription.trim(),
          peopleCount: issuePeopleCount,
          hasInjuries,
          immediateDanger,
          latitude: lat,
          longitude: lng,
          address,
          district,
          blockPanchayat: block,
          gramaPanchayat: grama,
          ward: selectedWard || detectedSector?.localAreas?.[0] || 'Ward 01',
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setIssueSubmittedTicket(data.ticket);
        setIssueDescription('');
        setShowIssueModal(false);
        fetchResidentFeed(activePhone);
      } else {
        setIssueFormError(data.error || 'Failed to submit issue.');
      }
    } catch (err: any) {
      setIssueFormError(err.message || 'Network error submitting issue.');
    } finally {
      setIsSubmittingIssue(false);
    }
  };

  // 6. Two-Way Delivery Handshake (Verifies Delivery to SEOC Admin Command)
  const handleAcknowledgeDelivery = async (
    targetAttemptId?: string,
    targetRequestId?: string,
    trackingNumber?: string
  ) => {
    setIsAckingSms(true);
    const activePhone = enrolledPhone || phone || '+919447100004';

    try {
      // Step A: Acknowledge SMS notification attempt
      await fetch('/api/notifications/ack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attemptId: targetAttemptId || incomingSms?.id,
          recipientPhone: activePhone,
          ackMethod: 'SMARTPHONE_TAP_CONFIRM',
        }),
      });

      // Step B: Acknowledge SOS request
      const reqId = targetRequestId || requestsWithDirectives[0]?.id;
      const tracking = trackingNumber || requestsWithDirectives[0]?.trackingNumber;
      if (reqId || tracking || activePhone) {
        await fetch('/api/resident/requests/ack', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            requestId: reqId,
            trackingNumber: tracking,
            phone: activePhone,
          }),
        });
      }

      setSmsAckConfirmed(true);
      setShowPushBanner(false);
      fetchResidentFeed(activePhone);
    } catch (e) {
    } finally {
      setIsAckingSms(false);
    }
  };

  const requestsWithDirectives = myRequests.filter((r) => r.adminMessage);
  const latestDirectiveReq = requestsWithDirectives.find((r) => !r.userMessageAckAt) || requestsWithDirectives[0];
  const activePushText = latestDirectiveReq?.adminMessage || incomingSms?.messageBody;

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] font-classic">
      {/* 0. AUTOMATIC CITIZEN IDENTITY ONBOARDING MODAL (NAME, GMAIL, PHONE) */}
      {showIdentityModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-2xl animate-in fade-in">
          <div className="ios-glass-card-elevated w-full max-w-lg p-7 sm:p-8 space-y-6 relative border border-white/[0.2] shadow-2xl text-left">
            {residentName && (
              <button
                onClick={() => setShowIdentityModal(false)}
                className="absolute top-5 right-5 p-1.5 rounded-full bg-white/[0.08] hover:bg-white/[0.15] text-[#929CAB] hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <div className="space-y-2">
              <div className="ios-capsule text-[#FF6B35] font-extrabold text-[10px] uppercase tracking-widest">
                <ShieldCheck className="w-3.5 h-3.5 text-[#FF6B35]" />
                <span>CITIZEN EMERGENCY IDENTIFICATION</span>
              </div>
              <h3 className="text-2xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
                Resident Safety Network Entry
              </h3>
              <p className="text-xs text-[#929CAB] font-classic leading-relaxed">
                Enter your identity credentials so SEOC emergency responders, NDRF battalions, and carrier alert systems address you directly during active disasters.
              </p>
            </div>

            <form onSubmit={handleSaveIdentity} className="space-y-4 font-classic">
              {identityError && (
                <div className="p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 text-xs text-[#EF4444] font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{identityError}</span>
                </div>
              )}

              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Full Name <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={residentName}
                    onChange={(e) => setResidentName(e.target.value)}
                    placeholder="e.g. Arun Kumar / Ananya Menon"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#FF6B35] focus:ring-1 focus:ring-[#FF6B35] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition"
                  />
                </div>
              </div>

              {/* Gmail / Email Account */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Gmail / Email Account <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <MessageSquare className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={residentEmail}
                    onChange={(e) => setResidentEmail(e.target.value)}
                    placeholder="e.g. yourname@gmail.com"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#38BDF8] focus:ring-1 focus:ring-[#38BDF8] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition font-mono"
                  />
                </div>
              </div>

              {/* Mobile Phone Number */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#F5F7FA] uppercase tracking-wider font-mono">
                  Mobile Phone Number <span className="text-[#EF4444]">*</span>
                </label>
                <div className="relative">
                  <Smartphone className="w-4 h-4 text-[#929CAB] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +91 98471 23456"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-white/[0.12] focus:border-[#22C55E] focus:ring-1 focus:ring-[#22C55E] text-sm text-[#F5F7FA] placeholder:text-[#6F7C93] outline-none transition font-mono"
                  />
                </div>
              </div>

              {/* Detected Real GPS Preview */}
              <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs font-mono space-y-1">
                <div className="flex items-center justify-between text-[#929CAB]">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#FF6B35]" />
                    <span>Real-time Detected Sector:</span>
                  </span>
                  <span className="text-[#22C55E] font-bold">
                    {locationSource === 'GPS' ? '● LIVE GPS FIX' : '● NETWORK CELL'}
                  </span>
                </div>
                <div className="text-[#F5F7FA] font-bold">
                  {detectedSector ? `${detectedSector.name}, ${detectedSector.districtName}` : 'Acquiring GPS location...'}
                </div>
                {coords && (
                  <div className="text-[10px] text-[#6F7C93]">
                    Coordinates: [{coords.lat.toFixed(4)}°N, {coords.lng.toFixed(4)}°E] (±{coords.accuracy.toFixed(1)}m)
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isSavingIdentity}
                className="ios-button-primary w-full py-4 text-sm font-bold shadow-xl cursor-pointer disabled:opacity-50"
              >
                {isSavingIdentity ? 'Saving Citizen Identity...' : '✓ Register Identity & Enter Safety Grid'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 1. TOP STATUS & LOCATION HUD BAR */}
      <div className="bg-[#0B1017] border-b border-[rgba(255,255,255,0.08)] sticky top-0 z-40 backdrop-blur-md px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#22C55E]/10 border border-[#22C55E]/30 text-[#22C55E] font-bold">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
              <span>SEOC RESILIENCE GRID CONNECTED</span>
            </div>
            <span className="text-[#6F7C93] hidden sm:inline">|</span>
            <div className="hidden sm:flex items-center gap-1.5 text-[#929CAB]">
              <MapPin className="w-3.5 h-3.5 text-[#FF6B35]" />
              <span className="text-[#F5F7FA] font-bold truncate max-w-xs">
                {detectedSector ? `${detectedSector.name}, ${detectedSector.districtName}` : 'Calibrating Location...'}
              </span>
              {coords && <span className="text-[10px] text-[#6F7C93]">(±{coords.accuracy.toFixed(1)}m)</span>}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLocationModal(true)}
              className="px-2.5 py-1 rounded bg-[#101720] border border-[rgba(255,255,255,0.12)] hover:border-[#FF6B35]/50 text-[#FF6B35] font-bold transition flex items-center gap-1 text-[11px]"
            >
              <Sliders className="w-3 h-3" />
              <span>Calibrate Location</span>
            </button>
            <button
              onClick={() => detectDeviceLocation()}
              disabled={isDetectingGps}
              className="p-1 rounded bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
              title="Refresh GPS"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isDetectingGps ? 'animate-spin text-[#FF6B35]' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN LAYOUT: LEFT SIDEBAR + CONTENT AREA */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT SIDEBAR (APPLE-INSPIRED MINIMAL NAVIGATION) */}
          <aside className="lg:col-span-3 space-y-4">
            {/* Resident Profile Card (Personalized Identity) */}
            <div className="ios-glass-card p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-[#FF6B35]/20 border border-[#FF6B35]/40 text-[#FF6B35] flex items-center justify-center font-bold text-sm shadow-md">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-extrabold text-[#F5F7FA] tracking-tight">
                      {residentName || 'Registered Resident'}
                    </div>
                    <div className="text-[11px] font-mono text-[#38BDF8] truncate max-w-[150px]">
                      {residentEmail || enrolledPhone || 'Unregistered'}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setShowIdentityModal(true)}
                  className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-[#929CAB] hover:text-white transition cursor-pointer"
                  title="Edit Identity Profile"
                >
                  <Sliders className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="pt-2 border-t border-white/[0.08] text-[11px] font-mono space-y-1">
                <div className="text-[#6F7C93] uppercase text-[9px] font-bold">VERIFIED CONTACT</div>
                <div className="text-[#22C55E] font-bold">
                  {enrolledPhone ? `✓ ${enrolledPhone}` : 'No phone linked'}
                </div>
              </div>

              <div className="pt-2 border-t border-white/[0.08] text-[11px] font-mono space-y-1">
                <div className="text-[#6F7C93] uppercase text-[9px] font-bold">DESIGNATED RELIEF CAMP</div>
                <div className="text-[#F5F7FA] font-semibold leading-tight">
                  {detectedSector?.designatedReliefCamp || 'Nearest District Relief Center'}
                </div>
              </div>
            </div>

            {/* Navigation Menu Links */}
            <nav className="p-2 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-1 font-mono text-xs">
              {[
                { id: 'overview', label: 'Overview', icon: Home },
                { id: 'alerts', label: 'Live Alerts', icon: Bell, badge: alerts.length },
                { id: 'location', label: 'My Location', icon: MapPin },
                { id: 'sos', label: 'Emergency SOS', icon: LifeBuoy, highlight: true },
                { id: 'evacuation', label: 'Relief Shelter', icon: HeartPulse },
                { id: 'contacts', label: 'Emergency Numbers', icon: Phone },
                { id: 'profile', label: 'Phone Profile', icon: User },
              ].map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as any);
                      const el = document.getElementById(item.id);
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      item.highlight && !isActive
                        ? 'text-[#EF4444] hover:bg-[#EF4444]/10'
                        : isActive
                        ? 'bg-[#151E29] text-[#FF6B35] font-bold border border-[rgba(255,255,255,0.12)]'
                        : 'text-[#929CAB] hover:text-[#F5F7FA] hover:bg-[#151E29]/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${item.highlight ? 'text-[#EF4444]' : ''}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-[#EF4444] text-white text-[10px] font-bold">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Quick Helpline Numbers Card */}
            <div className="p-4 rounded-2xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] space-y-2 text-xs font-mono">
              <div className="text-[10px] uppercase text-[#6F7C93] font-bold tracking-wider">
                24x7 STATE CONTROL ROOMS
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[#929CAB]">SEOC Emergency:</span>
                  <a href="tel:1077" className="text-[#FF6B35] font-bold hover:underline">1077</a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#929CAB]">Police Distress:</span>
                  <a href="tel:112" className="text-[#38BDF8] font-bold hover:underline">112</a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#929CAB]">Fire &amp; Rescue:</span>
                  <a href="tel:101" className="text-[#F5A623] font-bold hover:underline">101</a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#929CAB]">Medical Ambulance:</span>
                  <a href="tel:108" className="text-[#22C55E] font-bold hover:underline">108</a>
                </div>
              </div>
            </div>
          </aside>

          {/* MAIN CONTENT AREA */}
          <main className="lg:col-span-9 space-y-6">
            {/* 3. HEADS-UP 2-WAY CARRIER SMS PUSH BANNER (VK-KSDMA) */}
            {showPushBanner && activePushText && (
              <div className="p-5 rounded-2xl bg-gradient-to-r from-[#101720] via-[#151E29] to-[#101720] border-2 border-[#FF6B35] shadow-2xl space-y-3 relative overflow-hidden animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#FF6B35] animate-ping" />
                    <span className="text-[11px] font-mono font-bold uppercase text-[#FF6B35]">
                      DIRECTIVE FROM VK-KSDMA • CONFIRMATION REQUIRED
                    </span>
                  </div>
                  <button
                    onClick={() => setShowPushBanner(false)}
                    className="text-[#6F7C93] hover:text-[#F5F7FA] p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-sm font-semibold text-[#F5F7FA] leading-relaxed">
                  &ldquo;{activePushText}&rdquo;
                </p>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[rgba(255,255,255,0.08)]">
                  <span className="text-[11px] font-mono text-[#929CAB]">
                    Carrier: BSNL/Airtel SMS Handshake Handset delivery confirmed.
                  </span>
                  <button
                    onClick={() => handleAcknowledgeDelivery()}
                    disabled={isAckingSms}
                    className="px-4 py-2 rounded-xl bg-[#22C55E] hover:bg-[#16A34A] text-[#07090D] font-mono font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-lg"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isAckingSms ? 'Verifying...' : '✓ Confirm Safe & Received'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* 4. LOCATION-AWARE HERO GREETING (PERSONALIZED) */}
            <div id="overview" className="ios-glass-card-elevated p-7 sm:p-9 space-y-4 relative overflow-hidden">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E] animate-ping" />
                  <span>{greeting}, {residentName ? residentName.toUpperCase() : 'RESIDENT'}</span>
                  <span className="text-[#6F7C93]">•</span>
                  <span>RESIDENT SAFETY PROTOCOL</span>
                </div>

                <h1 className="text-3xl sm:text-5xl font-extrabold text-[#F5F7FA] font-headline tracking-tight">
                  {residentName ? `Stay safe, ${residentName}.` : 'Stay informed. Stay prepared.'}
                </h1>

                <p className="text-xs sm:text-sm text-[#929CAB] max-w-2xl leading-relaxed font-classic">
                  Real-time early warning telemetry, offline-first citizen distress mesh, and direct two-way coordination with the State Emergency Operations Centre (SEOC Kerala).
                </p>
              </div>

              {/* Real-time Location Badge */}
              <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-mono">
                <div className="px-3.5 py-1.5 rounded-xl bg-white/[0.06] border border-white/[0.12] flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#FF6B35]" />
                  <span className="text-[#F5F7FA] font-bold">
                    {detectedSector ? `${detectedSector.name}, ${detectedSector.districtName}` : 'Acquiring Live Sector...'}
                  </span>
                  {detectedSector?.blockName && (
                    <span className="text-[#929CAB]">
                      ({detectedSector.blockName})
                    </span>
                  )}
                </div>

                {coords && (
                  <div className="px-3.5 py-1.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[#929CAB] flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                    <span>GPS: [{coords.lat.toFixed(4)}°N, {coords.lng.toFixed(4)}°E] ±{coords.accuracy.toFixed(1)}m</span>
                  </div>
                )}

                <button
                  onClick={() => detectDeviceLocation()}
                  className="px-3 py-1.5 rounded-xl bg-[#FF6B35]/15 border border-[#FF6B35]/30 text-[#FF6B35] font-bold hover:bg-[#FF6B35]/25 transition flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isDetectingGps ? 'animate-spin' : ''}`} />
                  <span>Refresh GPS Fix</span>
                </button>
              </div>
            </div>

            {/* 5. PROMINENT EMERGENCY SOS SECTION (WITH ACCIDENTAL ACTIVATION PROTECTION) */}
            <div id="sos" className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#101720] via-[#151E29] to-[#0B1017] border-2 border-[#EF4444]/40 shadow-2xl space-y-5 relative overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="inline-flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-[#EF4444] font-bold">
                    <span className="w-2 h-2 rounded-full bg-[#EF4444] animate-ping" />
                    <span>SEOC PRIORITY 1 EMERGENCY DISPATCH</span>
                  </div>
                  <h2 className="text-2xl font-extrabold text-[#F5F7FA] mt-1 font-sans">
                    Emergency Rescue Beacon (SOS)
                  </h2>
                  <p className="text-xs text-[#929CAB] mt-0.5">
                    Transmits your verified GPS coordinates, family count, and nearest shelter assignment directly to deployed NDRF and Fire battalions.
                  </p>
                </div>

                <button
                  onClick={() => setShowIssueModal(true)}
                  className="px-4 py-2.5 rounded-xl bg-[#151E29] hover:bg-[#1C2736] border border-[rgba(255,255,255,0.12)] text-xs font-mono text-[#F5F7FA] transition flex items-center gap-2 self-start sm:self-center"
                >
                  <FileText className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Report Specific Emergency Details →</span>
                </button>
              </div>

              {/* SOS BUTTON WITH CONFIRMATION SAFETY CHECK */}
              <div className="pt-2">
                {!confirmingSos ? (
                  <button
                    onClick={startSosConfirmation}
                    disabled={isSosBroadcasting}
                    className="w-full py-5 rounded-2xl bg-gradient-to-r from-[#DC2626] to-[#EF4444] hover:from-[#EF4444] hover:to-[#DC2626] text-white font-extrabold text-base uppercase tracking-wider transition shadow-2xl shadow-[#EF4444]/40 flex items-center justify-center gap-3 cursor-pointer group active:scale-[0.99]"
                  >
                    <LifeBuoy className="w-6 h-6 animate-pulse group-hover:scale-110 transition" />
                    <span>BROADCAST EMERGENCY SOS BEACON</span>
                  </button>
                ) : (
                  /* Confirmation Safety Mode (Prevents Accidental Triggers) */
                  <div className="p-5 rounded-2xl bg-[#EF4444]/15 border-2 border-[#EF4444] space-y-4 animate-in fade-in">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <AlertTriangle className="w-5 h-5 text-[#EF4444] animate-bounce" />
                        <span className="text-sm font-bold text-[#F5F7FA] font-mono">
                          CONFIRM EMERGENCY SOS DISPATCH ({sosCountdown}s)
                        </span>
                      </div>
                      <span className="text-xs font-mono text-[#EF4444]">Tap Confirm to Transmit</span>
                    </div>

                    <p className="text-xs text-[#929CAB]">
                      You are about to broadcast a live distress signal for <strong>{detectedSector?.name || 'Current Sector'}</strong>. False alerts may divert critical rescue teams.
                    </p>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={handleBroadcastSOS}
                        disabled={isSosBroadcasting}
                        className="flex-1 py-3.5 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-mono font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                      >
                        {isSosBroadcasting ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        <span>{isSosBroadcasting ? 'Broadcasting to SEOC...' : 'YES, TRANSMIT SOS NOW'}</span>
                      </button>

                      <button
                        onClick={() => {
                          setConfirmingSos(false);
                          setSosCountdown(null);
                        }}
                        className="px-6 py-3.5 rounded-xl bg-[#151E29] hover:bg-[#1C2736] text-xs font-mono text-[#929CAB] hover:text-[#F5F7FA] transition cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* SOS Feedback Message */}
              {sosSuccessTicket && (
                <div className="p-4 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/30 text-xs font-mono text-[#22C55E] space-y-1 animate-in fade-in">
                  <div className="flex items-center gap-2 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
                    <span>EMERGENCY BEACON TRANSMITTED &bull; TICKET #{sosSuccessTicket.ticket?.trackingNumber || 'RESQ-SOS'}</span>
                  </div>
                  <p className="text-[#929CAB]">
                    Your distress beacon is registered with State Operations Command. Keep handset charged and powered on.
                  </p>
                </div>
              )}

              {sosError && (
                <div className="p-4 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-xs font-mono text-[#EF4444] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{sosError}</span>
                </div>
              )}
            </div>

            {/* 6. LIVE ALERT CARDS */}
            <div id="alerts" className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-[#FF6B35] font-bold">
                    REGIONAL CALAMITY INTELLIGENCE
                  </div>
                  <h3 className="text-xl font-bold text-[#F5F7FA] mt-0.5">
                    Live Hazard Alerts ({alerts.length})
                  </h3>
                </div>

                <button
                  onClick={() => fetchResidentFeed()}
                  className="p-1.5 rounded-lg bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] text-xs font-mono flex items-center gap-1.5 transition"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAlerts ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>
              </div>

              {alerts.length === 0 ? (
                <div className="p-8 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-[#22C55E] mx-auto" />
                  <div className="text-sm font-bold text-[#F5F7FA]">No Critical Alerts in Sector</div>
                  <p className="text-xs text-[#929CAB] max-w-md mx-auto">
                    Weather radar and catchment monitors report stable hydrological and geological conditions for {detectedSector?.name || 'this area'}.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {alerts.map((alert) => {
                    const isCritical = alert.severity === 'CRITICAL' || alert.severity === 'HIGH';
                    const isWarning = alert.severity === 'WARNING' || alert.severity === 'MEDIUM';

                    return (
                      <div
                        key={alert.id}
                        className={`p-5 rounded-2xl bg-[#101720] border transition space-y-3 relative overflow-hidden ${
                          isCritical
                            ? 'border-[#EF4444]/40 hover:border-[#EF4444]'
                            : isWarning
                            ? 'border-[#F5A623]/40 hover:border-[#F5A623]'
                            : 'border-[rgba(255,255,255,0.08)] hover:border-[#38BDF8]/40'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1.5 ${
                              isCritical
                                ? 'bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]'
                                : isWarning
                                ? 'bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623]'
                                : 'bg-[#38BDF8]/15 border border-[#38BDF8]/30 text-[#38BDF8]'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                isCritical ? 'bg-[#EF4444] animate-pulse' : isWarning ? 'bg-[#F5A623]' : 'bg-[#38BDF8]'
                              }`}
                            />
                            {alert.severity || 'WARNING'} • {alert.category || 'HYDRO-MET'}
                          </span>
                          <span className="text-[10px] font-mono text-[#6F7C93]">
                            {alert.createdAt ? new Date(alert.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Live'}
                          </span>
                        </div>

                        <div>
                          <h4 className="text-sm font-bold text-[#F5F7FA]">
                            {alert.title || 'Official Disaster Warning'}
                          </h4>
                          <p className="text-xs text-[#929CAB] mt-1 leading-relaxed">
                            {alert.description || alert.message || 'Follow emergency coordinator directives.'}
                          </p>
                        </div>

                        <div className="pt-2 border-t border-[rgba(255,255,255,0.06)] flex items-center justify-between text-[11px] font-mono text-[#6F7C93]">
                          <span>Authority: KSDMA / IMD</span>
                          <span className="text-[#22C55E]">✓ Cryptographic ES256</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* 7. PHONE NUMBER ENROLLMENT */}
            <div id="profile" className="p-6 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FF6B35]/15 text-[#FF6B35] flex items-center justify-center">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#F5F7FA]">Mobile Handset Enrollment</h3>
                  <p className="text-xs text-[#929CAB]">
                    Enrolled phone numbers receive prioritized SMS text broadcasts via TRAI DLT gateways during cellular congestion.
                  </p>
                </div>
              </div>

              {enrolledPhone ? (
                <div className="p-4 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="text-[#22C55E]">● Connected:</span>
                    <strong className="text-[#F5F7FA] text-sm">{enrolledPhone}</strong>
                  </div>
                  <button
                    onClick={() => {
                      setEnrolledPhone(null);
                      setPhone('');
                      localStorage.removeItem('resqlink_resident_phone');
                    }}
                    className="text-[#6F7C93] hover:text-[#EF4444] text-[11px] underline"
                  >
                    Unlink Handset
                  </button>
                </div>
              ) : (
                <form onSubmit={handleQuickEnroll} className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter 10-digit mobile number (e.g. 98472 56789)..."
                    className="flex-1 px-4 py-3 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-xs text-[#F5F7FA] placeholder:text-[#6F7C93] focus:border-[#FF6B35] focus:outline-none font-mono"
                  />
                  <button
                    type="submit"
                    disabled={isEnrolling}
                    className="px-6 py-3 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold text-xs font-mono transition flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                  >
                    {isEnrolling ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    <span>Link Handset</span>
                  </button>
                </form>
              )}
            </div>
          </main>
        </div>
      </div>

      {/* 8. MODAL: REGISTER AN ISSUE / REQUEST HELP */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#101720] border border-[rgba(255,255,255,0.12)] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-3">
              <div className="flex items-center gap-2">
                <LifeBuoy className="w-5 h-5 text-[#FF6B35]" />
                <h3 className="text-base font-bold text-[#F5F7FA]">Report Emergency Situation</h3>
              </div>
              <button onClick={() => setShowIssueModal(false)} className="text-[#6F7C93] hover:text-[#F5F7FA]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterIssue} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-[#929CAB]">Category:</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'TRAPPED', label: 'People Trapped' },
                    { id: 'MEDICAL', label: 'Medical Urgent' },
                    { id: 'FLOOD', label: 'Rising Flood' },
                    { id: 'LANDSLIDE', label: 'Landslide / Blocked' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setIssueCategory(cat.id)}
                      className={`p-2.5 rounded-xl text-left border cursor-pointer ${
                        issueCategory === cat.id
                          ? 'bg-[#FF6B35]/15 border-[#FF6B35] text-[#FF6B35] font-bold'
                          : 'bg-[#0B1017] border-[rgba(255,255,255,0.08)] text-[#929CAB]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[#929CAB]">Situation Details:</label>
                <textarea
                  required
                  rows={3}
                  value={issueDescription}
                  onChange={(e) => setIssueDescription(e.target.value)}
                  placeholder="Describe location, number of trapped individuals, building type, water level..."
                  className="w-full p-3 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA] text-xs focus:border-[#FF6B35] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#929CAB]">People Count:</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={issuePeopleCount}
                    onChange={(e) => setIssuePeopleCount(parseInt(e.target.value) || 1)}
                    className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA] text-xs"
                  />
                </div>

                <div className="space-y-2 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-[#929CAB]">
                    <input
                      type="checkbox"
                      checked={hasInjuries}
                      onChange={(e) => setHasInjuries(e.target.checked)}
                      className="rounded bg-[#0B1017] border-[rgba(255,255,255,0.2)] text-[#FF6B35]"
                    />
                    <span>Injuries Reported</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-[#EF4444]">
                    <input
                      type="checkbox"
                      checked={immediateDanger}
                      onChange={(e) => setImmediateDanger(e.target.checked)}
                      className="rounded bg-[#0B1017] border-[rgba(255,255,255,0.2)] text-[#EF4444]"
                    />
                    <span className="font-bold">Immediate Danger</span>
                  </label>
                </div>
              </div>

              {issueFormError && (
                <div className="p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]">
                  {issueFormError}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#0B1017] text-[#929CAB] hover:text-[#F5F7FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingIssue}
                  className="px-5 py-2.5 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmittingIssue ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>Submit to Rescue Queue</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 9. MODAL: LOCATION CALIBRATION & SECTOR SELECTOR (PRESERVED 3 MODES ACROSS 941 GRAMAS) */}
      {showLocationModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-[#101720] border border-[rgba(255,255,255,0.12)] rounded-3xl p-6 space-y-5 shadow-2xl relative max-h-[90vh] flex flex-col">
            <div className="flex items-start justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FF6B35]/15 text-[#FF6B35] border border-[#FF6B35]/30 flex items-center justify-center shrink-0">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#F5F7FA]">
                    Calibrate Resident Jurisdiction &amp; Location
                  </h3>
                  <p className="text-xs font-mono text-[#929CAB] mt-0.5">
                    Search across Kerala&apos;s 14 Districts, 152 Blocks &amp; 941 Gramas, or acquire satellite GPS.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowLocationModal(false)}
                className="p-1 rounded-lg text-[#6F7C93] hover:text-[#F5F7FA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] shrink-0 text-xs font-mono">
              <button
                type="button"
                onClick={() => setCalibTab('SEARCH')}
                className={`py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer font-bold ${
                  calibTab === 'SEARCH' ? 'bg-[#FF6B35] text-[#07090D]' : 'text-[#929CAB] hover:text-[#F5F7FA]'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>Instant Search</span>
              </button>
              <button
                type="button"
                onClick={() => setCalibTab('HIERARCHY')}
                className={`py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer font-bold ${
                  calibTab === 'HIERARCHY' ? 'bg-[#FF6B35] text-[#07090D]' : 'text-[#929CAB] hover:text-[#F5F7FA]'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>District / Block / Grama</span>
              </button>
              <button
                type="button"
                onClick={() => setCalibTab('GPS')}
                className={`py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer font-bold ${
                  calibTab === 'GPS' ? 'bg-[#FF6B35] text-[#07090D]' : 'text-[#929CAB] hover:text-[#F5F7FA]'
                }`}
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Satellite GPS</span>
              </button>
            </div>

            {/* Tab 1: Instant Search */}
            {calibTab === 'SEARCH' && (
              <div className="space-y-4 flex-1 overflow-y-auto">
                <div className="relative">
                  <Search className="w-4 h-4 text-[#6F7C93] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={locationSearchQuery}
                    onChange={(e) => setLocationSearchQuery(e.target.value)}
                    placeholder="Search Grama Panchayat, Block, or District (e.g. Meppadi, Kalpetta, Wayanad)..."
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-xs text-[#F5F7FA] placeholder:text-[#6F7C93] focus:border-[#FF6B35] focus:outline-none font-mono"
                    autoFocus
                  />
                </div>

                {locationSearchQuery.trim().length >= 2 && searchResults.length > 0 && (
                  <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                    {searchResults.map((item) => (
                      <button
                        key={`${item.type}-${item.name}-${item.district}`}
                        onClick={() => handleSelectSearchResult(item)}
                        className="w-full text-left p-3 rounded-xl bg-[#0B1017] hover:bg-[#151E29] border border-[rgba(255,255,255,0.06)] hover:border-[#FF6B35]/50 transition flex items-center justify-between group cursor-pointer"
                      >
                        <div>
                          <div className="text-xs font-bold text-[#F5F7FA] font-mono flex items-center gap-2">
                            <span>{item.name}</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#151E29] text-[#38BDF8]">
                              {item.type}
                            </span>
                          </div>
                          <div className="text-[11px] text-[#929CAB] mt-0.5 font-mono">
                            {item.block ? `${item.block}, ` : ''}{item.district}
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[#6F7C93] group-hover:text-[#FF6B35] group-hover:translate-x-1 transition" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Cascading Dropdowns */}
            {calibTab === 'HIERARCHY' && (
              <div className="space-y-3 flex-1 overflow-y-auto text-xs font-mono">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[#929CAB]">District:</label>
                    <select
                      value={calibDistrict}
                      onChange={(e) => handleDistrictChange(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                    >
                      {getAllDistricts().map((d) => (
                        <option key={d.name} value={d.name}>{d.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Block Panchayat:</label>
                    <select
                      value={calibBlock}
                      onChange={(e) => handleBlockChange(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                    >
                      {getBlocksForDistrict(calibDistrict).map((b) => (
                        <option key={b.name} value={b.name}>{b.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[#929CAB]">Grama Panchayat:</label>
                    <select
                      value={calibGrama}
                      onChange={(e) => setCalibGrama(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.08)] text-[#F5F7FA]"
                    >
                      {getGramasForBlock(calibDistrict, calibBlock).map((g) => (
                        <option key={g.name} value={g.name}>{g.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleApplyHierarchy}
                  className="w-full py-3 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold text-xs uppercase tracking-wider transition cursor-pointer mt-2"
                >
                  Confirm &amp; Apply Calibrated Sector
                </button>
              </div>
            )}

            {/* Tab 3: Precision Satellite GPS */}
            {calibTab === 'GPS' && (
              <div className="space-y-4 p-4 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] text-center text-xs font-mono">
                <Navigation className={`w-8 h-8 text-[#FF6B35] mx-auto ${isAcquiringGps ? 'animate-spin' : ''}`} />
                <p className="text-[#929CAB] max-w-sm mx-auto">
                  Acquires real-time high-accuracy coordinates from browser/handset and maps to nearest Grama centroid.
                </p>
                <button
                  type="button"
                  onClick={handleAcquireHighAccuracyGps}
                  disabled={isAcquiringGps}
                  className="px-6 py-3 rounded-xl bg-[#FF6B35] hover:bg-[#E85A24] text-[#07090D] font-bold text-xs uppercase tracking-wider transition disabled:opacity-50 cursor-pointer"
                >
                  {isAcquiringGps ? 'Locking Satellites...' : 'Acquire High-Accuracy GPS Fix'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
