'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  MapPin,
  Compass,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Plus,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function ResidentLocationsPage() {
  const [profile, setProfile] = useState<any>(null);
  const [locations, setLocations] = useState<any[]>([]);
  const [district, setDistrict] = useState('Wayanad');
  const [localBody, setLocalBody] = useState('');
  const [ward, setWard] = useState('');
  const [address, setAddress] = useState('');
  const [latitude, setLatitude] = useState(11.5545);
  const [longitude, setLongitude] = useState(76.1285);
  const [isLocating, setIsLocating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    fetch('/api/resident/profile')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          setProfile(data.profile);
          if (data.locations) setLocations(data.locations);
          if (data.profile) {
            setDistrict(data.profile.registeredDistrict || 'Wayanad');
            setLocalBody(data.profile.registeredLocalBody || '');
            setWard(data.profile.registeredWard || '');
            setAddress(data.profile.registeredAddress || '');
            setLatitude(data.profile.latitude || 11.5545);
            setLongitude(data.profile.longitude || 76.1285);
          }
        }
      })
      .catch(() => {});
  }, []);

  const handleAcquireGps = () => {
    if (!navigator.geolocation) return;
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(Number(pos.coords.latitude.toFixed(5)));
        setLongitude(Number(pos.coords.longitude.toFixed(5)));
        setIsLocating(false);
      },
      () => setIsLocating(false)
    );
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSuccessMsg('');

    try {
      const res = await fetch('/api/resident/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          district,
          localBody,
          ward,
          address,
          latitude,
          longitude,
        }),
      });

      if (res.ok) {
        setSuccessMsg('Primary registered residence location successfully updated.');
      }
    } catch (e) {
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
          <MapPin className="w-4 h-4 text-primary" />
          <span>Resident Risk Digital Twin Registry</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Registered Safe Locations &amp; Coordinates
        </h1>
        <p className="text-xs text-text-secondary mt-1">
          Your registered home coordinates determine which official hazard warning zones evaluate your exposure.
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-6">
        <h3 className="text-sm font-bold text-text-primary uppercase font-mono">
          Primary Home Location
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">Kerala District</label>
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
            >
              {KERALA_DISTRICTS.map((d) => (
                <option key={d.id} value={d.name}>
                  {d.name} ({d.nameMl})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">Local Body (Panchayat / Municipality)</label>
            <input
              type="text"
              value={localBody}
              onChange={(e) => setLocalBody(e.target.value)}
              placeholder="e.g. Meppadi Grama Panchayat"
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">Ward</label>
            <input
              type="text"
              value={ward}
              onChange={(e) => setWard(e.target.value)}
              placeholder="e.g. Ward 10"
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-mono text-text-muted">Full Address &amp; Landmarks</label>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="House Name/Number, Road, Landmark..."
            className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
          />
        </div>

        {/* GPS Coordinates & Acquisition */}
        <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-text-muted font-bold">WGS84 COORDINATES</span>
            <button
              type="button"
              onClick={handleAcquireGps}
              disabled={isLocating}
              className="text-xs font-mono text-primary hover:underline flex items-center gap-1 font-semibold"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>{isLocating ? 'Acquiring...' : 'Update from Device GPS'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs font-mono">
            <div>
              <span className="text-text-muted text-[10px]">Latitude:</span>
              <input
                type="number"
                step="any"
                value={latitude}
                onChange={(e) => setLatitude(parseFloat(e.target.value))}
                className="w-full bg-surface-1 border border-surface-3 rounded p-2 text-text-primary"
              />
            </div>
            <div>
              <span className="text-text-muted text-[10px]">Longitude:</span>
              <input
                type="number"
                step="any"
                value={longitude}
                onChange={(e) => setLongitude(parseFloat(e.target.value))}
                className="w-full bg-surface-1 border border-surface-3 rounded p-2 text-text-primary"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
        >
          {isSaving ? 'Saving...' : 'Save Location Updates'}
        </button>
      </form>
    </div>
  );
}
