'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function ResidentIndexRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/resident/dashboard');
  }, [router]);

  return (
    <div className="min-h-[50vh] flex items-center justify-center text-xs font-mono text-text-muted">
      <span>Redirecting to Resident Safety Portal...</span>
    </div>
  );
}
