'use client';

import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HeartPulse,
  MapPin,
  Lock,
} from 'lucide-react';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function ResidentProfilePage() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [householdSize, setHouseholdSize] = useState(4);
  const [hasElderly, setHasElderly] = useState(false);
  const [hasInfants, setHasInfants] = useState(false);
  const [hasDisabilities, setHasDisabilities] = useState(false);
  const [requiresEvacuationAssist, setRequiresEvacuationAssist] = useState(false);
  const [medicalNeedsSummary, setMedicalNeedsSummary] = useState('');

  // Phone Verification Modal State
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otpCode, setOtpCode] = useState('123456');
  const [otpMsg, setOtpMsg] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  useEffect(() => {
    fetch('/api/resident/profile')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          setUser(data.user);
          setProfile(data.profile);
          if (data.user) {
            setName(data.user.name || '');
            setPhone(data.user.phone || '');
            setPhoneVerified(data.user.phoneVerified || false);
          }
          if (data.profile) {
            setHouseholdSize(data.profile.householdSize || 1);
            setHasElderly(data.profile.hasElderly || false);
            setHasInfants(data.profile.hasInfants || false);
            setHasDisabilities(data.profile.hasDisabilities || false);
            setRequiresEvacuationAssist(data.profile.requiresEvacuationAssist || false);
            setMedicalNeedsSummary(data.profile.medicalNeedsSummary || '');
          }
        }
      })
      .catch(() => {});
  }, []);

  const handleVerifyPhone = async () => {
    setIsVerifying(true);
    setOtpMsg('');
    try {
      const res = await fetch('/api/auth/verify-phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otp: otpCode, phone }),
      });
      const data = await res.json();
      if (res.ok) {
        setPhoneVerified(true);
        setShowOtpModal(false);
        setStatusMsg('Mobile phone verified successfully via TRAI OTP registry.');
      } else {
        setOtpMsg(data.error || 'Verification failed');
      }
    } catch (e: any) {
      setOtpMsg(e.message || 'Network error');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMsg('');

    try {
      const res = await fetch('/api/resident/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          phone,
          householdSize,
          hasElderly,
          hasInfants,
          hasDisabilities,
          requiresEvacuationAssist,
          medicalNeedsSummary,
        }),
      });

      if (res.ok) {
        setStatusMsg('Resident profile and evacuation planning needs updated.');
      }
    } catch (e) {
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
          <User className="w-4 h-4 text-primary" />
          <span>Resident Registry</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Household Profile &amp; Evacuation Planning
        </h1>
      </div>

      {statusMsg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Contact & Phone Verification */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            Resident Contact &amp; Verification
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-mono text-text-muted">Full Legal Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono text-text-muted">Emergency Mobile Phone</label>
                {phoneVerified ? (
                  <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3 h-3" /> VERIFIED
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowOtpModal(true)}
                    className="text-[10px] font-mono text-amber-400 hover:underline font-bold"
                  >
                    VERIFY VIA OTP
                  </button>
                )}
              </div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary font-mono focus:border-primary"
              />
            </div>
          </div>
        </div>

        {/* Evacuation Support Flags */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            Special Evacuation Assistance Requirements
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-mono text-text-muted">Household Member Count</label>
              <input
                type="number"
                min={1}
                value={householdSize}
                onChange={(e) => setHouseholdSize(parseInt(e.target.value) || 1)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary"
              />
            </div>

            <div className="space-y-2 pt-2">
              <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasElderly}
                  onChange={(e) => setHasElderly(e.target.checked)}
                  className="rounded border-surface-3 text-primary"
                />
                <span>Elderly family members (Age 65+) in home</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasInfants}
                  onChange={(e) => setHasInfants(e.target.checked)}
                  className="rounded border-surface-3 text-primary"
                />
                <span>Infants or young children under 5 in home</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                <input
                  type="checkbox"
                  checked={requiresEvacuationAssist}
                  onChange={(e) => setRequiresEvacuationAssist(e.target.checked)}
                  className="rounded border-surface-3 text-primary"
                />
                <span className="text-amber-400 font-bold">
                  Flag for Priority Stretcher / 4x4 Evacuation Assistance
                </span>
              </label>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">
              Specialized Medical Needs or Equipment
            </label>
            <textarea
              rows={2}
              value={medicalNeedsSummary}
              onChange={(e) => setMedicalNeedsSummary(e.target.value)}
              placeholder="e.g. Grandfather bedridden, needs oxygen concentrator backup power, dialysis patient on Tuesdays/Thursdays."
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-3 text-xs text-text-primary focus:border-primary"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-2.5 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
        >
          {isSaving ? 'Updating Profile...' : 'Save Profile Changes'}
        </button>
      </form>

      {/* OTP Verification Modal */}
      {showOtpModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-surface-1 border border-surface-3 rounded-xl max-w-sm w-full p-6 space-y-4">
            <h4 className="text-sm font-bold text-text-primary">Verify Mobile Number</h4>
            <p className="text-xs text-text-secondary">
              For development demonstration, enter test OTP code: <strong className="text-primary font-mono">123456</strong>
            </p>

            {otpMsg && (
              <p className="text-xs text-red-400 bg-red-500/10 p-2 rounded">{otpMsg}</p>
            )}

            <input
              type="text"
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value)}
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-center font-mono text-lg text-primary tracking-widest"
            />

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleVerifyPhone}
                disabled={isVerifying}
                className="flex-1 py-2 rounded-lg bg-primary text-canvas font-bold text-xs uppercase"
              >
                {isVerifying ? 'Verifying...' : 'Verify OTP'}
              </button>
              <button
                type="button"
                onClick={() => setShowOtpModal(false)}
                className="px-4 py-2 rounded-lg bg-surface-2 text-text-secondary text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
