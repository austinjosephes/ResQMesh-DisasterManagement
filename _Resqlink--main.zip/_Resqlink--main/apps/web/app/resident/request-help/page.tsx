'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  LifeBuoy,
  ShieldAlert,
  MapPin,
  Users,
  Compass,
  AlertTriangle,
  CheckCircle2,
  Phone,
  WifiOff,
  ArrowRight,
  HeartPulse,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { useI18n } from '@/lib/i18n';
import { calculateRescuePriority } from '@/lib/priority-engine';
import { storeOfflineSOS } from '@/lib/offline-store';
import { KERALA_DISTRICTS } from '@/lib/geospatial';

export default function RequestHelpPage() {
  const router = useRouter();
  const { isEffectiveOffline } = useConnectivity();
  const { t } = useI18n();

  const [category, setCategory] = useState('LANDSLIDE');
  const [description, setDescription] = useState('');
  const [peopleCount, setPeopleCount] = useState(4);
  const [hasInjuries, setHasInjuries] = useState(true);
  const [immediateDanger, setImmediateDanger] = useState(true);
  const [district, setDistrict] = useState('Wayanad');
  const [latitude, setLatitude] = useState<number | null>(11.5545);
  const [longitude, setLongitude] = useState<number | null>(76.1285);
  const [address, setAddress] = useState('House 14/232, Near Chooralmala Bridge, Meppadi');
  const [accessibilityNeeds, setAccessibilityNeeds] = useState('Grandfather wheelchair dependent with portable oxygen concentrator');
  const [contactPreference, setContactPreference] = useState('SMS');

  const [isLocating, setIsLocating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedResult, setSubmittedResult] = useState<any | null>(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Live calculation of Rescue Priority
  const livePriority = calculateRescuePriority({
    category,
    peopleCount,
    hasInjuries,
    immediateDanger,
    locationConfidence: latitude ? 0.95 : 0.4,
    accessibilityNeeds,
    reportedAt: new Date(),
  });

  const handleAcquireLocation = () => {
    if (!navigator.geolocation) {
      setErrorMessage('Geolocation not supported by device.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(Number(pos.coords.latitude.toFixed(5)));
        setLongitude(Number(pos.coords.longitude.toFixed(5)));
        setIsLocating(false);
      },
      (err) => {
        setIsLocating(false);
        const dist = KERALA_DISTRICTS.find((d) => d.name === district);
        if (dist) {
          setLatitude(dist.center.lat);
          setLongitude(dist.center.lng);
        }
      },
      { timeout: 8000 }
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    const idempotencyKey = `sos_offline_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

    const payload = {
      category,
      description,
      peopleCount,
      hasInjuries,
      immediateDanger,
      latitude,
      longitude,
      address,
      district,
      accessibilityNeeds,
      contactPreference,
      locationSource: latitude ? 'DEVICE_GPS' : 'MANUAL_MAP',
      locationConfidence: latitude ? 0.95 : 0.5,
      idempotencyKey,
    };

    if (isEffectiveOffline) {
      // Store in local encrypted storage (Network-Loss Survival Mode)
      try {
        const tracking = `OFFLINE-KL-${Date.now().toString().slice(-6)}`;
        await storeOfflineSOS({
          trackingNumber: tracking,
          category,
          description,
          peopleCount,
          hasInjuries,
          immediateDanger,
          latitude: latitude || 11.5545,
          longitude: longitude || 76.1285,
          address,
          accessibilityNeeds,
          contactPreference,
          status: 'QUEUED_LOCAL',
          priority: livePriority.priorityCategory,
          createdAt: Date.now(),
          synced: false,
        });

        setSubmittedResult({
          offline: true,
          trackingNumber: tracking,
          priorityCategory: livePriority.priorityCategory,
          priorityScore: livePriority.totalScore,
        });
      } catch (err: any) {
        setErrorMessage('Failed to buffer offline SOS.');
      } finally {
        setIsSubmitting(false);
      }
      return;
    }

    try {
      const res = await fetch('/api/resident/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (res.ok) {
        setSubmittedResult(data);
      } else {
        setErrorMessage(data.error || 'Failed to submit SOS request.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Network error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submittedResult) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-6">
        <div
          className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
            submittedResult.offline
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
          }`}
        >
          {submittedResult.offline ? <WifiOff className="w-8 h-8" /> : <CheckCircle2 className="w-8 h-8" />}
        </div>

        <div className="space-y-2">
          <span className="text-xs font-mono uppercase px-2.5 py-0.5 rounded bg-surface-2 border border-surface-3 text-text-muted">
            {submittedResult.offline ? 'BUFFERED IN SURVIVAL MODE' : 'OFFICIALLY REGISTERED'}
          </span>
          <h2 className="text-2xl font-extrabold text-text-primary">
            {submittedResult.offline
              ? 'Distress SOS Queued Locally on Device'
              : 'Emergency SOS Broadcasted to State Control Room'}
          </h2>
          <p className="text-xs text-text-secondary max-w-md mx-auto leading-relaxed">
            {submittedResult.offline
              ? 'Your device is currently disconnected from backhaul. This request has been signed and buffered in local encrypted memory. It will automatically synchronize when cellular towers or peer relays are detected.'
              : 'Authorized district rescue coordinators and nearby field units have received your distress ticket.'}
          </p>
        </div>

        {/* Tracking Reference Badge */}
        <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 max-w-sm mx-auto space-y-2 text-xs font-mono">
          <div className="flex items-center justify-between">
            <span className="text-text-muted">Tracking Reference:</span>
            <span className="font-bold text-primary text-sm">
              {submittedResult.trackingNumber || submittedResult.sos?.trackingNumber}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-text-muted">Calculated Urgency:</span>
            <span className="font-bold text-red-400">
              {submittedResult.priorityCategory} (Score: {submittedResult.priorityScore}/100)
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Link
            href="/resident/requests"
            className="w-full sm:w-auto px-6 py-3 rounded-lg bg-primary text-canvas font-bold text-xs uppercase tracking-wider hover:bg-primary/90 transition shadow-glow-cyan"
          >
            Track SOS Status
          </Link>
          <Link
            href="/resident/dashboard"
            className="w-full sm:w-auto px-6 py-3 rounded-lg bg-surface-2 border border-surface-3 text-text-primary font-semibold text-xs hover:border-primary/50 transition"
          >
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-xs font-mono text-red-400">
          <LifeBuoy className="w-4 h-4 text-red-400" />
          <span>Priority Emergency Assistance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary">
          Broadcast Emergency SOS
        </h1>
        <p className="text-xs text-text-secondary max-w-lg mx-auto">
          Submit immediate distress coordinates. The Rescue Priority Engine scores reports
          deterministically based on danger, trapped victims, and special evacuation needs.
        </p>
      </div>

      {isEffectiveOffline && (
        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-3 text-xs text-amber-300">
          <WifiOff className="w-5 h-5 shrink-0" />
          <div>
            <p className="font-bold">Survival Mode Active (Offline)</p>
            <p className="text-[11px] text-amber-400/80">
              Your SOS will be safely buffered in local storage and submitted immediately upon gateway reconnect.
            </p>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-xs text-red-400">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Hazard Category */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            1. Emergency Category
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              { id: 'LANDSLIDE', label: 'Landslide / Debris' },
              { id: 'FLOOD', label: 'Rising Floodwaters' },
              { id: 'TRAPPED', label: 'Trapped in Attic/Roof' },
              { id: 'MEDICAL', label: 'Critical Medical' },
              { id: 'EVACUATION', label: 'Pre-emptive Evac' },
              { id: 'MISSING', label: 'Missing Person' },
              { id: 'OTHER', label: 'Other Hazard' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={`p-3 rounded-lg border text-left text-xs font-semibold transition ${
                  category === cat.id
                    ? 'bg-red-500/20 text-red-400 border-red-500/40 shadow-sm'
                    : 'bg-surface-2 border-surface-3 text-text-secondary hover:text-text-primary'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Danger & Trapped Counts */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            2. Life Threat &amp; Casualties
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-mono text-text-muted">People Trapped / Stranded</label>
              <input
                type="number"
                min={1}
                required
                value={peopleCount}
                onChange={(e) => setPeopleCount(parseInt(e.target.value) || 1)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-5">
              <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasInjuries}
                  onChange={(e) => setHasInjuries(e.target.checked)}
                  className="rounded border-surface-3 text-red-500 focus:ring-red-500"
                />
                <span className="font-semibold text-red-400">Trauma / Physical Injuries Present</span>
              </label>
            </div>

            <div className="flex items-center gap-2 pt-5">
              <label className="flex items-center gap-2 text-xs text-text-secondary cursor-pointer">
                <input
                  type="checkbox"
                  checked={immediateDanger}
                  onChange={(e) => setImmediateDanger(e.target.checked)}
                  className="rounded border-surface-3 text-red-500 focus:ring-red-500"
                />
                <span className="font-semibold text-red-400">Immediate Life-Threatening Danger</span>
              </label>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">
              Situation Description &amp; Immediate Obstacles *
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Silt and water pouring into ground floor. We are four adults and grandfather trapped on first floor balcony. Power out."
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-3 text-xs text-text-primary focus:border-primary focus:outline-none"
            />
          </div>
        </div>

        {/* Step 3: Location Coordinates */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
              3. Rescue Location Coordinates
            </h3>
            <button
              type="button"
              onClick={handleAcquireLocation}
              disabled={isLocating}
              className="text-xs font-mono text-primary hover:underline flex items-center gap-1 font-semibold"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>{isLocating ? 'Acquiring GPS...' : 'Acquire Device GPS Position'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div className="space-y-1">
              <label className="text-text-muted">District:</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2 text-xs text-text-primary focus:border-primary font-sans"
              >
                {KERALA_DISTRICTS.map((d) => (
                  <option key={d.id} value={d.name}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-text-muted">Latitude:</label>
              <input
                type="number"
                step="any"
                value={latitude || ''}
                onChange={(e) => setLatitude(parseFloat(e.target.value) || null)}
                placeholder="11.5545"
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2 text-xs text-text-primary"
              />
            </div>

            <div className="space-y-1">
              <label className="text-text-muted">Longitude:</label>
              <input
                type="number"
                step="any"
                value={longitude || ''}
                onChange={(e) => setLongitude(parseFloat(e.target.value) || null)}
                placeholder="76.1285"
                className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2 text-xs text-text-primary"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-mono text-text-muted">Physical Landmark / Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Near Chooralmala Primary School bridge, 2nd house with blue tin roof"
              className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary focus:outline-none"
            />
          </div>
        </div>

        {/* Step 4: Special Evacuation Needs */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider">
            4. Special Assistance / Medical Constraints
          </h3>
          <input
            type="text"
            value={accessibilityNeeds}
            onChange={(e) => setAccessibilityNeeds(e.target.value)}
            placeholder="e.g. Wheelchair user, oxygen cylinder, 6-month-old infant, dialysis patient..."
            className="w-full bg-surface-2 border border-surface-3 rounded-lg p-2.5 text-xs text-text-primary focus:border-primary focus:outline-none"
          />
        </div>

        {/* Transparent Priority Engine Live Preview */}
        <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-text-muted">TRANSPARENT RESCUE ENGINE PREVIEW:</span>
            <span className="font-bold text-red-400">
              {livePriority.priorityCategory} (Score: {livePriority.totalScore}/100)
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
            {livePriority.breakdown.reasons.map((r, i) => (
              <span key={i} className="px-2 py-0.5 rounded bg-surface-1 border border-surface-3 text-text-secondary">
                {r}
              </span>
            ))}
          </div>
        </div>

        {/* Broadcast Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-sm uppercase tracking-wider shadow-glow-ruby transition flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isSubmitting ? (
            <span>Broadcasting Distress Beacon...</span>
          ) : (
            <>
              <LifeBuoy className="w-5 h-5" />
              <span>Broadcast Emergency SOS Immediately</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
