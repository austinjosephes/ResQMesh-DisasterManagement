'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  LifeBuoy,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Phone,
  ShieldAlert,
  ArrowRight,
  Radio,
  ArrowLeft,
  CheckCheck,
} from 'lucide-react';

export default function ResidentRequestsPage() {
  const [requests, setRequests] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/resident/requests')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.requests) setRequests(data.requests);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const statusSteps = [
    'SUBMITTED',
    'AWAITING_VERIFICATION',
    'VERIFIED',
    'PRIORITIZED',
    'ASSIGNED',
    'EN_ROUTE',
    'ON_SCENE',
    'IN_PROGRESS',
    'RESOLVED',
  ];

  return (
    <div className="min-h-screen bg-[#07090D] text-[#F5F7FA] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Link
                href="/resident/dashboard"
                className="p-1.5 rounded-lg bg-[#101720] border border-[rgba(255,255,255,0.08)] text-[#929CAB] hover:text-[#F5F7FA] transition"
                title="Return to Dashboard"
              >
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-[#FF6B35] uppercase tracking-widest">
                <LifeBuoy className="w-3.5 h-3.5 text-[#FF6B35]" />
                <span>INCIDENT LIFECYCLE TRACKER</span>
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F7FA]">
              My SOS Requests &amp; Rescue Status
            </h1>
            <p className="text-xs text-[#929CAB] font-mono">
              Live status tracking of submitted emergency beacons, assigned NDRF units, and relief camp allocations.
            </p>
          </div>

          <Link
            href="/resident/dashboard"
            className="px-4 py-2 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-mono font-bold text-xs uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-[#EF4444]/20 self-start sm:self-center"
          >
            <LifeBuoy className="w-4 h-4" />
            <span>Broadcast SOS</span>
          </Link>
        </div>

        {requests.length === 0 ? (
          <div className="p-12 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] text-center space-y-3">
            <CheckCircle2 className="w-8 h-8 text-[#22C55E] mx-auto" />
            <h3 className="text-sm font-bold text-[#F5F7FA]">No Active Rescue Requests</h3>
            <p className="text-xs text-[#929CAB] max-w-sm mx-auto font-mono">
              You do not currently have any open emergency requests in the state dispatch registry.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {requests.map((req) => {
              const currentStepIdx = statusSteps.indexOf(req.status);
              const isCritical = req.priorityCategory === 'CRITICAL' || req.immediateDanger;

              return (
                <div
                  key={req.id}
                  className="p-6 rounded-2xl bg-[#101720] border border-[rgba(255,255,255,0.08)] space-y-5 shadow-xl relative overflow-hidden"
                >
                  {/* Header Strip */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[rgba(255,255,255,0.06)] pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono font-bold text-sm text-[#F5F7FA]">
                        #{req.trackingNumber || req.id.slice(-6)}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold ${
                          isCritical
                            ? 'bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444]'
                            : 'bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623]'
                        }`}
                      >
                        {req.priorityCategory || 'P1'} (Score: {req.priorityScore || 90}/100)
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs font-mono text-[#6F7C93]">
                      <Clock className="w-3.5 h-3.5" />
                      <span>
                        Reported: {new Date(req.createdAt).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })}
                      </span>
                    </div>
                  </div>

                  {/* Description & Telemetry */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                    <div className="md:col-span-2 space-y-2">
                      <p className="text-[#F5F7FA] leading-relaxed bg-[#0B1017] p-4 rounded-xl border border-[rgba(255,255,255,0.06)]">
                        {req.description}
                      </p>
                      {req.accessibilityNeeds && (
                        <p className="text-[#F5A623] text-[11px]">
                          ⚠️ Special Evacuation Needs: {req.accessibilityNeeds}
                        </p>
                      )}
                    </div>

                    <div className="p-4 rounded-xl bg-[#0B1017] border border-[rgba(255,255,255,0.06)] space-y-2 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-[#6F7C93]">People Stranded:</span>
                        <span className="font-bold text-[#F5F7FA]">{req.peopleCount} Persons</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#6F7C93]">Trauma / Injuries:</span>
                        <span className={req.hasInjuries ? 'text-[#EF4444] font-bold' : 'text-[#22C55E]'}>
                          {req.hasInjuries ? 'YES' : 'NONE'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#6F7C93]">Location Source:</span>
                        <span className="text-[#38BDF8]">{req.locationSource || 'GPS FIX'}</span>
                      </div>
                      {req.address && (
                        <div className="pt-1 text-[#929CAB] truncate border-t border-[rgba(255,255,255,0.06)]">
                          Loc: {req.address}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Assigned Team Banner */}
                  {req.assignedTeamName && (
                    <div className="p-3.5 rounded-xl bg-[#22C55E]/10 border border-[#22C55E]/30 flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2 text-[#22C55E] font-bold">
                        <Radio className="w-4 h-4 animate-pulse" />
                        <span>DISPATCHED UNIT: {req.assignedTeamName}</span>
                      </div>
                      <span className="text-[#6F7C93]">Live Radio Channel Active</span>
                    </div>
                  )}

                  {/* Progress Status Bar */}
                  <div className="space-y-2 pt-2 border-t border-[rgba(255,255,255,0.06)]">
                    <div className="flex justify-between text-[11px] font-mono text-[#6F7C93]">
                      <span>DISPATCH LIFECYCLE</span>
                      <span className="text-[#FF6B35] font-bold">{req.status}</span>
                    </div>
                    <div className="grid grid-cols-3 sm:grid-cols-9 gap-1.5 text-[9px] font-mono text-center">
                      {statusSteps.map((step, idx) => {
                        const isPast = currentStepIdx > idx;
                        const isCurrent = currentStepIdx === idx;

                        return (
                          <div
                            key={step}
                            className={`p-1.5 rounded-lg transition ${
                              isCurrent
                                ? 'bg-[#FF6B35] text-[#07090D] font-bold shadow-md shadow-[#FF6B35]/20'
                                : isPast
                                ? 'bg-[#22C55E]/20 text-[#22C55E] font-bold'
                                : 'bg-[#0B1017] text-[#6F7C93] opacity-40'
                            }`}
                          >
                            {step.replace('_', ' ').slice(0, 8)}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
