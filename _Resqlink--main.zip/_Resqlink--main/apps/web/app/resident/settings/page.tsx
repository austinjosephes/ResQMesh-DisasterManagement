'use client';

import React, { useState } from 'react';
import { Sliders, Globe, Bell, WifiOff, Trash2, CheckCircle2 } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useConnectivity } from '@/components/shell/ConnectivityContext';

export default function ResidentSettingsPage() {
  const { language, setLanguage, t } = useI18n();
  const { isEffectiveOffline, setSimulatedOffline } = useConnectivity();
  const [smsEnabled, setSmsEnabled] = useState(true);
  const [pushEnabled, setPushEnabled] = useState(true);
  const [msg, setMsg] = useState('');

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div className="border-b border-surface-3 pb-4">
        <span className="text-xs font-mono uppercase text-primary font-semibold flex items-center gap-1.5">
          <Sliders className="w-4 h-4 text-primary" />
          <span>System Preferences</span>
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary mt-1">
          Resident Portal Settings
        </h1>
      </div>

      {msg && (
        <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{msg}</span>
        </div>
      )}

      <div className="space-y-6">
        {/* Language Selection */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
            <Globe className="w-4 h-4 text-primary" />
            <span>Interface Language</span>
          </h3>
          <div className="flex items-center gap-3">
            <div className="px-4 py-2.5 rounded-lg border text-xs font-bold bg-primary text-canvas border-primary shadow-glow-cyan flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>English (Standard Operations)</span>
            </div>
          </div>
        </div>

        {/* Notification Delivery Channels */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-400" />
            <span>Notification Delivery Channels</span>
          </h3>
          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 rounded-lg bg-surface-2 cursor-pointer">
              <div>
                <p className="font-bold text-text-primary">TRAI High-Priority Emergency SMS</p>
                <p className="text-[11px] text-text-muted">
                  Receive SMS broadcasts formatted with verified DLT disaster templates.
                </p>
              </div>
              <input
                type="checkbox"
                checked={smsEnabled}
                onChange={(e) => setSmsEnabled(e.target.checked)}
                className="rounded border-surface-3 text-primary"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-lg bg-surface-2 cursor-pointer">
              <div>
                <p className="font-bold text-text-primary">In-App Web Push Notification</p>
                <p className="text-[11px] text-text-muted">
                  Instant push banner when hazard polygons intersect registered home coordinates.
                </p>
              </div>
              <input
                type="checkbox"
                checked={pushEnabled}
                onChange={(e) => setPushEnabled(e.target.checked)}
                className="rounded border-surface-3 text-primary"
              />
            </label>
          </div>
        </div>

        {/* Network-Loss Survival Mode Controls */}
        <div className="p-6 rounded-xl bg-surface-1 border border-surface-3 space-y-4">
          <h3 className="text-xs font-mono font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-emerald-400" />
            <span>Network-Loss Survival Simulation</span>
          </h3>
          <div className="flex items-center justify-between p-3 rounded-lg bg-surface-2 text-xs">
            <div>
              <p className="font-bold text-text-primary">Simulate Disconnected Network (Cell Blackout)</p>
              <p className="text-[11px] text-text-muted">
                Tests local encrypted IndexedDB buffering and offline guidance availability.
              </p>
            </div>
            <button
              onClick={() => setSimulatedOffline(!isEffectiveOffline)}
              className={`px-3 py-1.5 rounded text-xs font-mono font-bold ${
                isEffectiveOffline
                  ? 'bg-amber-500 text-canvas'
                  : 'bg-surface-3 text-text-secondary hover:text-text-primary'
              }`}
            >
              {isEffectiveOffline ? 'SURVIVAL ACTIVE' : 'LIVE GRID'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
