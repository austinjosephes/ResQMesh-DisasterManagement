'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  Key,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  FileCheck2,
  Lock,
  Layers,
  Fingerprint,
  Info,
} from 'lucide-react';
import { verifyCredentialOffline } from '@resqmesh/verifier';
import {
  getActiveDeviceKeyInfo,
  getCachedTrustBundle,
  getCachedStatusSnapshot,
} from '@/lib/offline-store';

export default function ResponderCredentialPage() {
  const [credential, setCredential] = useState<any>(null);
  const [deviceKey, setDeviceKey] = useState<any>(null);
  const [trustBundle, setTrustBundle] = useState<any>(null);
  const [statusSnapshot, setStatusSnapshot] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Verification state
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verifyResult, setVerifyResult] = useState<any>(null);

  useEffect(() => {
    loadCredentialData();
  }, []);

  const loadCredentialData = async () => {
    setLoading(true);
    try {
      const keyInfo = await getActiveDeviceKeyInfo();
      setDeviceKey(keyInfo);

      const bundle = await getCachedTrustBundle();
      setTrustBundle(bundle);

      const snapshot = await getCachedStatusSnapshot();
      setStatusSnapshot(snapshot);

      // Load active credential
      const res = await fetch('/api/credentials/7c9e6679-7425-40de-944b-e07fc1f90ae7');
      if (res.ok) {
        const data = await res.json();
        setCredential(data.credential);
      }
    } catch (e) {
      console.warn('Error loading credential:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyLocally = async () => {
    if (!credential || !credential.tokenJws) return;
    setIsVerifying(true);
    setVerifyResult(null);

    try {
      const result = await verifyCredentialOffline({
        tokenJws: credential.tokenJws,
        trustBundle: trustBundle || undefined,
        statusSnapshot: statusSnapshot || undefined,
        requestedAction: 'triage.record',
        deviceThumbprint: deviceKey?.thumbprint,
        currentTime: Math.floor(Date.now() / 1000),
      });

      setVerifyResult(result);
    } catch (err: any) {
      setVerifyResult({
        decision: 'REJECT',
        resultCode: 'VERIFICATION_EXCEPTION',
        diagnostics: [err.message],
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleLoadDemoCredential = async () => {
    try {
      const res = await fetch('/api/credentials/7c9e6679-7425-40de-944b-e07fc1f90ae7');
      if (res.ok) {
        const data = await res.json();
        setCredential(data.credential);
        setVerifyResult(null);
      }
    } catch (e) {
      alert('Unable to reload demo credential');
    }
  };

  const permissionsList = credential?.permissionsJson
    ? JSON.parse(credential.permissionsJson)
    : [
        'incident.view',
        'triage.read',
        'triage.record',
        'report.submit',
        'medication.administer.basic',
        'perimeter.cross.restricted',
      ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-3 pb-3 text-xs font-mono">
        <Link href="/responder" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Overview &amp; Triage
        </Link>
        <Link href="/responder/incidents" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Incident Registry
        </Link>
        <Link href="/responder/credential" className="px-3 py-1.5 rounded-lg bg-primary text-canvas font-bold shadow-glow-cyan">
          Credential &amp; Keys
        </Link>
        <Link href="/responder/offline-queue" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Offline Sync Queue
        </Link>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>OFFLINE-VERIFIABLE RESPONDER CREDENTIAL &bull; RFC 7515 JWS</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            Responder Identity &amp; Authorization Enclave
          </h1>
          <p className="text-xs text-text-muted">
            Inspect issued credential tokens, device cryptographic binding, and run local offline verification.
          </p>
        </div>

        <button
          onClick={handleLoadDemoCredential}
          className="px-4 py-2 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-primary text-xs font-mono transition shrink-0"
        >
          Load Demo Credential
        </button>
      </div>

      {/* Demo Warning Banner (Section 8.6 requirement) */}
      <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 flex items-start gap-3 text-xs">
        <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-text-primary">Demonstration Credential Notice</p>
          <p className="text-text-muted text-[11px]">
            This credential is for emergency coordination demonstration and testing purposes. Demo credentials must never be presented as real government-issued or officially approved credentials.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Credential Card Overview */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 md:p-8 rounded-2xl bg-surface-1 border border-surface-3 space-y-6 shadow-2xl">
            {/* Badge Top */}
            <div className="flex items-center justify-between border-b border-surface-3 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-text-muted block">
                    Certified Disaster Responder
                  </span>
                  <h2 className="text-lg font-bold text-text-primary">
                    {credential?.role || 'PARAMEDIC_TIER_2'}
                  </h2>
                </div>
              </div>

              <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                STATUS: {credential?.status || 'ACTIVE'}
              </span>
            </div>

            {/* Credential Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Unique Credential JTI</span>
                <span className="text-primary font-bold text-[11px] break-all">
                  {credential?.jti || '7c9e6679-7425-40de-944b-e07fc1f90ae7'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Subject (Responder Sub)</span>
                <span className="text-text-primary font-bold text-[11px] break-all">
                  {credential?.sub || 'resq-resp-8842-bravo'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Issuing Authority</span>
                <span className="text-text-primary text-[11px] break-all">
                  {credential?.iss || 'did:resqmesh:issuer:federal-fema-ca'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Incident Scope</span>
                <span className="text-text-primary text-[11px]">
                  {credential?.incidentScope || 'INCIDENT-CASCADE-QUAKE-2026'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Issued At</span>
                <span className="text-text-secondary text-[11px]">
                  {credential?.iat ? new Date(credential.iat * 1000).toLocaleDateString() : 'Active'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 space-y-1">
                <span className="text-[10px] text-text-muted uppercase block">Expires At</span>
                <span className="text-amber-400 font-bold text-[11px]">
                  {credential?.exp ? new Date(credential.exp * 1000).toLocaleDateString() : '3 Days Remaining'}
                </span>
              </div>
            </div>

            {/* Permitted Actions */}
            <div className="space-y-2">
              <span className="text-[11px] font-mono uppercase text-text-muted tracking-wider block font-bold">
                Permitted Role Capabilities ({permissionsList.length})
              </span>
              <div className="flex flex-wrap gap-1.5">
                {permissionsList.map((perm: string) => (
                  <span
                    key={perm}
                    className="px-2.5 py-1 rounded-lg bg-surface-2 border border-surface-3 font-mono text-[11px] text-primary"
                  >
                    ✓ {perm}
                  </span>
                ))}
              </div>
            </div>

            {/* Verify Locally Action */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleVerifyLocally}
                disabled={isVerifying}
                className="w-full py-3.5 rounded-xl bg-primary text-canvas font-bold text-xs flex items-center justify-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
              >
                <FileCheck2 className={`w-4 h-4 ${isVerifying ? 'animate-spin' : ''}`} />
                <span>{isVerifying ? 'Running Cryptographic Verification...' : 'Verify Locally (Run Web Crypto Engine)'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Verification Verdict & Proof Diagnostics */}
        <div className="lg:col-span-5 space-y-5">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <h3 className="text-xs font-bold text-text-primary flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <span>Local Verification Verdict</span>
            </h3>

            {!verifyResult ? (
              <div className="p-8 text-center rounded-xl bg-surface-2 border border-surface-3 text-text-muted text-xs space-y-2">
                <ShieldCheck className="w-8 h-8 mx-auto text-surface-3" />
                <p>Click &apos;Verify Locally&apos; to execute the genuine offline verifier against this credential.</p>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div
                  className={`p-4 rounded-xl border flex items-center gap-3 ${
                    verifyResult.decision === 'PERMIT'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-red-950/40 border-red-500/40 text-red-300'
                  }`}
                >
                  {verifyResult.decision === 'PERMIT' ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-red-400 shrink-0" />
                  )}
                  <div>
                    <span className="font-mono font-bold text-sm block">
                      {verifyResult.resultCode}
                    </span>
                    <span className="text-[11px] opacity-90">
                      Authorization: {verifyResult.decision}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 font-mono text-[11px]">
                  <span className="text-text-muted uppercase text-[10px] block">Cryptographic Diagnostics</span>
                  <div className="p-3 rounded-xl bg-canvas border border-surface-3 space-y-1 max-h-48 overflow-y-auto">
                    {verifyResult.diagnostics?.map((diag: string, i: number) => (
                      <div key={i} className="text-text-secondary flex items-start gap-1.5">
                        <span className="text-primary shrink-0">&gt;</span>
                        <span>{diag}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Device Key Binding Check */}
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-3 text-xs">
            <h3 className="font-bold text-text-primary flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-primary" />
              <span>Device-Key Binding (Proof of Possession)</span>
            </h3>
            <p className="text-text-secondary text-[11px] leading-relaxed">
              Bound Thumbprint: <span className="font-mono text-primary text-[10px] block break-all mt-1">{deviceKey?.thumbprint || 'Loading device thumbprint...'}</span>
            </p>
            <div className="pt-1 flex items-center gap-2 text-emerald-400 font-mono text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Confirmed non-extractable CryptoKey</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
