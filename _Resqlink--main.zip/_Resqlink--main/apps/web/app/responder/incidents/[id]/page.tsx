'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  Radio,
  AlertTriangle,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Activity,
  PlusCircle,
  FileCheck,
  User,
  RefreshCw,
  Send,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import {
  signChallengeWithDeviceKey,
  storeOfflineEvent,
  getActiveDeviceKeyInfo,
} from '@/lib/offline-store';
import { OfflineEventRecord } from '@resqmesh/shared';

export default function IncidentDetailPage() {
  const params = useParams();
  const id = params?.id as string;
  const { isEffectiveOffline } = useConnectivity();

  const [incident, setIncident] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [deviceKey, setDeviceKey] = useState<any>(null);

  // Triage Form State
  const [patientId, setPatientId] = useState('PT-8891');
  const [triageCategory, setTriageCategory] = useState('RED_IMMEDIATE');
  const [clinicalNotes, setClinicalNotes] = useState('Extricated from debris. Hypovolemic shock, bilateral chest auscultation clear.');
  const [submitting, setSubmitting] = useState(false);
  const [triageLogs, setTriageLogs] = useState<any[]>([]);
  const [statusMessage, setStatusMessage] = useState('');

  useEffect(() => {
    loadIncidentAndKey();
  }, [id]);

  const loadIncidentAndKey = async () => {
    setLoading(true);
    try {
      const keyInfo = await getActiveDeviceKeyInfo();
      setDeviceKey(keyInfo);

      const res = await fetch(`/api/incidents/${id}`);
      if (res.ok) {
        const data = await res.json();
        setIncident(data.incident);
      } else {
        // Fallback demo incident
        setIncident({
          id,
          incidentCode: 'INC-2026-CASCADE',
          title: 'Sector 4 Structural Collapse & Gas Leak',
          category: 'EARTHQUAKE',
          severity: 'CATASTROPHIC',
          status: 'ACTIVE',
          sector: 'Sector 4 Collapse Zone',
          latitude: 37.7749,
          longitude: -122.4194,
          radiusMeters: 750,
          description:
            'Multiple commercial structure collapses following seismic event. Severed utility mains. Paramedic units dispatched to secondary search sectors.',
          reportedBy: 'Regional Dispatch Unit 01',
          verifiedBy: 'Commander Sarah Vance',
        });
      }

      // Initial demo triage log
      setTriageLogs([
        {
          id: 'tri-01',
          patientId: 'PT-9942',
          category: 'RED_IMMEDIATE',
          notes: 'Compound femur fracture, tourniquet secured 14:15. Blood pressure 90/60.',
          timestamp: Date.now() - 1800 * 1000,
          responder: 'EMT Jordan Rivera',
        },
      ]);
    } catch (e) {
      console.warn('Error loading incident:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleRecordTriage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setStatusMessage('');

    try {
      const eventId = `event-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const payload = {
        incidentId: incident?.id || id,
        patientId,
        triageCategory,
        clinicalNotes,
        timestamp: Date.now(),
      };

      const payloadJson = JSON.stringify(payload);
      const encoder = new TextEncoder();
      const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(payloadJson));
      const payloadHash = Array.from(new Uint8Array(hashBuffer))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');

      let deviceSignature = 'SIMULATED_SIGNATURE';
      if (deviceKey && deviceKey.hasPrivateKey) {
        deviceSignature = await signChallengeWithDeviceKey(payloadHash);
      }

      const eventRecord: OfflineEventRecord = {
        event_id: eventId,
        device_id: deviceKey?.thumbprint || 'device-local-unknown',
        credential_jti: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
        sequence_number: triageLogs.length + 2,
        previous_event_hash: '0000000000000000000000000000000000000000000000000000000000000000',
        event_type: 'triage.recorded',
        payload_json: payloadJson,
        payload_hash: payloadHash,
        created_at: Math.floor(Date.now() / 1000),
        device_signature: deviceSignature,
      };

      // Store in offline IndexedDB
      await storeOfflineEvent(eventRecord);

      // Add to local state
      setTriageLogs((prev) => [
        {
          id: eventId,
          patientId,
          category: triageCategory,
          notes: clinicalNotes,
          timestamp: Date.now(),
          responder: 'EMT Jordan Rivera (Enrolled Device)',
        },
        ...prev,
      ]);

      setStatusMessage('✓ Triage event signed with device key and queued locally.');
      setPatientId(`PT-${Math.floor(1000 + Math.random() * 9000)}`);
      setClinicalNotes('');
    } catch (err: any) {
      setStatusMessage(`Error: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="max-w-5xl mx-auto px-4 py-16 text-center text-xs text-text-muted">Loading incident details...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-3 pb-3 text-xs font-mono">
        <Link href="/responder" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Overview &amp; Triage
        </Link>
        <Link href="/responder/incidents" className="px-3 py-1.5 rounded-lg bg-primary text-canvas font-bold shadow-glow-cyan">
          Incident Registry
        </Link>
        <Link href="/responder/credential" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Credential &amp; Keys
        </Link>
        <Link href="/responder/offline-queue" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Offline Sync Queue
        </Link>
      </div>

      {/* Incident Header */}
      <div className="p-6 md:p-8 rounded-2xl bg-surface-1 border border-surface-3 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="font-mono text-base font-bold text-primary">
              {incident?.incidentCode}
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded bg-surface-2 border border-surface-3 text-text-primary uppercase font-semibold">
              {incident?.category}
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-800/40 font-mono font-bold uppercase">
              {incident?.severity}
            </span>
          </div>

          <span className="text-xs font-mono text-emerald-400 bg-surface-2 px-3 py-1 rounded-full border border-surface-3">
            STATUS: {incident?.status}
          </span>
        </div>

        <div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            {incident?.title}
          </h1>
          <p className="text-xs md:text-sm text-text-secondary leading-relaxed mt-1">
            {incident?.description}
          </p>
        </div>

        <div className="pt-3 border-t border-surface-3 flex flex-wrap items-center gap-6 text-xs font-mono text-text-muted">
          <span className="flex items-center gap-1.5 text-text-secondary">
            <MapPin className="w-3.5 h-3.5 text-primary" />
            {incident?.sector} ({incident?.radiusMeters}m perimeter)
          </span>
          <span>Verified By: {incident?.verifiedBy}</span>
          <span>Reported By: {incident?.reportedBy}</span>
        </div>
      </div>

      {/* Rapid Field Triage Submission & Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Rapid Triage Form */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-5">
            <div className="flex items-center justify-between border-b border-surface-3 pb-3">
              <h2 className="text-sm font-bold text-text-primary flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-primary" />
                <span>Record Signed Triage Tag</span>
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 bg-surface-2 px-2 py-0.5 rounded">
                WebCrypto P-256
              </span>
            </div>

            <form onSubmit={handleRecordTriage} className="space-y-4 text-xs">
              {statusMessage && (
                <div className="p-3 rounded-lg bg-surface-2 border border-surface-3 text-[11px] font-mono text-emerald-400">
                  {statusMessage}
                </div>
              )}

              <div>
                <label className="block text-text-secondary mb-1 font-medium">Patient / Victim ID</label>
                <input
                  type="text"
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary font-mono focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-text-secondary mb-1 font-medium">Triage Priority Category</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'RED_IMMEDIATE', label: 'RED (Immediate)', color: 'border-red-500 text-red-400' },
                    { id: 'YELLOW_DELAYED', label: 'YELLOW (Delayed)', color: 'border-amber-500 text-amber-400' },
                    { id: 'GREEN_MINOR', label: 'GREEN (Walking)', color: 'border-emerald-500 text-emerald-400' },
                    { id: 'BLACK_EXPECTANT', label: 'BLACK (Deceased)', color: 'border-slate-500 text-slate-400' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setTriageCategory(cat.id)}
                      className={`p-2.5 rounded-xl border text-xs font-mono font-bold transition text-left ${
                        triageCategory === cat.id
                          ? `bg-surface-2 ${cat.color} shadow-sm`
                          : 'bg-surface-2 border-surface-3 text-text-muted hover:text-text-primary'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-text-secondary mb-1 font-medium">Field Clinical Notes</label>
                <textarea
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  rows={3}
                  required
                  placeholder="Vital signs, tourniquets, fractures, airway status..."
                  className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary text-xs focus:outline-none focus:border-primary"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-xl bg-primary text-canvas font-bold text-xs flex items-center justify-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{submitting ? 'Signing Event...' : 'Sign & Record Triage Event'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* Triage Log Feed */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <div className="flex items-center justify-between border-b border-surface-3 pb-3">
              <h3 className="text-sm font-bold text-text-primary flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                <span>Active Triage Logs for Incident</span>
              </h3>
              <span className="text-xs font-mono text-text-muted">{triageLogs.length} records</span>
            </div>

            <div className="space-y-3">
              {triageLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 font-mono">
                      <span className="font-bold text-primary">{log.patientId}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                          log.category.includes('RED')
                            ? 'bg-red-950/60 text-red-300 border border-red-800/40'
                            : 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                        }`}
                      >
                        {log.category}
                      </span>
                    </div>

                    <span className="text-[10px] font-mono text-text-muted">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  <p className="text-text-primary text-[11px] leading-relaxed">
                    {log.notes}
                  </p>

                  <div className="pt-2 border-t border-surface-3/50 flex items-center justify-between text-[10px] font-mono text-text-muted">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Signer: {log.responder}
                    </span>
                    <span className="text-emerald-400">Offline-Verifiable</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
