'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Radio,
  AlertTriangle,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Filter,
  Search,
  Users,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import { getCachedIncidents, cacheIncidents } from '@/lib/offline-store';

export default function ResponderIncidentsPage() {
  const { isEffectiveOffline } = useConnectivity();
  const [incidents, setIncidents] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    loadIncidents();
  }, [isEffectiveOffline]);

  const loadIncidents = async () => {
    setLoading(true);
    try {
      if (!isEffectiveOffline) {
        const res = await fetch('/api/incidents');
        if (res.ok) {
          const data = await res.json();
          setIncidents(data.incidents || []);
          await cacheIncidents(data.incidents || []);
        }
      } else {
        const cached = await getCachedIncidents();
        setIncidents(cached);
      }
    } catch (e) {
      console.warn('Error loading incidents:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredIncidents = incidents.filter((inc) => {
    const matchesSeverity = filterSeverity === 'ALL' || inc.severity === filterSeverity;
    const matchesSearch =
      searchQuery === '' ||
      inc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.sector.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.incidentCode.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSeverity && matchesSearch;
  });

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'CATASTROPHIC':
        return (
          <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-red-950/60 text-red-300 border border-red-800/40 font-bold uppercase">
            CATASTROPHIC
          </span>
        );
      case 'SEVERE':
        return (
          <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-amber-950/60 text-amber-300 border border-amber-800/40 font-bold uppercase">
            SEVERE
          </span>
        );
      case 'MODERATE':
        return (
          <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-blue-950/60 text-blue-300 border border-blue-800/40 font-bold uppercase">
            MODERATE
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-surface-3 text-text-muted uppercase">
            {sev}
          </span>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-3 pb-3 text-xs font-mono">
        <Link
          href="/responder"
          className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition"
        >
          Overview &amp; Triage
        </Link>
        <Link
          href="/responder/incidents"
          className="px-3 py-1.5 rounded-lg bg-primary text-canvas font-bold shadow-glow-cyan"
        >
          Incident Registry
        </Link>
        <Link
          href="/responder/credential"
          className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition"
        >
          Credential &amp; Keys
        </Link>
        <Link
          href="/responder/offline-queue"
          className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition"
        >
          Offline Sync Queue
        </Link>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono mb-2">
            <Radio className="w-4 h-4" />
            <span>INCIDENT COMMAND OPERATIONAL REGISTRY</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            Permitted Disaster Incidents
          </h1>
          <p className="text-xs text-text-muted">
            Incident reports and hot zone boundaries authorized under your credential scope.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-text-muted absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search incident title, sector, code..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-surface-1 border border-surface-3 text-text-primary text-xs focus:outline-none focus:border-primary transition"
          />
        </div>

        <div className="flex items-center gap-2">
          {['ALL', 'CATASTROPHIC', 'SEVERE', 'MODERATE'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-3 py-2 rounded-xl text-xs font-mono transition ${
                filterSeverity === sev
                  ? 'bg-primary text-canvas font-bold'
                  : 'bg-surface-1 hover:bg-surface-2 border border-surface-3 text-text-secondary'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* Incident Cards */}
      <div className="space-y-4">
        {loading ? (
          <div className="py-12 text-center text-xs text-text-muted">Loading authorized incidents...</div>
        ) : filteredIncidents.length === 0 ? (
          <div className="py-16 text-center rounded-2xl bg-surface-1 border border-surface-3 text-text-muted text-xs space-y-2">
            <AlertTriangle className="w-8 h-8 mx-auto text-surface-3" />
            <p>No disaster incidents match your filter.</p>
          </div>
        ) : (
          filteredIncidents.map((inc) => (
            <Link
              key={inc.id}
              href={`/responder/incidents/${inc.id}`}
              className="p-6 rounded-2xl bg-surface-1 hover:bg-surface-2 border border-surface-3 block transition group space-y-3 shadow-xl"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-bold text-primary">
                    {inc.incidentCode}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded bg-surface-2 border border-surface-3 font-semibold text-text-primary uppercase">
                    {inc.category}
                  </span>
                  {getSeverityBadge(inc.severity)}
                </div>

                <span className="text-xs font-mono px-2.5 py-0.5 rounded bg-surface-2 text-emerald-400 border border-emerald-500/20">
                  STATUS: {inc.status}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-text-primary group-hover:text-primary transition">
                  {inc.title}
                </h3>
                <p className="text-xs text-text-secondary leading-relaxed mt-1">
                  {inc.description}
                </p>
              </div>

              <div className="pt-3 border-t border-surface-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono text-text-muted">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5 text-text-secondary">
                    <MapPin className="w-3.5 h-3.5 text-primary" />
                    {inc.sector} ({inc.radiusMeters}m radius)
                  </span>
                  <span>Verified by: {inc.verifiedBy || 'Dispatch'}</span>
                </div>

                <span className="text-primary group-hover:translate-x-0.5 transition flex items-center gap-1 font-semibold">
                  Open Operational Details &amp; Triage <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
