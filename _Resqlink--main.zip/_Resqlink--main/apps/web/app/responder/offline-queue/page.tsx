'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Radio,
  RefreshCw,
  Send,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  ArrowRight,
  ShieldCheck,
  Hash,
  Activity,
  Trash2,
} from 'lucide-react';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import {
  getPendingOfflineEvents,
  clearSyncedEvents,
} from '@/lib/offline-store';
import { OfflineEventRecord } from '@resqmesh/shared';

export default function ResponderOfflineQueuePage() {
  const { isEffectiveOffline, setLastSyncTime } = useConnectivity();

  const [events, setEvents] = useState<OfflineEventRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [syncResults, setSyncResults] = useState<any[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<OfflineEventRecord | null>(null);

  useEffect(() => {
    loadQueue();
  }, [isEffectiveOffline]);

  const loadQueue = async () => {
    setLoading(true);
    try {
      const pending = await getPendingOfflineEvents();
      setEvents(pending);
    } catch (e) {
      console.warn('Error loading offline queue:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncQueue = async () => {
    if (isEffectiveOffline) {
      alert('Offline mode active. Turn offline mode off to synchronize with base server.');
      return;
    }

    if (events.length === 0) {
      alert('No pending offline events to synchronize.');
      return;
    }

    setSyncing(true);
    setSyncResults([]);

    try {
      const res = await fetch('/api/sync/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events }),
      });

      if (res.ok) {
        const data = await res.json();
        setSyncResults(data.results || []);

        // Clear accepted events from local storage
        const acceptedIds = (data.results || [])
          .filter((r: any) => r.status === 'ACCEPTED')
          .map((r: any) => r.event_id);

        if (acceptedIds.length > 0) {
          await clearSyncedEvents(acceptedIds);
        }

        setLastSyncTime(Date.now());
        await loadQueue();
      } else {
        alert('Sync server error');
      }
    } catch (err: any) {
      alert(`Sync failed: ${err.message}`);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-3 pb-3 text-xs font-mono">
        <Link href="/responder" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Overview &amp; Triage
        </Link>
        <Link href="/responder/incidents" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Incident Registry
        </Link>
        <Link href="/responder/credential" className="px-3 py-1.5 rounded-lg bg-surface-2 hover:bg-surface-3 text-text-secondary transition">
          Credential &amp; Keys
        </Link>
        <Link href="/responder/offline-queue" className="px-3 py-1.5 rounded-lg bg-primary text-canvas font-bold shadow-glow-cyan">
          Offline Sync Queue
        </Link>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono mb-2">
            <Radio className="w-4 h-4" />
            <span>LOCAL TRANSACTION JOURNAL &bull; IDEMPOTENT SYNC</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-text-primary">
            Locally Queued Responder Reports
          </h1>
          <p className="text-xs text-text-muted">
            All offline actions are cryptographically signed with your device key and sequence-chained before dispatch.
          </p>
        </div>

        <button
          onClick={handleSyncQueue}
          disabled={syncing || isEffectiveOffline || events.length === 0}
          className="px-5 py-2.5 rounded-xl bg-primary text-canvas font-bold text-xs flex items-center justify-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
          <span>{syncing ? 'Synchronizing Queue...' : `Sync All Queued Events (${events.length})`}</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Queue Items */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <div className="flex items-center justify-between border-b border-surface-3 pb-3">
              <h3 className="text-sm font-bold text-text-primary">Journal Records ({events.length})</h3>
              <span className="text-xs font-mono text-text-muted">IndexedDB &bull; Sequence Protected</span>
            </div>

            {loading ? (
              <div className="py-8 text-center text-xs text-text-muted">Loading queue...</div>
            ) : events.length === 0 ? (
              <div className="py-12 text-center rounded-xl bg-surface-2 border border-surface-3 text-text-muted text-xs space-y-2">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400" />
                <p className="font-semibold text-text-primary">Offline Queue is Clean</p>
                <p>All signed triage reports and events have been synchronized with the command base.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {events.map((ev) => (
                  <div
                    key={ev.event_id}
                    onClick={() => setSelectedEvent(ev)}
                    className={`p-4 rounded-xl border text-xs cursor-pointer transition space-y-2 ${
                      selectedEvent?.event_id === ev.event_id
                        ? 'bg-primary/10 border-primary shadow-glow-cyan'
                        : 'bg-surface-2 hover:bg-surface-3 border-surface-3'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-primary font-bold">#{ev.sequence_number}</span>
                        <span className="font-mono text-text-primary uppercase font-semibold">
                          {ev.event_type}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-text-muted">
                        {new Date(ev.created_at * 1000).toLocaleTimeString()}
                      </span>
                    </div>

                    <div className="font-mono text-[11px] text-text-muted truncate">
                      Event ID: {ev.event_id}
                    </div>

                    <div className="pt-2 border-t border-surface-3/50 flex items-center justify-between text-[10px] font-mono text-text-muted">
                      <span>Hash: {ev.payload_hash.substring(0, 16)}...</span>
                      <span className="text-primary font-semibold">Click to inspect payload</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Inspection & Sync Feedback */}
        <div className="lg:col-span-5 space-y-5">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <h3 className="text-xs font-bold text-text-primary flex items-center gap-2">
              <Hash className="w-4 h-4 text-primary" />
              <span>Event Cryptographic Inspection</span>
            </h3>

            {!selectedEvent ? (
              <div className="p-8 text-center rounded-xl bg-surface-2 border border-surface-3 text-text-muted text-xs">
                Select an event from the journal to view its canonical hash, signature, and payload.
              </div>
            ) : (
              <div className="space-y-3 text-xs font-mono">
                <div>
                  <span className="text-[10px] uppercase text-text-muted block">Event UUID</span>
                  <p className="text-primary text-[11px] break-all">{selectedEvent.event_id}</p>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-text-muted block">Signer Credential JTI</span>
                  <p className="text-text-primary text-[11px] break-all">{selectedEvent.credential_jti}</p>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-text-muted block">SHA-256 Payload Hash</span>
                  <p className="text-text-primary text-[11px] break-all bg-canvas p-2 rounded border border-surface-3">
                    {selectedEvent.payload_hash}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-text-muted block">Device ECDSA Signature</span>
                  <p className="text-text-muted text-[10px] break-all bg-canvas p-2 rounded border border-surface-3">
                    {selectedEvent.device_signature.substring(0, 64)}...
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-text-muted block">Raw Payload JSON</span>
                  <pre className="text-text-secondary text-[10px] bg-canvas p-2.5 rounded border border-surface-3 overflow-x-auto max-h-36">
                    {JSON.stringify(JSON.parse(selectedEvent.payload_json), null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>

          {/* Sync Results Feedback */}
          {syncResults.length > 0 && (
            <div className="p-5 rounded-2xl bg-surface-1 border border-surface-3 space-y-3 text-xs">
              <h4 className="font-bold text-text-primary flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Base Gateway Sync Receipts</span>
              </h4>
              <div className="space-y-2 font-mono text-[11px]">
                {syncResults.map((r, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg bg-surface-2 border border-surface-3 flex items-center justify-between"
                  >
                    <span className="text-text-secondary truncate">{r.event_id}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        r.status === 'ACCEPTED'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-amber-500/10 text-amber-400'
                      }`}
                    >
                      {r.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
