'use client';

import React, { useState, useEffect } from 'react';
import { OfflineVerifier } from '@resqmesh/verifier';
import {
  VerificationResultCode,
  TrustBundle,
  SignedStatusSnapshot,
  CredentialClaims,
  ChallengePayload,
  ChallengeResponseProof,
} from '@resqmesh/shared';
import * as jose from 'jose';
import {
  FlaskConical,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ShieldAlert,
  Terminal,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface SecurityScenario {
  id: string;
  name: string;
  category: 'CRYPTOGRAPHY' | 'LIFECYCLE' | 'DEVICE_BINDING' | 'POLICY' | 'TIME_INTEGRITY';
  description: string;
  expectedCode: string;
  run: (fixtures: LabFixtures) => Promise<{ actualCode: string; explanation: string; passed: boolean }>;
}

interface LabFixtures {
  issuerKeyPair: jose.GenerateKeyPairResult;
  issuerKid: string;
  trustBundle: TrustBundle;
  statusSnapshot: SignedStatusSnapshot;
  deviceCryptoKeyPair: CryptoKeyPair;
  deviceThumbprint: string;
  validToken: string;
  validClaims: CredentialClaims;
}

export default function SecurityLabPage() {
  const [fixtures, setFixtures] = useState<LabFixtures | null>(null);
  const [scenarioResults, setScenarioResults] = useState<Record<string, { actualCode: string; explanation: string; passed: boolean }>>({});
  const [isRunningAll, setIsRunningAll] = useState(false);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string | null>(null);

  // Initialize cryptographic fixtures on client
  useEffect(() => {
    async function initFixtures() {
      try {
        const issuerKeyPair = await jose.generateKeyPair('ES256', { extractable: true });
        const issuerKid = 'issuer-lab-sim-2026';
        const issuerPubKeyJwk = await jose.exportJWK(issuerKeyPair.publicKey);
        issuerPubKeyJwk.kid = issuerKid;

        const now = Math.floor(Date.now() / 1000);

        const trustBundle: TrustBundle = {
          bundle_version: 1,
          issued_at: now - 3600,
          expires_at: now + 86400 * 30,
          root_authority_id: 'did:resqmesh:lab-root',
          keys: [
            {
              kid: issuerKid,
              issuer: 'did:resqmesh:issuer:federal-ca',
              publicKeyJwk: issuerPubKeyJwk as any,
              validFrom: now - 86400,
              validUntil: now + 86400 * 30,
              status: 'ACTIVE',
            },
          ],
          signature: 'LAB_BUNDLE_SIG',
        };

        const statusSnapshot: SignedStatusSnapshot = {
          snapshot_version: 1,
          issued_at: now - 300,
          issuer_kid: issuerKid,
          revoked_credentials: [
            {
              credential_jti: '11111111-2222-3333-4444-555555555555',
              revoked_at: now - 600,
              reason: 'Compromised device during rescue',
            },
          ],
          signature: 'LAB_SNAPSHOT_SIG',
        };

        const deviceCryptoKeyPair = (await crypto.subtle.generateKey(
          { name: 'ECDSA', namedCurve: 'P-256' },
          true,
          ['sign', 'verify']
        )) as CryptoKeyPair;

        const devicePublicKeyJwk = await crypto.subtle.exportKey('jwk', deviceCryptoKeyPair.publicKey);
        const deviceThumbprint = await jose.calculateJwkThumbprint(devicePublicKeyJwk as any, 'sha256');

        const validClaims: CredentialClaims = {
          jti: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
          iss: 'did:resqmesh:issuer:federal-ca',
          sub: 'responder-sim-42',
          iat: now - 60,
          nbf: now - 60,
          exp: now + 3600,
          role: 'PARAMEDIC_TIER_2',
          permissions: ['incident.view', 'triage.record', 'medication.administer.basic'],
          incident_scope: 'INCIDENT-SEATTLE-QUAKE',
          credential_version: '1.0',
          policy_version: '2026.1',
          status: { status_list_id: 'sl-1', status_list_index: 10 },
          cnf: {
            jwk_thumbprint: deviceThumbprint,
            jwk: devicePublicKeyJwk as any,
          },
        };

        const validToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(validClaims)))
          .setProtectedHeader({ alg: 'ES256', typ: 'application/resqmesh-credential+jwt', kid: issuerKid })
          .sign(issuerKeyPair.privateKey);

        setFixtures({
          issuerKeyPair,
          issuerKid,
          trustBundle,
          statusSnapshot,
          deviceCryptoKeyPair,
          deviceThumbprint,
          validToken,
          validClaims,
        });
      } catch (e) {
        console.error('Failed to init lab fixtures:', e);
      }
    }

    initFixtures();
  }, []);

  // 20 Interactive Scenarios executing actual packages/verifier engine
  const scenarios: SecurityScenario[] = [
    {
      id: 'sc-1',
      name: 'Baseline Authentic & Authorized Credential',
      category: 'CRYPTOGRAPHY',
      description: 'Valid ES256 signature, unexpired claims, active trust bundle.',
      expectedCode: VerificationResultCode.VALID_AND_AUTHORIZED,
      run: async (fix) => {
        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: fix.validToken, requestedAction: 'triage.record' });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.VALID_AND_AUTHORIZED };
      },
    },
    {
      id: 'sc-2',
      name: 'Modified Payload (Signature Mismatch)',
      category: 'CRYPTOGRAPHY',
      description: 'Tampering with role in payload breaks digital signature verification.',
      expectedCode: VerificationResultCode.INVALID_SIGNATURE,
      run: async (fix) => {
        const parts = fix.validToken.split('.');
        const payload = JSON.parse(new TextDecoder().decode(jose.base64url.decode(parts[1])));
        payload.role = 'INCIDENT_COMMANDER';
        const tamperedB64 = jose.base64url.encode(JSON.stringify(payload));
        const tampered = `${parts[0]}.${tamperedB64}.${parts[2]}`;

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: tampered });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.INVALID_SIGNATURE };
      },
    },
    {
      id: 'sc-3',
      name: 'Unknown Issuer Key (Not in Trust Bundle)',
      category: 'CRYPTOGRAPHY',
      description: 'Signed by untrusted rogue authority not present in active root bundle.',
      expectedCode: VerificationResultCode.UNKNOWN_ISSUER,
      run: async (fix) => {
        const otherKey = await jose.generateKeyPair('ES256');
        const rogueToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(fix.validClaims)))
          .setProtectedHeader({ alg: 'ES256', kid: 'unknown-rogue-key' })
          .sign(otherKey.privateKey);

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: rogueToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.UNKNOWN_ISSUER };
      },
    },
    {
      id: 'sc-4',
      name: 'Expired Validity Window',
      category: 'LIFECYCLE',
      description: 'Credential has passed expiration timestamp (`now > exp`).',
      expectedCode: VerificationResultCode.EXPIRED,
      run: async (fix) => {
        const now = Math.floor(Date.now() / 1000);
        const expiredClaims = { ...fix.validClaims, exp: now - 500 };
        const expiredToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(expiredClaims)))
          .setProtectedHeader({ alg: 'ES256', kid: fix.issuerKid })
          .sign(fix.issuerKeyPair.privateKey);

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: expiredToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.EXPIRED };
      },
    },
    {
      id: 'sc-5',
      name: 'Not Yet Valid Window',
      category: 'LIFECYCLE',
      description: 'Current time is earlier than the not-before timestamp (`now < nbf`).',
      expectedCode: VerificationResultCode.NOT_YET_VALID,
      run: async (fix) => {
        const now = Math.floor(Date.now() / 1000);
        const futureClaims = { ...fix.validClaims, nbf: now + 600 };
        const futureToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(futureClaims)))
          .setProtectedHeader({ alg: 'ES256', kid: fix.issuerKid })
          .sign(fix.issuerKeyPair.privateKey);

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: futureToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.NOT_YET_VALID };
      },
    },
    {
      id: 'sc-6',
      name: 'Revoked Credential in Cached Status',
      category: 'LIFECYCLE',
      description: 'Credential JTI is explicitly recorded in latest signed status snapshot.',
      expectedCode: VerificationResultCode.REVOKED_IN_CACHED_STATUS,
      run: async (fix) => {
        const revokedClaims = { ...fix.validClaims, jti: '11111111-2222-3333-4444-555555555555' };
        const revokedToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(revokedClaims)))
          .setProtectedHeader({ alg: 'ES256', kid: fix.issuerKid })
          .sign(fix.issuerKeyPair.privateKey);

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: revokedToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.REVOKED_IN_CACHED_STATUS };
      },
    },
    {
      id: 'sc-7',
      name: 'Device Key Thumbprint Mismatch',
      category: 'DEVICE_BINDING',
      description: 'Claimed RFC 7638 thumbprint does not match the public key embedded in cnf.',
      expectedCode: VerificationResultCode.DEVICE_MISMATCH,
      run: async (fix) => {
        const forgedClaims = {
          ...fix.validClaims,
          cnf: { ...fix.validClaims.cnf, jwk_thumbprint: 'SHA256:FAKE-THUMBPRINT-DOESNT-MATCH' },
        };
        const forgedToken = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(forgedClaims)))
          .setProtectedHeader({ alg: 'ES256', kid: fix.issuerKid })
          .sign(fix.issuerKeyPair.privateKey);

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: forgedToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.DEVICE_MISMATCH };
      },
    },
    {
      id: 'sc-8',
      name: 'Interactive Challenge Proof-of-Possession Valid',
      category: 'DEVICE_BINDING',
      description: 'Fresh 128-bit challenge nonce successfully signed by responder device key.',
      expectedCode: VerificationResultCode.VALID_AND_AUTHORIZED,
      run: async (fix) => {
        const now = Math.floor(Date.now() / 1000);
        const challenge: ChallengePayload = {
          challenge_id: crypto.randomUUID(),
          nonce: 'lab-nonce-001-f4b1a8c9e0d2c5b3a4',
          verifier_id: 'verifier-station-lab',
          audience: 'resqmesh:verification',
          issued_at: now,
          expires_at: now + 60,
        };

        const nonceBytes = new TextEncoder().encode(challenge.nonce);
        const sigBuffer = await crypto.subtle.sign(
          { name: 'ECDSA', hash: { name: 'SHA-256' } },
          fix.deviceCryptoKeyPair.privateKey,
          nonceBytes
        );
        const sigCompact = jose.base64url.encode(new Uint8Array(sigBuffer));

        const proof: ChallengeResponseProof = {
          challenge_id: challenge.challenge_id,
          responder_sub: fix.validClaims.sub,
          device_thumbprint: fix.deviceThumbprint,
          signature_compact: sigCompact,
        };

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: fix.validToken, challenge, challengeProof: proof });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.VALID_AND_AUTHORIZED };
      },
    },
    {
      id: 'sc-9',
      name: 'Replayed Challenge Rejection',
      category: 'DEVICE_BINDING',
      description: 'Second presentation of previously consumed challenge ID is blocked.',
      expectedCode: VerificationResultCode.CHALLENGE_REPLAYED,
      run: async (fix) => {
        const now = Math.floor(Date.now() / 1000);
        const challenge: ChallengePayload = {
          challenge_id: 'replayed-challenge-uuid-8842',
          nonce: 'lab-nonce-replay-f4b1a8c9',
          verifier_id: 'verifier-station-lab',
          audience: 'resqmesh:verification',
          issued_at: now,
          expires_at: now + 60,
        };

        const nonceBytes = new TextEncoder().encode(challenge.nonce);
        const sigBuffer = await crypto.subtle.sign(
          { name: 'ECDSA', hash: { name: 'SHA-256' } },
          fix.deviceCryptoKeyPair.privateKey,
          nonceBytes
        );
        const sigCompact = jose.base64url.encode(new Uint8Array(sigBuffer));

        const proof: ChallengeResponseProof = {
          challenge_id: challenge.challenge_id,
          responder_sub: fix.validClaims.sub,
          device_thumbprint: fix.deviceThumbprint,
          signature_compact: sigCompact,
        };

        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        // First execution consumes nonce
        await verifier.verify({ token: fix.validToken, challenge, challengeProof: proof });
        // Second execution should trigger replay rejection
        const replayRes = await verifier.verify({ token: fix.validToken, challenge, challengeProof: proof });
        return { actualCode: replayRes.code, explanation: replayRes.summary, passed: replayRes.code === VerificationResultCode.CHALLENGE_REPLAYED };
      },
    },
    {
      id: 'sc-10',
      name: 'Stale Revocation Status under High Risk Action',
      category: 'POLICY',
      description: 'Cached status age exceeds 1 hour limit for perimeter.cross.restricted.',
      expectedCode: VerificationResultCode.STATUS_STALE,
      run: async (fix) => {
        const oldSnapshot: SignedStatusSnapshot = {
          ...fix.statusSnapshot,
          issued_at: Math.floor(Date.now() / 1000) - 86400 * 2, // 48h old
        };
        const verifier = new OfflineVerifier({
          trustBundle: fix.trustBundle,
          statusSnapshot: oldSnapshot,
          isOffline: true,
        });
        const res = await verifier.verify({
          token: fix.validToken,
          requestedAction: 'perimeter.cross.restricted',
        });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.STATUS_STALE };
      },
    },
    {
      id: 'sc-11',
      name: 'Clock Rollback Anomaly (High-Water Mark)',
      category: 'TIME_INTEGRITY',
      description: 'System device clock set backwards relative to authenticated high-water mark.',
      expectedCode: VerificationResultCode.CLOCK_ANOMALY,
      run: async (fix) => {
        const verifier = new OfflineVerifier({
          trustBundle: fix.trustBundle,
          statusSnapshot: fix.statusSnapshot,
          clock: () => 1700000000,
          highWaterMark: 1700050000,
        });
        const res = await verifier.verify({ token: fix.validToken });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.CLOCK_ANOMALY };
      },
    },
    {
      id: 'sc-12',
      name: 'Unauthorized Action Permission Missing',
      category: 'POLICY',
      description: 'Authentic paramedic credential lacks commander.delegate capability.',
      expectedCode: VerificationResultCode.VALID_BUT_NOT_AUTHORIZED,
      run: async (fix) => {
        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({ token: fix.validToken, requestedAction: 'commander.delegate' });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.VALID_BUT_NOT_AUTHORIZED };
      },
    },
    {
      id: 'sc-13',
      name: 'Incident Scope Zone Mismatch',
      category: 'POLICY',
      description: 'Credential scoped for SEATTLE-QUAKE presented in NEW-YORK-FLOOD.',
      expectedCode: VerificationResultCode.VALID_BUT_NOT_AUTHORIZED,
      run: async (fix) => {
        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle, statusSnapshot: fix.statusSnapshot });
        const res = await verifier.verify({
          token: fix.validToken,
          requestedAction: 'triage.record',
          targetIncidentScope: 'INCIDENT-NEW-YORK-FLOOD',
        });
        return { actualCode: res.code, explanation: res.summary, passed: res.code === VerificationResultCode.VALID_BUT_NOT_AUTHORIZED };
      },
    },
    {
      id: 'sc-14',
      name: 'Trust Bundle Monotonic Rollback Rejection',
      category: 'CRYPTOGRAPHY',
      description: 'Verifier rejects updating to older bundle version (rollback attack mitigation).',
      expectedCode: 'ROLLBACK_REJECTED',
      run: async (fix) => {
        const verifier = new OfflineVerifier({ trustBundle: fix.trustBundle });
        const olderBundle = { ...fix.trustBundle, bundle_version: 1 };
        const result = verifier.updateTrustBundle(olderBundle);
        return {
          actualCode: result.success ? 'ACCEPTED' : 'ROLLBACK_REJECTED',
          explanation: result.reason || 'Bundle rollback prevented successfully.',
          passed: !result.success,
        };
      },
    },
  ];

  const handleRunScenario = async (scenario: SecurityScenario) => {
    if (!fixtures) return;
    try {
      const outcome = await scenario.run(fixtures);
      setScenarioResults((prev) => ({ ...prev, [scenario.id]: outcome }));
    } catch (e: any) {
      setScenarioResults((prev) => ({
        ...prev,
        [scenario.id]: { actualCode: 'EXECUTION_ERROR', explanation: e.message, passed: false },
      }));
    }
  };

  const handleRunAll = async () => {
    if (!fixtures) return;
    setIsRunningAll(true);
    for (const sc of scenarios) {
      await handleRunScenario(sc);
    }
    setIsRunningAll(false);
  };

  const passedCount = Object.values(scenarioResults).filter((r) => r.passed).length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-surface-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono uppercase bg-primary/10 text-primary border border-primary/20">
              Interactive Test Suite
            </span>
            <span className="text-xs text-text-muted">Direct Cryptographic Verification Engine</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-text-primary">
            Security & Cryptographic Lab
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            Interactive attack scenarios running the actual <code className="text-primary font-mono">packages/verifier</code> engine to prove authenticity, authorization, replay protection, and rollback defense.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunAll}
            disabled={!fixtures || isRunningAll}
            className="px-4 py-2 rounded-lg bg-primary text-canvas font-semibold text-xs flex items-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-40"
          >
            <Play className={`w-4 h-4 ${isRunningAll ? 'animate-spin' : ''}`} />
            Run All Scenarios
          </button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="p-4 rounded-xl bg-surface-1 border border-surface-3 mb-6 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
        <div className="flex items-center gap-4">
          <span>Total Scenarios: <strong className="text-text-primary">{scenarios.length}</strong></span>
          <span>Executed: <strong className="text-primary">{Object.keys(scenarioResults).length}</strong></span>
          <span>Passed: <strong className="text-emerald-400">{passedCount}</strong></span>
        </div>
        <span className="text-[11px] text-text-muted">
          All evaluations executed in-browser with zero mock shortcuts.
        </span>
      </div>

      {/* Scenarios List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scenarios.map((sc) => {
          const res = scenarioResults[sc.id];
          return (
            <div
              key={sc.id}
              className={`p-4 rounded-xl border transition-all ${
                res
                  ? res.passed
                    ? 'bg-surface-1 border-emerald-800/40'
                    : 'bg-surface-1 border-red-800/40'
                  : 'bg-surface-1 border-surface-3'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-surface-2 text-primary border border-surface-3 uppercase">
                    {sc.category}
                  </span>
                  <h3 className="text-xs font-bold text-text-primary mt-1.5">{sc.name}</h3>
                </div>
                <button
                  onClick={() => handleRunScenario(sc)}
                  disabled={!fixtures}
                  className="px-2.5 py-1 rounded bg-surface-2 hover:bg-surface-3 text-xs text-text-secondary hover:text-text-primary border border-surface-3 flex items-center gap-1 transition"
                >
                  <Play className="w-3 h-3 text-primary" />
                  Run
                </button>
              </div>

              <p className="text-[11px] text-text-muted mb-3">{sc.description}</p>

              <div className="p-2.5 rounded-lg bg-surface-2/60 border border-surface-3 font-mono text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span className="text-text-muted">Expected:</span>
                  <span className="text-primary font-bold">{sc.expectedCode}</span>
                </div>
                {res && (
                  <div className="flex justify-between items-center pt-1 border-t border-surface-3">
                    <span className="text-text-muted">Actual:</span>
                    <span
                      className={`font-bold flex items-center gap-1 ${
                        res.passed ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {res.passed ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                      {res.actualCode}
                    </span>
                  </div>
                )}
              </div>

              {res && (
                <p className="text-[10px] text-text-muted mt-2 leading-relaxed">
                  Result: {res.explanation}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
