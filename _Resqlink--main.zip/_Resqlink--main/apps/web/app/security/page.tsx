'use client';

import React from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  Key,
  Lock,
  Layers,
  Clock,
  AlertTriangle,
  CheckCircle2,
  FileCheck2,
  ArrowRight,
  Fingerprint,
  Cpu,
} from 'lucide-react';

export default function SecurityArchitecturePage() {
  const securityPillars = [
    {
      title: '1. Cryptographic Authenticity',
      icon: ShieldCheck,
      description: 'Every credential is an RFC 7515 Compact JWS signed using ECDSA P-256 (ES256) by an enrolled issuing authority in the offline trust bundle.',
      details: 'The public key is pinned locally. Altered signatures, header forgery, or unknown key IDs (kid) are immediately rejected by the browser.',
    },
    {
      title: '2. Device-Bound Proof of Possession',
      icon: Fingerprint,
      description: 'Credentials include an RFC 7638 JWK thumbprint binding (`cnf` confirmation claim) to a non-extractable private key generated inside the device.',
      details: 'Even if a credential token is stolen or copied, the bearer must sign a fresh cryptographic challenge to prove possession of the bound hardware/browser key.',
    },
    {
      title: '3. Role-Based Authorization Policy',
      icon: Lock,
      description: 'Granular permissions (e.g. `triage.record`, `medication.administer`, `perimeter.cross`) are evaluated locally against the credential scope.',
      details: 'A medical responder cannot cross restricted hazardous perimeters without explicit credential entitlement, and expired credentials block privileged actions.',
    },
    {
      title: '4. Monotonic Freshness & Stale Revocation',
      icon: Clock,
      description: 'In an offline partitioned sector, real-time revocation checking is mathematically impossible.',
      details: 'ResQMesh uses signed monotonic status snapshots with strict risk tier policies. Stale snapshots degrade permissions to emergency-read-only gracefully.',
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-10">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono">
          <ShieldCheck className="w-4 h-4" />
          <span>SECURITY SUBSYSTEM &bull; ZERO-TRUST OFFLINE IDENTITY</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-text-primary">
          Offline Trust & Cryptographic Security Architecture
        </h1>
        <p className="text-sm text-text-secondary max-w-3xl">
          How ResQMesh enables offline role authorization, tamper detection, and proof-of-possession when all cloud servers and telecom networks are severed.
        </p>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {securityPillars.map((pillar, idx) => {
          const Icon = pillar.icon;
          return (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4 hover:border-primary/40 transition"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                  <Icon className="w-5 h-5" />
                </div>
                <h2 className="text-base font-bold text-text-primary">{pillar.title}</h2>
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">{pillar.description}</p>
              <div className="p-3 rounded-xl bg-surface-2 border border-surface-3 text-[11px] text-text-muted leading-relaxed">
                {pillar.details}
              </div>
            </div>
          );
        })}
      </div>

      {/* Honest Threat Model & Truthfulness Matrix */}
      <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-5">
        <div className="flex items-center gap-3 border-b border-surface-3 pb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-text-primary">Honest Threat Model: Browser vs Native Mobile</h3>
            <p className="text-xs text-text-muted">Rigorous transparency regarding browser platform limits</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
            <h4 className="font-semibold text-text-primary flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>What Web Crypto & IndexedDB Guarantee</span>
            </h4>
            <ul className="space-y-1.5 text-text-secondary list-disc pl-4 text-[11px]">
              <li>Non-extractable private keys cannot be read via standard JavaScript `exportKey` calls.</li>
              <li>Signatures are mathematically verifiable in milliseconds on any modern phone browser.</li>
              <li>SHA-256 hash chaining detects offline event alteration or deletion.</li>
              <li>Challenge nonces prevent replay of intercepted proof-of-possession assertions.</li>
            </ul>
          </div>

          <div className="p-4 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
            <h4 className="font-semibold text-text-primary flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Real World Limitations & Mitigation</span>
            </h4>
            <ul className="space-y-1.5 text-text-secondary list-disc pl-4 text-[11px]">
              <li>Browsers lack direct access to hardware Secure Enclave or Android Keystore biometric locks.</li>
              <li>A rooted or compromised OS can inspect browser IndexedDB storage files directly.</li>
              <li>Offline devices cannot know of sudden credential revocations in real-time until snapshot sync.</li>
              <li>Production deployment targets native PWA wrappers (Capacitor/Cordova) to access hardware HSM.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap items-center gap-4 pt-2">
        <Link
          href="/verify-credential"
          className="px-5 py-3 rounded-xl bg-primary text-canvas font-semibold text-xs flex items-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan"
        >
          <FileCheck2 className="w-4 h-4" />
          <span>Test Live Credential Verifier</span>
        </Link>
        <Link
          href="/security-lab"
          className="px-5 py-3 rounded-xl bg-surface-2 hover:bg-surface-3 border border-surface-3 text-text-primary text-xs font-semibold flex items-center gap-2 transition"
        >
          <Layers className="w-4 h-4 text-primary" />
          <span>Launch 14 Attack Vectors in Security Lab</span>
          <ArrowRight className="w-3.5 h-3.5 text-text-muted" />
        </Link>
      </div>
    </div>
  );
}
