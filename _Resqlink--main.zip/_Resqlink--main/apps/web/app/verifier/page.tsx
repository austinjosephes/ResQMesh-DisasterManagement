'use client';

import React, { useState, useEffect } from 'react';
import { OfflineVerifier } from '@resqmesh/verifier';
import {
  VerificationResultCode,
  VerificationResult,
  TrustBundle,
  SignedStatusSnapshot,
  DEFAULT_ACTION_POLICIES,
  ChallengePayload,
  ChallengeResponseProof,
} from '@resqmesh/shared';
import { useConnectivity } from '@/components/shell/ConnectivityContext';
import {
  getCachedTrustBundle,
  getCachedStatusSnapshot,
  cacheTrustBundle,
  cacheStatusSnapshot,
} from '@/lib/offline-store';
import {
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Clock,
  Radio,
  FileText,
  Copy,
  Check,
  RefreshCw,
  AlertTriangle,
  Download,
  Key,
  Layers,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

export default function VerifierPage() {
  const { isEffectiveOffline } = useConnectivity();
  const [tokenInput, setTokenInput] = useState('');
  const [requestedAction, setRequestedAction] = useState('triage.record');
  const [incidentScope, setIncidentScope] = useState('INCIDENT-CASCADE-QUAKE-2026');
  const [activeTrustBundle, setActiveTrustBundle] = useState<TrustBundle | null>(null);
  const [activeStatusSnapshot, setActiveStatusSnapshot] = useState<SignedStatusSnapshot | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [activeTab, setActiveTab] = useState<'paste' | 'scenarios' | 'qr'>('scenarios');
  const [interactiveChallenge, setInteractiveChallenge] = useState<ChallengePayload | null>(null);
  const [challengeProof, setChallengeProof] = useState<ChallengeResponseProof | null>(null);

  // Load trust material from server or offline cache on initial mount
  useEffect(() => {
    async function loadTrustMaterial() {
      try {
        let bundle: TrustBundle | null = await getCachedTrustBundle();
        let snapshot: SignedStatusSnapshot | null = await getCachedStatusSnapshot();

        // If online or not cached, try fetching from backend
        if (!bundle || !isEffectiveOffline) {
          const res = await fetch('/api/trust/bundle');
          if (res.ok) {
            const data = await res.json();
            bundle = data.bundle;
            if (bundle) await cacheTrustBundle(bundle);
          }
        }

        if (!snapshot || !isEffectiveOffline) {
          const res = await fetch('/api/trust/status-snapshot');
          if (res.ok) {
            const data = await res.json();
            snapshot = data.snapshot;
            if (snapshot) await cacheStatusSnapshot(snapshot);
          }
        }

        if (bundle) setActiveTrustBundle(bundle);
        if (snapshot) setActiveStatusSnapshot(snapshot);
      } catch (e) {
        console.error('Failed to load trust material:', e);
      }
    }

    loadTrustMaterial();
  }, [isEffectiveOffline]);

  // Execute verification engine
  const executeVerification = async (
    token: string,
    action: string = requestedAction,
    proof: ChallengeResponseProof | null = challengeProof
  ) => {
    if (!token || !activeTrustBundle) return;
    setIsVerifying(true);

    try {
      const verifier = new OfflineVerifier({
        trustBundle: activeTrustBundle,
        statusSnapshot: activeStatusSnapshot || undefined,
        isOffline: isEffectiveOffline,
      });

      const result = await verifier.verify({
        token,
        requestedAction: action,
        targetIncidentScope: incidentScope,
        challenge: interactiveChallenge || undefined,
        challengeProof: proof || undefined,
      });

      setVerificationResult(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsVerifying(false);
    }
  };

  // Generate interactive 128-bit challenge
  const handleGenerateChallenge = async () => {
    try {
      const res = await fetch('/api/verifier/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ verifierId: 'verifier-station-alpha' }),
      });
      if (res.ok) {
        const data = await res.json();
        setInteractiveChallenge(data.challenge);
        setChallengeProof(null);
      }
    } catch (e) {
      // Offline fallback challenge generation
      const now = Math.floor(Date.now() / 1000);
      const fallback: ChallengePayload = {
        challenge_id: crypto.randomUUID(),
        nonce: Array.from(crypto.getRandomValues(new Uint8Array(16)))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join(''),
        verifier_id: 'local-offline-station',
        audience: 'resqmesh:verification',
        issued_at: now,
        expires_at: now + 60,
      };
      setInteractiveChallenge(fallback);
      setChallengeProof(null);
    }
  };

  // Pre-configured test scenarios
  const scenarios = [
    {
      id: 'valid-paramedic',
      title: 'Valid Paramedic Credential',
      desc: 'Authentic ES256 signature, active role, fresh cached status.',
      expected: 'VALID_AND_AUTHORIZED',
      load: async () => {
        const res = await fetch('/api/credentials');
        const data = await res.json();
        const activeCred = data.credentials?.find((c: any) => c.status === 'ACTIVE');
        if (activeCred) {
          setTokenInput(activeCred.tokenJws);
          setRequestedAction('triage.record');
          await executeVerification(activeCred.tokenJws, 'triage.record');
        }
      },
    },
    {
      id: 'tampered-signature',
      title: 'Tampered Signature / Modified Role',
      desc: 'Role edited in payload; signature fails cryptographic verification.',
      expected: 'INVALID_SIGNATURE',
      load: async () => {
        const res = await fetch('/api/credentials');
        const data = await res.json();
        const activeCred = data.credentials?.[0];
        if (activeCred) {
          const parts = activeCred.tokenJws.split('.');
          const payload = JSON.parse(atob(parts[1]));
          payload.role = 'INCIDENT_COMMANDER';
          payload.permissions.push('commander.delegate');
          const tamperedB64 = btoa(JSON.stringify(payload)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
          const tampered = `${parts[0]}.${tamperedB64}.${parts[2]}`;
          setTokenInput(tampered);
          await executeVerification(tampered);
        }
      },
    },
    {
      id: 'unauthorized-action',
      title: 'Unauthorized Action (Valid Signature)',
      desc: 'Authentic credential attempting action without required role permission.',
      expected: 'VALID_BUT_NOT_AUTHORIZED',
      load: async () => {
        const res = await fetch('/api/credentials');
        const data = await res.json();
        const activeCred = data.credentials?.[0];
        if (activeCred) {
          setTokenInput(activeCred.tokenJws);
          setRequestedAction('commander.delegate'); // Not in paramedic permissions
          await executeVerification(activeCred.tokenJws, 'commander.delegate');
        }
      },
    },
    {
      id: 'revoked-credential',
      title: 'Revoked Responder Device',
      desc: 'Identified as explicitly revoked in cached signed status snapshot.',
      expected: 'REVOKED_IN_CACHED_STATUS',
      load: async () => {
        const res = await fetch('/api/credentials');
        const data = await res.json();
        const revokedCred = data.credentials?.find((c: any) => c.status === 'REVOKED');
        if (revokedCred) {
          setTokenInput(revokedCred.tokenJws);
          await executeVerification(revokedCred.tokenJws);
        }
      },
    },
    {
      id: 'stale-status',
      title: 'Stale Status Evaluation',
      desc: 'Simulates snapshot exceeding allowable age for HIGH risk action.',
      expected: 'STATUS_STALE',
      load: async () => {
        const res = await fetch('/api/credentials');
        const data = await res.json();
        const activeCred = data.credentials?.[0];
        if (activeCred && activeStatusSnapshot) {
          // Temporarily mock an old snapshot
          const oldSnapshot: SignedStatusSnapshot = {
            ...activeStatusSnapshot,
            issued_at: Math.floor(Date.now() / 1000) - 86400 * 2, // 48h old
          };
          const verifier = new OfflineVerifier({
            trustBundle: activeTrustBundle!,
            statusSnapshot: oldSnapshot,
            isOffline: true,
          });
          setTokenInput(activeCred.tokenJws);
          setRequestedAction('perimeter.cross.restricted'); // High risk tier: max 1 hour
          const result = await verifier.verify({
            token: activeCred.tokenJws,
            requestedAction: 'perimeter.cross.restricted',
          });
          setVerificationResult(result);
        }
      },
    },
  ];

  const handleCopyDiagnostics = () => {
    if (!verificationResult) return;
    navigator.clipboard.writeText(JSON.stringify(verificationResult, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Cockpit Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-surface-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono uppercase bg-primary/10 text-primary border border-primary/20">
              Cockpit v5.0
            </span>
            <span className="text-xs text-text-muted">
              Trust Bundle v{activeTrustBundle?.bundle_version || 1} •{' '}
              {isEffectiveOffline ? 'Offline Mode (Local Storage)' : 'Online Connected'}
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-text-primary">
            Offline Credential Verifier
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            Cryptographically evaluate disaster-responder credentials against cached trust material without network access.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => executeVerification(tokenInput)}
            disabled={!tokenInput || isVerifying}
            className="px-4 py-2 rounded-lg bg-primary text-canvas font-semibold text-xs flex items-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isVerifying ? 'animate-spin' : ''}`} />
            Run Verification
          </button>
        </div>
      </div>

      {/* 3-Panel Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Panel 1: Input & Scenarios (4 Columns) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="p-5 rounded-xl bg-surface-1 border border-surface-3">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-surface-3">
              <h2 className="text-sm font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                1. Credential Input
              </h2>
              <div className="flex rounded-lg bg-surface-2 p-0.5 border border-surface-3 text-[11px]">
                <button
                  onClick={() => setActiveTab('scenarios')}
                  className={`px-2 py-1 rounded transition ${activeTab === 'scenarios' ? 'bg-surface-3 text-primary font-medium' : 'text-text-muted hover:text-text-primary'}`}
                >
                  Scenarios
                </button>
                <button
                  onClick={() => setActiveTab('paste')}
                  className={`px-2 py-1 rounded transition ${activeTab === 'paste' ? 'bg-surface-3 text-primary font-medium' : 'text-text-muted hover:text-text-primary'}`}
                >
                  Paste JWS
                </button>
              </div>
            </div>

            {activeTab === 'scenarios' ? (
              <div className="space-y-2.5">
                <p className="text-xs text-text-muted mb-3">
                  Select a pre-built cryptographic vector to test the verification pipeline:
                </p>
                {scenarios.map((sc) => (
                  <button
                    key={sc.id}
                    onClick={sc.load}
                    className="w-full text-left p-3 rounded-lg bg-surface-2 hover:bg-surface-3 border border-surface-3 hover:border-primary/40 transition group flex items-start justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-text-primary group-hover:text-primary transition flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-primary" />
                        {sc.title}
                      </p>
                      <p className="text-[11px] text-text-secondary mt-1">{sc.desc}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-text-muted group-hover:text-primary shrink-0 ml-2 mt-0.5" />
                  </button>
                ))}
              </div>
            ) : (
              <div>
                <label className="block text-xs font-medium text-text-secondary mb-1.5">
                  Raw Compact JWS Token
                </label>
                <textarea
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  placeholder="eyJhbGciOiJFUzI1NiIs..."
                  rows={8}
                  className="w-full p-3 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary transition"
                />
                <button
                  onClick={() => executeVerification(tokenInput)}
                  className="mt-3 w-full py-2 rounded-lg bg-surface-2 hover:bg-surface-3 border border-surface-3 text-xs font-medium text-text-primary transition flex items-center justify-center gap-1.5"
                >
                  Evaluate Pasted Token
                </button>
              </div>
            )}
          </div>

          {/* Interactive Challenge-Response Panel */}
          <div className="p-5 rounded-xl bg-surface-1 border border-surface-3">
            <h2 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-3 flex items-center gap-2">
              <Key className="w-4 h-4 text-primary" />
              Device Challenge-Response
            </h2>
            <p className="text-xs text-text-muted mb-4">
              Enforce RFC 7638 device key possession via 128-bit single-use challenge nonce with 60s replay protection.
            </p>

            {interactiveChallenge ? (
              <div className="space-y-3 p-3 rounded-lg bg-surface-2 border border-surface-3 font-mono text-[11px]">
                <div>
                  <span className="text-text-muted">Challenge ID: </span>
                  <span className="text-primary">{interactiveChallenge.challenge_id.slice(0, 8)}...</span>
                </div>
                <div>
                  <span className="text-text-muted">Nonce: </span>
                  <span className="text-text-primary">{interactiveChallenge.nonce}</span>
                </div>
                <div>
                  <span className="text-text-muted">Expires in: </span>
                  <span className="text-amber-400">
                    {Math.max(0, interactiveChallenge.expires_at - Math.floor(Date.now() / 1000))}s
                  </span>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleGenerateChallenge}
                    className="flex-1 py-1.5 rounded bg-surface-3 hover:bg-surface-1 text-xs text-text-secondary transition"
                  >
                    New Nonce
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={handleGenerateChallenge}
                className="w-full py-2 rounded-lg bg-surface-2 hover:bg-surface-3 border border-surface-3 text-xs font-medium text-text-primary transition flex items-center justify-center gap-1.5"
              >
                Generate Verification Challenge
              </button>
            )}
          </div>
        </div>

        {/* Panel 2: Subject & Action Selector (3 Columns) */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          <div className="p-5 rounded-xl bg-surface-1 border border-surface-3">
            <h2 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
              <Radio className="w-4 h-4 text-primary" />
              2. Operational Scope
            </h2>

            {/* Requested Action */}
            <div className="mb-4">
              <label className="block text-xs font-medium text-text-secondary mb-1.5">
                Requested Operational Action
              </label>
              <select
                value={requestedAction}
                onChange={(e) => {
                  setRequestedAction(e.target.value);
                  if (tokenInput) executeVerification(tokenInput, e.target.value);
                }}
                className="w-full p-2.5 rounded-lg bg-surface-2 border border-surface-3 text-xs text-text-primary focus:outline-none focus:border-primary transition"
              >
                <option value="incident.view">incident.view (Tier: LOW)</option>
                <option value="triage.read">triage.read (Tier: LOW)</option>
                <option value="triage.record">triage.record (Tier: MEDIUM)</option>
                <option value="report.submit">report.submit (Tier: MEDIUM)</option>
                <option value="medication.administer.basic">medication.administer.basic (Tier: MEDIUM)</option>
                <option value="perimeter.cross.restricted">perimeter.cross.restricted (Tier: HIGH)</option>
                <option value="narcotics.dispense">narcotics.dispense (Tier: HIGH - Online Only)</option>
                <option value="commander.delegate">commander.delegate (Tier: CRITICAL)</option>
              </select>
              <p className="text-[11px] text-text-muted mt-1.5">
                Policy Max Age: {DEFAULT_ACTION_POLICIES[requestedAction]?.maxStatusAgeSeconds ? `${DEFAULT_ACTION_POLICIES[requestedAction].maxStatusAgeSeconds / 3600}h` : 'Online Mandatory'}
              </p>
            </div>

            {/* Target Incident Zone */}
            <div className="mb-4">
              <label className="block text-xs font-medium text-text-secondary mb-1.5">
                Incident Deployment Zone
              </label>
              <input
                type="text"
                value={incidentScope}
                onChange={(e) => setIncidentScope(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-surface-2 border border-surface-3 text-xs font-mono text-text-primary focus:outline-none focus:border-primary transition"
              />
            </div>

            {/* Parsed Claims Overview if Available */}
            {verificationResult?.claims && (
              <div className="pt-4 border-t border-surface-3 space-y-2 text-xs">
                <span className="font-semibold text-text-secondary uppercase text-[10px] tracking-wider">
                  Parsed Subject Claims
                </span>
                <div className="p-2.5 rounded-lg bg-surface-2/60 border border-surface-3 font-mono text-[11px] space-y-1.5">
                  <div>
                    <span className="text-text-muted">Sub: </span>
                    <span className="text-text-primary">{verificationResult.claims.sub}</span>
                  </div>
                  <div>
                    <span className="text-text-muted">Role: </span>
                    <span className="text-primary font-semibold">{verificationResult.claims.role}</span>
                  </div>
                  <div>
                    <span className="text-text-muted">Scope: </span>
                    <span className="text-text-primary">{verificationResult.claims.incident_scope}</span>
                  </div>
                  <div>
                    <span className="text-text-muted">Thumbprint: </span>
                    <span className="text-text-muted">
                      {verificationResult.claims.cnf?.jwk_thumbprint?.slice(0, 16)}...
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Panel 3: Live Verification Diagnostics (5 Columns) */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          <div className="p-5 rounded-xl bg-surface-1 border border-surface-3">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-surface-3">
              <h2 className="text-sm font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-primary" />
                3. Verification Cockpit
              </h2>
              {verificationResult && (
                <button
                  onClick={handleCopyDiagnostics}
                  className="text-xs text-text-muted hover:text-primary transition flex items-center gap-1 font-mono"
                >
                  {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedJson ? 'Copied' : 'JSON'}
                </button>
              )}
            </div>

            {/* Decision Headline Banner */}
            {verificationResult ? (
              <div>
                <div
                  className={`p-4 rounded-xl border mb-5 flex items-start gap-3 transition-all ${
                    verificationResult.code === VerificationResultCode.VALID_AND_AUTHORIZED
                      ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
                      : verificationResult.code === VerificationResultCode.VALID_BUT_NOT_AUTHORIZED ||
                        verificationResult.code === VerificationResultCode.STATUS_STALE
                      ? 'bg-amber-950/40 border-amber-700/60 text-amber-200'
                      : 'bg-red-950/40 border-red-700/60 text-red-200'
                  }`}
                >
                  {verificationResult.code === VerificationResultCode.VALID_AND_AUTHORIZED ? (
                    <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                  ) : verificationResult.code === VerificationResultCode.VALID_BUT_NOT_AUTHORIZED ||
                    verificationResult.code === VerificationResultCode.STATUS_STALE ? (
                    <ShieldAlert className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
                  ) : (
                    <ShieldX className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono font-bold text-xs uppercase px-2 py-0.5 rounded bg-black/40">
                        {verificationResult.code}
                      </span>
                    </div>
                    <p className="text-xs font-medium leading-relaxed">{verificationResult.summary}</p>
                    <div className="flex gap-3 mt-2 text-[11px] font-mono opacity-80">
                      <span>Authentic: {verificationResult.authentic ? 'YES' : 'NO'}</span>
                      <span>•</span>
                      <span>Authorized: {verificationResult.authorized ? 'YES' : 'NO'}</span>
                      <span>•</span>
                      <span>Fresh: {verificationResult.freshnessOk ? 'YES' : 'NO'}</span>
                    </div>
                  </div>
                </div>

                {/* Ordered Diagnostic Check List */}
                <h3 className="text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2.5">
                  Ordered Verification Pipeline Checks
                </h3>
                <div className="space-y-2">
                  {verificationResult.checks.map((chk) => (
                    <div
                      key={chk.id}
                      className="p-3 rounded-lg bg-surface-2 border border-surface-3 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-text-primary">{chk.name}</span>
                        </div>
                        <p className="text-[11px] text-text-muted mt-1">{chk.explanation}</p>
                      </div>
                      <span
                        className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded uppercase shrink-0 ${
                          chk.status === 'PASSED'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                            : chk.status === 'WARNING'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                            : chk.status === 'FAILED'
                            ? 'bg-red-950/60 text-red-400 border border-red-800/40'
                            : 'bg-surface-3 text-text-muted border border-surface-3'
                        }`}
                      >
                        {chk.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-text-muted">
                <ShieldCheck className="w-10 h-10 mx-auto mb-3 opacity-30 text-primary" />
                <p className="text-sm">No credential evaluated yet.</p>
                <p className="text-xs mt-1">Select a scenario or paste a Compact JWS to run live verification.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
