'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  FileCheck2,
  RefreshCw,
  Lock,
  ArrowRight,
  Fingerprint,
  FileCode,
} from 'lucide-react';
import { verifyCredentialOffline } from '@resqmesh/verifier';
import { getCachedTrustBundle, getCachedStatusSnapshot } from '@/lib/offline-store';

export default function VerifyCredentialPublicPage() {
  const [tokenInput, setTokenInput] = useState('');
  const [requestedAction, setRequestedAction] = useState('triage.record');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [trustBundle, setTrustBundle] = useState<any>(null);
  const [statusSnapshot, setStatusSnapshot] = useState<any>(null);

  useEffect(() => {
    // Fetch trust bundle and snapshot from server or local cache
    fetch('/api/trust/bundle')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.bundle) setTrustBundle(data.bundle);
      })
      .catch(() => {});

    fetch('/api/trust/status-snapshot')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.snapshot) setStatusSnapshot(data.snapshot);
      })
      .catch(() => {});
  }, []);

  const handleLoadDemoToken = async () => {
    try {
      const res = await fetch('/api/credentials/7c9e6679-7425-40de-944b-e07fc1f90ae7');
      if (res.ok) {
        const data = await res.json();
        if (data.credential && data.credential.tokenJws) {
          setTokenInput(data.credential.tokenJws);
          setVerificationResult(null);
        }
      }
    } catch (e) {
      alert('Unable to load demo credential token');
    }
  };

  const handleRunVerify = async () => {
    if (!tokenInput.trim()) return;
    setIsVerifying(true);
    setVerificationResult(null);

    try {
      // Run the genuine pure verifier engine in browser
      const result = await verifyCredentialOffline({
        tokenJws: tokenInput.trim(),
        trustBundle: trustBundle || undefined,
        statusSnapshot: statusSnapshot || undefined,
        requestedAction,
        currentTime: Math.floor(Date.now() / 1000),
      });

      setVerificationResult(result);
    } catch (err: any) {
      setVerificationResult({
        decision: 'REJECT',
        resultCode: 'MALFORMED_INPUT',
        diagnostics: [err.message || 'Verification execution failed'],
      });
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-primary/30 text-primary text-xs font-mono">
          <FileCheck2 className="w-4 h-4" />
          <span>PUBLIC VERIFIER &bull; PRIVACY-PRESERVING DEMONSTRATION</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-text-primary">
          Offline Credential Verification Engine
        </h1>
        <p className="text-sm text-text-secondary max-w-3xl">
          Test any ResQMesh digital responder credential directly in this browser. Verification runs 100% locally using the Web Crypto API and pinned offline trust bundle.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Panel */}
        <div className="lg:col-span-7 space-y-5">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-text-primary flex items-center gap-2">
                <FileCode className="w-4 h-4 text-primary" />
                <span>Compact JWS Credential Token</span>
              </label>
              <button
                type="button"
                onClick={handleLoadDemoToken}
                className="text-xs text-primary hover:underline font-mono"
              >
                + Load Active Demo Credential
              </button>
            </div>

            <textarea
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="eyJhbGciOiJFUzI1NiIs..."
              rows={6}
              className="w-full p-3 rounded-xl bg-surface-2 border border-surface-3 text-text-primary font-mono text-xs focus:outline-none focus:border-primary transition"
            />

            <div>
              <label className="block text-xs font-semibold text-text-primary mb-2">
                Requested Action to Authorize
              </label>
              <select
                value={requestedAction}
                onChange={(e) => setRequestedAction(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-surface-2 border border-surface-3 text-text-primary text-xs font-mono focus:outline-none focus:border-primary transition"
              >
                <option value="triage.read">triage.read (View medical triage records)</option>
                <option value="triage.record">triage.record (Record patient triage tag)</option>
                <option value="report.submit">report.submit (Submit incident report)</option>
                <option value="medication.administer.basic">medication.administer.basic (Dispense emergency meds)</option>
                <option value="perimeter.cross.restricted">perimeter.cross.restricted (Access hot hazard zone)</option>
                <option value="incident.command.override">incident.command.override (Restricted commander action)</option>
              </select>
            </div>

            <button
              type="button"
              onClick={handleRunVerify}
              disabled={isVerifying || !tokenInput.trim()}
              className="w-full py-3 rounded-xl bg-primary text-canvas font-semibold text-xs flex items-center justify-center gap-2 hover:bg-primary/90 transition shadow-glow-cyan disabled:opacity-50"
            >
              {isVerifying ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing Web Crypto Engine...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify Credential Locally</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Verification Result Panel */}
        <div className="lg:col-span-5 space-y-5">
          <div className="p-6 rounded-2xl bg-surface-1 border border-surface-3 space-y-4">
            <h3 className="text-xs font-semibold text-text-primary flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <span>Verification Verdict & Diagnostics</span>
            </h3>

            {!verificationResult ? (
              <div className="p-8 text-center rounded-xl bg-surface-2 border border-surface-3 text-text-muted text-xs space-y-2">
                <ShieldCheck className="w-8 h-8 mx-auto text-surface-3" />
                <p>Load or paste a credential token and click &apos;Verify Credential Locally&apos; to view cryptographic diagnostics.</p>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                {/* Decision Banner */}
                <div
                  className={`p-4 rounded-xl border flex items-center gap-3 ${
                    verificationResult.decision === 'PERMIT'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : verificationResult.decision === 'PERMIT_RESTRICTED'
                      ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                      : 'bg-red-950/40 border-red-500/40 text-red-300'
                  }`}
                >
                  {verificationResult.decision === 'PERMIT' ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                  ) : (
                    <ShieldAlert className="w-6 h-6 text-red-400 shrink-0" />
                  )}
                  <div>
                    <span className="font-mono font-bold text-sm block">
                      {verificationResult.resultCode}
                    </span>
                    <span className="text-[11px] opacity-90">
                      Decision: {verificationResult.decision}
                    </span>
                  </div>
                </div>

                {/* Subject and Role Information */}
                {verificationResult.claims && (
                  <div className="p-3.5 rounded-xl bg-surface-2 border border-surface-3 space-y-2">
                    <p className="text-[11px] text-text-muted font-mono uppercase tracking-wider">
                      Verified Identity Claims
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-text-muted block text-[10px]">Role:</span>
                        <span className="text-text-primary font-mono font-semibold">
                          {verificationResult.claims.role || 'N/A'}
                        </span>
                      </div>
                      <div>
                        <span className="text-text-muted block text-[10px]">Incident Scope:</span>
                        <span className="text-text-primary font-mono text-[11px] truncate block">
                          {verificationResult.claims.incident_scope || 'GLOBAL'}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-text-muted block text-[10px]">Subject ID:</span>
                        <span className="text-primary font-mono text-[11px]">
                          {verificationResult.claims.sub || 'N/A'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Diagnostics Log */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-text-muted font-mono uppercase tracking-wider block">
                    Execution Diagnostics
                  </span>
                  <div className="p-3 rounded-xl bg-canvas border border-surface-3 font-mono text-[11px] space-y-1 max-h-48 overflow-y-auto">
                    {verificationResult.diagnostics?.map((diag: string, i: number) => (
                      <div key={i} className="text-text-secondary flex items-start gap-1.5">
                        <span className="text-primary shrink-0">&gt;</span>
                        <span>{diag}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
