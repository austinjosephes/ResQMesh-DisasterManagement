import { PrismaClient } from './generated-client/index.js';
import * as jose from 'jose';
import * as crypto from 'crypto';
import { calculateRescuePriority } from './lib/priority-engine.ts';
import { formatKeralaAlertSms } from './lib/sms-adapter.ts';

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: 'file:D:/ResQLink/prisma/dev.db',
    },
  },
});

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(`resqmesh_salt_${password}`).digest('hex');
}

function computeAuditHash(
  previousHash: string,
  seq: number,
  actor: string,
  action: string,
  resource: string,
  timestamp: number,
  outcome: string,
  correlationId: string
): string {
  const canonical = `${previousHash}|${seq}|${actor}|${action}|${resource}|${timestamp}|${outcome}|${correlationId}`;
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

async function main() {
  console.log('Seeding ResQLink Kerala — Predict, Reach, Rescue database...');

  // Clean existing records in correct foreign key order
  await prisma.offlineSyncRecord.deleteMany().catch(() => {});
  await prisma.providerHealth.deleteMany().catch(() => {});
  await prisma.resource.deleteMany().catch(() => {});
  await prisma.shelter.deleteMany().catch(() => {});
  await prisma.incidentStatusHistory.deleteMany().catch(() => {});
  await prisma.incidentAssignment.deleteMany().catch(() => {});
  await prisma.teamMembership.deleteMany().catch(() => {});
  await prisma.rescueTeam.deleteMany().catch(() => {});
  await prisma.notificationAcknowledgement.deleteMany().catch(() => {});
  await prisma.notificationAttempt.deleteMany().catch(() => {});
  await prisma.notificationJob.deleteMany().catch(() => {});
  await prisma.hazardAlertVersion.deleteMany().catch(() => {});
  await prisma.hazardAlert.deleteMany().catch(() => {});
  await prisma.consent.deleteMany().catch(() => {});
  await prisma.emergencyContact.deleteMany().catch(() => {});
  await prisma.residentLocation.deleteMany().catch(() => {});
  await prisma.residentProfile.deleteMany().catch(() => {});
  await prisma.sOSRequest.deleteMany().catch(() => {});
  await prisma.incident.deleteMany().catch(() => {});
  await prisma.notification.deleteMany().catch(() => {});
  await prisma.syncReceipt.deleteMany().catch(() => {});
  await prisma.auditLog.deleteMany().catch(() => {});
  await prisma.offlineEvent.deleteMany().catch(() => {});
  await prisma.verificationRecord.deleteMany().catch(() => {});
  await prisma.adminApproval.deleteMany().catch(() => {});
  await prisma.revocation.deleteMany().catch(() => {});
  await prisma.signedStatusSnapshot.deleteMany().catch(() => {});
  await prisma.trustBundleRecord.deleteMany().catch(() => {});
  await prisma.credentialLifecycleHistory.deleteMany().catch(() => {});
  await prisma.credential.deleteMany().catch(() => {});
  await prisma.device.deleteMany().catch(() => {});
  await prisma.session.deleteMany().catch(() => {});
  await prisma.user.deleteMany().catch(() => {});

  // 1. Seed Core Kerala Administrative & Citizen Accounts
  const adminUser = await prisma.user.create({
    data: {
      email: 'admin@resqlink.kerala.gov.in',
      name: 'Dr. Sheela Varma IAS',
      phone: '+919447100001',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'ADMIN',
      district: 'Thiruvananthapuram',
      preferredLanguage: 'en',
    },
  });

  const officerUser = await prisma.user.create({
    data: {
      email: 'officer@resqlink.kerala.gov.in',
      name: 'Capt. Arun Kumar (KSDMA Duty Officer)',
      phone: '+919447100002',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'COORDINATOR',
      district: 'Thiruvananthapuram',
      preferredLanguage: 'en',
    },
  });

  const coordinatorUser = await prisma.user.create({
    data: {
      email: 'coordinator@resqlink.kerala.gov.in',
      name: 'M. P. Radhakrishnan (District Disaster Coordinator)',
      phone: '+919447100003',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'COORDINATOR',
      district: 'Wayanad',
      preferredLanguage: 'ml',
    },
  });

  const responderUser = await prisma.user.create({
    data: {
      email: 'responder@resqlink.kerala.gov.in',
      name: 'Inspector Rajesh Nair (NDRF Team Leader)',
      phone: '+919447100004',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'RESPONDER',
      district: 'Wayanad',
      preferredLanguage: 'en',
    },
  });

  const auditorUser = await prisma.user.create({
    data: {
      email: 'auditor@resqlink.kerala.gov.in',
      name: 'Suma Joseph (Independent Oversight Auditor)',
      phone: '+919447100005',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'AUDITOR',
      district: 'Ernakulam',
      preferredLanguage: 'en',
    },
  });

  const citizenUser = await prisma.user.create({
    data: {
      email: 'citizen@resqlink.kerala.gov.in',
      name: 'Anoop Chandran',
      phone: '+919847256789',
      phoneVerified: true,
      passwordHash: hashPassword('ResQLink@2026!'),
      role: 'CITIZEN',
      district: 'Wayanad',
      localBody: 'Meppadi Grama Panchayat',
      ward: 'Ward 10 (Chooralmala)',
      preferredLanguage: 'ml',
    },
  });

  // Backward compatible accounts for existing verifier/mesh unit tests
  await prisma.user.create({
    data: {
      email: 'admin@resqmesh.trust',
      name: 'Commander Sarah Vance',
      passwordHash: hashPassword('Admin2026!ResQ'),
      role: 'ADMIN',
    },
  });
  await prisma.user.create({
    data: {
      email: 'responder@resqmesh.trust',
      name: 'EMT Jordan Rivera',
      passwordHash: hashPassword('Responder2026!'),
      role: 'RESPONDER',
    },
  });
  await prisma.user.create({
    data: {
      email: 'verifier@resqmesh.trust',
      name: 'Inspector Blake Chen',
      passwordHash: hashPassword('Verifier2026!'),
      role: 'VERIFIER',
    },
  });
  await prisma.user.create({
    data: {
      email: 'citizen@resqmesh.trust',
      name: 'Alex Mercer',
      passwordHash: hashPassword('Citizen2026!'),
      role: 'CITIZEN',
    },
  });

  // 2. Seed Resident Profiles & Locations (Digital Twin Foundation)
  await prisma.residentProfile.create({
    data: {
      userId: citizenUser.id,
      householdSize: 4,
      hasElderly: true,
      hasInfants: false,
      hasDisabilities: true,
      requiresEvacuationAssist: true,
      medicalNeedsSummary: 'Elderly grandfather with wheelchair mobility restriction and hypertension medications.',
      evacuationPriorityNotes: 'Requires ground ambulance or 4x4 vehicle with stretcher support if road waterlogged.',
      registeredDistrict: 'Wayanad',
      blockPanchayat: 'Kalpetta Block',
      gramaPanchayat: 'Meppadi Grama Panchayat',
      registeredLocalBody: 'Meppadi Grama Panchayat',
      registeredWard: 'Ward 10 (Chooralmala)',
      registeredAddress: 'House 14/232, Near Chooralmala Bridge, Meppadi, Wayanad 673577',
      latitude: 11.5545,
      longitude: 76.1285,
    },
  });

  await prisma.residentLocation.create({
    data: {
      userId: citizenUser.id,
      label: 'Home (Registered Residence)',
      address: 'House 14/232, Near Chooralmala Bridge, Meppadi, Wayanad',
      district: 'Wayanad',
      localBody: 'Meppadi Grama Panchayat',
      ward: 'Ward 10',
      latitude: 11.5545,
      longitude: 76.1285,
      accuracyMeters: 4.8,
      locationSource: 'GPS',
      isVerified: true,
      isPrimary: true,
    },
  });

  await prisma.emergencyContact.create({
    data: {
      userId: citizenUser.id,
      name: 'Divya Anoop (Wife)',
      phone: '+919847112233',
      relationship: 'Family',
      priority: 1,
    },
  });

  await prisma.consent.create({
    data: {
      userId: citizenUser.id,
      consentType: 'LOCATION_PROCESSING',
      granted: true,
    },
  });

  await prisma.consent.create({
    data: {
      userId: citizenUser.id,
      consentType: 'EMERGENCY_SMS',
      granted: true,
    },
  });

  // Simulated residents across Kerala districts, blocks, and grama panchayats
  const additionalResidents = [
    {
      name: 'Santhosh Kumar',
      email: 'santhosh.meppadi@sample.resqlink.in',
      phone: '+919447200001',
      district: 'Wayanad',
      blockPanchayat: 'Kalpetta Block',
      gramaPanchayat: 'Meppadi Grama Panchayat',
      localBody: 'Meppadi Grama Panchayat',
      ward: 'Ward 11 (Mundakkai)',
      lat: 11.5510,
      lng: 76.1250,
      size: 5,
      elderly: true,
      infant: true,
      disabled: false,
      assist: true,
    },
    {
      name: 'Jincy Mathew',
      email: 'jincy.meppadi@sample.resqlink.in',
      phone: '+919447200011',
      district: 'Wayanad',
      blockPanchayat: 'Kalpetta Block',
      gramaPanchayat: 'Meppadi Grama Panchayat',
      localBody: 'Meppadi Grama Panchayat',
      ward: 'Ward 8 (Meppadi Town)',
      lat: 11.5580,
      lng: 76.1290,
      size: 3,
      elderly: false,
      infant: false,
      disabled: false,
      assist: false,
    },
    {
      name: 'Shaji Vythiri',
      email: 'shaji.vythiri@sample.resqlink.in',
      phone: '+919847200012',
      district: 'Wayanad',
      blockPanchayat: 'Kalpetta Block',
      gramaPanchayat: 'Vythiri Grama Panchayat',
      localBody: 'Vythiri Grama Panchayat',
      ward: 'Ward 4 (Lakkidi Ghat)',
      lat: 11.5520,
      lng: 76.0420,
      size: 4,
      elderly: true,
      infant: false,
      disabled: false,
      assist: true,
    },
    {
      name: 'Ramesh Thirunelly',
      email: 'ramesh.thirunelly@sample.resqlink.in',
      phone: '+919400200013',
      district: 'Wayanad',
      blockPanchayat: 'Mananthavady Block',
      gramaPanchayat: 'Thirunelly Grama Panchayat',
      localBody: 'Thirunelly Grama Panchayat',
      ward: 'Ward 6 (Thirunelly Temple Road)',
      lat: 11.9020,
      lng: 75.9980,
      size: 4,
      elderly: false,
      infant: true,
      disabled: false,
      assist: false,
    },
    {
      name: 'Mariamma Mathew',
      email: 'mariamma.aluva@sample.resqlink.in',
      phone: '+919447200002',
      district: 'Ernakulam',
      blockPanchayat: 'Aluva Block',
      gramaPanchayat: 'Chengamanad Grama Panchayat',
      localBody: 'Chengamanad Grama Panchayat',
      ward: 'Ward 4 (Manappuram)',
      lat: 10.1520,
      lng: 76.3750,
      size: 3,
      elderly: true,
      infant: false,
      disabled: true,
      assist: true,
    },
    {
      name: 'Jithin Varghese',
      email: 'jithin.paravur@sample.resqlink.in',
      phone: '+919447200003',
      district: 'Ernakulam',
      blockPanchayat: 'Paravur Block',
      gramaPanchayat: 'Chendamangalam Grama Panchayat',
      localBody: 'Chendamangalam Grama Panchayat',
      ward: 'Ward 7 (Paliyam)',
      lat: 10.1680,
      lng: 76.2420,
      size: 4,
      elderly: false,
      infant: true,
      disabled: false,
      assist: false,
    },
    {
      name: 'George K. Joseph',
      email: 'george.munnar@sample.resqlink.in',
      phone: '+919447200004',
      district: 'Idukki',
      blockPanchayat: 'Devikulam Block',
      gramaPanchayat: 'Munnar Grama Panchayat',
      localBody: 'Munnar Grama Panchayat',
      ward: 'Ward 2 (Ikka Nagar)',
      lat: 10.0889,
      lng: 77.0595,
      size: 2,
      elderly: true,
      infant: false,
      disabled: false,
      assist: false,
    },
    {
      name: 'K. Sukumaran',
      email: 'sukumaran.kuttanad@sample.resqlink.in',
      phone: '+919447200005',
      district: 'Alappuzha',
      blockPanchayat: 'Champakulam Block (Kuttanad)',
      gramaPanchayat: 'Nedumudi Grama Panchayat',
      localBody: 'Nedumudi Grama Panchayat',
      ward: 'Ward 3 (Nedumudi Jetty)',
      lat: 9.4420,
      lng: 76.4150,
      size: 6,
      elderly: true,
      infant: false,
      disabled: true,
      assist: true,
    },
    {
      name: 'Reji Seethathode',
      email: 'reji.seethathode@sample.resqlink.in',
      phone: '+919447200051',
      district: 'Pathanamthitta',
      blockPanchayat: 'Ranni Block',
      gramaPanchayat: 'Seethathode Grama Panchayat',
      localBody: 'Seethathode Grama Panchayat',
      ward: 'Ward 5 (Moozhiyar Road)',
      lat: 9.3350,
      lng: 77.0120,
      size: 4,
      elderly: false,
      infant: false,
      disabled: false,
      assist: false,
    },
    {
      name: 'Sreejith Menon',
      email: 'sreejith.tvm@sample.resqlink.in',
      phone: '+919447200007',
      district: 'Thiruvananthapuram',
      blockPanchayat: 'Nedumangad Block',
      gramaPanchayat: 'Vithura Grama Panchayat',
      localBody: 'Vithura Grama Panchayat',
      ward: 'Ward 4 (Ponmudi Road)',
      lat: 8.6680,
      lng: 77.1020,
      size: 3,
      elderly: false,
      infant: false,
      disabled: false,
      assist: false,
    },
  ];

  for (const r of additionalResidents) {
    const user = await prisma.user.create({
      data: {
        email: r.email,
        name: r.name,
        phone: r.phone,
        phoneVerified: true,
        passwordHash: hashPassword('SampleResident2026!'),
        role: 'CITIZEN',
        district: r.district,
        localBody: r.localBody,
        ward: r.ward,
      },
    });

    await prisma.residentProfile.create({
      data: {
        userId: user.id,
        householdSize: r.size,
        hasElderly: r.elderly,
        hasInfants: r.infant,
        hasDisabilities: r.disabled,
        requiresEvacuationAssist: r.assist,
        registeredDistrict: r.district,
        blockPanchayat: r.blockPanchayat,
        gramaPanchayat: r.gramaPanchayat,
        registeredLocalBody: r.localBody,
        registeredWard: r.ward,
        registeredAddress: `${r.ward}, ${r.localBody}, ${r.district}`,
        latitude: r.lat,
        longitude: r.lng,
      },
    });

    await prisma.residentLocation.create({
      data: {
        userId: user.id,
        label: 'Home',
        address: `${r.ward}, ${r.localBody}, ${r.district}`,
        district: r.district,
        localBody: r.localBody,
        ward: r.ward,
        latitude: r.lat,
        longitude: r.lng,
        locationSource: 'MANUAL_PIN',
        isVerified: true,
        isPrimary: true,
      },
    });
  }

  // 3. Official Hazard Alert Zones (Geospatial Polygons in Kerala)
  // Polygon 1: Wayanad Meppadi Debris Flow Zone
  const wayanadPolygonGeoJson = JSON.stringify({
    type: 'Polygon',
    coordinates: [
      [
        [76.110, 11.530],
        [76.155, 11.530],
        [76.160, 11.580],
        [76.105, 11.575],
        [76.110, 11.530],
      ],
    ],
  });

  const wayanadAlert = await prisma.hazardAlert.create({
    data: {
      externalSourceId: 'KSDMA-WYND-2026-RED-001',
      source: 'KSDMA_IMD_JOINT',
      hazardType: 'LANDSLIDE',
      severity: 'EMERGENCY',
      headline: 'RED ALERT: Severe Landslide & Debris Flow Risk in Meppadi-Chooralmala Hill Tracts',
      description: 'Extremely heavy rainfall exceeding 240mm in 24 hours recorded. Critical slope instability detected along Chooralmala, Mundakkai, and Attamala hillsides. Flash torrents possible.',
      instruction: 'Immediate evacuation ordered for all low-lying riverbank houses and steep hillside dwellings. Move immediately to St. Joseph School relief camp. Avoid all vehicular travel on Meppadi ghat roads.',
      headlineMl: 'റെഡ് അലർട്ട്: മേപ്പാടി-ചൂരൽമല മേഖലയിൽ അതിതീവ്ര ഉരുൾപൊട്ടൽ സാധ്യത',
      descriptionMl: 'കഴിഞ്ഞ 24 മണിക്കൂറിൽ 240 മില്ലിമീറ്ററിലധികം മഴ രേഖപ്പെടുത്തി. മലയോര മേഖലകളിൽ മണ്ണിടിച്ചിൽ സാധ്യത അതീവ ഗുരുതരം.',
      instructionMl: 'നദീതീരങ്ങളിലും ചരിവുകളിലും താമസിക്കുന്നവർ ഉടനടി സുരക്ഷിത ദുരിതാശ്വാസ ക്യാമ്പുകളിലേക്ക് മാറുക. ചുരം റോഡുകളിലൂടെയുള്ള യാത്ര ഒഴിവാക്കുക.',
      affectedDistrict: 'Wayanad',
      polygonGeoJson: wayanadPolygonGeoJson,
      effectiveAt: new Date(Date.now() - 3600 * 1000 * 4),
      expiresAt: new Date(Date.now() + 3600 * 1000 * 20),
      status: 'ACTIVE',
      version: 1,
    },
  });

  // Polygon 2: Ernakulam Periyar River Basin Flood Inundation
  const periyarPolygonGeoJson = JSON.stringify({
    type: 'Polygon',
    coordinates: [
      [
        [76.310, 10.080],
        [76.390, 10.085],
        [76.400, 10.150],
        [76.320, 10.145],
        [76.310, 10.080],
      ],
    ],
  });

  const ernakulamAlert = await prisma.hazardAlert.create({
    data: {
      externalSourceId: 'CWC-ERKM-2026-ORANGE-002',
      source: 'CENTRAL_WATER_COMMISSION',
      hazardType: 'FLOOD',
      severity: 'WARNING',
      headline: 'ORANGE WARNING: Periyar River Level Breaches Danger Mark at Aluva Manappuram',
      description: 'Discharge from Idamalayar and Bhothathankettu shutters has elevated Periyar river stage by 1.8m above danger contour. Kalamassery lowlands and Aluva markets at risk of backwater inundation.',
      instruction: 'Residents in ground floor units along Periyar banks must secure electrical mains and prepare emergency go-bags. Relief camp opened at UC College Aluva.',
      headlineMl: 'ഓറഞ്ച് അലർട്ട്: ആലുവ മണപ്പുറത്ത് പെരിയാർ ജലനിരപ്പ് അപകടനില കടന്നു',
      descriptionMl: 'ഇടമലയാർ, ഭൂതത്താൻകെട്ട് ഷട്ടറുകൾ തുറന്നതോടെ പെരിയാറിലെ ജലനിരപ്പ് ക്രമാതീതമായി ഉയർന്നു. താഴ്ന്ന പ്രദേശങ്ങൾ വെള്ളപ്പൊക്ക ഭീഷണിയിൽ.',
      instructionMl: 'തീരപ്രദേശങ്ങളിലുള്ളവർ വൈദ്യുതി ഉപകരണങ്ങൾ സുരക്ഷിതമാക്കുക. യു.സി കോളേജ് ക്യാമ്പിലേക്ക് ആവശ്യമെങ്കിൽ മാറുക.',
      affectedDistrict: 'Ernakulam',
      polygonGeoJson: periyarPolygonGeoJson,
      effectiveAt: new Date(Date.now() - 3600 * 1000 * 6),
      expiresAt: new Date(Date.now() + 3600 * 1000 * 18),
      status: 'ACTIVE',
      version: 1,
    },
  });

  // Polygon 3: Alappuzha Kuttanad Inundation Alert
  const kuttanadPolygonGeoJson = JSON.stringify({
    type: 'Polygon',
    coordinates: [
      [
        [76.300, 9.420],
        [76.450, 9.425],
        [76.460, 9.550],
        [76.290, 9.540],
        [76.300, 9.420],
      ],
    ],
  });

  await prisma.hazardAlert.create({
    data: {
      externalSourceId: 'KSDMA-ALPY-2026-AMBER-003',
      source: 'KSDMA_IRRIGATION',
      hazardType: 'FLOOD',
      severity: 'WATCH',
      headline: 'YELLOW WATCH: Waterlogging and High Tide Ingress in Kuttanad Lowlands',
      description: 'Pamba and Achankovil runoff draining slowly due to high sea tides at Thottappally spillway. Water levels in padasekharams rising steadily.',
      instruction: 'Keep country boats ready. Relocate livestock to higher bunds. District control room operating 24/7 boat ambulance.',
      affectedDistrict: 'Alappuzha',
      polygonGeoJson: kuttanadPolygonGeoJson,
      effectiveAt: new Date(Date.now() - 3600 * 1000 * 10),
      expiresAt: new Date(Date.now() + 3600 * 1000 * 30),
      status: 'ACTIVE',
      version: 1,
    },
  });

  // Record Alert Version history
  await prisma.hazardAlertVersion.create({
    data: {
      alertId: wayanadAlert.id,
      versionNumber: 1,
      changeSummary: 'Initial emergency red warning issued based on IMD radar and automated rain gauge network.',
      polygonGeoJson: wayanadPolygonGeoJson,
      severity: 'EMERGENCY',
    },
  });

  // 4. Adaptive Notification Jobs & Delivery Pipeline
  const wayanadJob = await prisma.notificationJob.create({
    data: {
      alertId: wayanadAlert.id,
      targetDistrict: 'Wayanad',
      channel: 'SMS',
      totalMatched: 450,
      successfulCount: 418,
      failedCount: 14,
      pendingCount: 18,
      status: 'PROCESSING',
    },
  });

  const smsTemplate = formatKeralaAlertSms({
    area: 'Meppadi-Chooralmala, Wayanad',
    hazardType: 'Landslide',
    authority: 'KSDMA & IMD Kerala',
    issuedTime: '10:30 PM IST',
    expiryTime: 'Tomorrow 06:00 PM IST',
    language: 'en',
  });

  // Sample notification attempts showing realistic delivery telemetry
  await prisma.notificationAttempt.create({
    data: {
      jobId: wayanadJob.id,
      recipientPhone: citizenUser.phone || '+919847256789',
      recipientName: citizenUser.name,
      messageBody: smsTemplate.body,
      dltTemplateId: smsTemplate.dltTemplateId,
      providerName: 'AIRTEL_KERALA_DLT_GATEWAY',
      providerMsgId: 'DLT_KL_WYND_774102',
      status: 'DELIVERED',
      deliveredAt: new Date(Date.now() - 3600 * 1000 * 2),
      retryCount: 0,
    },
  });

  await prisma.notificationAttempt.create({
    data: {
      jobId: wayanadJob.id,
      recipientPhone: '+919447200001',
      recipientName: 'Santhosh Kumar',
      messageBody: smsTemplate.body,
      dltTemplateId: smsTemplate.dltTemplateId,
      providerName: 'BSNL_KERALA_CIRCLE_SMS',
      providerMsgId: 'DLT_KL_BSNL_99182',
      status: 'SUBMITTED',
      retryCount: 0,
    },
  });

  await prisma.notificationAttempt.create({
    data: {
      jobId: wayanadJob.id,
      recipientPhone: '+919447200008',
      recipientName: 'V. Raman (Mundakkai)',
      messageBody: smsTemplate.body,
      dltTemplateId: smsTemplate.dltTemplateId,
      providerName: 'JIO_KERALA_GATEWAY',
      status: 'FAILED',
      lastError: 'RADIO_TOWER_DOWN_MEPPADI_SOUTH_CELL_8',
      retryCount: 2,
    },
  });

  await prisma.notificationAcknowledgement.create({
    data: {
      jobId: wayanadJob.id,
      recipientPhone: citizenUser.phone || '+919847256789',
      ackMethod: 'WEB_TAP',
      acknowledgedAt: new Date(Date.now() - 3600 * 1000 * 1.5),
    },
  });

  // 5. Rescue Teams (Official Kerala & National Disaster Responders)
  const ndrfTeam = await prisma.rescueTeam.create({
    data: {
      teamCode: 'NDRF-04-BN-ALPHA',
      name: '04 Battalion NDRF Special Flood & Collapsed Structure Rescue Unit',
      agency: 'NDRF',
      baseDistrict: 'Wayanad',
      contactPhone: '+919447000101',
      captainName: 'Inspector Rajesh Nair',
      memberCount: 18,
      boatCapacity: 4,
      hasMedicalKit: true,
      status: 'DISPATCHED',
      currentLatitude: 11.5560,
      currentLongitude: 76.1290,
    },
  });

  const kfrsTeam = await prisma.rescueTeam.create({
    data: {
      teamCode: 'KFRS-WYND-STF-1',
      name: 'Kerala Fire & Rescue Services Wayanad High Altitude Search & Rescue',
      agency: 'KERALA_FIRE_RESCUE',
      baseDistrict: 'Wayanad',
      contactPhone: '+919447000102',
      captainName: 'Station Officer Biju Narayanan',
      memberCount: 12,
      boatCapacity: 2,
      hasMedicalKit: true,
      status: 'ON_SCENE',
      currentLatitude: 11.5540,
      currentLongitude: 76.1280,
    },
  });

  const fishermenTeam = await prisma.rescueTeam.create({
    data: {
      teamCode: 'KER-COAST-VOL-ALUVA',
      name: 'Kerala Coastal Fishermen Volunteer Rescue Flotilla ("Kerala\'s Own Army")',
      agency: 'FISHERMEN_VOLUNTEERS',
      baseDistrict: 'Ernakulam',
      contactPhone: '+919447000103',
      captainName: 'Johnson Antony (Chellanam Captain)',
      memberCount: 24,
      boatCapacity: 8,
      hasMedicalKit: true,
      status: 'AVAILABLE',
      currentLatitude: 10.1080,
      currentLongitude: 76.3510,
    },
  });

  const coastGuardTeam = await prisma.rescueTeam.create({
    data: {
      teamCode: 'ICG-KOCHI-AIR-ENCLAVE',
      name: 'Indian Coast Guard District HQ 4 Kochi Helo Evacuation Flight',
      agency: 'COAST_GUARD',
      baseDistrict: 'Ernakulam',
      contactPhone: '+919447000104',
      captainName: 'Commandant P. Sen',
      memberCount: 6,
      boatCapacity: 0,
      hasMedicalKit: true,
      status: 'AVAILABLE',
      currentLatitude: 9.9540,
      currentLongitude: 76.2730,
    },
  });

  // Link responder user to team
  await prisma.teamMembership.create({
    data: {
      teamId: ndrfTeam.id,
      userId: responderUser.id,
      roleInTeam: 'LEADER',
    },
  });

  // 6. Incidents & SOS Requests (Demonstrating Rescue Priority Engine)
  const incident1 = await prisma.incident.create({
    data: {
      incidentCode: 'INC-2026-WYND-001',
      title: 'Chooralmala Bridge Slope Breach & Family Trapped in Attic',
      description: 'Major mudflow engulfed the ground floor of houses adjacent to Chooralmala stream. 4 family members including an elderly mobility-impaired grandfather trapped on upper floor.',
      category: 'LANDSLIDE',
      severity: 'CATASTROPHIC',
      status: 'ACTIVE',
      district: 'Wayanad',
      sector: 'Meppadi Sector North',
      latitude: 11.5545,
      longitude: 76.1285,
      radiusMeters: 300,
      reportedBy: citizenUser.name,
      verifiedBy: coordinatorUser.name,
    },
  });

  // Calculate transparent priority score for SOS 1
  const priorityResult1 = calculateRescuePriority({
    category: 'LANDSLIDE',
    peopleCount: 4,
    hasInjuries: true,
    immediateDanger: true,
    locationConfidence: 0.95,
    accessibilityNeeds: 'Elderly bedridden patient with oxygen cylinder and wheelchair requirement',
    reportedAt: new Date(Date.now() - 45 * 60 * 1000),
  });

  await prisma.sOSRequest.create({
    data: {
      trackingNumber: 'SOS-KL-2026-77891',
      userId: citizenUser.id,
      category: 'LANDSLIDE',
      description: 'Debris flowing around our building foundation. Water and silt entering first floor. Grandfather cannot walk and oxygen concentrator power is out.',
      peopleCount: 4,
      hasInjuries: true,
      immediateDanger: true,
      latitude: 11.5545,
      longitude: 76.1285,
      address: 'House 14/232, Near Chooralmala Bridge, Meppadi, Wayanad',
      district: 'Wayanad',
      accessibilityNeeds: 'Elderly bedridden patient with oxygen cylinder and wheelchair requirement',
      contactPreference: 'SMS',
      locationSource: 'DEVICE_GPS',
      locationConfidence: 0.95,
      priorityScore: priorityResult1.totalScore,
      priorityCategory: priorityResult1.priorityCategory,
      scoreBreakdown: JSON.stringify(priorityResult1.breakdown),
      verificationStatus: 'VERIFIED',
      status: 'ASSIGNED',
      assignedTeamId: ndrfTeam.id,
      assignedTeamName: ndrfTeam.name,
      incidentId: incident1.id,
    },
  });

  // Assign Team to Incident 1
  await prisma.incidentAssignment.create({
    data: {
      incidentId: incident1.id,
      teamId: ndrfTeam.id,
      assignedBy: coordinatorUser.name,
      status: 'EN_ROUTE',
      fieldNotes: 'NDRF team en route via 4x4 rescue truck carrying stretcher and portable battery power pack.',
    },
  });

  // SOS 2: Aluva riverside flood request
  const priorityResult2 = calculateRescuePriority({
    category: 'FLOOD',
    peopleCount: 3,
    hasInjuries: false,
    immediateDanger: true,
    locationConfidence: 0.90,
    accessibilityNeeds: 'Infant child 6 months old',
    reportedAt: new Date(Date.now() - 75 * 60 * 1000),
  });

  const incident2 = await prisma.incident.create({
    data: {
      incidentCode: 'INC-2026-ERKM-002',
      title: 'Aluva Manappuram Riverside Residential Inundation',
      description: 'Periyar river spill overtopping local road. 3 residents stranded in house with water level at 4 feet.',
      category: 'FLOOD',
      severity: 'SEVERE',
      status: 'ACTIVE',
      district: 'Ernakulam',
      sector: 'Aluva Urban East',
      latitude: 10.1085,
      longitude: 76.3520,
      radiusMeters: 250,
      reportedBy: 'Mariamma Mathew',
    },
  });

  await prisma.sOSRequest.create({
    data: {
      trackingNumber: 'SOS-KL-2026-88120',
      category: 'FLOOD',
      description: 'Water has reached 4 feet height on ground floor. We are on the balcony with 6-month-old infant. Inflow is rising.',
      peopleCount: 3,
      hasInjuries: false,
      immediateDanger: true,
      latitude: 10.1085,
      longitude: 76.3520,
      address: 'Riverside Road, Near Aluva Shiva Temple, Aluva',
      district: 'Ernakulam',
      accessibilityNeeds: 'Infant child 6 months old, needs dry formula and warm blankets',
      contactPreference: 'SMS',
      locationSource: 'DEVICE_GPS',
      locationConfidence: 0.90,
      priorityScore: priorityResult2.totalScore,
      priorityCategory: priorityResult2.priorityCategory,
      scoreBreakdown: JSON.stringify(priorityResult2.breakdown),
      verificationStatus: 'VERIFIED',
      status: 'ASSIGNED',
      assignedTeamId: fishermenTeam.id,
      assignedTeamName: fishermenTeam.name,
      incidentId: incident2.id,
    },
  });

  await prisma.incidentAssignment.create({
    data: {
      incidentId: incident2.id,
      teamId: fishermenTeam.id,
      assignedBy: officerUser.name,
      status: 'ON_SCENE',
      fieldNotes: 'Fishermen rescue boat navigating submerged street. Visual contact established with occupants on balcony.',
    },
  });

  // SOS 3: Low confidence report requiring verification
  const priorityResult3 = calculateRescuePriority({
    category: 'FLOOD',
    peopleCount: 2,
    hasInjuries: false,
    immediateDanger: false,
    locationConfidence: 0.32, // Low confidence cell tower
    accessibilityNeeds: null,
    reportedAt: new Date(Date.now() - 20 * 60 * 1000),
  });

  await prisma.sOSRequest.create({
    data: {
      trackingNumber: 'SOS-KL-2026-99304',
      category: 'FLOOD',
      description: 'Water entering compound wall. Cell signal very weak.',
      peopleCount: 2,
      hasInjuries: false,
      immediateDanger: false,
      latitude: 11.2320,
      longitude: 75.8410,
      address: 'Approximate area near Chaliyar riverbank, Feroke',
      district: 'Kozhikode',
      locationSource: 'CELL_TRIANGULATION',
      locationConfidence: 0.32,
      priorityScore: priorityResult3.totalScore,
      priorityCategory: priorityResult3.priorityCategory,
      scoreBreakdown: JSON.stringify(priorityResult3.breakdown),
      verificationStatus: 'AWAITING_VERIFICATION',
      status: 'AWAITING_VERIFICATION',
    },
  });

  // 7. Relief Shelters across Kerala Districts
  const shelters = [
    {
      code: 'SHELTER-WYND-01',
      name: 'St. Joseph Higher Secondary School Relief Camp',
      district: 'Wayanad',
      localBody: 'Meppadi Grama Panchayat',
      address: 'Meppadi Main Road, Wayanad 673577',
      lat: 11.5580,
      lng: 76.1310,
      totalCapacity: 500,
      currentOccupancy: 184,
      power: true,
      medical: true,
      water: true,
      foodDays: 6,
      inCharge: 'K. Balakrishnan (Tahsildar)',
      phone: '+919447000201',
      status: 'OPEN',
    },
    {
      code: 'SHELTER-ERKM-01',
      name: 'Union Christian (UC) College Relief Center',
      district: 'Ernakulam',
      localBody: 'Aluva Municipality',
      address: 'UC College Post, Aluva, Ernakulam 683102',
      lat: 10.1250,
      lng: 76.3450,
      totalCapacity: 800,
      currentOccupancy: 310,
      power: true,
      medical: true,
      water: true,
      foodDays: 7,
      inCharge: 'Prof. Mary George & Revenue Inspector Roy',
      phone: '+919447000202',
      status: 'OPEN',
    },
    {
      code: 'SHELTER-ALPY-01',
      name: 'SDV High School & Relief Camp',
      district: 'Alappuzha',
      localBody: 'Alappuzha Municipality',
      address: 'Near Beach Road, Alappuzha 688001',
      lat: 9.4920,
      lng: 76.3260,
      totalCapacity: 600,
      currentOccupancy: 95,
      power: true,
      medical: true,
      water: true,
      foodDays: 5,
      inCharge: 'P. Raveendran (Camp Officer)',
      phone: '+919447000203',
      status: 'OPEN',
    },
    {
      code: 'SHELTER-IDKK-01',
      name: 'Government Model Higher Secondary School Cheruthoni',
      district: 'Idukki',
      localBody: 'Cheruthoni',
      address: 'Cheruthoni Dam Road, Idukki 685602',
      lat: 9.8520,
      lng: 76.9780,
      totalCapacity: 350,
      currentOccupancy: 42,
      power: true,
      medical: true,
      water: true,
      foodDays: 4,
      inCharge: 'James Sebastian (Deputy Collector)',
      phone: '+919447000204',
      status: 'OPEN',
    },
  ];

  for (const s of shelters) {
    await prisma.shelter.create({
      data: {
        code: s.code,
        name: s.name,
        district: s.district,
        localBody: s.localBody,
        address: s.address,
        latitude: s.lat,
        longitude: s.lng,
        totalCapacity: s.totalCapacity,
        currentOccupacy: s.currentOccupancy,
        hasPowerBackup: s.power,
        hasMedicalPost: s.medical,
        hasDrinkingWater: s.water,
        foodStockDays: s.foodDays,
        inChargeName: s.inCharge,
        inChargePhone: s.phone,
        status: s.status,
      },
    });
  }

  // 8. Emergency Resources
  const resources = [
    { type: 'INFLATABLE_BOAT', name: 'Zodiac 10-Person Motorized Rescue Craft', district: 'Wayanad', qty: 6, avail: 2 },
    { type: 'INFLATABLE_BOAT', name: 'FRP High-Draft Rescue Boat', district: 'Ernakulam', qty: 15, avail: 9 },
    { type: 'DRONE', name: 'Thermal Imaging Night-Search Quadcopter', district: 'Wayanad', qty: 4, avail: 3 },
    { type: 'SATELLITE_PHONE', name: 'ISRO BGAN Satellite Terminal Unit', district: 'Wayanad', qty: 3, avail: 2 },
    { type: 'WATER_PURIFIER', name: 'High-Volume Mobile Dewatering & RO Plant', district: 'Alappuzha', qty: 8, avail: 5 },
  ];

  for (const res of resources) {
    await prisma.resource.create({
      data: {
        resourceType: res.type,
        name: res.name,
        district: res.district,
        quantity: res.qty,
        available: res.avail,
      },
    });
  }

  // 9. Provider Health Telemetry
  await prisma.providerHealth.create({
    data: {
      providerKey: 'IMD_API_THIRUVANANTHAPURAM',
      name: 'India Meteorological Department (IMD) Kerala Radar Feed',
      type: 'WEATHER_FEED',
      status: 'OPERATIONAL',
      latencyMs: 38,
      successRate24h: 99.8,
      details: 'Doppler Weather Radar Thiruvananthapuram & Kochi operational. 15-min scan interval.',
    },
  });

  await prisma.providerHealth.create({
    data: {
      providerKey: 'KSDMA_CAP_FEED',
      name: 'Kerala State Disaster Management Authority CAP Alert Engine',
      type: 'HAZARD_POLYGON',
      status: 'OPERATIONAL',
      latencyMs: 52,
      successRate24h: 99.4,
      details: 'OASIS CAP v1.2 compliant geo-hazard XML broadcast receiver active.',
    },
  });

  await prisma.providerHealth.create({
    data: {
      providerKey: 'CWC_RIVER_GAUGE',
      name: 'Central Water Commission (CWC) Telemetric River Gauging Network',
      type: 'HAZARD_POLYGON',
      status: 'OPERATIONAL',
      latencyMs: 74,
      successRate24h: 98.9,
      details: 'Periyar, Pamba, Chaliyar, and Bharathapuzha automated river stage telemetry online.',
    },
  });

  await prisma.providerHealth.create({
    data: {
      providerKey: 'SMS_GATEWAY_AIRTEL_DLT',
      name: 'Indian Telecom DLT High-Priority Emergency SMS Pipeline',
      type: 'TELECOM_GATEWAY',
      status: 'SIMULATED',
      latencyMs: 22,
      successRate24h: 96.5,
      details: 'Operating in Development Simulated Adapter mode. Compliant with TRAI DLT headers.',
    },
  });

  // 10. Tamper-Evident SHA-256 Audit Log Chain
  let prevHash = '0000000000000000000000000000000000000000000000000000000000000000';
  const auditEntries = [
    {
      seq: 1,
      actor: adminUser.email,
      action: 'SYSTEM_GENESIS_INITIALIZE',
      resource: 'ResQLink_Kerala_Core',
      outcome: 'SUCCESS',
      correlationId: 'GENESIS-2026-0001',
    },
    {
      seq: 2,
      actor: officerUser.email,
      action: 'INGEST_HAZARD_POLYGON',
      resource: wayanadAlert.id,
      outcome: 'SUCCESS',
      correlationId: 'ALERT-INGEST-WYND-01',
    },
    {
      seq: 3,
      actor: coordinatorUser.email,
      action: 'ASSIGN_RESCUE_TEAM',
      resource: incident1.id,
      outcome: 'SUCCESS',
      correlationId: 'ASSIGN-NDRF-WYND-01',
    },
    {
      seq: 4,
      actor: citizenUser.email,
      action: 'SUBMIT_SOS_REQUEST',
      resource: 'SOS-KL-2026-77891',
      outcome: 'SUCCESS',
      correlationId: 'SOS-SUBMIT-77891',
    },
  ];

  for (const entry of auditEntries) {
    const timestamp = Math.floor(Date.now() / 1000) - (10 - entry.seq) * 60;
    const currentHash = computeAuditHash(
      prevHash,
      entry.seq,
      entry.actor,
      entry.action,
      entry.resource,
      timestamp,
      entry.outcome,
      entry.correlationId
    );

    await prisma.auditLog.create({
      data: {
        sequence: entry.seq,
        actor: entry.actor,
        action: entry.action,
        resource: entry.resource,
        timestamp,
        outcome: entry.outcome,
        correlationId: entry.correlationId,
        previousHash: prevHash,
        currentHash,
      },
    });

    prevHash = currentHash;
  }

  // 11. Retain legacy cryptographic keys & credentials for verifier unit test suite
  const rootKey = await jose.generateKeyPair('ES256', { extractable: true });
  const rootJwk = await jose.exportJWK(rootKey.publicKey);
  rootJwk.kid = 'kerala-sdma-root-2026';
  const rootThumbprint = await jose.calculateJwkThumbprint(rootJwk);

  const bundle = {
    bundleVersion: 1,
    rootAuthorities: [
      {
        authorityId: 'kerala-sdma-root-2026',
        publicKeyJwk: rootJwk,
        validFrom: Math.floor(Date.now() / 1000) - 3600,
        validUntil: Math.floor(Date.now() / 1000) + 86400 * 365,
        status: 'ACTIVE',
      },
    ],
  };

  const bundleJwt = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(bundle)))
    .setProtectedHeader({ alg: 'ES256', kid: 'kerala-sdma-root-2026' })
    .sign(rootKey.privateKey);

  await prisma.trustBundleRecord.create({
    data: {
      version: 1,
      issuedAt: Math.floor(Date.now() / 1000),
      expiresAt: Math.floor(Date.now() / 1000) + 86400 * 30,
      rootAuthorityId: 'kerala-sdma-root-2026',
      bundleJson: JSON.stringify(bundle),
      signature: bundleJwt,
    },
  });

  const snapshot = {
    version: 1,
    issuedAt: Math.floor(Date.now() / 1000),
    issuerKid: 'kerala-sdma-root-2026',
    revocations: [],
    suspensions: [],
  };

  const snapshotJwt = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(snapshot)))
    .setProtectedHeader({ alg: 'ES256', kid: 'kerala-sdma-root-2026' })
    .sign(rootKey.privateKey);

  await prisma.signedStatusSnapshot.create({
    data: {
      version: 1,
      issuedAt: Math.floor(Date.now() / 1000),
      issuerKid: 'kerala-sdma-root-2026',
      snapshotJson: JSON.stringify(snapshot),
      signature: snapshotJwt,
    },
  });

  console.log('✅ ResQLink Kerala database seed completed successfully!');
  console.log('--- DEMO ACCOUNTS READY ---');
  console.log('System Admin:        admin@resqlink.kerala.gov.in / ResQLink@2026!');
  console.log('Disaster Officer:    officer@resqlink.kerala.gov.in / ResQLink@2026!');
  console.log('District Coord:      coordinator@resqlink.kerala.gov.in / ResQLink@2026!');
  console.log('Rescue Operator:     responder@resqlink.kerala.gov.in / ResQLink@2026!');
  console.log('Auditor:             auditor@resqlink.kerala.gov.in / ResQLink@2026!');
  console.log('Resident:            citizen@resqlink.kerala.gov.in / ResQLink@2026!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
