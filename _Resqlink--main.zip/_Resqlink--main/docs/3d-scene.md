# ResQMesh Trust 3D Scene Architecture & Performance Tiers

## 1. Overview
The landing page features an interactive, scroll-linked WebGL scene rendered via Three.js and React Three Fiber (`@react-three/fiber`). It visually illustrates the catastrophe of connectivity loss and how device-bound cryptographic trust continues to function locally.

## 2. Five Storytelling Chapters
1. **Scene 1: The Severed Network (Scroll 0.00 - 0.18):**
   - Instanced 3D wireframe globe with glowing nodes and interconnecting arcs.
   - Central backbone links snap and dissolve, leaving an isolated island cluster glowing in cyan.
   - Core message: *"Trust must survive the loss of connectivity."*
2. **Scene 2: The Credential In Space (Scroll 0.18 - 0.38):**
   - The isolated node expands into a holographic card representation showing the cryptographic claims, issuer signature, and device binding thumbprint.
3. **Scene 3: Offline Verification Exchange (Scroll 0.38 - 0.62):**
   - Verifier and Responder devices perform local challenge-response.
   - Clear visual diagnostics indicate separate checks (Signature, Expiry, Role, Stale Status).
4. **Scene 4: Authority & Command (Scroll 0.62 - 0.82):**
   - The view expands to showcase administrative fleet management, audit chain integrity, and synchronization review queues.
5. **Scene 5: Call to Resilience (Scroll 0.82 - 1.00):**
   - Minimalist grid horizon with direct entry points into Verifier, Responder, and Admin Command portals.

## 3. Performance Tiers & Resource Cleanup
- **High Tier:** Full 3D globe with 600 instanced nodes, bloom pass, 60fps target.
- **Medium Tier:** 250 nodes, simple point lights, postprocessing disabled.
- **Low / Reduced Motion:** Static SVG/Canvas poster illustration with zero GPU overhead.
- **Resource Disposal:** All geometries, textures, and render targets are strictly disposed on route unmount.
