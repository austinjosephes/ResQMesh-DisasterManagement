# ResQMesh Trust API Reference

## 1. Authentication & Sessions
- `POST /api/auth/login` — Authenticate admin or responder session (Argon2id password check, sets HttpOnly SameSite cookie).
- `POST /api/auth/logout` — Invalidate server-side session and clear cookie.
- `GET /api/auth/me` — Return current authenticated session, role, and capabilities.

## 2. Trust Bundles & Revocation Snapshots
- `GET /api/trust/bundle` — Return the latest signed Trust Bundle (version, issuer public keys, policy parameters, root signature).
- `GET /api/trust/status-snapshot` — Return the latest issuer-signed revocation status snapshot.
- `POST /api/trust/bundle/update` — (Admin) Distribute new versioned trust bundle or key rotation.

## 3. Credential Lifecycle
- `POST /api/credentials/issue` — (Admin/Commander) Issue a newly signed Compact JWS credential bound to a responder's device thumbprint.
- `GET /api/credentials` — List credentials (filterable by state: PENDING, ACTIVE, SUSPENDED, REVOKED, EXPIRED).
- `GET /api/credentials/:id` — Detailed credential inspection with decoded claims and lifecycle history.
- `POST /api/credentials/:id/suspend` — Transition credential state to SUSPENDED.
- `POST /api/credentials/:id/revoke` — Permanently revoke credential (reason, effective epoch, signed status snapshot bump).

## 4. Device Enrollment & Challenges
- `POST /api/devices/enroll` — Register responder device public key (JWK) after proof-of-possession challenge.
- `POST /api/verifier/challenge` — Generate 128-bit replay-protected challenge for proof-of-possession verification.
- `POST /api/verifier/verify` — Online verification evaluation endpoint (mirrors offline packages/verifier engine).

## 5. Offline Event Synchronization
- `POST /api/sync/events` — Ingest batch of offline-recorded responder events.
  - Verifies device ECDSA signature.
  - Validates sequence numbering and previous-event SHA-256 hash.
  - Checks for duplicate event IDs (idempotency) and payload collisions.
  - Classifies: `ACCEPTED`, `REJECTED`, or `NEEDS_REVIEW`.
- `GET /api/sync/review` — (Admin) Queue of conflicting or ambiguous offline events awaiting human adjudication.
- `POST /api/sync/review/:id/adjudicate` — Approve or reject an event flagged for review.

## 6. Audit & Integrity
- `GET /api/audit/logs` — Paginated tamper-evident audit log records.
- `POST /api/audit/verify-chain` — Execute cryptographic verification of the complete hash chain from genesis to head.
