# ResQMesh Trust Architecture Specification

## 1. Executive Summary
ResQMesh Trust is an identity, authorization, and cryptographic verification infrastructure designed for disaster-response and disconnected operational environments. It decouples authenticity from authorization, enforces device binding via WebCrypto ECDSA P-256 keys, and executes deterministic offline policy evaluation using signed trust bundles and revocation status snapshots.

## 2. Monorepo Structure
```
resqmesh-trust/
├── apps/
│   └── web/                     # Next.js App Router (UI, API routes, Server Components)
│       ├── app/
│       │   ├── (public)/        # Landing page, Security Lab, Login, How it works
│       │   ├── verifier/        # Disconnected offline verification cockpit
│       │   ├── responder/       # Device key enrollment, credentials, sync queue
│       │   ├── admin/           # Fleet management, lifecycle, audit chain, sync review
│       │   └── api/             # Typed Next.js route handlers
│       ├── components/          # Reusable UI primitives (shadcn, Radix, Tailwind v4)
│       ├── lib/                 # Browser crypto adapters, IndexedDB offline store
│       └── styles/              # Global styles, OKLCH design tokens
├── packages/
│   ├── verifier/                # Shared verification engine (browser & Node.js compatible)
│   └── shared/                  # Zod schemas, TypeScript types, constants, risk policies
├── prisma/
│   ├── schema.prisma            # Relational database schema with SQLite/Postgres compatibility
│   └── seed.ts                  # Deterministic fictional seed data for demonstrations
├── docs/                        # Security, architecture, and operational specifications
├── tests/                       # Unit, integration, and Playwright E2E suites
├── PLAN.md
├── PROGRESS.md
└── README.md
```

## 3. Trust Boundaries & Data Flow
1. **Issuer Key Isolation:** Issuer private keys reside exclusively on the secure backend/HSM boundary. Never exported to clients or exposed via API.
2. **Device Key Non-Extractability:** Responder device private keys are generated via `window.crypto.subtle.generateKey` with `{ extractable: false }`, stored in IndexedDB as a CryptoKey object.
3. **Decoupled Verification Engine:** The verification engine accepts pure interfaces:
   - Clock (injected for deterministic testing and clock-rollback detection)
   - Trust Bundle Store (monotonic versions, pinned root anchor)
   - Revocation Status Store (signed snapshots with maximum age)
   - Device Challenge Resolver (nonce replay protection)
4. **Tamper-Evident Audit Chain:** Append-only SHA-256 hash-chained log (`Hash_n = SHA256(Hash_{n-1} || Record_n)`).

## 4. The Four Independent Verification Decisions
- **Decision A (Authenticity):** Compact JWS signature validates against an active public key in the trusted bundle.
- **Decision B (Device Possession):** Fresh challenge signed by the private key corresponding to the credential's `cnf.jwk` thumbprint.
- **Decision C (Authorization):** Subject's role, permissions, and incident scope match the requested operational action.
- **Decision D (Freshness):** Age of cached signed revocation status meets the risk tier threshold (LOW: 24h, MEDIUM: 6h, HIGH: 1h / online required).
