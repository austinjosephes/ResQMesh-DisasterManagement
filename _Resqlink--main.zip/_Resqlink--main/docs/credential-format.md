# ResQMesh Trust Credential Format Specification

## 1. Specification & Standards Alignment
ResQMesh Trust credentials format adheres to **RFC 7515 (JSON Web Signature - JWS)** Compact Serialization and **RFC 7638 (JWK Thumbprint)** for confirmation methods (`cnf`). It aligns with core **W3C Verifiable Credentials Data Model 2.0** semantics without asserting full external conformance where custom disaster-response profiles are used.

## 2. JWS Compact Serialization Structure
```
<Base64URL(UTF8(ProtectedHeader))> . <Base64URL(UTF8(ClaimsPayload))> . <Base64URL(Signature)>
```

### 2.1 Protected Header
```json
{
  "alg": "ES256",
  "typ": "application/resqmesh-credential+jwt",
  "kid": "issuer-key-2026-alpha"
}
```
- `alg`: Mandatory `ES256` (ECDSA using P-256 and SHA-256). Other algorithms are rejected.
- `typ`: Document type identifier.
- `kid`: Identifier of the public key in the active Trust Bundle.

### 2.2 Payload Schema
```json
{
  "jti": "urn:uuid:7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "iss": "did:resqmesh:issuer:federal-fema-ca",
  "sub": "resq-resp-8842-bravo",
  "iat": 1730200000,
  "nbf": 1730200000,
  "exp": 1730286400,
  "credential_version": "1.0",
  "policy_version": "2026.1",
  "role": "PARAMEDIC_TIER_2",
  "permissions": [
    "triage.record",
    "medication.administer.basic",
    "perimeter.cross.restricted"
  ],
  "incident_scope": "INCIDENT-CASCADE-QUAKE-2026",
  "status": {
    "status_list_id": "sl-2026-10",
    "status_list_index": 428
  },
  "cnf": {
    "jwk_thumbprint": "SHA256:N7yM9uL3x2K...",
    "jwk": {
      "kty": "EC",
      "crv": "P-256",
      "x": "f83OJ3D2xFmT4v7GyUbqrPllP52VU6rq9VyPfUvPE60",
      "y": "x_da7WJxEcQHoA4ZXQQvCQVVmCTqq4TU_RR3JWAuiqU"
    }
  }
}
```

## 3. Claim Definitions
- `jti`: Universally unique credential instance identifier.
- `iss`: Decentralized or federated issuer identifier matching an authority in the Trust Bundle.
- `sub`: Pseudonymous responder handle. (PII minimization).
- `iat`: Issuance epoch timestamp in seconds.
- `nbf`: Not-before timestamp in seconds.
- `exp`: Expiry timestamp in seconds (typically 24–72 hours for deployment shifts).
- `role`: Standardized disaster-response operational role.
- `permissions`: Granular capability flags tested against requested actions.
- `incident_scope`: Bounded geographic or incident identifier.
- `status`: Pointer to status snapshot list for monotonic signed revocation evaluation.
- `cnf`: Confirmation claim binding credential to the public key of the responder's device.
