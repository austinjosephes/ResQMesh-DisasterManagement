# ResQMesh Trust Motion & Animation Specification

## 1. Operational Philosophy
Animations serve comprehension, not entertainment.
- Never delay or block an urgent user decision with decorative transitions.
- Every state transition reflects a verified reality: never show "Verified" before the cryptographic engine validates signatures and claims.

## 2. Durations & Easing
- **Instant:** 90ms (`ease-out`) for active clicks, checkbox toggles, and status badges.
- **Fast:** 160ms (`cubic-bezier(0.2, 0, 0, 1)`) for tooltips, toasts, and hover cards.
- **Standard:** 240ms (`cubic-bezier(0.2, 0, 0, 1)`) for drawers, modals, and accordion expands.
- **Cinematic:** 800ms–1400ms for landing page 3D storytelling transitions.

## 3. Reduced Motion Support
When `prefers-reduced-motion: reduce` is detected:
- 3D canvas switches to static poster mode with simple low-contrast lighting.
- Scroll-pinned landing sections transform into accessible natural-flow document blocks.
- Transforms and parallax are completely disabled; instant opacity fades are used instead.
