# ResQMesh Trust Offline Policy Specification

## 1. Principles of Disconnected Authorization
In high-stress disaster response, network infrastructure is frequently compromised or saturated. ResQMesh Trust enforces risk-stratified policies configured within the cryptographically signed Trust Bundle:

1. **Explicit Risk Tiers:** Every operational action is categorized by risk (LOW, MEDIUM, HIGH, CRITICAL).
2. **Deterministic Time Windows:** Maximum age of cached signed revocation status snapshots is enforced.
3. **No Silent Fallbacks:** Stale status never silently escalates into unconstrained authority.

## 2. Policy Matrix by Risk Tier
| Risk Tier | Sample Actions | Max Status Age | Allowed Offline? | Policy Outcome When Status Stale |
|---|---|---|---|---|
| **LOW** | `incident.view`, `triage.read`, `checkin.general` | 24 Hours | YES | Permitted with informational warning (`STATUS_STALE_ACCEPTED`) |
| **MEDIUM** | `report.submit`, `patient.record`, `supply.request` | 6 Hours | YES | Permitted under restricted quota; flagged for post-sync review |
| **HIGH** | `perimeter.access.critical`, `narcotics.dispense` | 1 Hour | RESTRICTED | Blocked unless override credential with co-signature is present |
| **CRITICAL** | `commander.delegate`, `issuer.rotate_key` | 0 Hours | NO | Reconnect mandatory (`RECONNECT_MANDATORY_HIGH_RISK`) |

## 3. Clock Skew and Time High-Water Mark
- **Permitted Clock Skew:** Verifier allows up to $\pm 120$ seconds of clock skew for network drift.
- **High-Water Mark Enforcement:**
  - The verifier records `max(seen_valid_signed_timestamp)`.
  - If current local device clock is less than `high_water_mark - skew_allowance`, clock rollback is detected (`CLOCK_ANOMALY`).
  - Credential is rejected or degraded to the highest risk restriction.
