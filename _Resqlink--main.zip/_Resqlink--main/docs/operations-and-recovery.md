# ResQMesh Trust Operations & Disaster Recovery Guide

## 1. Trust Bundle Bootstrap & Key Management
- **Key Generation:** Development keys are generated using ECDSA P-256 (`ES256`).
- **Production Path:** Production environments must integrate with AWS KMS, Google Cloud KMS, or HashiCorp Vault Transit engine for unexportable issuer keys.
- **Key Compromise Emergency Protocol:**
  1. Administrative quorum signs a Trust Bundle revision incrementing the monotonic `bundle_version`.
  2. The compromised `kid` is marked with `status: "COMPROMISED"`.
  3. Verifiers synchronizing or receiving offline updates via signed QR/USB immediately reject any credential signed by that key.

## 2. Lost Device Recovery Protocol
- In the event of a lost or destroyed responder device:
  1. The administrator marks the existing credential as `SUSPENDED` or `REVOKED`.
  2. A new signed status snapshot is distributed.
  3. On replacement hardware, the responder registers a new WebCrypto key pair and completes proof-of-possession.
  4. The previous private key is never transferred across devices.

## 3. Database & Audit Chain Recovery
- Database backups must preserve the sequential order of audit records.
- Run `POST /api/audit/verify-chain` following any restore or migration to guarantee no transaction logs were corrupted or dropped.
