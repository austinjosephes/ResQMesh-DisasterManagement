# ResQMesh Trust Threat Model & Security Boundaries

## 1. Scope & Assets
- **Primary Assets:**
  - Issuer signing keys (server-side ES256).
  - Responder device private keys (client-side non-extractable WebCrypto P-256).
  - Responder digital credentials (RFC 7515 Compact JWS).
  - Trust bundles and signed revocation status snapshots.
  - Verification records and offline operational event logs.
  - Server-side hash-chained audit log.

## 2. Threat Actors & Capabilities
1. **Physical Device Thief:** Possesses stolen responder hardware. Cannot extract WebCrypto private key without platform compromise; mitigated by short credential expiry and administrative revocation.
2. **Eavesdropper / MitM:** Intercepts credential payloads and status snapshots. Credentials contain only pseudonymous identifiers; payloads are tamper-evident (signatures fail if modified).
3. **Malicious Responder:** Attempts privilege escalation, replay of old challenges, or modifying incident scopes. Rejected by strict claim validation and non-repudiable device binding.
4. **Disconnected Attacker / Clock Manipulator:** Attempts to roll back system clock or trust bundle version. Mitigated by monotonic version enforcement and trusted-time high-water marks.
5. **Rogue Administrator:** Attempts to silently alter past events. Tamper-evident hash chain detects any modification to historical audit logs.

## 3. Threat Matrix & Mitigations
| Threat | Attack Vector | Security Control | Residual Risk |
|---|---|---|---|
| Cloned Credential | Exporting payload to unauthorized device | Credential binds to `cnf.jwk` thumbprint; requires ECDSA signature over fresh challenge | Attacker controlling physical phone lock-screen before revocation |
| Replayed Challenge | Capturing valid challenge-response exchange | 128-bit random nonce, 60s TTL, single-use cache | Sub-minute local relay attack if adversary in physical proximity |
| Payload Modification | Editing role from EMT to INCIDENT_COMMANDER | ES256 digital signature over protected header and claims | None (signature verification fails immediately) |
| Stale Revocation Attack | Disconnecting verifier to hide recent revocation | Risk-tiered freshness policy (LOW: 24h, MED: 6h, HIGH: 1h/online); clear UI status | Window of vulnerability bounded by tier max age |
| Trust Bundle Rollback | Feeding older trust bundle without revoked issuer | Monotonic bundle version check; verifier rejects `version < current_max` | Local device storage reset by privileged attacker |
| Clock Rollback | Setting device time backwards to un-expire credential | Monotonic trusted-time high-water mark; rejects time < watermark | Fresh verifier with cold storage and untrusted initial clock |
| Offline Event Tampering | Modifying local event before sync | Device signs each event; per-device sequence counter; hash chain | Un-enrolled rogue device submitting unauthenticated events |

## 4. Truthful Security Disclosures
- **Web Storage Limitation:** Web Crypto `extractable: false` protects keys from malicious page JavaScript, but root/debugger access on the host OS can extract memory.
- **Revocation Delay:** Offline verification cannot know if a credential was revoked 5 minutes ago if the verifier has not connected to the network.
- **Hash Chain vs Tamper Proof:** A local hash chain is tamper-evident, not inherently tamper-proof against a database admin with full rewrite capabilities without external anchoring.
