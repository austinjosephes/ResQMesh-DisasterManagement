# ResQMesh Trust UI Architecture & Design Tokens

## 1. Design Direction: Calm Authority Under Pressure
ResQMesh Trust UI is built for operational clarity in chaotic disaster scenarios. High contrast, tabular numerals for time and hashes, disciplined visual hierarchy, and instant cognitive feedback.

## 2. Color System & Semantic Tokens (OKLCH)
```css
:root {
  /* Canvas & Surfaces */
  --color-canvas: oklch(0.12 0.02 260);          /* #0B1020 Dark navy backdrop */
  --color-surface-1: oklch(0.16 0.02 260);       /* #111827 Elevated panel */
  --color-surface-2: oklch(0.20 0.03 260);       /* #172033 Interactive card */
  --color-surface-3: oklch(0.25 0.03 260);       /* #1E2A42 Inset / borders */

  /* Text & Legibility */
  --color-text-primary: oklch(0.96 0.01 260);    /* #F3F6FC Crisp white */
  --color-text-secondary: oklch(0.72 0.03 260);  /* #9BA8BC Supportive */
  --color-text-muted: oklch(0.55 0.02 260);      /* #6F7C93 Technical labels */

  /* Accents & Brand */
  --color-accent: oklch(0.82 0.14 200);          /* #55D6E8 ResQ Cyan */
  --color-accent-subtle: oklch(0.30 0.06 200);

  /* Status Tokens */
  --color-status-valid: oklch(0.75 0.18 145);     /* Emerald verified */
  --color-status-warning: oklch(0.80 0.16 85);    /* Amber warning / stale */
  --color-status-revoked: oklch(0.65 0.22 25);    /* Coral / Ruby revoked */
  --color-status-neutral: oklch(0.60 0.02 260);   /* Slate informational */
}
```

## 3. Responsive Breakpoints
- **Mobile compact:** 360px – 480px (full-width stacked cards, sticky decision drawer)
- **Tablet / Rugged Toughbook:** 768px – 1024px (2-column layout)
- **Command Workstation:** 1280px – 1920px (3-pane layout: Input / Inspection / Live Verification Diagnostics)
