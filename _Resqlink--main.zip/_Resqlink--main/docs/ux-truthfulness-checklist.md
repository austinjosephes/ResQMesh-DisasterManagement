# ResQMesh Trust UX Truthfulness Checklist

## Principles of Honest Security Communication
1. **Never conflate Authenticity with Authorization:**
   - A valid ES256 signature means the issuer signed the credential.
   - It does NOT mean the responder is permitted to access a specific narcotics locker or enter an unauthorized sector.
2. **Never claim instant revocation in disconnected environments:**
   - Clearly state: *"Revocation status is as of [timestamp]. Offline verifiers cannot detect server revocations that occurred after their last synchronization."*
3. **Never claim ordinary browser keys are "hardware-backed":**
   - WebCrypto `extractable: false` keys are stored in browser IndexedDB.
   - Label truthfully: *"Browser-Managed Software Key (Non-extractable)"*, unless running inside WebAuthn Secure Enclave / Android StrongBox.
4. **Never simulate real network operations secretly:**
   - Clearly distinguish between *"Live Network Verification"* and *"Offline Verification (Cached Trust Material)"*.
   - When offline simulation is toggled, display an explicit banner: `[OFFLINE SIMULATION ACTIVE - Network Bypassed]`.
5. **Accurately describe audit log integrity:**
   - The SHA-256 hash chain is *tamper-evident*.
   - Do not claim it is "unalterable" or "immutable" against a rogue superuser without external anchoring.
