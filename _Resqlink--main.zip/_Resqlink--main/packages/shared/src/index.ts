import { z } from 'zod';

// ==========================================
// 1. Result Codes & Verification Status
// ==========================================
export const VerificationResultCode = {
  VALID_AND_AUTHORIZED: 'VALID_AND_AUTHORIZED',
  VALID_BUT_NOT_AUTHORIZED: 'VALID_BUT_NOT_AUTHORIZED',
  INVALID_SIGNATURE: 'INVALID_SIGNATURE',
  MALFORMED_CREDENTIAL: 'MALFORMED_CREDENTIAL',
  UNKNOWN_ISSUER: 'UNKNOWN_ISSUER',
  EXPIRED: 'EXPIRED',
  NOT_YET_VALID: 'NOT_YET_VALID',
  DEVICE_MISMATCH: 'DEVICE_MISMATCH',
  INVALID_CHALLENGE_PROOF: 'INVALID_CHALLENGE_PROOF',
  CHALLENGE_REPLAYED: 'CHALLENGE_REPLAYED',
  CHALLENGE_EXPIRED: 'CHALLENGE_EXPIRED',
  REVOKED_IN_CACHED_STATUS: 'REVOKED_IN_CACHED_STATUS',
  STATUS_STALE: 'STATUS_STALE',
  INSUFFICIENT_TRUST_DATA: 'INSUFFICIENT_TRUST_DATA',
  CLOCK_ANOMALY: 'CLOCK_ANOMALY',
  SUSPENDED: 'SUSPENDED',
  SUPERSEDED: 'SUPERSEDED',
} as const;

export type VerificationResultCode = typeof VerificationResultCode[keyof typeof VerificationResultCode];

export type CheckStatus = 'PASSED' | 'FAILED' | 'SKIPPED' | 'WARNING';

export interface VerificationCheckDetail {
  id: string;
  name: string;
  status: CheckStatus;
  explanation: string;
  timestamp: number;
}

export interface VerificationResult {
  code: VerificationResultCode;
  authentic: boolean;
  authorized: boolean;
  freshnessOk: boolean;
  deviceBoundOk: boolean;
  summary: string;
  checks: VerificationCheckDetail[];
  claims?: CredentialClaims;
  diagnostics: {
    issuerKid?: string;
    trustBundleVersion?: number;
    statusSnapshotAgeSeconds?: number;
    riskTier?: RiskTier;
    requestedAction?: string;
    verificationTimestamp: number;
    isOffline: boolean;
    clockSkewSeconds?: number;
  };
}

// ==========================================
// 2. Credential Payload & Claims (RFC 7515 & RFC 7638)
// ==========================================
export const JWKSchema = z.object({
  kty: z.literal('EC'),
  crv: z.literal('P-256'),
  x: z.string(),
  y: z.string(),
  d: z.string().optional(),
  kid: z.string().optional(),
});
export type JWK = z.infer<typeof JWKSchema>;

export const ConfirmationMethodSchema = z.object({
  jwk_thumbprint: z.string(),
  jwk: JWKSchema,
});
export type ConfirmationMethod = z.infer<typeof ConfirmationMethodSchema>;

export const CredentialStatusPointerSchema = z.object({
  status_list_id: z.string(),
  status_list_index: z.number().int().nonnegative(),
});
export type CredentialStatusPointer = z.infer<typeof CredentialStatusPointerSchema>;

export const CredentialClaimsSchema = z.object({
  jti: z.string().uuid(),
  iss: z.string(),
  sub: z.string(),
  iat: z.number().int(),
  nbf: z.number().int(),
  exp: z.number().int(),
  role: z.string(),
  permissions: z.array(z.string()),
  incident_scope: z.string(),
  credential_version: z.string().default('1.0'),
  policy_version: z.string().default('2026.1'),
  status: CredentialStatusPointerSchema,
  cnf: ConfirmationMethodSchema,
});
export type CredentialClaims = z.infer<typeof CredentialClaimsSchema>;

export const ProtectedHeaderSchema = z.object({
  alg: z.literal('ES256'),
  typ: z.string().default('application/resqmesh-credential+jwt'),
  kid: z.string(),
});
export type ProtectedHeader = z.infer<typeof ProtectedHeaderSchema>;

// ==========================================
// 3. Trust Bundle & Key Management
// ==========================================
export const TrustedIssuerKeySchema = z.object({
  kid: z.string(),
  issuer: z.string(),
  publicKeyJwk: JWKSchema,
  validFrom: z.number().int(),
  validUntil: z.number().int(),
  status: z.enum(['ACTIVE', 'REVOKED', 'COMPROMISED']),
});
export type TrustedIssuerKey = z.infer<typeof TrustedIssuerKeySchema>;

export const TrustBundleSchema = z.object({
  bundle_version: z.number().int().positive(),
  issued_at: z.number().int(),
  expires_at: z.number().int(),
  root_authority_id: z.string(),
  keys: z.array(TrustedIssuerKeySchema),
  signature: z.string(),
});
export type TrustBundle = z.infer<typeof TrustBundleSchema>;

// ==========================================
// 4. Signed Revocation Status Snapshot
// ==========================================
export const RevocationStatusEntrySchema = z.object({
  credential_jti: z.string().uuid(),
  revoked_at: z.number().int(),
  reason: z.string(),
});
export type RevocationStatusEntry = z.infer<typeof RevocationStatusEntrySchema>;

export const SignedStatusSnapshotSchema = z.object({
  snapshot_version: z.number().int().positive(),
  issued_at: z.number().int(),
  issuer_kid: z.string(),
  revoked_credentials: z.array(RevocationStatusEntrySchema),
  signature: z.string(),
});
export type SignedStatusSnapshot = z.infer<typeof SignedStatusSnapshotSchema>;

// ==========================================
// 5. Offline Risk Policies
// ==========================================
export type RiskTier = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ActionPolicy {
  riskTier: RiskTier;
  maxStatusAgeSeconds: number;
  allowedOffline: boolean;
  requiredPermission: string;
}

export const DEFAULT_ACTION_POLICIES: Record<string, ActionPolicy> = {
  'incident.view': {
    riskTier: 'LOW',
    maxStatusAgeSeconds: 86400, // 24 hours
    allowedOffline: true,
    requiredPermission: 'incident.view',
  },
  'triage.read': {
    riskTier: 'LOW',
    maxStatusAgeSeconds: 86400,
    allowedOffline: true,
    requiredPermission: 'triage.read',
  },
  'triage.record': {
    riskTier: 'MEDIUM',
    maxStatusAgeSeconds: 21600, // 6 hours
    allowedOffline: true,
    requiredPermission: 'triage.record',
  },
  'report.submit': {
    riskTier: 'MEDIUM',
    maxStatusAgeSeconds: 21600,
    allowedOffline: true,
    requiredPermission: 'report.submit',
  },
  'medication.administer.basic': {
    riskTier: 'MEDIUM',
    maxStatusAgeSeconds: 21600,
    allowedOffline: true,
    requiredPermission: 'medication.administer.basic',
  },
  'perimeter.cross.restricted': {
    riskTier: 'HIGH',
    maxStatusAgeSeconds: 3600, // 1 hour
    allowedOffline: true,
    requiredPermission: 'perimeter.cross.restricted',
  },
  'narcotics.dispense': {
    riskTier: 'HIGH',
    maxStatusAgeSeconds: 3600,
    allowedOffline: false, // Online mandatory
    requiredPermission: 'narcotics.dispense',
  },
  'commander.delegate': {
    riskTier: 'CRITICAL',
    maxStatusAgeSeconds: 0,
    allowedOffline: false,
    requiredPermission: 'commander.delegate',
  },
};

// ==========================================
// 6. Challenge-Response Protocols (RFC 7638 Device Binding)
// ==========================================
export const ChallengePayloadSchema = z.object({
  challenge_id: z.string().uuid(),
  nonce: z.string(), // >= 128-bit hex or base64
  verifier_id: z.string(),
  audience: z.string(),
  issued_at: z.number().int(),
  expires_at: z.number().int(), // default 60s
});
export type ChallengePayload = z.infer<typeof ChallengePayloadSchema>;

export const ChallengeResponseProofSchema = z.object({
  challenge_id: z.string().uuid(),
  responder_sub: z.string(),
  device_thumbprint: z.string(),
  signature_compact: z.string(), // raw ES256 signature over nonce string
});
export type ChallengeResponseProof = z.infer<typeof ChallengeResponseProofSchema>;

// ==========================================
// 7. Offline Operational Events & Sync Queue
// ==========================================
export type SyncClassification = 'ACCEPTED' | 'REJECTED' | 'NEEDS_REVIEW';

export const OfflineEventRecordSchema = z.object({
  event_id: z.string().uuid(),
  device_id: z.string(),
  credential_jti: z.string().uuid(),
  sequence_number: z.number().int().nonnegative(),
  previous_event_hash: z.string(), // Genesis starts with "0000000000000000000000000000000000000000000000000000000000000000"
  event_type: z.string(),
  payload_json: z.string(),
  payload_hash: z.string(), // SHA-256 of payload_json
  created_at: z.number().int(),
  device_signature: z.string(), // ES256 signature by device key over canonical hash
});
export type OfflineEventRecord = z.infer<typeof OfflineEventRecordSchema>;

export interface SyncResultItem {
  event_id: string;
  status: SyncClassification;
  reason: string;
  server_receipt_time: number;
}

// ==========================================
// 8. Tamper-Evident Audit Chain Log
// ==========================================
export interface AuditRecord {
  id: string;
  sequence: number;
  actor: string;
  action: string;
  resource: string;
  timestamp: number;
  outcome: 'SUCCESS' | 'FAILURE' | 'BLOCKED';
  reason?: string;
  correlation_id: string;
  previous_hash: string;
  current_hash: string; // SHA256(previous_hash + sequence + actor + action + resource + timestamp + outcome + correlation_id)
}
