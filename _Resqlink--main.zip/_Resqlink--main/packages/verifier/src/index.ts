import * as jose from 'jose';
import {
  VerificationResultCode,
  VerificationResult,
  VerificationCheckDetail,
  CheckStatus,
  CredentialClaims,
  CredentialClaimsSchema,
  ProtectedHeaderSchema,
  TrustBundle,
  SignedStatusSnapshot,
  ChallengePayload,
  ChallengeResponseProof,
  DEFAULT_ACTION_POLICIES,
  ActionPolicy,
} from '@resqmesh/shared';

export interface VerifierDependencies {
  clock?: () => number; // Returns current epoch timestamp in seconds
  highWaterMark?: number; // Monotonic high-water mark timestamp
  trustBundle: TrustBundle;
  statusSnapshot?: SignedStatusSnapshot;
  usedChallenges?: Set<string>; // For replay protection
  actionPolicies?: Record<string, ActionPolicy>;
  isOffline?: boolean;
}

export interface VerificationInput {
  token: string;
  requestedAction?: string;
  targetIncidentScope?: string;
  challenge?: ChallengePayload;
  challengeProof?: ChallengeResponseProof;
}

export class OfflineVerifier {
  private getNow: () => number;
  private highWaterMark: number;
  private trustBundle: TrustBundle;
  private statusSnapshot?: SignedStatusSnapshot;
  private usedChallenges: Set<string>;
  private actionPolicies: Record<string, ActionPolicy>;
  private isOffline: boolean;

  constructor(deps: VerifierDependencies) {
    this.getNow = deps.clock || (() => Math.floor(Date.now() / 1000));
    this.highWaterMark = deps.highWaterMark || 0;
    this.trustBundle = deps.trustBundle;
    this.statusSnapshot = deps.statusSnapshot;
    this.usedChallenges = deps.usedChallenges || new Set<string>();
    this.actionPolicies = deps.actionPolicies || DEFAULT_ACTION_POLICIES;
    this.isOffline = deps.isOffline ?? false;
  }

  public updateTrustBundle(newBundle: TrustBundle): { success: boolean; reason?: string } {
    if (newBundle.bundle_version <= this.trustBundle.bundle_version) {
      return {
        success: false,
        reason: `Rollback rejected: new bundle version ${newBundle.bundle_version} is not greater than active version ${this.trustBundle.bundle_version}`,
      };
    }
    this.trustBundle = newBundle;
    return { success: true };
  }

  public updateStatusSnapshot(snapshot: SignedStatusSnapshot): void {
    this.statusSnapshot = snapshot;
  }

  public async verify(input: VerificationInput): Promise<VerificationResult> {
    const checks: VerificationCheckDetail[] = [];
    const now = this.getNow();
    const clockSkewSeconds = 120; // 2 minutes tolerance

    const addCheck = (id: string, name: string, status: CheckStatus, explanation: string) => {
      checks.push({ id, name, status, explanation, timestamp: now });
    };

    // ----------------------------------------------------
    // Step 1: Clock Anomaly & High-Water Mark Detection
    // ----------------------------------------------------
    if (this.highWaterMark > 0 && now < this.highWaterMark - clockSkewSeconds) {
      addCheck(
        'clock_anomaly',
        'Clock Rollback Detection',
        'FAILED',
        `Current clock (${now}) is older than verified high-water mark (${this.highWaterMark}) beyond skew allowance (${clockSkewSeconds}s)`
      );
      return {
        code: VerificationResultCode.CLOCK_ANOMALY,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Clock anomaly detected: device time appears to have been rolled back.',
        checks,
        diagnostics: {
          verificationTimestamp: now,
          isOffline: this.isOffline,
          clockSkewSeconds,
        },
      };
    } else {
      addCheck('clock_check', 'Device Time & Skew', 'PASSED', `Clock timestamp ${now} is within valid bounds.`);
    }

    // ----------------------------------------------------
    // Step 2: Parse Compact JWS
    // ----------------------------------------------------
    const parts = (input.token || '').trim().split('.');
    if (parts.length !== 3) {
      addCheck(
        'parse_format',
        'JWS Format Structure',
        'FAILED',
        `Expected 3 dot-separated base64url segments, received ${parts.length}`
      );
      return {
        code: VerificationResultCode.MALFORMED_CREDENTIAL,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Credential is not a valid Compact JWS.',
        checks,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }

    let headerJson: any;
    let claimsJson: any;
    try {
      headerJson = JSON.parse(new TextDecoder().decode(jose.base64url.decode(parts[0])));
      claimsJson = JSON.parse(new TextDecoder().decode(jose.base64url.decode(parts[1])));
    } catch (e: any) {
      addCheck('parse_encoding', 'Base64URL / JSON Decode', 'FAILED', `Malformed JSON segment: ${e.message}`);
      return {
        code: VerificationResultCode.MALFORMED_CREDENTIAL,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Failed to decode credential segments as UTF-8 JSON.',
        checks,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }

    // Validate Header
    const headerParse = ProtectedHeaderSchema.safeParse(headerJson);
    if (!headerParse.success) {
      addCheck('header_schema', 'Protected Header Validation', 'FAILED', headerParse.error.message);
      return {
        code: VerificationResultCode.MALFORMED_CREDENTIAL,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Invalid or unsupported protected header (requires ES256 and valid kid).',
        checks,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }
    const protectedHeader = headerParse.data;
    addCheck('header_schema', 'Protected Header Validation', 'PASSED', `Algorithm: ES256, Key ID: ${protectedHeader.kid}`);

    // Validate Claims Schema
    const claimsParse = CredentialClaimsSchema.safeParse(claimsJson);
    if (!claimsParse.success) {
      addCheck('claims_schema', 'Payload Schema Validation', 'FAILED', claimsParse.error.message);
      return {
        code: VerificationResultCode.MALFORMED_CREDENTIAL,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Credential payload does not match required disaster responder schema.',
        checks,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }
    const claims: CredentialClaims = claimsParse.data;
    addCheck('claims_schema', 'Payload Schema Validation', 'PASSED', `Valid claims for subject ${claims.sub}`);

    // ----------------------------------------------------
    // Step 3: Resolve Issuer in Trust Bundle
    // ----------------------------------------------------
    const issuerKey = this.trustBundle.keys.find((k) => k.kid === protectedHeader.kid);
    if (!issuerKey) {
      addCheck(
        'issuer_trust',
        'Trust Bundle Resolution',
        'FAILED',
        `Signing key kid "${protectedHeader.kid}" not found in active trust bundle (v${this.trustBundle.bundle_version})`
      );
      return {
        code: VerificationResultCode.UNKNOWN_ISSUER,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: `Unknown issuer key (${protectedHeader.kid}) not recognized by this device's trust bundle.`,
        checks,
        claims,
        diagnostics: {
          issuerKid: protectedHeader.kid,
          trustBundleVersion: this.trustBundle.bundle_version,
          verificationTimestamp: now,
          isOffline: this.isOffline,
        },
      };
    }

    if (issuerKey.status !== 'ACTIVE') {
      addCheck(
        'issuer_status',
        'Issuer Key Status',
        'FAILED',
        `Issuer key "${protectedHeader.kid}" is marked as ${issuerKey.status}`
      );
      return {
        code: VerificationResultCode.INVALID_SIGNATURE,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: `Issuer key is not active (${issuerKey.status}).`,
        checks,
        claims,
        diagnostics: {
          issuerKid: protectedHeader.kid,
          trustBundleVersion: this.trustBundle.bundle_version,
          verificationTimestamp: now,
          isOffline: this.isOffline,
        },
      };
    }
    addCheck('issuer_trust', 'Trust Bundle Resolution', 'PASSED', `Issuer key ${issuerKey.kid} verified active.`);

    // ----------------------------------------------------
    // Step 4: Cryptographic Signature Verification (ES256)
    // ----------------------------------------------------
    try {
      const importedPublicKey = await jose.importJWK(issuerKey.publicKeyJwk, 'ES256');
      await jose.compactVerify(input.token, importedPublicKey);
      addCheck('crypto_signature', 'ES256 Digital Signature', 'PASSED', 'Cryptographic signature is authentic and verified.');
    } catch (e: any) {
      addCheck('crypto_signature', 'ES256 Digital Signature', 'FAILED', `Signature verification failed: ${e.message}`);
      return {
        code: VerificationResultCode.INVALID_SIGNATURE,
        authentic: false,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Digital signature does not match issuer key. Credential may have been altered.',
        checks,
        claims,
        diagnostics: {
          issuerKid: protectedHeader.kid,
          verificationTimestamp: now,
          isOffline: this.isOffline,
        },
      };
    }

    // ----------------------------------------------------
    // Step 5: Validity Windows (nbf, exp with clock skew)
    // ----------------------------------------------------
    if (now + clockSkewSeconds < claims.nbf) {
      addCheck(
        'time_nbf',
        'Not-Before (nbf) Check',
        'FAILED',
        `Credential not yet valid (nbf: ${claims.nbf}, now: ${now})`
      );
      return {
        code: VerificationResultCode.NOT_YET_VALID,
        authentic: true,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Credential is not yet active according to its not-before timestamp.',
        checks,
        claims,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    } else {
      addCheck('time_nbf', 'Not-Before (nbf) Check', 'PASSED', `Valid from ${new Date(claims.nbf * 1000).toISOString()}`);
    }

    if (now - clockSkewSeconds > claims.exp) {
      addCheck(
        'time_exp',
        'Expiration (exp) Check',
        'FAILED',
        `Credential expired at ${new Date(claims.exp * 1000).toISOString()} (now: ${now})`
      );
      return {
        code: VerificationResultCode.EXPIRED,
        authentic: true,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Credential has expired. Re-issuance required.',
        checks,
        claims,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    } else {
      addCheck('time_exp', 'Expiration (exp) Check', 'PASSED', `Valid until ${new Date(claims.exp * 1000).toISOString()}`);
    }

    // ----------------------------------------------------
    // Step 6: Device Binding & Proof of Possession
    // ----------------------------------------------------
    // Verify RFC 7638 thumbprint
    let expectedThumbprint = '';
    try {
      expectedThumbprint = await jose.calculateJwkThumbprint(claims.cnf.jwk, 'sha256');
    } catch (e: any) {
      addCheck('device_thumbprint', 'Device Key Thumbprint Calculation', 'FAILED', e.message);
      return {
        code: VerificationResultCode.DEVICE_MISMATCH,
        authentic: true,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Failed to compute RFC 7638 thumbprint of device key.',
        checks,
        claims,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }

    if (claims.cnf.jwk_thumbprint !== expectedThumbprint) {
      addCheck(
        'device_thumbprint',
        'Device Key Thumbprint Match',
        'FAILED',
        `Thumbprint mismatch: claimed "${claims.cnf.jwk_thumbprint}", computed "${expectedThumbprint}"`
      );
      return {
        code: VerificationResultCode.DEVICE_MISMATCH,
        authentic: true,
        authorized: false,
        freshnessOk: false,
        deviceBoundOk: false,
        summary: 'Credential confirmation thumbprint does not match embedded device key.',
        checks,
        claims,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
      };
    }
    addCheck('device_thumbprint', 'Device Key Thumbprint Match', 'PASSED', `Matches RFC 7638 thumbprint ${expectedThumbprint.slice(0, 12)}...`);

    // If challenge proof was supplied, verify it
    let deviceBoundOk = false;
    if (input.challenge && input.challengeProof) {
      const challenge = input.challenge;
      const proof = input.challengeProof;

      if (this.usedChallenges.has(challenge.challenge_id)) {
        addCheck('challenge_replay', 'Replay Protection', 'FAILED', `Challenge ID ${challenge.challenge_id} has already been used.`);
        return {
          code: VerificationResultCode.CHALLENGE_REPLAYED,
          authentic: true,
          authorized: false,
          freshnessOk: false,
          deviceBoundOk: false,
          summary: 'Challenge has already been consumed (replay attack detected).',
          checks,
          claims,
          diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
        };
      }

      if (now > challenge.expires_at) {
        addCheck('challenge_expiry', 'Challenge Expiry', 'FAILED', `Challenge expired at ${challenge.expires_at} (now: ${now})`);
        return {
          code: VerificationResultCode.CHALLENGE_EXPIRED,
          authentic: true,
          authorized: false,
          freshnessOk: false,
          deviceBoundOk: false,
          summary: 'Challenge-response window expired (60s timeout exceeded).',
          checks,
          claims,
          diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
        };
      }

      // Verify challenge signature using credential's cnf.jwk via SubtleCrypto
      try {
        const devicePubKey = await crypto.subtle.importKey(
          'jwk',
          claims.cnf.jwk,
          { name: 'ECDSA', namedCurve: 'P-256' },
          true,
          ['verify']
        );
        const nonceBytes = new TextEncoder().encode(challenge.nonce);
        const sigBytes = jose.base64url.decode(proof.signature_compact);

        const validProof = await crypto.subtle.verify(
          { name: 'ECDSA', hash: { name: 'SHA-256' } },
          devicePubKey,
          sigBytes as unknown as BufferSource,
          nonceBytes
        );

        if (!validProof) {
          addCheck('challenge_signature', 'Proof-of-Possession Signature', 'FAILED', 'Device signature over challenge nonce invalid.');
          return {
            code: VerificationResultCode.INVALID_CHALLENGE_PROOF,
            authentic: true,
            authorized: false,
            freshnessOk: false,
            deviceBoundOk: false,
            summary: 'Device failed proof-of-possession challenge.',
            checks,
            claims,
            diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
          };
        }

        this.usedChallenges.add(challenge.challenge_id);
        deviceBoundOk = true;
        addCheck('challenge_signature', 'Proof-of-Possession Signature', 'PASSED', 'Responder device successfully proved private key possession.');
      } catch (e: any) {
        addCheck('challenge_signature', 'Proof-of-Possession Signature', 'FAILED', e.message);
        return {
          code: VerificationResultCode.INVALID_CHALLENGE_PROOF,
          authentic: true,
          authorized: false,
          freshnessOk: false,
          deviceBoundOk: false,
          summary: `Proof-of-possession verification error: ${e.message}`,
          checks,
          claims,
          diagnostics: { verificationTimestamp: now, isOffline: this.isOffline },
        };
      }
    } else {
      addCheck(
        'device_proof',
        'Device Proof-of-Possession',
        'SKIPPED',
        'No interactive challenge provided; credential authenticity verified, device possession unconfirmed.'
      );
    }

    // ----------------------------------------------------
    // Step 7: Revocation Status & Freshness Policy
    // ----------------------------------------------------
    let freshnessOk = false;
    let statusSnapshotAgeSeconds = 0;
    const requestedAction = input.requestedAction || 'incident.view';
    const policy = this.actionPolicies[requestedAction] || {
      riskTier: 'HIGH',
      maxStatusAgeSeconds: 3600,
      allowedOffline: false,
      requiredPermission: requestedAction,
    };

    if (!this.statusSnapshot) {
      addCheck('revocation_status', 'Signed Status Snapshot', 'WARNING', 'No cached revocation status snapshot available on device.');
      if (this.isOffline && policy.riskTier !== 'LOW') {
        return {
          code: VerificationResultCode.INSUFFICIENT_TRUST_DATA,
          authentic: true,
          authorized: false,
          freshnessOk: false,
          deviceBoundOk,
          summary: 'Insufficient trust data: no cached revocation status for this risk tier.',
          checks,
          claims,
          diagnostics: {
            verificationTimestamp: now,
            isOffline: this.isOffline,
            riskTier: policy.riskTier,
            requestedAction,
          },
        };
      }
    } else {
      statusSnapshotAgeSeconds = Math.max(0, now - this.statusSnapshot.issued_at);
      
      // Check if credential is explicitly revoked
      const isRevoked = this.statusSnapshot.revoked_credentials.some((r) => r.credential_jti === claims.jti);
      if (isRevoked) {
        addCheck(
          'revocation_status',
          'Revocation Check',
          'FAILED',
          `Credential ${claims.jti} is explicitly listed as REVOKED in snapshot v${this.statusSnapshot.snapshot_version}`
        );
        return {
          code: VerificationResultCode.REVOKED_IN_CACHED_STATUS,
          authentic: true,
          authorized: false,
          freshnessOk: true,
          deviceBoundOk,
          summary: 'Credential has been revoked by disaster authority.',
          checks,
          claims,
          diagnostics: {
            verificationTimestamp: now,
            isOffline: this.isOffline,
            statusSnapshotAgeSeconds,
            riskTier: policy.riskTier,
          },
        };
      } else {
        addCheck('revocation_status', 'Revocation Check', 'PASSED', `Credential not revoked in snapshot v${this.statusSnapshot.snapshot_version}`);
      }

      // Freshness evaluation against action risk tier
      if (statusSnapshotAgeSeconds > policy.maxStatusAgeSeconds) {
        addCheck(
          'freshness_policy',
          'Status Freshness Tier',
          'WARNING',
          `Snapshot age (${Math.floor(statusSnapshotAgeSeconds / 60)} min) exceeds max allowable age (${Math.floor(policy.maxStatusAgeSeconds / 60)} min) for ${policy.riskTier} risk tier action "${requestedAction}"`
        );
        freshnessOk = false;

        if (policy.riskTier === 'HIGH' || policy.riskTier === 'CRITICAL' || !policy.allowedOffline) {
          return {
            code: VerificationResultCode.STATUS_STALE,
            authentic: true,
            authorized: false,
            freshnessOk: false,
            deviceBoundOk,
            summary: `Cached revocation status is stale for ${policy.riskTier} action. Reconnect mandatory.`,
            checks,
            claims,
            diagnostics: {
              verificationTimestamp: now,
              isOffline: this.isOffline,
              statusSnapshotAgeSeconds,
              riskTier: policy.riskTier,
              requestedAction,
            },
          };
        }
      } else {
        freshnessOk = true;
        addCheck('freshness_policy', 'Status Freshness Tier', 'PASSED', `Snapshot age (${Math.floor(statusSnapshotAgeSeconds / 60)} min) is within ${policy.riskTier} limit.`);
      }
    }

    // ----------------------------------------------------
    // Step 8: Authorization (Action & Permissions & Incident Scope)
    // ----------------------------------------------------
    const hasPermission = claims.permissions.includes(policy.requiredPermission);
    if (!hasPermission) {
      addCheck(
        'auth_permission',
        'Action Permission Check',
        'FAILED',
        `Subject role "${claims.role}" lacks required permission "${policy.requiredPermission}" for action "${requestedAction}"`
      );
      return {
        code: VerificationResultCode.VALID_BUT_NOT_AUTHORIZED,
        authentic: true,
        authorized: false,
        freshnessOk,
        deviceBoundOk,
        summary: `Authentic credential, but unauthorized for action "${requestedAction}".`,
        checks,
        claims,
        diagnostics: {
          verificationTimestamp: now,
          isOffline: this.isOffline,
          requestedAction,
          riskTier: policy.riskTier,
        },
      };
    } else {
      addCheck('auth_permission', 'Action Permission Check', 'PASSED', `Granted permission "${policy.requiredPermission}"`);
    }

    if (input.targetIncidentScope && input.targetIncidentScope !== claims.incident_scope) {
      addCheck(
        'auth_scope',
        'Incident Scope Check',
        'FAILED',
        `Credential scope "${claims.incident_scope}" does not match target incident "${input.targetIncidentScope}"`
      );
      return {
        code: VerificationResultCode.VALID_BUT_NOT_AUTHORIZED,
        authentic: true,
        authorized: false,
        freshnessOk,
        deviceBoundOk,
        summary: `Credential scope (${claims.incident_scope}) does not match incident zone (${input.targetIncidentScope}).`,
        checks,
        claims,
        diagnostics: { verificationTimestamp: now, isOffline: this.isOffline, requestedAction },
      };
    } else {
      addCheck('auth_scope', 'Incident Scope Check', 'PASSED', `Valid for incident ${claims.incident_scope}`);
    }

    // ----------------------------------------------------
    // Step 9: Final Success
    // ----------------------------------------------------
    return {
      code: VerificationResultCode.VALID_AND_AUTHORIZED,
      authentic: true,
      authorized: true,
      freshnessOk,
      deviceBoundOk,
      summary: `Responder credential verified and authorized for "${requestedAction}".`,
      checks,
      claims,
      diagnostics: {
        issuerKid: protectedHeader.kid,
        trustBundleVersion: this.trustBundle.bundle_version,
        statusSnapshotAgeSeconds,
        riskTier: policy.riskTier,
        requestedAction,
        verificationTimestamp: now,
        isOffline: this.isOffline,
      },
    };
  }
}

export async function verifyCredentialOffline(opts: {
  tokenJws: string;
  trustBundle?: TrustBundle;
  statusSnapshot?: SignedStatusSnapshot;
  requestedAction?: string;
  targetIncidentScope?: string;
  deviceThumbprint?: string;
  currentTime?: number;
}): Promise<{
  decision: 'PERMIT' | 'PERMIT_RESTRICTED' | 'REJECT';
  resultCode: string;
  diagnostics: string[];
  claims?: any;
}> {
  // Default bundle anchor for development/offline if none provided
  const fallbackBundle: TrustBundle = opts.trustBundle || {
    bundle_version: 1,
    issued_at: Math.floor(Date.now() / 1000) - 3600,
    expires_at: Math.floor(Date.now() / 1000) + 86400 * 90,
    root_authority_id: 'did:resqmesh:root-ca',
    keys: [],
    signature: 'INITIAL_SIG',
  };

  const verifier = new OfflineVerifier({
    clock: opts.currentTime ? () => opts.currentTime! : undefined,
    trustBundle: fallbackBundle,
    statusSnapshot: opts.statusSnapshot,
    isOffline: true,
  });

  const res = await verifier.verify({
    token: opts.tokenJws,
    requestedAction: opts.requestedAction || 'triage.record',
    targetIncidentScope: opts.targetIncidentScope,
  });

  const diagnostics = res.checks.map((c) => `[${c.status}] ${c.name}: ${c.explanation}`);

  let decision: 'PERMIT' | 'PERMIT_RESTRICTED' | 'REJECT' = 'REJECT';
  if (res.code === VerificationResultCode.VALID_AND_AUTHORIZED) {
    decision = 'PERMIT';
  } else if (res.code === VerificationResultCode.STATUS_STALE) {
    decision = 'PERMIT_RESTRICTED';
  }

  return {
    decision,
    resultCode: res.code,
    diagnostics,
    claims: res.claims,
  };
}
