import { describe, it, expect } from 'vitest';
import crypto from 'crypto';

describe('ResQMesh Authentication & Tamper-Evident Hash Chain Suite', () => {
  function hashPassword(password: string): string {
    return crypto.createHash('sha256').update(`resqmesh_salt_${password}`).digest('hex');
  }

  function verifyPassword(password: string, hash: string): boolean {
    const computed = hashPassword(password);
    return crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(hash));
  }

  function computeAuditHash(
    previousHash: string,
    seq: number,
    actor: string,
    action: string,
    resource: string,
    timestamp: number,
    outcome: string,
    correlationId: string
  ): string {
    const canonical = `${previousHash}|${seq}|${actor}|${action}|${resource}|${timestamp}|${outcome}|${correlationId}`;
    return crypto.createHash('sha256').update(canonical).digest('hex');
  }

  it('should verify correct password and reject incorrect password safely', () => {
    const rawPass = 'Citizen2026!';
    const hash = hashPassword(rawPass);

    expect(verifyPassword(rawPass, hash)).toBe(true);
    expect(verifyPassword('WrongPassword123', hash)).toBe(false);
  });

  it('should compute and verify a tamper-evident audit log hash chain', () => {
    const genesisHash = '0000000000000000000000000000000000000000000000000000000000000000';
    const now = 1730000000;

    // Block 1: Initial authority setup
    const hash1 = computeAuditHash(
      genesisHash,
      1,
      'system:genesis',
      'trust_bundle.initialize',
      'did:resqmesh:root-ca',
      now,
      'SUCCESS',
      'corr-01'
    );

    // Block 2: Credential issuance
    const hash2 = computeAuditHash(
      hash1,
      2,
      'admin@resqmesh.trust',
      'credential.issue',
      'cred-7c9e',
      now + 60,
      'SUCCESS',
      'corr-02'
    );

    expect(hash1).toHaveLength(64);
    expect(hash2).toHaveLength(64);
    expect(hash2).not.toBe(hash1);

    // Tampering test: If an attacker modifies Block 1 actor or resource
    const tamperedHash1 = computeAuditHash(
      genesisHash,
      1,
      'attacker@malicious.com', // Tampered!
      'trust_bundle.initialize',
      'did:resqmesh:root-ca',
      now,
      'SUCCESS',
      'corr-01'
    );

    // The chain verification for Block 2 will fail because parent hash does not match
    expect(tamperedHash1).not.toBe(hash1);
  });
});
