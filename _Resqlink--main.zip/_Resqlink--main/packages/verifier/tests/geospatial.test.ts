import { describe, it, expect } from 'vitest';
import {
  isPointInPolygon,
  haversineDistanceKm,
  checkHazardExposure,
  KERALA_DISTRICTS,
  PolygonCoords,
} from '../../../apps/web/lib/geospatial.ts';

describe('ResQLink Kerala — Geospatial & Digital Twin Engine', () => {
  it('should include all 14 official Kerala districts', () => {
    expect(KERALA_DISTRICTS.length).toBe(14);
    const districtNames = KERALA_DISTRICTS.map((d) => d.name);
    expect(districtNames).toContain('Thiruvananthapuram');
    expect(districtNames).toContain('Kollam');
    expect(districtNames).toContain('Pathanamthitta');
    expect(districtNames).toContain('Alappuzha');
    expect(districtNames).toContain('Kottayam');
    expect(districtNames).toContain('Idukki');
    expect(districtNames).toContain('Ernakulam');
    expect(districtNames).toContain('Thrissur');
    expect(districtNames).toContain('Palakkad');
    expect(districtNames).toContain('Malappuram');
    expect(districtNames).toContain('Kozhikode');
    expect(districtNames).toContain('Wayanad');
    expect(districtNames).toContain('Kannur');
    expect(districtNames).toContain('Kasaragod');
  });

  it('should correctly identify points inside a hazard polygon', () => {
    // Wayanad Meppadi Landslide Polygon [lng, lat]
    const polygon: PolygonCoords = [
      [76.110, 11.530],
      [76.155, 11.530],
      [76.160, 11.580],
      [76.105, 11.575],
      [76.110, 11.530],
    ];

    // Chooralmala house inside polygon (lat: 11.5545, lng: 76.1285)
    const insidePoint = { lat: 11.5545, lng: 76.1285 };
    expect(isPointInPolygon(insidePoint, polygon)).toBe(true);

    // Kalpetta town center outside polygon (lat: 11.6050, lng: 76.0820)
    const outsidePoint = { lat: 11.6050, lng: 76.0820 };
    expect(isPointInPolygon(outsidePoint, polygon)).toBe(false);
  });

  it('should evaluate hazard exposure using GeoJSON format', () => {
    const geoJson = JSON.stringify({
      type: 'Polygon',
      coordinates: [
        [
          [76.310, 10.080],
          [76.390, 10.085],
          [76.400, 10.150],
          [76.320, 10.145],
          [76.310, 10.080],
        ],
      ],
    });

    const aluvaHouse = { lat: 10.1085, lng: 76.3520 };
    expect(checkHazardExposure(aluvaHouse, geoJson)).toBe(true);

    const munnarHouse = { lat: 10.0889, lng: 77.0595 };
    expect(checkHazardExposure(munnarHouse, geoJson)).toBe(false);
  });

  it('should calculate accurate Haversine distances in km across Kerala', () => {
    // Kochi to Aluva (~18-22 km)
    const kochiLat = 9.9816, kochiLng = 76.2999;
    const aluvaLat = 10.1076, aluvaLng = 76.3516;
    const dist = haversineDistanceKm(kochiLat, kochiLng, aluvaLat, aluvaLng);
    expect(dist).toBeGreaterThan(13);
    expect(dist).toBeLessThan(20);
  });
});
