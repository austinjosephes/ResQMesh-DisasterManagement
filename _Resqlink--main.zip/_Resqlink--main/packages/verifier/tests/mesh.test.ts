import { describe, it, expect } from 'vitest';
import {
  VirtualMeshSimulator,
  createSignedMeshPacket,
  MeshPacket,
} from '../../../apps/web/lib/mesh-transport';

describe('ResQMesh Transport & Multi-Node Relay Protocol', () => {
  it('should generate a valid mesh packet with canonical SHA-256 hash', async () => {
    const packet = await createSignedMeshPacket(
      'node-citizen-01',
      'SOS_BEACON',
      { patientCount: 2, danger: true, category: 'TRAPPED' }
    );

    expect(packet.packetId).toMatch(/^pkt-/);
    expect(packet.sourceNodeId).toBe('node-citizen-01');
    expect(packet.destinationNodeId).toBe('BROADCAST');
    expect(packet.ttl).toBe(4);
    expect(packet.hopCount).toBe(0);
    expect(packet.canonicalHash).toHaveLength(64);
  });

  it('should forward a packet across virtual hops to the incident gateway', async () => {
    const simulator = VirtualMeshSimulator.getInstance();
    const packet = await createSignedMeshPacket(
      'node-citizen-01',
      'SOS_BEACON',
      { latitude: 37.7749, longitude: -122.4194 }
    );

    const hopsRecorded: number[] = [];
    const result = await simulator.simulateRelayRoute(packet, (hopNum) => {
      hopsRecorded.push(hopNum);
    });

    expect(result.delivered).toBe(true);
    expect(result.totalHops).toBe(2);
    expect(result.path).toContain('node-citizen-01');
    expect(result.path).toContain('node-volunteer-relay');
    expect(result.path).toContain('node-command-gateway');
  });

  it('should suppress duplicate packets with identical packetId', async () => {
    const simulator = VirtualMeshSimulator.getInstance();
    const packet = await createSignedMeshPacket(
      'node-citizen-01',
      'SOS_BEACON',
      { seq: 101 }
    );

    const firstRun = await simulator.simulateRelayRoute(packet);
    expect(firstRun.delivered).toBe(true);

    // Second delivery of same packet should be suppressed
    const secondRun = await simulator.simulateRelayRoute(packet);
    expect(secondRun.delivered).toBe(false);
  });
});
