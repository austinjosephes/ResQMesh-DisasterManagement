import { describe, it, expect } from 'vitest';
import { calculateRescuePriority } from '../../../apps/web/lib/priority-engine.ts';

describe('ResQLink Kerala — Rescue Priority Engine', () => {
  it('should score critical life-threatening situations with maximum urgency', () => {
    const result = calculateRescuePriority({
      category: 'LANDSLIDE',
      peopleCount: 6,
      hasInjuries: true,
      immediateDanger: true,
      locationConfidence: 0.95,
      accessibilityNeeds: 'Elderly bedridden patient with oxygen cylinder',
      reportedAt: new Date(Date.now() - 40 * 60 * 1000), // 40 mins ago
    });

    expect(result.priorityCategory).toBe('CRITICAL');
    expect(result.totalScore).toBeGreaterThanOrEqual(75);
    expect(result.requiresVerification).toBe(false);
    expect(result.breakdown.threatScore).toBeGreaterThan(0);
    expect(result.breakdown.vulnerabilityBonus).toBe(10);
    expect(result.breakdown.reasons.length).toBeGreaterThan(3);
  });

  it('should flag low-confidence locations as NEEDS_VERIFICATION', () => {
    const result = calculateRescuePriority({
      category: 'FLOOD',
      peopleCount: 2,
      hasInjuries: false,
      immediateDanger: false,
      locationConfidence: 0.25, // Very coarse triangulation
      accessibilityNeeds: null,
      reportedAt: new Date(Date.now() - 10 * 60 * 1000),
    });

    expect(result.priorityCategory).toBe('NEEDS_VERIFICATION');
    expect(result.requiresVerification).toBe(true);
    expect(result.breakdown.reasons[0]).toContain('Low-confidence location triggers mandatory operator verification');
  });

  it('should increase priority score as waiting time elapses', () => {
    const recentReport = calculateRescuePriority({
      category: 'FLOOD',
      peopleCount: 2,
      hasInjuries: false,
      immediateDanger: false,
      locationConfidence: 0.9,
      accessibilityNeeds: null,
      reportedAt: new Date(Date.now() - 5 * 60 * 1000), // 5 mins ago
    });

    const delayedReport = calculateRescuePriority({
      category: 'FLOOD',
      peopleCount: 2,
      hasInjuries: false,
      immediateDanger: false,
      locationConfidence: 0.9,
      accessibilityNeeds: null,
      reportedAt: new Date(Date.now() - 150 * 60 * 1000), // 150 mins ago
    });

    expect(delayedReport.breakdown.waitTimeScore).toBeGreaterThan(recentReport.breakdown.waitTimeScore);
    expect(delayedReport.totalScore).toBeGreaterThan(recentReport.totalScore);
  });
});
