import { describe, it, expect } from 'vitest';
import {
  SimulatedSmsAdapter,
  formatKeralaAlertSms,
  getRetryBackoffMs,
} from '../../../apps/web/lib/sms-adapter.ts';

describe('ResQLink Kerala — Adaptive Alert Delivery Intelligence', () => {
  it('should format Indian Telecom DLT compliant SMS messages in English', () => {
    const formatted = formatKeralaAlertSms({
      area: 'Meppadi, Wayanad',
      hazardType: 'Landslide',
      authority: 'KSDMA',
      issuedTime: '06:00 PM',
      expiryTime: 'Tomorrow 10:00 AM',
      language: 'en',
    });

    expect(formatted.dltTemplateId).toBe('DLT_KL_DISASTER_EMG_EN_1001');
    expect(formatted.body).toContain('RESQLINK KERALA');
    expect(formatted.body).toContain('Meppadi, Wayanad');
    expect(formatted.body).toContain('KSDMA');
  });

  it('should format Indian Telecom DLT compliant SMS messages in Malayalam', () => {
    const formatted = formatKeralaAlertSms({
      area: 'ആലുവ, എറണാകുളം',
      hazardType: 'വെള്ളപ്പൊക്കം',
      authority: 'കെ.എസ്.ഡി.എം.എ',
      issuedTime: '04:00 PM',
      expiryTime: 'നാളെ 08:00 AM',
      language: 'ml',
    });

    expect(formatted.dltTemplateId).toBe('DLT_KL_DISASTER_EMG_ML_1007');
    expect(formatted.body).toContain('റെസ്ക്യൂലിങ്ക് കേരളം');
    expect(formatted.body).toContain('ആലുവ, എറണാകുളം');
  });

  it('should calculate exponential backoff with bounded upper limit', () => {
    const delay0 = getRetryBackoffMs(0);
    const delay1 = getRetryBackoffMs(1);
    const delay2 = getRetryBackoffMs(2);
    const delay10 = getRetryBackoffMs(10);

    expect(delay0).toBeGreaterThanOrEqual(2000);
    expect(delay1).toBeGreaterThan(delay0);
    expect(delay2).toBeGreaterThan(delay1);
    // Bounded at 60,000ms max
    expect(delay10).toBeLessThanOrEqual(60000);
  });

  it('should simulate SMS submission without falsely claiming immediate delivery', async () => {
    const adapter = new SimulatedSmsAdapter();
    const result = await adapter.send('+919847256789', 'Test Emergency Warning');

    expect(result.latencyMs).toBeGreaterThan(0);
    if (result.success) {
      // Must be SUBMITTED to carrier, not prematurely claimed as DELIVERED
      expect(result.status).toBe('SUBMITTED');
      expect(result.providerMsgId).toContain('DLT_KER');
    } else {
      expect(result.status).toBe('FAILED');
    }
  });
});
