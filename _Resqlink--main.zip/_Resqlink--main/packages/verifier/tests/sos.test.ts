import { describe, it, expect } from 'vitest';
import crypto from 'crypto';

describe('Emergency SOS Life-Cycle & Priority Calculation Suite', () => {
  function calculateSOSPriority(hasImmediateDanger: boolean, hasInjuries: boolean, peopleCount: number): string {
    if (hasImmediateDanger) return 'CRITICAL';
    if (hasInjuries || peopleCount > 5) return 'HIGH';
    return 'MEDIUM';
  }

  function createOfflineSOSEvent(data: {
    trackingNumber: string;
    category: string;
    description: string;
    hasInjuries: boolean;
    immediateDanger: boolean;
    peopleCount: number;
  }) {
    const priority = calculateSOSPriority(data.immediateDanger, data.hasInjuries, data.peopleCount);
    const payloadJson = JSON.stringify(data);
    const payloadHash = crypto.createHash('sha256').update(payloadJson).digest('hex');

    return {
      trackingNumber: data.trackingNumber,
      priority,
      status: 'QUEUED_LOCAL',
      payloadJson,
      payloadHash,
      createdAt: Date.now(),
    };
  }

  it('should elevate immediate danger to CRITICAL priority', () => {
    const priority = calculateSOSPriority(true, false, 1);
    expect(priority).toBe('CRITICAL');
  });

  it('should elevate reported injuries to HIGH priority', () => {
    const priority = calculateSOSPriority(false, true, 2);
    expect(priority).toBe('HIGH');
  });

  it('should elevate large casualty group (>5 people) to HIGH priority', () => {
    const priority = calculateSOSPriority(false, false, 8);
    expect(priority).toBe('HIGH');
  });

  it('should default minor hazard to MEDIUM priority', () => {
    const priority = calculateSOSPriority(false, false, 2);
    expect(priority).toBe('MEDIUM');
  });

  it('should produce immutable SHA-256 payload hash for tamper detection', () => {
    const record = createOfflineSOSEvent({
      trackingNumber: 'SOS-2026-9901',
      category: 'MEDICAL',
      description: 'Laceration bleeding heavily',
      hasInjuries: true,
      immediateDanger: false,
      peopleCount: 1,
    });

    expect(record.status).toBe('QUEUED_LOCAL');
    expect(record.priority).toBe('HIGH');
    expect(record.payloadHash).toHaveLength(64);

    // Modifying description should invalidate hash
    const tamperedPayload = JSON.stringify({
      trackingNumber: 'SOS-2026-9901',
      category: 'MEDICAL',
      description: 'TAMPERED DESCRIPTION',
      hasInjuries: true,
      immediateDanger: false,
      peopleCount: 1,
    });
    const tamperedHash = crypto.createHash('sha256').update(tamperedPayload).digest('hex');
    expect(tamperedHash).not.toBe(record.payloadHash);
  });
});
