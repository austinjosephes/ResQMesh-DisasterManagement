import { describe, it, expect, beforeAll } from 'vitest';
import * as jose from 'jose';
import { OfflineVerifier } from '../src/index';
import {
  VerificationResultCode,
  TrustBundle,
  SignedStatusSnapshot,
  CredentialClaims,
  ChallengePayload,
} from '@resqmesh/shared';

describe('OfflineVerifier Engine Suite', () => {
  let issuerKeyPair: jose.GenerateKeyPairResult;
  let issuerKid: string;
  let issuerPublicKeyJwk: any;
  let trustBundle: TrustBundle;
  let validStatusSnapshot: SignedStatusSnapshot;
  let deviceCryptoKeyPair: CryptoKeyPair;
  let devicePublicKeyJwk: any;
  let deviceThumbprint: string;

  beforeAll(async () => {
    // Generate Issuer Key Pair (ES256)
    issuerKeyPair = await jose.generateKeyPair('ES256', { extractable: true });
    issuerKid = 'issuer-test-alpha-2026';
    issuerPublicKeyJwk = await jose.exportJWK(issuerKeyPair.publicKey);
    issuerPublicKeyJwk.kid = issuerKid;

    const now = Math.floor(Date.now() / 1000);

    trustBundle = {
      bundle_version: 1,
      issued_at: now - 3600,
      expires_at: now + 86400 * 30,
      root_authority_id: 'did:resqmesh:root-ca',
      keys: [
        {
          kid: issuerKid,
          issuer: 'did:resqmesh:issuer:federal-ca',
          publicKeyJwk: issuerPublicKeyJwk,
          validFrom: now - 86400,
          validUntil: now + 86400 * 30,
          status: 'ACTIVE',
        },
      ],
      signature: 'dummy-bundle-sig',
    };

    validStatusSnapshot = {
      snapshot_version: 1,
      issued_at: now - 300,
      issuer_kid: issuerKid,
      revoked_credentials: [],
      signature: 'valid-snapshot-sig',
    };

    // Generate Device Key Pair via WebCrypto API
    deviceCryptoKeyPair = (await crypto.subtle.generateKey(
      { name: 'ECDSA', namedCurve: 'P-256' },
      true,
      ['sign', 'verify']
    )) as CryptoKeyPair;

    devicePublicKeyJwk = await crypto.subtle.exportKey('jwk', deviceCryptoKeyPair.publicKey);
    deviceThumbprint = await jose.calculateJwkThumbprint(devicePublicKeyJwk, 'sha256');
  });

  async function createTestCredential(overrides: Partial<CredentialClaims> = {}, headerOverrides: any = {}) {
    const now = Math.floor(Date.now() / 1000);
    const claims: CredentialClaims = {
      jti: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
      iss: 'did:resqmesh:issuer:federal-ca',
      sub: 'responder-charlie-9',
      iat: now - 60,
      nbf: now - 60,
      exp: now + 3600,
      role: 'PARAMEDIC_TIER_2',
      permissions: ['incident.view', 'triage.record', 'medication.administer.basic'],
      incident_scope: 'INCIDENT-SEATTLE-QUAKE',
      credential_version: '1.0',
      policy_version: '2026.1',
      status: { status_list_id: 'sl-1', status_list_index: 10 },
      cnf: {
        jwk_thumbprint: deviceThumbprint,
        jwk: devicePublicKeyJwk,
      },
      ...overrides,
    };

    const header = {
      alg: 'ES256',
      typ: 'application/resqmesh-credential+jwt',
      kid: issuerKid,
      ...headerOverrides,
    };

    const token = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(claims)))
      .setProtectedHeader(header)
      .sign(issuerKeyPair.privateKey);

    return { token, claims };
  }

  it('1. Validates an authentic and authorized credential with cached status', async () => {
    const { token } = await createTestCredential();
    const verifier = new OfflineVerifier({
      trustBundle,
      statusSnapshot: validStatusSnapshot,
      isOffline: true,
    });
    const result = await verifier.verify({ token, requestedAction: 'triage.record' });

    expect(result.code).toBe(VerificationResultCode.VALID_AND_AUTHORIZED);
    expect(result.authentic).toBe(true);
    expect(result.authorized).toBe(true);
    expect(result.checks.find((c) => c.id === 'crypto_signature')?.status).toBe('PASSED');
  });

  it('2. Detects altered credential payload (invalid signature)', async () => {
    const { token } = await createTestCredential();
    const parts = token.split('.');
    // Tamper with payload
    const decoded = JSON.parse(new TextDecoder().decode(jose.base64url.decode(parts[1])));
    decoded.role = 'INCIDENT_COMMANDER';
    decoded.permissions.push('commander.delegate');
    const tamperedPayload = jose.base64url.encode(JSON.stringify(decoded));
    const tamperedToken = `${parts[0]}.${tamperedPayload}.${parts[2]}`;

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({ token: tamperedToken });

    expect(result.code).toBe(VerificationResultCode.INVALID_SIGNATURE);
    expect(result.authentic).toBe(false);
  });

  it('3. Rejects unknown issuer not present in trust bundle', async () => {
    const otherKeyPair = await jose.generateKeyPair('ES256');
    const { claims } = await createTestCredential();
    const token = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(claims)))
      .setProtectedHeader({ alg: 'ES256', kid: 'unknown-rogue-key' })
      .sign(otherKeyPair.privateKey);

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({ token });

    expect(result.code).toBe(VerificationResultCode.UNKNOWN_ISSUER);
    expect(result.authentic).toBe(false);
  });

  it('4. Rejects expired credential', async () => {
    const now = Math.floor(Date.now() / 1000);
    const { token } = await createTestCredential({
      exp: now - 300, // Expired 5 minutes ago
    });

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({ token });

    expect(result.code).toBe(VerificationResultCode.EXPIRED);
    expect(result.authentic).toBe(true);
    expect(result.authorized).toBe(false);
  });

  it('5. Rejects not yet valid credential', async () => {
    const now = Math.floor(Date.now() / 1000);
    const { token } = await createTestCredential({
      nbf: now + 500, // Valid 500s into future
    });

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({ token });

    expect(result.code).toBe(VerificationResultCode.NOT_YET_VALID);
    expect(result.authentic).toBe(true);
    expect(result.authorized).toBe(false);
  });

  it('6. Rejects thumbprint mismatch for forged device key', async () => {
    const otherDeviceKey = await jose.generateKeyPair('ES256');
    const otherPubJwk: any = await jose.exportJWK(otherDeviceKey.publicKey);

    const { token } = await createTestCredential({
      cnf: {
        jwk_thumbprint: 'SHA256:FAKE-THUMBPRINT-DOESNT-MATCH',
        jwk: otherPubJwk,
      },
    });

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({ token });

    expect(result.code).toBe(VerificationResultCode.DEVICE_MISMATCH);
    expect(result.deviceBoundOk).toBe(false);
  });

  it('7. Enforces challenge-response and rejects replayed challenges', async () => {
    const { token, claims } = await createTestCredential();
    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const now = Math.floor(Date.now() / 1000);

    const challenge: ChallengePayload = {
      challenge_id: 'urn:uuid:11111111-2222-3333-4444-555555555555',
      nonce: 'f4b1a8c9e0d2c5b3a4f6e8d0c2b4a6f8',
      verifier_id: 'verifier-mobile-station-1',
      audience: 'resqmesh:verification',
      issued_at: now,
      expires_at: now + 60,
    };

    // Responder device signs challenge nonce using WebCrypto CryptoKey
    const nonceBytes = new TextEncoder().encode(challenge.nonce);
    const signatureBytes = await crypto.subtle.sign(
      { name: 'ECDSA', hash: { name: 'SHA-256' } },
      deviceCryptoKeyPair.privateKey,
      nonceBytes
    );
    const signatureCompact = jose.base64url.encode(new Uint8Array(signatureBytes));

    const proof = {
      challenge_id: challenge.challenge_id,
      responder_sub: claims.sub,
      device_thumbprint: deviceThumbprint,
      signature_compact: signatureCompact,
    };

    // First attempt: valid
    const firstResult = await verifier.verify({
      token,
      challenge,
      challengeProof: proof,
    });
    expect(firstResult.code).toBe(VerificationResultCode.VALID_AND_AUTHORIZED);
    expect(firstResult.deviceBoundOk).toBe(true);

    // Second attempt: replay should be blocked
    const replayResult = await verifier.verify({
      token,
      challenge,
      challengeProof: proof,
    });
    expect(replayResult.code).toBe(VerificationResultCode.CHALLENGE_REPLAYED);
  });

  it('8. Evaluates revoked status in cached snapshot', async () => {
    const { token, claims } = await createTestCredential();
    const now = Math.floor(Date.now() / 1000);

    const statusSnapshot: SignedStatusSnapshot = {
      snapshot_version: 12,
      issued_at: now - 300,
      issuer_kid: issuerKid,
      revoked_credentials: [
        {
          credential_jti: claims.jti,
          revoked_at: now - 600,
          reason: 'Compromised device during rescue',
        },
      ],
      signature: 'valid-signed-snapshot-sig',
    };

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot });
    const result = await verifier.verify({ token });

    expect(result.code).toBe(VerificationResultCode.REVOKED_IN_CACHED_STATUS);
    expect(result.authentic).toBe(true);
    expect(result.authorized).toBe(false);
  });

  it('9. Enforces authorization policies (valid but unauthorized)', async () => {
    const { token } = await createTestCredential({
      permissions: ['incident.view'], // lacks 'perimeter.cross.restricted'
    });

    const verifier = new OfflineVerifier({ trustBundle, statusSnapshot: validStatusSnapshot });
    const result = await verifier.verify({
      token,
      requestedAction: 'perimeter.cross.restricted',
    });

    expect(result.code).toBe(VerificationResultCode.VALID_BUT_NOT_AUTHORIZED);
    expect(result.authentic).toBe(true);
    expect(result.authorized).toBe(false);
  });

  it('10. Detects clock rollback via high-water mark', async () => {
    const { token } = await createTestCredential();
    const fixedNow = 1700000000;
    const highWaterMark = 1700050000; // High-water mark is 50,000s ahead of device clock

    const verifier = new OfflineVerifier({
      trustBundle,
      statusSnapshot: validStatusSnapshot,
      clock: () => fixedNow,
      highWaterMark,
    });

    const result = await verifier.verify({ token });
    expect(result.code).toBe(VerificationResultCode.CLOCK_ANOMALY);
  });

  it('11. Rejects trust bundle rollback to an older or equal version', () => {
    const verifier = new OfflineVerifier({ trustBundle });
    const olderBundle = { ...trustBundle, bundle_version: 1 };
    const res = verifier.updateTrustBundle(olderBundle);

    expect(res.success).toBe(false);
    expect(res.reason).toContain('Rollback rejected');
  });
});
