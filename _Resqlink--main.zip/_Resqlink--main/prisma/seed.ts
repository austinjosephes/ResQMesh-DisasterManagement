import { PrismaClient } from '@prisma/client';
import * as jose from 'jose';
import * as crypto from 'crypto';

const prisma = new PrismaClient();

// Helper to hash password
function hashPassword(password: string): string {
  // Simple sha256 + salt for local demonstration
  return crypto.createHash('sha256').update(`resqmesh_salt_${password}`).digest('hex');
}

// Helper to compute audit hash
function computeAuditHash(
  previousHash: string,
  seq: number,
  actor: string,
  action: string,
  resource: string,
  timestamp: number,
  outcome: string,
  correlationId: string
): string {
  const canonical = `${previousHash}|${seq}|${actor}|${action}|${resource}|${timestamp}|${outcome}|${correlationId}`;
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

async function main() {
  console.log('Seeding ResQMesh Trust database...');

  // 1. Clear existing records cleanly
  await prisma.auditLog.deleteMany();
  await prisma.offlineEvent.deleteMany();
  await prisma.verificationRecord.deleteMany();
  await prisma.revocation.deleteMany();
  await prisma.signedStatusSnapshot.deleteMany();
  await prisma.trustBundleRecord.deleteMany();
  await prisma.credentialLifecycleHistory.deleteMany();
  await prisma.credential.deleteMany();
  await prisma.device.deleteMany();
  await prisma.session.deleteMany();
  await prisma.user.deleteMany();

  // 2. Create Users
  const adminUser = await prisma.user.create({
    data: {
      email: 'admin@resqmesh.trust',
      name: 'Commander Sarah Vance',
      passwordHash: hashPassword('Admin2026!ResQ'),
      role: 'ADMIN',
    },
  });

  const responderUser = await prisma.user.create({
    data: {
      email: 'responder@resqmesh.trust',
      name: 'EMT Jordan Rivera',
      passwordHash: hashPassword('Responder2026!'),
      role: 'RESPONDER',
    },
  });

  const verifierUser = await prisma.user.create({
    data: {
      email: 'verifier@resqmesh.trust',
      name: 'Inspector Blake Chen',
      passwordHash: hashPassword('Verifier2026!'),
      role: 'VERIFIER',
    },
  });

  // 3. Generate Development Issuer Key Pair (ES256)
  const issuerKeyPair = await jose.generateKeyPair('ES256', { extractable: true });
  const issuerKid = 'issuer-fema-alpha-2026';
  const issuerPubKeyJwk = await jose.exportJWK(issuerKeyPair.publicKey);
  issuerPubKeyJwk.kid = issuerKid;
  const issuerPrivKeyJwk = await jose.exportJWK(issuerKeyPair.privateKey);

  const now = Math.floor(Date.now() / 1000);

  // 4. Create Initial Trust Bundle Record
  const trustBundleData = {
    bundle_version: 1,
    issued_at: now - 3600,
    expires_at: now + 86400 * 90,
    root_authority_id: 'did:resqmesh:root-ca',
    keys: [
      {
        kid: issuerKid,
        issuer: 'did:resqmesh:issuer:federal-fema-ca',
        publicKeyJwk: issuerPubKeyJwk,
        validFrom: now - 86400,
        validUntil: now + 86400 * 90,
        status: 'ACTIVE',
      },
    ],
    signature: 'INITIAL_ROOT_ANCHOR_SIG_ES256',
  };

  await prisma.trustBundleRecord.create({
    data: {
      version: 1,
      issuedAt: trustBundleData.issued_at,
      expiresAt: trustBundleData.expires_at,
      rootAuthorityId: trustBundleData.root_authority_id,
      bundleJson: JSON.stringify(trustBundleData),
      signature: trustBundleData.signature,
    },
  });

  // 5. Generate Device Key Pair for Responder Jordan Rivera
  const deviceKeyPair = await jose.generateKeyPair('ES256', { extractable: true });
  const devicePubKeyJwk = await jose.exportJWK(deviceKeyPair.publicKey);
  const deviceThumbprint = await jose.calculateJwkThumbprint(devicePubKeyJwk, 'sha256');

  const responderDevice = await prisma.device.create({
    data: {
      userId: responderUser.id,
      responderSub: 'resq-resp-8842-bravo',
      deviceThumbprint: deviceThumbprint,
      publicKeyJwk: JSON.stringify(devicePubKeyJwk),
      status: 'ENROLLED',
    },
  });

  // 6. Issue Active Credential for Responder Jordan Rivera
  const credentialJti = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
  const permissions = [
    'incident.view',
    'triage.read',
    'triage.record',
    'report.submit',
    'medication.administer.basic',
    'perimeter.cross.restricted',
  ];

  const claims = {
    jti: credentialJti,
    iss: 'did:resqmesh:issuer:federal-fema-ca',
    sub: 'resq-resp-8842-bravo',
    iat: now - 3600,
    nbf: now - 3600,
    exp: now + 86400 * 3, // Valid 3 days
    role: 'PARAMEDIC_TIER_2',
    permissions,
    incident_scope: 'INCIDENT-CASCADE-QUAKE-2026',
    credential_version: '1.0',
    policy_version: '2026.1',
    status: {
      status_list_id: 'sl-2026-10',
      status_list_index: 428,
    },
    cnf: {
      jwk_thumbprint: deviceThumbprint,
      jwk: devicePubKeyJwk,
    },
  };

  const header = {
    alg: 'ES256',
    typ: 'application/resqmesh-credential+jwt',
    kid: issuerKid,
  };

  const tokenJws = await new jose.CompactSign(new TextEncoder().encode(JSON.stringify(claims)))
    .setProtectedHeader(header)
    .sign(issuerKeyPair.privateKey);

  const cred = await prisma.credential.create({
    data: {
      jti: credentialJti,
      sub: claims.sub,
      iss: claims.iss,
      kid: issuerKid,
      role: claims.role,
      permissionsJson: JSON.stringify(permissions),
      incidentScope: claims.incident_scope,
      iat: claims.iat,
      nbf: claims.nbf,
      exp: claims.exp,
      status: 'ACTIVE',
      cnfThumbprint: deviceThumbprint,
      tokenJws,
    },
  });

  await prisma.credentialLifecycleHistory.create({
    data: {
      credentialId: cred.id,
      state: 'ACTIVE',
      changedBy: 'admin@resqmesh.trust',
      reason: 'Initial deployment credential issuance for Cascade Quake response.',
    },
  });

  // 7. Seed Revocation Record & Signed Status Snapshot
  const sampleRevokedJti = '11111111-2222-3333-4444-555555555555';
  await prisma.revocation.create({
    data: {
      credentialJti: sampleRevokedJti,
      revokedAt: now - 1800,
      reason: 'Reported lost radio pack and responder device in Sector 4',
      issuerKid: issuerKid,
    },
  });

  const statusSnapshotData = {
    snapshot_version: 1,
    issued_at: now - 600, // 10 minutes ago
    issuer_kid: issuerKid,
    revoked_credentials: [
      {
        credential_jti: sampleRevokedJti,
        revoked_at: now - 1800,
        reason: 'Reported lost radio pack and responder device in Sector 4',
      },
    ],
    signature: 'SNAPSHOT_SIG_ES256',
  };

  await prisma.signedStatusSnapshot.create({
    data: {
      version: 1,
      issuedAt: statusSnapshotData.issued_at,
      issuerKid: issuerKid,
      snapshotJson: JSON.stringify(statusSnapshotData),
      signature: statusSnapshotData.signature,
    },
  });

  // 8. Seed Genesis Audit Logs with Tamper-Evident SHA-256 Hash Chain
  const genesisHash = '0000000000000000000000000000000000000000000000000000000000000000';
  const corr1 = 'genesis-init-001';
  const hash1 = computeAuditHash(genesisHash, 1, 'system:genesis', 'trust_bundle.initialize', 'did:resqmesh:root-ca', now - 3600, 'SUCCESS', corr1);

  await prisma.auditLog.create({
    data: {
      sequence: 1,
      actor: 'system:genesis',
      action: 'trust_bundle.initialize',
      resource: 'did:resqmesh:root-ca',
      timestamp: now - 3600,
      outcome: 'SUCCESS',
      reason: 'Root authority trust anchor deployed with version 1 bundle.',
      correlationId: corr1,
      previousHash: genesisHash,
      currentHash: hash1,
    },
  });

  const corr2 = 'issuance-001';
  const hash2 = computeAuditHash(hash1, 2, 'admin@resqmesh.trust', 'credential.issue', credentialJti, now - 3500, 'SUCCESS', corr2);

  await prisma.auditLog.create({
    data: {
      sequence: 2,
      actor: 'admin@resqmesh.trust',
      action: 'credential.issue',
      resource: credentialJti,
      timestamp: now - 3500,
      outcome: 'SUCCESS',
      reason: `Issued PARAMEDIC_TIER_2 credential to ${claims.sub}`,
      correlationId: corr2,
      previousHash: hash1,
      currentHash: hash2,
    },
  });

  // 9. Seed Sample Offline Event in Review Queue (for testing Admin Command Review screen)
  await prisma.offlineEvent.create({
    data: {
      eventId: '22222222-3333-4444-5555-666666666666',
      deviceId: responderDevice.id,
      credentialJti: credentialJti,
      sequenceNumber: 1,
      previousEventHash: genesisHash,
      eventType: 'triage.recorded',
      payloadJson: JSON.stringify({ patientId: 'PT-9942', triageCategory: 'RED_IMMEDIATE', sector: 'Sector 4 Collapse Zone' }),
      payloadHash: crypto.createHash('sha256').update(JSON.stringify({ patientId: 'PT-9942', triageCategory: 'RED_IMMEDIATE', sector: 'Sector 4 Collapse Zone' })).digest('hex'),
      createdAtClient: now - 1200,
      deviceSignature: 'SIMULATED_DEVICE_SIG_ECDSA_P256',
      syncStatus: 'NEEDS_REVIEW',
      reviewReason: 'Submitted while cached status age was within warning margin; human confirmation recommended.',
    },
  });

  console.log('Seeding completed successfully!');
  console.log(`- Admin account: admin@resqmesh.trust / Admin2026!ResQ`);
  console.log(`- Responder account: responder@resqmesh.trust / Responder2026!`);
  console.log(`- Verifier account: verifier@resqmesh.trust / Verifier2026!`);
  console.log(`- Active credential JTI: ${credentialJti}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
