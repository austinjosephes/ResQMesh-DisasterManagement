const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');

const OUT_DIR = path.resolve(__dirname, '..', 'screenshots');
if (!fs.existsSync(OUT_DIR)) {
  fs.mkdirSync(OUT_DIR, { recursive: true });
}

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CITIZEN_URL = 'https://resqlink-citizen-portal.vercel.app';
const ADMIN_URL = 'https://resqlink-admin-command.vercel.app';

async function capture() {
  console.log('Starting High-Resolution Image Capture Suite...');
  const browser = await puppeteer.launch({
    executablePath: EDGE_PATH,
    args: [
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--hide-scrollbars',
      '--window-size=1920,1080'
    ],
    headless: 'new'
  });

  const page = await browser.newPage();
  // 4K Ultra-sharp capture with deviceScaleFactor 2
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 2 });

  // 1. Citizen Home Landing
  console.log('Capturing 01_citizen_home_landing.png...');
  await page.goto(CITIZEN_URL, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2500));
  await page.screenshot({ path: path.join(OUT_DIR, '01_citizen_home_landing.png'), fullPage: false });

  // 2. Citizen Registration / Quick Profile Modal
  console.log('Capturing 02_citizen_quick_registration_modal.png...');
  // Click on "Verify Profile" or "Update Profile" or trigger the enrollment modal
  try {
    const modalBtn = await page.$('button[data-modal-trigger="enrollment"], button:has-text("Verify Profile"), button:has-text("Update Profile"), button:has-text("Profile")');
    if (modalBtn) {
      await modalBtn.click();
      await new Promise(r => setTimeout(r, 1000));
    } else {
      // Evaluate click on profile button if present
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const target = btns.find(b => b.textContent.includes('Profile') || b.textContent.includes('Register') || b.textContent.includes('Resident'));
        if (target) target.click();
      });
      await new Promise(r => setTimeout(r, 1000));
    }
  } catch (e) {
    console.log('Modal trigger fallback:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '02_citizen_quick_registration_modal.png'), fullPage: false });

  // 3. Emergency SOS Request Intake
  console.log('Capturing 03_citizen_sos_emergency_intake.png...');
  await page.goto(`${CITIZEN_URL}/portal/sos/new`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '03_citizen_sos_emergency_intake.png'), fullPage: false });

  // 4. Hazard Alerts & Early Warning
  console.log('Capturing 04_citizen_hazard_alerts_early_warning.png...');
  await page.goto(`${CITIZEN_URL}/resident/alerts`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '04_citizen_hazard_alerts_early_warning.png'), fullPage: false });

  // 5. Interactive Kerala GIS Tactical Map
  console.log('Capturing 05_citizen_interactive_tactical_map.png...');
  await page.goto(`${CITIZEN_URL}/portal/map`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2500));
  await page.screenshot({ path: path.join(OUT_DIR, '05_citizen_interactive_tactical_map.png'), fullPage: false });

  // 6. Citizen Live Activity & Status Tracking
  console.log('Capturing 06_citizen_live_activity_tracking.png...');
  await page.goto(`${CITIZEN_URL}/portal/activity`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '06_citizen_live_activity_tracking.png'), fullPage: false });

  // 7. Network-Loss Survival Mode
  console.log('Capturing 07_citizen_offline_mesh_survival.png...');
  await page.goto(`${CITIZEN_URL}/portal/offline`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '07_citizen_offline_mesh_survival.png'), fullPage: false });

  // 8. Digital Identity & Device Verification
  console.log('Capturing 08_citizen_digital_identity_token.png...');
  await page.goto(`${CITIZEN_URL}/portal/identity`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '08_citizen_digital_identity_token.png'), fullPage: false });

  // 9. SEOC Admin Command Overview
  console.log('Capturing 09_seoc_admin_command_overview.png...');
  await page.goto(`${ADMIN_URL}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2500));
  await page.screenshot({ path: path.join(OUT_DIR, '09_seoc_admin_command_overview.png'), fullPage: false });

  // 10. SEOC Incident Management & Scoring
  console.log('Capturing 10_seoc_admin_incident_triage.png...');
  await page.goto(`${ADMIN_URL}/admin/incidents`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2500));
  await page.screenshot({ path: path.join(OUT_DIR, '10_seoc_admin_incident_triage.png'), fullPage: false });

  // 11. Full-page panoramic capture of Citizen Portal
  console.log('Capturing 11_citizen_portal_fullpage_panoramic.png...');
  await page.goto(CITIZEN_URL, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '11_citizen_portal_fullpage_panoramic.png'), fullPage: true });

  await browser.close();
  console.log('All high-resolution screenshots captured successfully!');
}

capture().catch(err => {
  console.error('Fatal capture error:', err);
  process.exit(1);
});
