const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');

const OUT_DIR = path.resolve(__dirname, '..', 'screenshots');
const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CITIZEN_URL = 'https://resqlink-citizen-portal.vercel.app';
const ADMIN_URL = 'https://resqlink-admin-command.vercel.app';

async function captureDeepViews() {
  console.log('Capturing deep views and authenticated admin dashboard...');
  const browser = await puppeteer.launch({
    executablePath: EDGE_PATH,
    args: [
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--hide-scrollbars',
      '--window-size=1920,1080'
    ],
    headless: 'new'
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 2 });

  // 1. Citizen Landing - Unobstructed Hero (dismiss location modal)
  console.log('Capturing 01b_citizen_hero_unobstructed.png...');
  await page.goto(CITIZEN_URL, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  try {
    // Click close 'x' or select district
    await page.evaluate(() => {
      const closeBtn = document.querySelector('button[aria-label="Close"], button svg.lucide-x');
      if (closeBtn) {
        closeBtn.closest('button').click();
      } else {
        const btns = Array.from(document.querySelectorAll('button'));
        const xBtn = btns.find(b => b.textContent.includes('Select District') || b.textContent.includes('×') || b.querySelector('svg'));
        if (xBtn) xBtn.click();
      }
    });
    await new Promise(r => setTimeout(r, 1500));
  } catch (e) {
    console.log('Modal dismiss notice:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '01b_citizen_hero_unobstructed.png') });

  // 2. Citizen Identity Enrollment Form
  console.log('Capturing 02b_citizen_enrollment_form.png...');
  await page.goto(`${CITIZEN_URL}/portal/identity`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(OUT_DIR, '02b_citizen_enrollment_form.png') });

  // 3. Admin SEOC - Authenticate and enter Command Dashboard
  console.log('Authenticating into SEOC Command Center...');
  await page.goto(`${ADMIN_URL}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 2000));
  try {
    // Click "Quick Duty Clear (SEOC-KERALA-2026-HQ)" or type into input
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const quickBtn = btns.find(b => b.textContent.includes('SEOC-KERALA-2026-HQ') || b.textContent.includes('Quick Duty Clear'));
      if (quickBtn) {
        quickBtn.click();
      } else {
        const input = document.querySelector('input[type="password"], input[type="text"]');
        if (input) {
          input.value = 'SEOC-KERALA-2026-HQ';
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    });
    await new Promise(r => setTimeout(r, 800));

    // Click "VERIFY ADMIN SECURITY CLEARANCE"
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const verifyBtn = btns.find(b => b.textContent.includes('VERIFY ADMIN') || b.textContent.includes('CLEARANCE'));
      if (verifyBtn) verifyBtn.click();
    });
    await new Promise(r => setTimeout(r, 3000));
  } catch (e) {
    console.log('Auth click notice:', e.message);
  }

  console.log('Capturing 09b_seoc_admin_command_dashboard.png...');
  await page.screenshot({ path: path.join(OUT_DIR, '09b_seoc_admin_command_dashboard.png') });

  // 4. Admin Direct Multi-Channel Dispatch (SMS, Email, Phone)
  console.log('Capturing 12_seoc_admin_multichannel_dispatch.png...');
  try {
    await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a, button'));
      const dispatchLink = links.find(l => l.textContent.includes('Direct Dispatch') || l.textContent.includes('SMS'));
      if (dispatchLink) dispatchLink.click();
    });
    await new Promise(r => setTimeout(r, 2500));
  } catch (e) {
    console.log('Dispatch navigation notice:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '12_seoc_admin_multichannel_dispatch.png') });

  // 5. Admin Tactical Radar / Map
  console.log('Capturing 13_seoc_admin_tactical_radar.png...');
  try {
    await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a, button'));
      const radarLink = links.find(l => l.textContent.includes('Tactical Radar') || l.textContent.includes('Radar'));
      if (radarLink) radarLink.click();
    });
    await new Promise(r => setTimeout(r, 2500));
  } catch (e) {
    console.log('Radar navigation notice:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '13_seoc_admin_tactical_radar.png') });

  // 6. Admin Rescue Teams Readiness
  console.log('Capturing 14_seoc_admin_rescue_teams.png...');
  try {
    await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a, button'));
      const teamsLink = links.find(l => l.textContent.includes('Rescue Teams') || l.textContent.includes('Teams'));
      if (teamsLink) teamsLink.click();
    });
    await new Promise(r => setTimeout(r, 2500));
  } catch (e) {
    console.log('Teams navigation notice:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '14_seoc_admin_rescue_teams.png') });

  // 7. Admin Relief Camps & Shelters
  console.log('Capturing 15_seoc_admin_relief_camps.png...');
  try {
    await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a, button'));
      const campsLink = links.find(l => l.textContent.includes('Relief Camps') || l.textContent.includes('Camps') || l.textContent.includes('Shelters'));
      if (campsLink) campsLink.click();
    });
    await new Promise(r => setTimeout(r, 2500));
  } catch (e) {
    console.log('Camps navigation notice:', e.message);
  }
  await page.screenshot({ path: path.join(OUT_DIR, '15_seoc_admin_relief_camps.png') });

  await browser.close();
  console.log('Deep view capture suite completed successfully!');
}

captureDeepViews().catch(err => {
  console.error('Fatal deep capture error:', err);
  process.exit(1);
});
