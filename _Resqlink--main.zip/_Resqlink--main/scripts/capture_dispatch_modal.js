const puppeteer = require('puppeteer-core');
const path = require('path');

const OUT_DIR = path.resolve(__dirname, '..', 'screenshots');
const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const ADMIN_URL = 'https://resqlink-admin-command.vercel.app';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: EDGE_PATH,
    args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars', '--window-size=1920,1080'],
    headless: 'new'
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 2 });

  await page.goto(`${ADMIN_URL}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise(r => setTimeout(r, 1500));

  // Enter clearance code
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const quickBtn = btns.find(b => b.textContent.includes('SEOC-KERALA-2026-HQ'));
    if (quickBtn) quickBtn.click();
    const verifyBtn = btns.find(b => b.textContent.includes('VERIFY ADMIN'));
    if (verifyBtn) verifyBtn.click();
  });
  await new Promise(r => setTimeout(r, 1500));

  // Authorize clearance
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const authBtn = btns.find(b => b.textContent.includes('Authorize Command Clearance') || b.textContent.includes('Authorize'));
    if (authBtn) authBtn.click();
  });
  await new Promise(r => setTimeout(r, 2000));

  // Click "Dispatch Directive (SMS/Call/Gmail)"
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const dispatchBtn = btns.find(b => b.textContent.includes('Dispatch Directive'));
    if (dispatchBtn) dispatchBtn.click();
  });
  await new Promise(r => setTimeout(r, 2000));

  await page.screenshot({ path: path.join(OUT_DIR, '12b_seoc_admin_dispatch_modal.png') });
  console.log('12b_seoc_admin_dispatch_modal.png saved successfully!');
  await browser.close();
})();
