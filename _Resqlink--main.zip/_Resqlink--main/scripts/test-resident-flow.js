async function runTest() {
  const base = 'http://localhost:3000';

  console.log('--- 1. Testing Phone Quick Enrollment ---');
  const enrollRes = await fetch(`${base}/api/resident/quick-enroll`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: '+919847555123',
      latitude: 11.5545,
      longitude: 76.1285,
      accuracy: 4.2
    })
  });
  const enrollData = await enrollRes.json();
  console.log('Enroll Status:', enrollRes.status);
  console.log('Enrolled User:', enrollData.user.name, enrollData.user.phone);
  console.log('Auto-detected Sector:', enrollData.user.gramaPanchayat, '|', enrollData.user.blockPanchayat, '|', enrollData.user.district);
  console.log('Designated Shelter:', enrollData.user.reliefCamp);

  console.log('\n--- 2. Testing 1-Tap SOS Broadcast ---');
  const sosRes = await fetch(`${base}/api/resident/sos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: '+919847555123',
      category: 'FLOOD',
      description: 'Water rising in front yard, need emergency rescue assistance',
      peopleCount: 3,
      immediateDanger: true,
      latitude: 11.5545,
      longitude: 76.1285
    })
  });
  const sosData = await sosRes.json();
  console.log('SOS Status:', sosRes.status);
  console.log('SOS Tracking #:', sosData.trackingNumber, '| Priority:', sosData.priorityCategory, '| Score:', sosData.priorityScore);

  console.log('\n--- 3. Testing Register an Issue ---');
  const issueRes = await fetch(`${base}/api/resident/requests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: '+919847555123',
      category: 'MEDICAL',
      description: 'Elderly citizen requires urgent oxygen cylinder & transport',
      peopleCount: 1,
      hasInjuries: false,
      latitude: 11.5545,
      longitude: 76.1285
    })
  });
  const issueData = await issueRes.json();
  console.log('Issue Status:', issueRes.status);
  console.log('Issue Tracking #:', issueData.trackingNumber, '| Category:', issueData.ticket.category);

  console.log('\n--- 4. Testing Resident Alerts & SMS Ingestion Feed ---');
  const alertsRes = await fetch(`${base}/api/resident/alerts?phone=%2B919847555123`);
  const alertsData = await alertsRes.json();
  console.log('Alerts Status:', alertsRes.status);
  console.log('Active Alerts for sector:', alertsData.alerts ? alertsData.alerts.length : 0);
  console.log('Incoming Handset SMS:', alertsData.incomingSms ? {
    id: alertsData.incomingSms.id,
    recipientPhone: alertsData.incomingSms.recipientPhone,
    messageBody: alertsData.incomingSms.messageBody?.substring(0, 80) + '...',
    status: alertsData.incomingSms.status
  } : 'None');

  console.log('\n--- 5. Testing Handset SMS Safety Confirmation ---');
  if (alertsData.incomingSms) {
    const ackRes = await fetch(`${base}/api/notifications/ack`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        attemptId: alertsData.incomingSms.id,
        recipientPhone: '+919847555123',
        ackMethod: 'SMARTPHONE_TAP_CONFIRM'
      })
    });
    const ackData = await ackRes.json();
    console.log('ACK Response:', ackRes.status, ackData);
  }

  console.log('\n✓ ALL RESIDENT PLATFORM FLOWS TESTED SUCCESSFULLY');
}

runTest().catch(console.error);
