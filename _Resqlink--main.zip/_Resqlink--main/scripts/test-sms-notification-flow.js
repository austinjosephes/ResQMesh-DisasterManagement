/**
 * End-to-End Verification Test Script
 * Verifies SMS text notification delivery to respective phone number and two-way verification handshake.
 */

async function runTest() {
  const testPhone = '+919745123456';
  const cleanPhone = '9745123456';

  console.log('--- STEP 1: Resident Enrolls Phone Number & Registers Emergency SOS ---');
  const enrollRes = await fetch('http://localhost:3000/api/resident/quick-enroll', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: testPhone,
      latitude: 11.5545,
      longitude: 76.1285,
      accuracy: 4.5,
    }),
  });
  const enrollData = await enrollRes.json();
  console.log('Enroll result:', enrollRes.status, enrollData.success ? 'ENROLLED' : enrollData);

  const sosRes = await fetch('http://localhost:3000/api/resident/sos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: testPhone,
      category: 'TRAPPED',
      description: 'Flood water reached first floor. 4 members awaiting rescue at Meppadi.',
      peopleCount: 4,
      hasInjuries: false,
      immediateDanger: true,
      latitude: 11.5545,
      longitude: 76.1285,
      district: 'Wayanad',
    }),
  });
  const sosData = await sosRes.json();
  console.log('SOS registered:', sosData.trackingNumber, 'Priority:', sosData.priorityScore);

  console.log('\n--- STEP 2: Admin Dashboard Fetches Incoming Requests Queue ---');
  const overviewRes = await fetch('http://localhost:3000/api/admin/overview');
  const overviewData = await overviewRes.json();
  const foundRequest = overviewData.liveResidentRequests.find(
    (r) => r.trackingNumber === sosData.trackingNumber || r.phone === testPhone
  );
  console.log('Admin detected incoming request:', foundRequest ? `FOUND (${foundRequest.trackingNumber})` : 'NOT FOUND');
  console.log('Phone registered in Admin queue:', foundRequest?.phone);

  console.log('\n--- STEP 3: Admin Sends SMS Text Message to Respective Phone Number ---');
  const smsMessageText = 'NDRF Team Alpha mobilized with rescue boat. ETA 8 minutes. Signal with mobile torch.';
  const sendSmsRes = await fetch('http://localhost:3000/api/admin/direct-sms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      recipientPhone: testPhone,
      messageBody: smsMessageText,
      trackingNumber: sosData.trackingNumber,
      category: 'DIRECTIVE',
    }),
  });
  const sendSmsData = await sendSmsRes.json();
  console.log('SMS Dispatch status:', sendSmsRes.status, sendSmsData.message);
  console.log('SMS Recipient Phone:', sendSmsData.attempt?.recipientPhone);

  console.log('\n--- STEP 4: Resident Safety Portal Receives SMS Text Message for Respective Phone Number ---');
  const alertRes = await fetch(`http://localhost:3000/api/resident/alerts?phone=${encodeURIComponent(testPhone)}`);
  const alertData = await alertRes.json();
  console.log('Resident incoming SMS text:', alertData.incomingSms?.messageBody);
  console.log('Target recipient matched:', alertData.incomingSms?.recipientPhone === testPhone);
  console.log('Delivery status before ACK:', alertData.incomingSms?.status);

  console.log('\n--- STEP 5: Resident Acknowledges Receipt on Mobile Handset ---');
  const ackRes = await fetch('http://localhost:3000/api/resident/requests/ack', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      requestId: foundRequest.id,
      trackingNumber: sosData.trackingNumber,
      phone: testPhone,
    }),
  });
  const ackData = await ackRes.json();
  console.log('User Handshake ACK result:', ackData.verified ? 'VERIFIED' : 'FAILED', ackData.acknowledgedAt);

  console.log('\n--- STEP 6: Admin Dashboard Verifies Resident Has Received the Message ---');
  const finalOverviewRes = await fetch('http://localhost:3000/api/admin/overview');
  const finalOverviewData = await finalOverviewRes.json();
  const verifiedRequest = finalOverviewData.liveResidentRequests.find(
    (r) => r.trackingNumber === sosData.trackingNumber
  );
  console.log('Admin Dashboard Delivery Handshake Confirmed:', Boolean(verifiedRequest?.userMessageAckAt));
  console.log('Delivery ACK Timestamp:', verifiedRequest?.userMessageAckAt);

  if (verifiedRequest?.userMessageAckAt) {
    console.log('\n>>> SUCCESS: ALL TWO-WAY SMS AND VERIFICATION REQUIREMENTS FULLY CONFIRMED! <<<');
  } else {
    console.error('\n>>> ERROR: ACK was not reflected on admin dashboard <<<');
  }
}

runTest().catch(console.error);
