async function testTwoWayFlow() {
  const base = 'http://localhost:3000';
  const testPhone = '+919847999888';

  console.log('================================================================');
  console.log('1. RESIDENT REGISTERS ISSUE WITH PHONE NUMBER & AUTO-LOCATION');
  console.log('================================================================');
  const reqRes = await fetch(`${base}/api/resident/requests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      phone: testPhone,
      category: 'TRAPPED',
      description: 'Family of 4 trapped on terrace due to flash flood surge in Chooralmala. Need rescue boat.',
      peopleCount: 4,
      immediateDanger: true,
      latitude: 11.5404,
      longitude: 75.9870 // Meppadi / Chooralmala coordinates
    })
  });
  const reqData = await reqRes.json();
  console.log('Status:', reqRes.status);
  console.log('Tracking Number:', reqData.trackingNumber);
  console.log('Category:', reqData.ticket.category);
  console.log('Auto-detected Sector:', reqData.ticket.gramaPanchayat, '|', reqData.ticket.district);
  console.log('Priority Score:', reqData.ticket.priorityScore, `(${reqData.priorityCategory})`);
  const trackingNumber = reqData.trackingNumber;

  console.log('\n================================================================');
  console.log('2. ADMIN DASHBOARD RECEIVES & NOTIFIES INCOMING CITIZEN REQUEST');
  console.log('================================================================');
  const adminOverviewRes = await fetch(`${base}/api/admin/overview`);
  const adminData = await adminOverviewRes.json();
  console.log('Admin Dashboard Status:', adminOverviewRes.status);
  console.log('Pending Requests Count:', adminData.metrics.pendingRequestsCount);
  const foundRequest = adminData.liveResidentRequests.find(r => r.trackingNumber === trackingNumber);
  if (!foundRequest) {
    throw new Error(`Request ${trackingNumber} not found on Admin Dashboard!`);
  }
  console.log('✓ Found on Admin Dashboard:');
  console.log('  - Phone:', foundRequest.phone);
  console.log('  - Location:', foundRequest.gramaPanchayat, foundRequest.district);
  console.log('  - Status:', foundRequest.status);
  console.log('  - Admin Message Sent:', foundRequest.adminMessage || 'None (Pending action)');
  console.log('  - User ACK Status:', foundRequest.userMessageAckAt ? 'ACKNOWLEDGED' : 'AWAITING_ACTION');

  console.log('\n================================================================');
  console.log('3. ADMIN COMMAND EXECUTES FURTHER OPERATIONAL DEVELOPMENTS');
  console.log('================================================================');
  const developmentRes = await fetch(`${base}/api/admin/incidents/developments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      trackingNumber,
      status: 'EN_ROUTE',
      assignedTeamName: 'NDRF 04 Battalion Alpha Team',
      assignedReliefCamp: 'Govt Higher Secondary School Meppadi / Chooralmala St. Joseph Hall',
      etaMinutes: 10,
      adminMessage: 'NDRF Rescue Boat Unit 02 has been dispatched to your GPS coordinates. ETA ~10 minutes. Move to highest ground or roof with a flashlight.',
      responderNotes: 'Dispatched 4-person inflatable motor raft team from Kalpetta station.'
    })
  });
  const devData = await developmentRes.json();
  console.log('Development Execution Status:', developmentRes.status);
  console.log('Updated Status:', devData.incident.status);
  console.log('Assigned Team:', devData.incident.assignedTeamName);
  console.log('ETA:', devData.incident.etaMinutes, 'mins');
  console.log('Admin Directive Message:', devData.incident.adminMessage);

  console.log('\n================================================================');
  console.log('4. USER PORTAL RECEIVES ADMIN DIRECTIVE & OPERATIONAL STATUS');
  console.log('================================================================');
  const userCheckRes = await fetch(`${base}/api/resident/requests?phone=${encodeURIComponent(testPhone)}`);
  const userCheckData = await userCheckRes.json();
  const userReq = userCheckData.requests.find(r => r.trackingNumber === trackingNumber);
  console.log('User Portal Status:', userCheckRes.status);
  console.log('✓ Directive Displayed on User Portal:');
  console.log('  - Directive Body:', userReq.adminMessage);
  console.log('  - Assigned Team:', userReq.assignedTeamName);
  console.log('  - Live ETA:', userReq.etaMinutes, 'mins');
  console.log('  - Emergency Shelter:', userReq.assignedReliefCamp);
  console.log('  - User Confirmed Receipt yet?:', userReq.userMessageAckAt ? 'YES' : 'NO (Awaiting Confirmation)');

  console.log('\n================================================================');
  console.log('5. USER CONFIRMS & VERIFIES RECEIPT OF ADMIN DIRECTIVE MESSAGE');
  console.log('================================================================');
  const ackRes = await fetch(`${base}/api/resident/requests/ack`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      trackingNumber,
      phone: testPhone
    })
  });
  const ackData = await ackRes.json();
  console.log('User Handset ACK Status:', ackRes.status);
  console.log('Verified:', ackData.verified);
  console.log('Handset ACK Timestamp:', ackData.acknowledgedAt);

  console.log('\n================================================================');
  console.log('6. ADMIN DASHBOARD VERIFIES USER HAS RECEIVED THE MESSAGE');
  console.log('================================================================');
  const adminVerifyRes = await fetch(`${base}/api/admin/overview`);
  const adminVerifyData = await adminVerifyRes.json();
  const verifiedRequest = adminVerifyData.liveResidentRequests.find(r => r.trackingNumber === trackingNumber);
  console.log('✓ Admin Dashboard Verification:');
  console.log('  - Tracking Number:', verifiedRequest.trackingNumber);
  console.log('  - Status:', verifiedRequest.status);
  console.log('  - User ACK Timestamp:', verifiedRequest.userMessageAckAt);
  console.log('  - Delivery Confirmed:', Boolean(verifiedRequest.userMessageAckAt));

  console.log('\n================================================================');
  console.log('✓ FULL TWO-WAY DISASTER DEVELOPMENT & VERIFICATION CONFIRMED!');
  console.log('================================================================');
}

testTwoWayFlow().catch(console.error);
